const text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log bound");
ck(q(48,100).lt(q(54,100).mul(o.sub(q(46,100).sq().div(two)))),"vertical real fraction");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(o.sub(q(46,100).sq().div(two))).mul(pu.div(q(16))))),"splice angle fraction");
const lo=x=>eb(x)[0],K0=q(14),D=q(223),n=q(224),sk0=q(374,100),sd=q(149,10),u=q(3,5),reach=q(66,100),wide=q(67,100),pk=q(49,100),C=q(27,8),v=D.div(n);

ck(q(14).mul(ex(q(1,6*223))).lt(pk.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(13))),"binomial peak");
const phi=x=>x.sq().div(two).sub(x.sq().mul(x).div(q(3)));
const F=q(3,4), G0=q(7,10);
for(const [r,w,a] of [[reach,q(166,100),F],[wide,q(164,100),G0]]){
 ck(w.sq().mul(r.sq()).mul(q(15,16)).lt(q(15,14).sq()),"good-label mean");
 ck(pk.div(sk0.mul(o.sub(o.div(w)))).mul(em(q(13).mul(phi(w.sub(o))))).lt(o.sub(a)),"good-label tail");
}
const e=q(278,1000),l=q(49,100),a=q(128,1000);
ck(o.div(e).lt(lo(q(25,9).mul(q(1,2).sub(q(1,27)))))&&q(6,5).div(F).mul(e).lt(l),"high ratios");
ck(q(250).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12)))))&&q(3,2).div(F).div(q(250)).lt(l),"small ratios");
ck(C.mul(q(11,10)).div(l).lt(lo(v.mul(sd).mul(o.div(u).sub(o.div(reach))))),"outward exit");
ck(o.div(F.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(u.sq()))),"curvature bound");
function witness(e,m){const z=o.sub(e.sq());return two.div(F).mul(e.div(z).add(e.mul(o.add(e.sq())).div(q(m).mul(z.sq())))).lt(o);}
ck(witness(e,6)&&q(1000,22).lt(lo(D.div(q(25)).mul(q(1,2).sub(q(1,15)))))&&witness(q(22,1000),1),"opposing witnesses");
const cap=q(375,100), d=q(645,1000),b=q(168,10000),xn=q(1327,1000),xn2=q(153,100),dm=q(16,100);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(u.div(sd).add(pk.div(sk0))).lt(d)&&cap.div(n).lt(b),"generic drift");
ck(xn.lt(q(4,3).mul(v))&&q(11,2).lt(q(327,1000).mul(K0).add(o)),"heavy drift spacing");
ck(C.div(v).mul(xn).mul(pk).div(sk0).mul(em(q(13).mul(phi(q(327,1000))))).div(o.sub(em(q(11,2)))).lt(q(40,100)),"heavy drift");
ck(xn2.sq().mul(wide.sq()).mul(q(15,16)).lt(v.sq())&&q(48,10).lt(q(53,100).mul(q(14)).add(o))&&o.lt(wide.sub(u).mul(sd)),"near drift window");
ck(o.div(G0.mul(v)).mul(xn2).mul(pk).div(sk0).mul(em(q(13).mul(phi(q(53,100))))).div(o.sub(em(q(48,10)))).lt(dm),"near drift");
const z=o.sub(l.sq()),tail=d.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l.sq()).div(z.sq()));
ck(two.mul(a).add(dm).add(a.mul(l).mul(dm).div(z)).add(a.mul(dm)).add(a.mul(l.sq()).mul(tail)).lt(o.sub(a)),"signed mean margin");
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sd)))).lt(q(313,100))&&u.div(sd).lt(q(1,16))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sd)).lt(q(1,16)),"floor splice");

console.log('PASS: upper_edge');
