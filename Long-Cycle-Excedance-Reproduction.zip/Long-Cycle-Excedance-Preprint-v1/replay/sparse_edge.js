const text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(17)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}



const pl=q(157,50),pu=q(22,7),lo=x=>eb(x)[0],sk=q(374,100),K=q(14),pk=q(60,100),M=q(3);
ck(sk.sq().lt(K),"sqrt"); 
ck(K.mul(ex(q(1,6*28))).lt(pk.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(13))),"Robbins peak");
for(const [D,H,H4,LR,RL,pw,aL,aR,d,j,r,b] of [
 [28,q(18,7),q(9,14),q(212,1000),q(281,1000),q(468,1000),q(7,1000),q(215,1000),q(414,1000),q(126,1000),q(679,1000),q(89,1000)],
 [36,q(3),q(3,4),q(136,1000),q(195,1000),q(616,1000),q(2,1000),q(102,1000),q(482,1000),q(61,1000),q(726,1000),q(82,1000)]
]){
 const Dq=q(D),N=q(D+1),dz=o.sub(H4),lx=q(1,3);
 const L3=lx.sq().div(two).sub(lx.sq().mul(lx).div(q(3))).add(lx.sq().sq().div(q(4))).sub(lx.sq().sq().mul(lx).div(q(5)));
 const p4=pk.div(sk).div(dz).mul(em(K.mul(dz.sq().div(two).add(dz.sq().mul(dz).div(q(3))))));
 ck(q(3,8).add(q(5,8).mul(p4)).lt(pw),"r4 upper");
 ck(o.div(LR).lt(lo(Dq.div(q(18))))&&o.div(RL).lt(lo(Dq.mul(L3))),"first pure at 3");
 const el=q(D===28?98:51,1000);ck(o.div(el).lt(lo(Dq.div(q(12)))),"pure at ≤2");
 ck(H.sq().div(aL.mul(o.sub(aL))).lt(lo(Dq.div(q(4))))&&q(8).mul(pw).div(aR.mul(o.sub(aR))).lt(lo(Dq.div(q(9)))),"curvature deductions");
 const opp=em(q(9*D,36)), zz=o.sub(RL.sq());
 ck(two.mul(LR).add(q(4).mul(pw).mul(RL)).add(two.mul(H).mul(opp).div(zz)).lt(o),"m3 witness");
 ck(two.mul(H).mul(el).div(o.sub(el.sq())).lt(o),"m≤2 witness");
 ck(H.div(j).lt(lo(q(39*D,360)))&&H.div(j).lt(lo(q(D,6))),"later ratios");
 ck(H.mul(pk.div(sk)).lt(d)&&H.mul(q(3).div(N).add(pk.div(sk))).lt(r)&&H.div(N).lt(b),"drift");
 const zz2=o.sub(j.sq()),tail=r.add(q(3).mul(b)).div(zz2).add(two.mul(b).mul(j.sq()).div(zz2.sq()));
 let vl=aL.add(d).add(aL.mul(j).mul(d).div(zz2)).div(o.sub(aL));
 let vr=aR.add(aR.mul(r.add(b))).add(aR.mul(j.sq()).mul(tail)).div(o.sub(aR));
 ck(vl.add(vr).lt(o),"two-alpha sign");
}
ck(q(3,28).lt(q(1,8))&&q(10,3).mul(q(29)).mul(q(3,28).sq()).mul(q(3,28)).lt(q(1,8)),"phase");

console.log('PASS: sparse_edge');
