const text = console.log;

const gcd=(a,b)=>{while(b){[a,b]=[b,a%b]}return a<0n?-a:a;};
let bin=(n,r)=>{let x=1n;for(let i=1;i<=r;i++)x=x*BigInt(n-i+1)/BigInt(i);return x};
const A=[[1n]];for(let n=1;n<=31;n++){A[n]=Array.from({length:n},(_,j)=>BigInt(j+1)*(A[n-1][j]??0n)+BigInt(n-j)*(A[n-1][j-1]??0n));}
function E(n,k){let f=A[n-1].slice();if(n<2*k)return f;for(let m=k;m<=n-k;m++)for(let i=0;i<A[m-1].length;i++)for(let j=0;j<A[n-m-1].length;j++){
 let v=bin(n,m)*A[m-1][i]*A[n-m-1][j];if(m===n-m){if(v%2n)throw Error("parity");v/=2n;}
 if(m<=n-m)f[i+j+1]+=v;
 }return f;}
function rem(f,g){let v=f.slice(),lc=g.at(-1);if(lc<=0n)throw Error("negative divisor");while(v.length>=g.length){let a=v.at(-1),d=v.length-g.length;v=v.map(x=>x*lc);for(let j=0;j<g.length;j++)v[j+d]-=a*g[j];while(v.at(-1)===0n)v.pop();let z=v.reduce(gcd,0n);if(z>1n)v=v.map(x=>x/z);}return v.map(x=>-x);}
for(let k of [14,15])for(let n of [2*k-1,2*k]){
 let f=E(n+1,k),g=E(n,k),ds=[f.length-1,g.length-1];
 while(g.length>1){let h=rem(f,g);if(h.length!==g.length-1||h.at(-1)<=0n)throw Error("non-Sturm");ds.push(h.length-1);[f,g]=[g,h];}
 if(g[0]<=0n||ds.at(-1)!==0)throw Error("constant");text([k,n,ds]);}

console.log('PASS: onset');
