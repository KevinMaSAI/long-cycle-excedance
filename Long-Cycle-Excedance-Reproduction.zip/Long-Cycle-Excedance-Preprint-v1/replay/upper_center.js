const text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log bound");
ck(q(48,100).lt(q(54,100).mul(o.sub(q(46,100).sq().div(two)))),"vertical real fraction");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(o.sub(q(46,100).sq().div(two))).mul(pu.div(q(16))))),"splice angle fraction");
const rows=[[14,16,40,550,5,16,1],[14,16,50,550,5,16,4],[14,16,60,600,5,16,5],[14,16,70,600,5,16,6],[14,16,87,450,4,22,0],[14,22,100,350,5,30,0],[14,30,116,350,5,41,0],[14,41,134,350,7,56,0],[14,56,154,350,7,76,0],[14,76,178,250,7,103,0],[14,103,187,350,7,114,0]];
const covered={14:16};
for(const [K,B,a2,at,L,N,core] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(374,100);
 ck(!q(K).lt(sk.sq())&&(core||B<=covered[K])&&B>L&&(core||N>covered[K]),"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(74,1000).mul(ex(alpha.mul(q(3)))).add(q(38,10000).mul(ex(alpha.mul(q(4)))).div(o.sub(ea.div(q(4)))))).div(two));
 const eps=up(ex(q(780,1000).mul(p)).sub(o).mul(q(394,10000)).div(fact(L)).add(em(alpha.mul(q(Math.round(4*(B-L)),4))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(394,10000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(q(1725,1000).mul(em(alpha.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(q(725,1000).sub(delta).mul(em(alpha.mul(q(Math.round(4*(B-L)),4)))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(394,10000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 let ref=two.sub(ex(q(780,1000).mul(p))), angular=q(0);
 if(core!==1){
  const ell=q(core||7),s=sk.mul(ell);
  const fd=z=>{let t=o,u=o;for(let j=1;j<=14;j++){t=t.mul(z).div(q(j));u=u.add(t);}return em(z).mul(u);};
  const J=ex(q(5).div(ell.sq())).mul(fd(s).add(fd(s.mul(two)).div(two.mul(o.sub(em(s.sub(q(7))))))));
  const z=J.add(pu.div(s)),c0=o.sub(z.sq().div(two)),ph=pu.div(q(16));
  ck(q(0).lt(c0),"gamma angle");
  const a0=q(5,3).mul(dn(o.div(ex(J)))).div(pu.mul(R));
  ref=a0.mul(c0);angular=a0.mul(c0.mul(o.sub(ph.sq().div(two))).sub(z.mul(ph)));
 }
 const c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 if(core===0||core===6)ck(V.lt(angular.sub(eps)),"splice phase");
 const rad=a.sub(q(313,100).div(sk));
 if(!core)ck(q(0).lt(rad)&&q(Math.round(4*N)*25,36).lt(rad.sq()),"splice location");
 if(!core)covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
ck(covered[14]>112,"eventual overlap");
text(covered);


console.log('PASS: upper_center');
