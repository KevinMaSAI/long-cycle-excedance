globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[96,900,103,25,18,1471],[96,1471,121,20,18,2042],[96,2042,135,15,18,2543],[96,2543,145,12,18,2934],[96,2934,152,10,18,3225],[96,3225,156,10,18,3396],[128,900,108,25,18,1621],[128,1621,131,15,18,2392],[128,2392,148,12,18,3063],[128,3063,160,10,18,3584],[128,3584,168,8,18,3945],[128,3945,174,8,18,4236],[128,4236,177,8,18,4387],[128,4387,179,8,18,4488],[128,4488,181,8,18,4589],[160,900,111,25,18,1721],[160,1721,137,15,18,2622],[160,2622,157,10,18,3453],[160,3453,172,8,18,4144],[160,4144,182,8,18,4635],[160,4635,188,8,18,4946],[160,4946,192,6,18,5167],[160,5167,194,6,18,5268],[160,5268,196,6,18,5379],[160,5379,197,6,18,5440],[192,900,113,25,18,1781],[192,1781,142,15,18,2822],[192,2822,165,10,18,3813],[192,3813,181,8,18,4584],[192,4584,192,8,18,5165],[192,5165,199,6,18,5546],[192,5546,204,6,18,5827]];
const covered={96:900,128:900,160:900,192:900};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(9,5).div(sk));
 ck(q(0).lt(rad)&&q(16*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const elo=y=>eb(y)[0];
ck(q(380).lt(elo(q(6)))&&q(508).lt(elo(q(63,10))),"eventual logs");
ck(covered[160]>=5400 && covered[192]>=5670,"eventual overlap");
const t=q(3,4), F=q(999,1000),loEta=q(1,1000), hiEta=q(413,1000),n0=q(86400),D0=q(86399);
const a0=q(22,100), l0=q(45,100), rr=q(27,4), dd=q(34,100), gg=q(79,1000000);
ck(q(16,25).mul(q(256,900)).lt(q(1,4)),"heavy occupancy");
ck(q(1000).lt(elo(q(3,10).mul(q(96)))),"occupancy threshold");
ck(o.div(hiEta).lt(elo(o.div(t.sq()).mul(q(1,2).sub(q(1,660))))),"high pure ratio");
ck(q(1000).lt(elo(D0.div(q(2*16*17)))),"low pure ratio");
ck(q(81,16).div(l0).lt(elo(D0.div(n0).mul(q(293)).mul(q(1,12)))),"far right loss");
ck(hiEta.mul(q(17,16)).div(F).lt(l0),"local right ratio");
ck(o.div(F.sq().mul(a0).mul(o.sub(a0))).lt(elo(o.div(t.sq()))),"curvature");
const pow=(x,i)=>{let p=o;while(i--)p=p.mul(x);return p};
const zz=o.sub(hiEta.sq()),za=o.sub(hiEta);
const remainder=pow(hiEta,16).mul(two.div(za).add(hiEta.div(q(16).mul(za.sq()))));
ck(two.mul(hiEta).div(zz).add(remainder).div(F).lt(o),"high witness with paired envelope");
const zlo=o.sub(loEta.sq());
ck(two.mul(loEta).mul(o.div(zlo).add(o.add(loEta.sq()).div(zlo.sq()))).div(F).lt(o),"low witness");
ck(q(100).lt(elo(q(5))),"Fourier far peak");
ck(o.lt(q(4).mul(q(43,100).sq()).mul(pl).mul(q(11,24)).mul(q(99,100)).mul(q(95,96))),"Fourier Gaussian peak");
ck(q(800).lt(elo(q(40))),"Fourier remainder less than .02/sqrt(k)");
ck(rr.mul(t.div(q(293)).add(q(45,100).div(q(97,10)))).lt(dd)&&rr.div(n0).lt(gg),"right drift");
ck(q(7000).lt(elo(q(2995,10000).mul(q(96)))),"small-index drift");
const z=o.sub(l0.sq());
ck(two.mul(a0).add(q(1,1000)).add(a0.mul(l0).div(q(1000).mul(z))).add(a0.mul(dd.div(z).add(gg.mul(o.add(l0.sq())).div(z.sq())))).lt(o.sub(a0)),"signed mean");
ck(o.div(t.sq()).div(o.sub(o.div(t.mul(q(293))))).lt(q(9,5)),"floor correction");
ck(t.add(q(10,3).mul(t.sq()).mul(t).mul(n0.div(D0))).div(q(293)).lt(q(1,40)),"phase correction");

console.log("PASS: long_cycles_dense_edge_k96-01");
