globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),nn=q(720),DD=q(719),sD=q(268,10),sk=q(244,100),A=q(39,50),Drel=q(719,720),C=q(27,8);
const lo=x=>eb(x)[0],geom=(f,r)=>f.div(o.sub(r));
ck(sD.sq().lt(DD)&&sk.sq().lt(q(6))&&q(20).lt(A.mul(sD)),"scale");
ck(ex(q(2)).lt(q(74,10))&&two.mul(pu).sq().mul(q(394,10)).lt(q(40).sq()),"Fourier L2 bound");
ck(q(6,5).mul(pu).lt(q(4))&&q(10000).lt(lo(q(10))),"contour elementary");
const floor=o.div(A.sq()).div(o.sub(o.div(A.mul(sD))));
ck(floor.lt(q(174,100)),"floor correction");
const rho2=o.div(A).add(q(174,100).div(sD)).sq().add(q(10,720));
ck(rho2.lt(q(184,100)),"rho^2");
ck(q(300).div(pl).mul(q(184,100)).mul(ex(q(4))).lt(q(10000))&&q(150).mul(ex(q(4))).lt(q(10000)),"contour units");
ck(q(10000*10*1320*1000).lt(lo(q(34))),"contour attenuation");
const rate=two.mul(pl.sq()).div(q(6,5).sq());
ck(q(47).lt(rate.mul(q(720,206))),"small radial");
const odd=(x)=>q(3).div(o.sub(x)).add(two.mul(x).div(o.sub(x).sq()));
ck(em(q(14)).mul(odd(em(q(94)))).lt(q(1,1000)),"small far poles");
ck(q(6,5).sq().mul(o.add(q(10,196))).lt(q(124,100).sq()),"pole / s");
function Gbound(s){
 const s0=q(s),rt=em(q(38,100).mul(s0)),qq=em(s0);
 return q(1024).mul(geom(rt,rt)).add(o.add(q(124,100).mul(s0)).mul(geom(qq,qq)));
}
ck(Gbound(14).lt(q(51,10))&&Gbound(34).lt(q(3,1000)),"large pole size");
ck(q(34).lt(sD.div(A))&&pu.mul(em(q(34))).lt(q(1,1000)),"large splice s");
ck(q(74,10).lt(rate.div(q(184,100))),"large radial");
ck(em(q(46,10)).mul(odd(em(q(148,10)))).lt(q(31,1000)),"large far poles");
const phase=two.mul(A).div(sD),phase2=q(721,719).mul(q(10,3)).mul(A.sq()).mul(A).div(sD);
ck(phase.add(q(4,1000).div(pl)).lt(q(1,12))&&phase2.add(q(4,1000).div(pl)).lt(q(1,12)),"splice phase");

const reach=q(9,10),pk=q(46,100),near=q(4,1000),eta=q(453,1000),lambda=q(49,100),alpha=q(27,100),C2=q(47,10);
ck(reach.sq().mul(q(11,120)).lt(o.div(q(36,10).sq())),"dense mean");
ck(q(36,10).lt(lo(q(13,10)))&&q(1000).lt(lo(q(78,10))),"dense failure");
ck(q(36,10).sq().lt(Drel.sq().mul(q(120,11)).div(reach.sq())),"dense D/r");
ck(q(3).lt(reach.sub(A).mul(sD)),"first 3 dense offsets");
ck(q(99,100).lt(o.sub(q(1,120)))&&q(6).mul(ex(q(1,6*719))).lt(pk.sq().mul(two).mul(pl).mul(q(99,100)).mul(q(5))),"binomial peak");
const ge=(x,loss,step)=>C.div(Drel).mul(x).mul(pk.div(sk)).mul(geom(em(loss),em(step)));
ck(ge(q(36,10),q(65,10),q(16)).lt(near),"near drift");
ck(q(199,100).lt(lo(q(7,10)))&&ge(q(199,100),q(145,100),q(69,10)).lt(q(103,100)),"non-dense small-index drift");
ck(q(346,100).sq().lt(q(12))&&q(4).div(o.sub(o.div(two.mul(q(346,100))))).lt(C2),"cap 2k");
const d=q(103,100),b=q(66,10000);
ck(C2.mul(A.div(sD).add(pk.div(sk))).lt(d)&&C2.div(nn).lt(b),"all drifts");
const dense=q(999,1000);
ck(o.div(eta).lt(lo(q(1,2).sub(q(1,60)).div(A.sq())))&&q(14,13).div(dense).mul(eta).lt(lambda),"first ratio");
const lowEta=q(14,100);
ck(o.div(lowEta).lt(lo(q(719,364)))&&q(3,2).div(dense).mul(lowEta).lt(lambda),"small witnesses");
ck(o.div(dense.sq().mul(alpha).mul(o.sub(alpha))).lt(lo(o.div(A.sq()))),"curvature");
const beyond=Drel.mul(sD).mul(o.div(A).sub(o.div(reach)));
ck(q(81,16).div(lambda).lt(lo(beyond)),"outside dense");
const eta3=q(17,10000);
ck(o.div(eta3).lt(lo(q(9,2).div(A.sq()).mul(q(20,23)))),"third offset");
const u=o.sub(eta.sq()),v=o.sub(lowEta.sq());
const far=two.mul(eta3).div(dense).mul(o.add(q(3,13)).div(u).add(q(2,13).mul(eta.sq()).div(u.sq())));
ck(two.mul(eta).div(dense).add(far).lt(o),"high witness sign");
ck(two.div(dense).mul(lowEta.div(v).add(lowEta.mul(o.add(lowEta.sq())).div(v.sq()))).lt(o),"low witness sign");
const z=o.sub(lambda.sq());
const later=alpha.mul(lambda.sq().sq()).mul(d.add(q(5).mul(b)).div(z).add(two.mul(b).mul(lambda.sq()).div(z.sq())));
const cost=two.mul(alpha).add(near).add(alpha.mul(lambda).mul(near).div(z)).add(alpha.mul(near).div(z)).add(later);
ck(cost.lt(o.sub(alpha)),"signed margin");
text({rho2:rho2.val(),cost:cost.val(),G14:Gbound(14).val(),G34:Gbound(34).val()});
text("All exact eventual bounds passed.");

console.log("PASS: long_cycles_uniform_residue_k6-01");
