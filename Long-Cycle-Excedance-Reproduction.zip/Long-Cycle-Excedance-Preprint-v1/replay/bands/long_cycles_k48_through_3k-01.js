globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}

const lo=x=>eb(x)[0], pl=q(157,50),pu=q(22,7),k0=q(48),sk=q(69,10),xi=q(816,1000);
function center(a,rr,B){
 const b=q(4).mul(pl.sq()).div(a.sq().mul(k0).add(q(10)));
 ck(o.add(a.sq().mul(k0).div(pl.sq())).div(k0.sq()).lt(rr.sq())&&two.lt(b.mul(q(23*25**2-312))),"core lattice scale");
 function sc(m,w){let x=q(0);for(let l=1;l<=12;l++){const u=b.mul(q(l*(l+1))); x=x.add(q(w?2*l+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return x.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(w?1:27)))));}
 const f=sc(23,true),h=sc(23,false),g=sc(47,true),j=sc(47,false);
 const P=two.mul(ex(xi.mul(rr).mul(o.add(q(3,2).mul(h)))).sub(o));
 const Z=two.mul(ex(xi.mul(rr).mul(q(3,2).add(q(4,3).mul(h)))).sub(o));
 const V=P.add(Z.mul(h)).add(j),W=P.add(Z.mul(f)).add(g).add(o.add(j).mul(rr).div(B));
 ck(V.sq().add(W.sq()).lt(o)&&V.lt(q(3,4)),"central ellipse and slice");
 text({V:V.val(),W:W.val()});
}
center(q(414,100),q(192,1000),q(2));
function chkCur(C,s,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(s));}
function wit(C,e){return two.mul(C).mul(e).div(o.sub(e.sq())).lt(o);}
function margin(a,l,d,b,dL=d,al=a,ar=a){
 const zz=o.sub(l.sq());
 const left=al.add(d).add(al.mul(l).mul(dL).div(zz)).div(o.sub(al));
 const right=ar.add(ar.mul(d.div(zz).add(b.mul(o.add(l.sq())).div(zz.sq())))).div(o.sub(ar));
 return left.add(right).lt(o);
}
const C0=q(5,2),e0=q(19,100),l0=q(476,1000),a0=q(133,1000),pk0=q(58,100);
ck(o.div(e0).lt(lo(q(5,3)))&&C0.mul(e0).lt(l0)&&chkCur(C0,q(4),a0)&&wit(C0,e0),"first band");
ck(q(48).mul(ex(q(1,6*94))).lt(pk0.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(47))),"first peak");
const d0=q(34,100),b0=q(27,1000);
ck(C0.mul(q(1,2).div(q(969,100)).add(pk0.div(sk))).lt(d0)&&C0.div(q(95)).lt(b0)&&margin(a0,l0,d0,b0),"first drift and margin");
ck(q(5*99*99,2*16*100).lt(q(16))&&q(72,5).lt(q(16)),"first upper S");
const C=q(279,100),e=q(166,1000),l=q(464,1000),a=q(174,1000),pk=q(55,100);
ck(q(5,2).div(o.sub(o.div(q(978,100)))).lt(C),"cap");
ck(q(48).mul(ex(q(1,6*120))).lt(pk.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(47))),"second peak");
ck(o.div(e).lt(lo(q(2).sub(q(4,18)).add(q(1,36)).sub(q(4,1080))))&&C.mul(e).lt(l)&&q(3).div(l).lt(lo(q(120,50)))&&chkCur(C,q(4),a)&&wit(C,e),"high");
const d=q(351,1000),b1=q(24,1000),dl=q(364,1000);
ck(C.mul(q(1,2).div(q(1095,100)).add(pk.div(sk))).lt(d)&&q(3).mul(q(5,121).add(pk.div(sk))).lt(dl)&&C.div(q(121)).lt(b1)&&margin(a,l,d,b1,dl),"high drift");
const em1=q(136,1000),lm=q(41,100),am=q(82,1000),dm=q(39,100),bm=q(25,1000);
ck(o.div(em1).lt(lo(q(2)))&&q(3).mul(em1).lt(lm)&&chkCur(q(3),q(120,25),am)&&wit(q(3),em1),"m<=4 ratios");
ck(q(3).mul(q(6,121).add(pk.div(sk))).lt(dm)&&q(3).div(q(121)).lt(bm)&&margin(am,lm,dm,bm),"m<=4 drift");
ck(q(3).mul(e).lt(q(1,2))&&chkCur(q(3),q(144,25),q(30,1000))&&chkCur(C,q(4),a)&&margin(a,q(1,2),dm,bm,dm,q(30,1000),a),"m5 sign");
ck(q(1000,92).lt(lo(q(144,60)))&&wit(q(3),q(92,1000)),"m5 witness");
ck(q(3*143*143,25*144).lt(q(414,100).sq())&&q(49,3).lt(q(414,100).sq()),"second splice radius");
for(const [D,n,root] of [[94,95,q(969,100)],[120,121,q(1095,100)]]){
 ck(q(1,2).div(root).lt(q(1,8))&&q(10,24).mul(q(n,D)).div(root).lt(q(1,8)),"phase correction");
}

console.log("PASS: long_cycles_k48_through_3k-01");
