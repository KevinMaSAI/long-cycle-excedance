globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=48,sk=q(69,10),xi=q(816,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[3,468,60,2,4],[4,513,60,2,5],[5,553,60,2,6],[6,589,60,2,7]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(26,100).sq().div(two));
ck(pu.div(q(92)).mul(ex(q(5,16)).sq()).lt(q(26,100).sq()),"vertical log");
ck(q(71,100).lt(q(74,100).mul(ca)),"vertical positive");
ck(q(92,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(26,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=23;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(524,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(87,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(136,1000):L===3?q(37,1000):q(524,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(104,100):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const ps=em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 if(B<8 && L===2){
  const P=min(U0.mul(abs),U.mul(abs).add(E.mul(ps))), xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=U0.mul(ex(xc).sub(o).sub(xc)).add(q(119,1000).mul(x));
  W=up(high.mul(f).add(U.mul(x).mul(j).div(two)).add((B>=4?U:U0).mul(x).mul(ell).div(q(4))).add(g));
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }else{
  const eps=up(abs.mul(delta).add(ps));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(B-1)))).mul(f)).add(E.mul(em(al.mul(q(B-L))).mul(fl)));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));let at=o;for(let j=1;j<B;j++)at=up(at.mul(p.div(two)).div(q(j)));drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(at).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  let ref=max(q(71,60).div(a.div(sk).add(two)),o.sub(abs));
  if(p.lt(o))ref=max(ref,dn(o.sub(p.sq().div(two)).div(ex(p))));
  c=ref.sub(eps);slice=q(92,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const mr=Math.floor(Math.sqrt(N*K-1)/2);
 ck(4*mr*mr<=N*K-1 && N*K-1<4*(mr+1)*(mr+1),"cut index");
 const wcut=q(4*mr*mr-1,mr-1).div(sk), w1=q(4*(mr+1)*(mr+1)-1,mr).div(sk), vmax=q(4*N).mul(o.add(q(1,mr)).sq()),v2=q(4*N).mul(o.add(q(1,mr+1)).sq());
 ck(wcut.lt(a)&&(w1.lt(a)||vmax.lt(a.sq()))&&v2.lt(a.sq()),"floor splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0], capH=q(299,100),capK=q(321,100),cap2=q(432,100),nmin=q(144),D=q(143),sd=q(119,10);
ck(q(693,1000).lt(two.mul(q(1,3).add(q(1,81)).add(q(1,1215)).add(q(1,15309))))&&q(2).lt(lo(q(694,1000))),"log2 estimates");
ck(q(1000,575).lt(lo(q(575,1000).sub(q(1,48))))&&o.add(q(694,1000)).add(q(1,190)).lt(q(575,1000).mul(q(143,48))),"uniform count upper");
const cmin=q(555,1000);
ck(q(0).lt(q(1693,1000).sub(q(3).mul(cmin)).sub(q(9).mul(cmin.sub(q(1,2)).sq()))),"count quadratic lower");
ck(q(1693,1000).add(q(1,2)).add(q(47,36*48)).lt(q(4).mul(cmin))===false,"count sum lower");
ck(q(575,555).lt(q(104,100))&&o.div(cmin).lt(q(181,100))&&o.sub(q(500,555)).lt(q(136,1000))&&o.sub(q(555,575)).lt(q(37,1000))&&q(575,555).sub(o).lt(q(37,1000)),"relative counts");
ck(q(48).mul(ex(q(1,6*143))).lt(q(1,4).mul(two).mul(pl).mul(q(2,3)).mul(q(47))),"Stirling peak");
ck(q(11,4).sub(q(1,63)).div(o.sub(o.div(q(12)))).lt(capH)&&q(3).sub(q(2,63)).div(o.sub(o.div(q(138,10)))).lt(capK)&&q(4).div(o.sub(o.div(q(195,10)))).lt(cap2),"caps");
ck(q(2).add(q(7,8)).sub(q(1,63)).div(o.sub(o.div(q(129,10)))).lt(q(311,100))&&q(2).add(q(7,9)).sub(q(1,63)).div(o.sub(o.div(q(122,10)))).lt(q(302,100)),"small r caps");
ck(q(1,2).add(o.div(sd)).sq().mul(q(63)).div(q(3).sub(q(1,48))).lt(q(9)),"beta range");
function below(w){const u=o.sub(w);return em(q(47).mul(u.sq().div(two).add(u.sq().mul(u).div(q(3)))))}
function above(w){const u=w.sub(o);return em(q(47).mul(u.sq().div(two).sub(u.sq().mul(u).div(q(3)))))}
function tail(a,beta){return above(q(a).div(beta)).div(o.sub(em(q(47).mul(o.div(beta).sub(q(1,a))))))}
const bd=q(14,10);
ck(o.add(tail(2,q(13,10))).lt(bd),"beta band 1");
ck(below(q(10,13)).add(above(q(20,17))).add(tail(3,q(17,10))).lt(bd),"beta band 2");
ck(below(q(10,17)).add(o).add(tail(3,q(22,10))).lt(bd),"beta band 3");
ck(below(q(5,11)).add(o).add(tail(3,q(245,100))).lt(bd),"beta band 4");
ck(below(q(20,49)).add(below(q(40,49))).add(above(q(60,53))).add(tail(4,q(265,100))).lt(bd),"beta band 5");
ck(below(q(20,53)).add(below(q(40,53))).add(o).add(tail(4,q(3))).lt(bd),"beta band 6");
const eta=q(166,1000),lam=q(499,1000),eta2=q(77,1000), da=q(207,1000), al0=q(72,1000),ar0=q(234,1000);
ck(o.div(eta).lt(lo(q(2).sub(q(4,18)).add(q(1,36)).sub(q(4,1080))))&&o.div(eta).lt(lo(q(143,25).mul(q(1,2).sub(q(1,15)))))&&capH.mul(eta).lt(lam),"generic high pure");
ck(capK.div(lam).lt(lo(q(251,112)))&&cap2.div(lam).lt(lo(q(335,98))),"middle or low base");
for(const [r,c,f] of [[8,q(311,100),q(158,1000)],[9,q(302,100),q(156,1000)]]){
 const x=q(1,r), loss=two.sub(q(4,3).mul(x)).add(x.sq()).sub(q(4,5).mul(x.sq()).mul(x));
 ck(c.div(lam).lt(lo(loss))&&o.div(f).lt(lo(loss)),"bases 8 and 9");
}
ck(q(7).div(eta2).lt(lo(q(4).mul(q(5,6).add(q(25,84)))))&&q(7).div(eta2).lt(lo(q(6))),"steep second offsets");
function cu(c,x,a){return c.sq().div(a.mul(o.sub(a))).lt(lo(x))}
ck(cu(capH,q(4),da)&&cu(capK,q(251,49),al0)&&cu(q(311,100),q(324,64),al0)&&cu(q(302,100),q(400,81),al0),"curvature left and high");
ck(cu(q(311,100),q(4),ar0),"curvature middle right");
const third=q(7,1000000);ck(o.div(third).lt(lo(q(12))),"third witness");
function witness(c,e,t){return two.mul(c).mul(e.add(t.div(o.sub(e.sq())))).lt(o);}
ck(witness(capH,eta,third)&&witness(q(311,100),q(158,1000),third)&&witness(q(302,100),q(156,1000),third)&&witness(capK,q(108,1000),q(108,1000).sq().mul(q(108,1000))),"main witnesses");
const dll=q(44,100), dh=q(304,1000), di=q(327,1000),rt=q(37,100),sl=q(23,1000),z=o.sub(eta2.sq());
ck(capH.mul(bd).div(two.mul(sk)).lt(dh)&&capK.mul(bd).div(two.mul(sk)).lt(di)&&cap2.mul(bd).div(two.mul(sk)).lt(dll)&&capK.mul(q(1,2).div(sd).add(o.div(two.mul(sk)))).lt(rt)&&capK.div(nmin).lt(sl),"sharp drift");
function mat(aL,aR,d){
 const l=aL.add(d).add(aL.mul(eta2).mul(dll).div(z)).div(o.sub(aL));
 const rr=rt.add(q(3).mul(sl)).div(z).add(two.mul(sl).mul(eta2.sq()).div(z.sq()));
 const r=aR.add(aR.mul(d)).add(aR.mul(eta2.sq()).mul(rr)).div(o.sub(aR));
 return l.add(r).lt(o);
}
ck(mat(da,da,dh)&&mat(al0,ar0,di),"high and mixed signs");
const el=q(99,1000),ll=q(43,100),aa=q(61,1000),dd=q(1,2),bb=q(31,1000);
ck(o.div(el).lt(lo(q(335,144)))&&cap2.mul(el).lt(ll)&&q(7).div(ll).lt(lo(q(670,63))),"low pure");
ck(cu(capK,q(335,64),aa)&&cu(cap2,q(335,49),aa)&&cu(q(7),q(1340,49),aa),"low curvature");
ck(witness(cap2,el,el.sq().mul(el))&&q(1000).lt(lo(q(670,63)))&&witness(q(7),q(1,1000),q(1,1000).sq().mul(q(1,1000))),"low witnesses");
ck(cap2.mul(q(1,2).div(sd).add(o.div(two.mul(sk)))).lt(dd)&&cap2.div(nmin).lt(bb),"low drift");
const zz=o.sub(ll.sq());
ck(two.mul(aa).add(dd).add(aa.mul(ll).mul(dd).div(zz)).add(aa.mul(dd.div(zz).add(bb.mul(o.add(ll.sq())).div(zz.sq())))).lt(o.sub(aa)),"low margin");
ck(q(7000).lt(lo(q(293,1000).mul(q(48)))),"tiny drift");
ck(q(1,2).div(sd).lt(q(1,16))&&q(10,24).mul(nmin.div(D)).div(sd).lt(q(1,16)),"phase windows");

console.log("PASS: long_cycles_k48_through_7k-01");
