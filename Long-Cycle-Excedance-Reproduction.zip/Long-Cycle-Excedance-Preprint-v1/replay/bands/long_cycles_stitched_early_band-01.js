globalThis.text = console.log;
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const C=q(25,9),eta=q(1,20),x=q(1).div(two.mul(q(1,3).add(q(1,22))).mul(q(1,3).add(q(2,22))));
let term=one, sum=one;for(let j=1;j<=12;j++){term=term.mul(x).div(q(j));sum=sum.add(term)}
assert(q(20).lt(sum));
assert(q(1,66).add(q(1,511)).lt(q(18,1000)));
assert(C.mul(q(18,1000).add(q(1,16))).lt(q(225,1000)));
assert(C.div(q(511)).lt(q(6,1000)));
assert(C.mul(two).mul(eta).div(one.sub(eta)).lt(one));
const cost=C.mul(q(1006,1000).mul(eta).div(one.sub(eta).pow(2)).add(q(625,1000).mul(eta).div(one.sub(eta))));
assert(cost.lt(q(375,1000)));
// Phase at S: upper deviation M/D and lower deviation <= n*pi^2*M^3/(3D^3).
const A=q(1,3).add(q(1,22));
assert(A.div(q(22)).lt(q(1,40)));
assert(q(511,510).mul(q(10,3)).mul(A.pow(3)).div(q(22)).lt(q(1,40)));
assert(q(473,1000).lt(one.sub(q(10,2*40**2))));
text("PASS: all edge and stitch constants for 256 <= k, n <= 25 k / 9");

console.log("PASS: long_cycles_stitched_early_band-01");
