globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(124)).mul(ex(q(5,16)).sq()).lt(q(22,100).sq()),"vertical log bound");
ck(q(76,100).lt(q(78,100).mul(o.sub(q(22,100).sq().div(two)))),"vertical real fraction");
ck(q(97,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(22,100).div(o.sub(q(22,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[64,16,106,550,5,31],[64,31,150,325,7,64],[64,64,203,200,7,119],[64,119,256,125,10,190],[64,190,304,75,10,271],[64,271,331,60,10,322],[64,300,356,60,16,801],[64,801,498,25,16,1572],[64,1572,622,15,16,2453],[64,2453,718,12,16,3274],[64,3274,786,10,16,3925],[64,3925,832,8,16,4406],[64,4406,862,8,16,4727]];
const covered={64:16};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(8);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(83,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(13,16).mul(p)).sub(o).mul(q(1,2)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(1,2).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(1,2).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(19,15).div(a.div(sk).add(two)); const ref2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(97,100).mul(ref).sub(eps)),"splice phase");
 const dense=B>=300; const rad=a.sub((dense?q(8,5):q(18,5)).div(sk));
 ck(q(0).lt(rad)&&(dense?q(25*N,16):q(400*N,121)).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1], C=q(27,8),sk=q(8),A=q(43,100),mt=q(43,100),sp=q(319,10),n0=q(1024),D=q(1023),v=D.div(n0),u=q(55,100);
ck(q(156).lt(lo(q(51,10)))&&covered[64]>4590,"eventual overlap");
ck(q(1000,573).lt(lo(q(573,1000).sub(q(1,64))))&&q(83,1000).mul(q(3,2)).lt(q(125,1000)),"cycle tail");
ck(q(64).mul(eu(q(1,6*1023))).lt(mt.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(63))),"Stirling peak");
function geom(x,y){return x.div(o.sub(y))}
function low(x){return q(63).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))));}
const eps=q(18,1000),r0=A.mul(q(13,14)),h=q(93,100),L=q(199,100),R=q(112,100);
ck(q(62,100).sq().mul(q(79,16)).lt(q(3,2).sq()),"only singleton critical");
ck(q(62,100).sq().mul(q(79,16)).mul(q(15,14).sq()).lt(q(2).div(q(135,100)).sq())&&q(10).lt(q(63).mul(q(135,200).sub(q(1,2)))),"long profile");
ck(mt.div(sk.mul(o.sub(o.div(q(135,100))))).lt(q(21,100)),"prefactor");
ck(q(6,10000).add(q(3,2).mul(q(21,100)).mul(geom(em(low(q(35,100))),em(q(10))))).lt(eps),"profile error");
ck(eu(o).mul(mt).div(sk.mul(r0.sq())).lt(h)&&o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L)&&q(15,14).mul(o.add(eps)).div(o.sub(eps)).lt(R),"profile ratios");
const eH=q(205,1000),lH=q(415,1000),aH=q(92,1000),eM=q(113,1000),lM=q(42,100),aM=q(14,100),eL=q(10,1000),lL=q(51,1000);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,51))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(462,1000)).mul(q(493,1000))))),"medium pure");
ck(o.div(eL).lt(lo(D.div(q(220)))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&C.mul(q(21,20)).div(lH).lt(lo(v.mul(sp).mul(o.div(u).sub(q(50,31))))),"exits");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM)&&C.mul(q(3,2)).mul(eL).lt(lL),"ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(o.div(u.sq()))),"curvature high");
ck(C.sq().mul(q(11,10)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(462,1000).sq())))&&C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(D.div(q(81)))),"curvature middle");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,14,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witnesses");
const d=q(253,1000),b=q(35,10000), C3=q(354,100);
ck(q(10,3).div(o.sub(o.div(q(18)))).lt(C3)&&C3.mul(u.div(sp).add(mt.div(sk))).lt(d)&&C3.div(n0).lt(b),"main drift");
ck(q(1331,1000).lt(q(4,3).mul(v))&&q(22).lt(q(331,1000).mul(q(64)).add(o)),"lower drift spacing");
ck(C.div(v).mul(q(1331,1000)).mul(mt).div(sk).mul(geom(em(low(q(331,1000))),em(q(22)))).lt(q(2,100)),"lower drift magnitude");
function margin(a,l,d,b){const z=o.sub(l.sq());return two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a))}
ck(margin(aH,lH,d,b)&&margin(aM,lM,d,b)&&margin(lL,lL,d,b),"signed margin");
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sp)))).lt(q(18,5))&&u.div(sp).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sp)).lt(q(1,40)),"splice");
const dense=q(4,5),f=q(999,1000),de=q(461,1000),dl=q(491,1000),da=q(31,100),dn0=q(19200),v0=q(19199,19200),s0=q(138);
ck(q(9,10).sq().mul(q(79,300)).lt(q(1,4))&&q(1000).lt(lo(q(192,10))),"dense amplitude");
ck(o.div(de).lt(lo(o.div(dense.sq()).mul(q(1,2).sub(q(1,330))))),"dense pure");
ck(o.div(q(12,10000)).lt(lo(q(9).div(two.mul(dense.sq())).mul(q(110,113)))),"third witness");
ck(de.mul(q(17,16)).div(f).lt(dl)&&q(81,16).div(dl).lt(lo(v0.mul(s0).mul(q(5,36)))),"dense actual");
ck(o.div(f.sq().mul(da).mul(o.sub(da))).lt(lo(o.div(dense.sq()))),"dense curvature");
const z0=o.sub(de.sq());
ck(two.div(f).mul(de.add(q(12,10000).mul(q(19,16).div(z0).add(de.sq().div(q(8).mul(z0.sq())))))).lt(o),"dense witness");
const dd=q(22,100),db=q(19,100000),full=q(1,1000),u0=o.sub(dl),w0=o.sub(dl.sq());let p=o;for(let j=0;j<12;j++)p=p.mul(dl);
ck(C3.mul(dense.div(s0).add(mt.div(sk))).lt(dd)&&C3.div(dn0).lt(db),"dense drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(64)))),"dense small drift");
const late=da.mul(p).mul(dd.add(q(13).mul(db)).div(u0).add(db.mul(dl).div(u0.sq())));
ck(two.mul(da).add(full).add(da.mul(dl).mul(full).div(w0)).add(da.mul(full).div(w0)).add(late).lt(o.sub(da)),"dense margin");
ck(o.div(dense.sq()).div(o.sub(o.div(dense.mul(s0)))).lt(q(8,5))&&dense.div(s0).lt(q(1,40))&&q(10,3).mul(dense.sq()).mul(dense).div(v0.mul(s0)).lt(q(1,40)),"dense splice");

console.log("PASS: long_cycles_k64_from_16k-01");
