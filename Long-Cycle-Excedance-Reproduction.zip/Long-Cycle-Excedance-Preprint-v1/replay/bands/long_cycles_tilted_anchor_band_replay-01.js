globalThis.text = console.log;
const text=console.log;
function gcd(a,b){while(b!==0n){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g} add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)} sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)} mul(y){return new Q(this.a*y.a,this.b*y.b)} div(y){return new Q(this.a*y.b,this.b*y.a)} pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))} lt(y){return this.a*y.b<y.a*this.b} val(){return Number(this.a)/Number(this.b)}}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),pi=q(157,50),fact=q(362880),grid=10n**12n;
const ceil=(n,d)=>q((grid*n+d-1n)/d,grid), up=x=>ceil(x.a,x.b),dn=x=>q(grid*x.a/x.b,grid);
function expS(x){
 let t=o,u=o,z=o,w=o;
 for(let i=1;i<=30;i++){t=dn(t.mul(x).div(q(i)));u=up(u.mul(x).div(q(i)));z=z.add(t);w=w.add(u)}
 return [z,w.add(up(u.mul(x).div(q(31)).div(o.sub(x.div(q(32))))))];
}
function ck(v,label){if(!v)throw Error(label)}

const E=(z)=>expS(z)[1], EL=z=>expS(z)[0], minus=z=>o.div(EL(z)), C=q(31,10);
ck(E(q(2,5)).add(E(q(4,5)).div(q(2).sub(E(q(2,5))))).lt(q(6)),"tilt");
for(const [K,B,a,R,f,h,j,g] of [[256,14,q(15,2),q(14934,100000),q(2259,1000),q(645,1000),q(35,100000),q(18,100000)],[512,19,q(39,4),q(13725,100000),q(4209,1000),q(1057,1000),q(174,100000),q(115,100000)],[704,22,q(11),q(13205,100000),q(5523,1000),q(1293,1000),q(322,100000),q(233,100000)]]){
const b=q(4).mul(pi.pow(2)).div(a.pow(2).mul(q(K)).add(q(10)));
function lat(m,w){let s=q(0);for(let l=1;l<=6;l++){let z=o.add(b.mul(q(l*(l+1))));s=s.add(ceil(BigInt(w?2*l+1:1)*z.b**BigInt(m),z.a**BigInt(m)))}
let z=o.add(b.mul(q(42)));return s.add(ceil(b.b*z.b**BigInt(m-1),b.a*BigInt((m-1)*(w?1:13))*z.a**BigInt(m-1)))}
const m=Math.floor((K-1)/2);
ck(q(2).lt(b.mul(q(26*m-12)))&&lat(m,true).lt(f)&&lat(m,false).lt(h)&&lat((B-1)*K/2,true).lt(j)&&lat(B*K/2,true).lt(g),"lattices");
ck(o.add(a.pow(2).mul(q(K)).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)),"radius");
const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
const eps=E(p).sub(o).div(q(120)).add(minus(q(2*(B-6),5)).mul(E(q(3).mul(p)).sub(o)));
const c=o.sub(p).mul(o.sub(p.pow(2).div(two))).sub(eps);
const W=two.mul(E(q(3).mul(x)).sub(o)).mul(minus(q(2,5)).mul(j).add(minus(q(2*(B-1),5)).mul(f))).add(g),V=W.div(q(3));
let fac=1n;for(let y=1n;y<BigInt(B);y++)fac*=y;
const mismatch=q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(BigInt(B)*fac));
const P=two.mul(E(p).sub(o));
ck(eps.lt(q(1,10))&&V.pow(2).add(W.add(mismatch).add(two.mul(eps)).pow(2)).lt(c.pow(2)),"central sign");
ck(V.lt(c.mul(o.sub(q(10,3200))).sub(P.mul(q(22,280)))),"splice slice");
text({K,B,a:a.val(),value:V.val(),center:W.val(),c:c.val(),eps:eps.val()});
}
for(const [K,B,H,sd,sk,cap,Cs,et,ds,gs,d,g,left] of [
[256,14,19,59,16,4,q(61,10),q(5,1000),q(408,1000),q(18,10000),q(226,1000),q(1,1000),q(127,100)],
[512,19,40,98,22,8,q(101,10),q(3,1000),q(48,100),q(11,10000),q(16,100),q(1,1000),q(19,10)]]){
const N=q(K*B),D=N.sub(o),k=q(K),h=q(H),low=q(cap+2).div(o.sub(q(1,cap===4?64:128)));
ck(q(sd*sd).lt(D)&&!k.lt(q(sk*sk))&&low.lt(Cs),"cap and roots");
ck(o.div(et).lt(EL(k.sub(q(1,B)).div(two.mul(h.add(q(3)).add(q(2,B)))))),"low decay");
ck(h.div(q(36,100)).lt(EL(k.sub(q(1,B)).div(two.mul(h)))),"nonplateau step");
const A=h.mul(et),den=o.sub(A);
ck(two.mul(h).mul(et).div(o.sub(et.pow(2))).lt(o),"low witnesses");
ck(Cs.mul(q(1,sk).add(o.add(q(1,B)).div(k))).lt(ds)&&Cs.div(N).lt(gs),"low drift");
ck(two.mul(A).add(ds).add(A.mul(ds.div(den).add(gs.div(den.pow(2))))).lt(den),"low signs");
ck(C.mul(q(3,5).div(q(sd)).add(q(1,sk))).lt(d)&&C.div(N).lt(g)&&h.mul(q(1,K).add(q(1,sk))).lt(left),"main drifts");
for(const [a,l] of [[q(132,1000),q(42,100)],[q(125,1000),q(36,100)]]){
 const den=o.sub(l.pow(2)),LE=a.mul(l).mul(left).div(den),RO=a.mul(d.div(den).add(g.mul(o.add(l.pow(2))).div(den.pow(2))));
 ck(two.mul(a).add(d).add(LE).add(RO).lt(o.sub(a)),"medium high signs");
}
}
for(const [H,a,sk] of [[19,q(15,2),16],[32,q(39,4),22],[40,q(11),26]])ck(q(25,9).mul(q(H)).lt(a.sub(q(29,10*sk)).pow(2)),"splice");
text("Widened central and edge bands: exact bounds passed.");


console.log("PASS: long_cycles_tilted_anchor_band_replay-01");
