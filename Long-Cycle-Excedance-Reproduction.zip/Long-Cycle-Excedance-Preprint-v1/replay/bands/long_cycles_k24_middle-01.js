globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}


const lo=x=>eb(x)[0],eu=x=>eb(x)[1],C=q(27,8),K=q(24),sk=q(489,100),pl=q(157,50),p=q(51,100),n0=q(72),D=q(71),sv=q(842,100),A=q(1,2),F=q(3,5);
ck(sk.sq().lt(K)&&sv.sq().lt(D)&&q(31,12).lt(q(161,100).sq()),"scales and beta ceiling");
ck(K.mul(eu(q(1,6*71))).lt(p.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(23))),"Robbins peak");
function Phi(w,upper){const x=upper?o.sub(w):w.sub(o), cubic=x.sq().mul(x).div(q(3));return upper?x.sq().div(two).add(cubic):x.sq().div(two).sub(cubic);}
function lowerTail(w){return p.div(sk.mul(o.sub(o.div(w)))).mul(em(q(23).mul(Phi(w,false))));}
function upperTail(w){return p.div(sk.mul(o.sub(w))).mul(em(q(24).mul(Phi(w,true))));}
function bad(U,w){return lowerTail(w).div(q(U).mul(o.sub(em(q(23).mul(w.sub(o)).div(q(U))))));}
ck(bad(2,q(10,7)).lt(q(4,100))&&bad(3,q(300,161)).lt(q(3,1000)),"long cycle errors");
ck(q(128,100).lt(q(200,161).mul(q(31,30)))&&q(76,100).lt(o.sub(lowerTail(q(128,100)))),"doubleton success");
ck(upperTail(q(25,28)).lt(q(845,1000))&&upperTail(q(5,7)).lt(q(115,1000)),"singleton success");
const bp=q(32,100),qp=q(36,100),right=q(38,100),rp=q(64,100);
ck(rp.mul(bp).lt(two.mul(qp).mul(right))&&right.mul(qp).lt(rp.mul(bp)),"monotonic ratios A");
ck(o.div(bp).lt(q(313,100))&&q(6,5).mul(right.add(rp)).div(bp.add(qp)).lt(q(181,100))&&right.div(bp.sq()).lt(q(372,100)),"neighbors A");
ck(q(3,4).div(q(335,1000)).lt(q(313,100))&&q(5,4).mul(right.add(rp)).div(q(335,1000).add(q(1,3))).lt(q(191,100)),"A at 4");
ck(q(15,16).mul(right).div(q(335,1000).sq()).lt(q(372,100))&&rp.mul(q(335,1000)).lt(two.mul(q(1,3)).mul(right))&&rp.mul(q(335,1000)).lt(two.mul(q(1,3)).mul(right)),"A at 4 product");
const den=q(273,1000),Pleft=q(9208,10000),Pright=q(4536,10000);
ck(Pleft.div(den).lt(q(338,100))&&q(6,5).mul(Pright).div(den).lt(q(2))&&Pleft.mul(Pright).div(den.sq()).lt(q(561,100)),"neighbors B");
const dr4=q(247,1000);
ck(q(3,4).div(dr4).lt(q(304,100))&&q(5,4).mul(Pright).div(dr4).lt(q(230,100)),"B at 4");
const eta=q(172,1000),eta4=q(158,1000),eL=q(136,1000),lam=q(47,100),al=q(75,1000),ar=q(117,1000);
ck(o.div(eL).lt(lo(q(2)))&&o.div(eta).lt(lo(q(2).sub(q(4,15)).add(q(1,25)).sub(q(4,625))))&&o.div(eta4).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"pure first");
ck(q(338,100).mul(eL).lt(lam)&&q(2).mul(eta).lt(lam)&&q(230,100).mul(eta4).lt(lam)&&q(191,100).mul(eta4).lt(lam)&&q(304,100).mul(eL).lt(lam),"actual first");
const tiny=q(47,1000),lam2=q(72,1000);
ck(o.div(tiny).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&C.mul(q(3,2)).mul(tiny).lt(lam),"small base");
ck(C.mul(q(3,2)).div(lam2).lt(lo(q(4).mul(q(4,5).add(q(4,15)))))&&C.div(lam2).lt(lo(q(6))),"steep after first");
ck(q(372,100).div(al.mul(o.sub(al))).lt(lo(q(4)))&&q(561,100).div(ar.mul(o.sub(ar))).lt(lo(q(4)))&&q(15,16).mul(Pright).div(dr4.sq()).div(ar.mul(o.sub(ar))).lt(lo(D.div(q(16))))&&C.sq().mul(q(3,2)).div(al.mul(o.sub(al))).lt(lo(D.div(q(9)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R,E,m] of [[q(313,100),q(181,100),eta,5],[q(338,100),q(2),eta,5],[q(313,100),q(191,100),eta4,4],[q(304,100),q(230,100),eta4,4]])ck(L.mul(eL).add(R.mul(E)).add(cost(E,m,true)).lt(o),"witnesses");
ck(cost(tiny,1,false).lt(o),"low witness");
const cap=q(366,100),d=q(60,100),db=q(51,1000),xx=q(1314,1000),v=D.div(n0);
ck(q(10,3).div(o.sub(o.div(q(113,10)))).lt(cap)&&cap.mul(A.div(sv).add(p.div(sk))).lt(d)&&cap.div(n0).lt(db),"drift cap");
ck(xx.lt(q(4,3).mul(v))&&q(8).lt(q(314,1000).mul(K).add(o)),"drift spacing");
ck(C.div(v).mul(xx).mul(p).div(sk).mul(em(q(23).mul(Phi(xx,false)))).div(o.sub(em(q(8)))).lt(q(20,100)),"heavy drift");
const dR=d.add(db),dB=q(475,1000);
ck(o.div(q(14,10).mul(dr4)).mul(A.div(sv).add(p.div(sk))).lt(dB),"case B main drift");
function margin(a,dL){
 const z=o.sub(lam2.sq()),left=a.add(dL).add(a.mul(lam2).mul(d).div(z)).div(o.sub(a));
 const rem=d.add(q(3).mul(db)).div(z).add(two.mul(db).mul(lam2.sq()).div(z.sq()));
 const right=ar.add(ar.mul(dR)).add(ar.mul(lam2.sq()).mul(rem)).div(o.sub(ar));
 return left.add(right).lt(o);
}
ck(margin(al,d)&&margin(ar,dB),"signed comparison");
ck(q(10,3).mul(n0.div(D)).div(q(4)).lt(o),"phase positive");
ck(pl.sq().div(q(3)).mul(o.sub(q(6,4*71))).lt(q(16,5))===false,"phase upper");

console.log("PASS: long_cycles_k24_middle-01");
