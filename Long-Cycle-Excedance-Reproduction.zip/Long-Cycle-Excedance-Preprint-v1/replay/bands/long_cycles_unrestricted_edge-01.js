globalThis.text = console.log;
let g=(a,b)=>b?g(b,a%b):a<0n?-a:a;
let mk=(a,b=1n)=>{let z=g(a,b);return [a/z,b/z]};
let q=x=>{x=String(x);let [a,b=""]=x.split(".");return mk(BigInt((a||"0")+b),10n**BigInt(b.length))};
let A=(a,b)=>mk(a[0]*b[1]+b[0]*a[1],a[1]*b[1]),N=a=>[-a[0],a[1]],S=(a,b)=>A(a,N(b)),M=(a,b)=>mk(a[0]*b[0],a[1]*b[1]),D=(a,b)=>mk(a[0]*b[1],a[1]*b[0]),L=(a,b)=>a[0]*b[1]<b[0]*a[1],sq=a=>M(a,a);
let plus=(...x)=>x.reduce(A,q(0)), times=(...x)=>x.reduce(M,q(1));
function ex(x){let a=q(1),s=a;for(let j=1;j<=25;++j){a=D(M(a,x),q(j));s=A(s,a)}return s}
const chk=(flag,key)=>{if(!flag)throw Error(key)};
const C=D(q(27),q(8)), v=D(q(3583),q(3584));
let invexp=(x,y,key)=>chk(L(y,ex(x)),key);
invexp(times(D(q(25),q(9)),S(q(".5"),D(q(1),q(105)))),D(q(1),q(".26")),"high outward");
invexp(D(v,times(q(2),q(".467"),q(".484"))),D(q(1),q(".112")),"middle outward");
invexp(D(q(3583),q(220)),q(1000),"low outward");
invexp(D(v,times(q(2),sq(q(".45")))),D(C,q(".42")),"high left");
invexp(times(q(59),v,D(q(5),q(12))),D(times(C,q("1.5")),q(".42")),"high right");
chk(L(times(C,D(q(12),q(11)),q(".112")),q(".42")),"middle actual");
chk(L(times(q("1.58"),q(".26")),q(".42")),"high actual");
let cur=(c,x,a,key)=>invexp(x,D(c,times(a,S(q(1),a))),key);
cur(times(q("1.58"),q("1.15")),D(q(25),q(9)),q(".132"),"high curvature");
cur(times(sq(C),D(q(23),q(22))),D(v,sq(q(".467"))),q(".148"),"middle curvature");
cur(times(sq(C),q("1.5")),D(q(3583),sq(q(21))),q(".148"),"middle small curvature");
function odd(e,m,far){let z=sq(e),u=S(q(1),z), f=D(e,u), h=D(M(e,A(q(1),z)),sq(u)); if(far){f=S(f,e);h=S(h,e)}return times(q(2),C,A(f,D(h,m)))}
chk(L(A(times(q("2.73"),q(".26")),odd(q(".26"),q(27),true)),q(1)),"high witness");
chk(L(odd(q(".112"),q(10),false),q(1)),"middle witness");
chk(L(odd(q(".001"),q(1),false),q(1)),"low witness");
chk(L(times(D(q(27),q(4)),A(D(q(".6"),q(59)),D(q(".45"),q(16)))),q(".26")),"main drift");
chk(L(D(D(q(27),q(4)),q(3584)),q(".0019")),"drift slope");
invexp(times(q(".2995"),q(256)),q(7000),"tiny drift");
for(let [a,l] of [[".132",".42"],[".148",".42"],[".006",".006"]]){
  let x=q(a),z=q(l), h=S(q(1),sq(z)), d=q(".26"), b=q(".0019");
  let leftExtra=D(times(x,z,d),h);
  let rightExtra=M(x,A(D(d,h),D(times(b,A(q(1),sq(z))),sq(h))));
  chk(L(plus(times(q(2),x),d,leftExtra,rightExtra),S(q(1),x)),"signed margin "+a)
}

console.log("PASS: long_cycles_unrestricted_edge-01");
