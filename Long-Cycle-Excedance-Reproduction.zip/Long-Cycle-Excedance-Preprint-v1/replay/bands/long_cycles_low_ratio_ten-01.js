globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[128,10,61,400,5,11],[128,11,66,425,5,13],[128,13,68,450,5,14]];
const covered={128:10};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)); const ref2=dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(16,5).div(sk));
 ck(q(0).lt(rad)&&q(2500*N,841).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1],C=q(27,8),v=q(1279,1280),sk=q(113,10),n0=q(1280),eM=q(128,1000),eH=q(24,100),eL=q(4,1000), u=q(58,100);
ck(covered[128]>=14,"overlap");
ck(o.lt(q(4).mul(q(445,1000).sq()).mul(pl).mul(q(11,24)).mul(q(9,10)).mul(q(127,128))),"Fourier main");
ck(q(3200).lt(lo(q(40))),"Fourier tail");
function geo(first,ratio){return first.div(o.sub(ratio));}
function bad(x){return em(q(128).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3)))));}
function short(x){return em(q(128).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3)))));}
const e1=q(46,1000),e2=q(23,1000),e3=q(19,1000),e4=q(30,1000), L=q(175,100),R=q(117,100);
ck(q(1259,1000).lt(q(34,27))&&q(16).lt(q(128).mul(q(17,27).sub(q(1,2)))),"long b2");
ck(q(6,10000).add(q(3,2).mul(geo(bad(q(259,1000)),em(q(16))))).lt(e1),"error one");
ck(q(131,100).lt(q(3).div(q(215,100).mul(q(17,16))))&&q(13).lt(q(128).mul(o.div(q(215,100).mul(q(17,16))).sub(q(1,3)))),"long b3");
ck(q(5,1000).add(q(5).mul(short(q(288,1000)))).add(q(5,6).mul(geo(bad(q(31,100)),em(q(13))))).lt(e2),"error two");
ck(q(134,100).lt(q(4).div(q(285,100).mul(q(23,22))))&&q(10).lt(q(128).mul(o.div(q(285,100).mul(q(23,22))).sub(q(1,4)))),"long b4");
ck(q(14,1000).add(q(7).mul(short(q(1,2)))).add(q(7,8).mul(geo(bad(q(34,100)),em(q(10))))).lt(e3),"error third");
const mb5=q(62,100).sq().mul(q(255,10)).mul(q(30,29).sq());
ck(mb5.lt(q(5).div(q(154,100)).sq())&&q(13).lt(q(128).mul(q(154,500).sub(q(1,5)))),"long b5");
ck(q(6,1000).add(q(10).mul(short(q(1,2)).add(short(q(27,100)).div(two)))).add(q(2,3).mul(geo(bad(q(54,100)),em(q(13))))).lt(e4),"error fourth");
const A=q(45,100),r1=A.mul(q(16,17)),r2=A.mul(q(15,16)),r3=A.mul(q(21,22)),r4=A.mul(q(28,29));
for(const [h,eps,m,ss,pk,rf] of [
[q(62,100),e1,q(18,17),o,A,r1],[q(39,100),e2,q(17,16),q(1,2),A,r2],
[q(56,100),e3,q(23,22),q(5,6),q(1,2),r3],[q(51,100),e4,q(30,29),q(7,12),q(6,10),r4]]){
ck(eu(ss).mul(pk).div(sk.mul(rf.sq())).lt(h),"derivative");
ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L) && m.mul(o.add(eps)).div(o.sub(eps)).lt(R),"profile ratios");
}
const z=q(1,7), modal=q(127).mul(z.sq().div(two).sub(z.sq().mul(z).div(q(3))));
ck(q(3).lt(lo(modal)),"separated modes for 3 and 4");
const lH=q(43,100),lM=q(48,100),lL=q(21,1000),aH=q(125,1000),aM=q(19,100);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,60))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(478,1000)).mul(q(506,1000))))),"middle pure");
ck(q(250).lt(lo(q(1279,220))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq())))) && C.mul(q(23,22)).div(lH).lt(lo(v.mul(q(35)).mul(o.div(u).sub(q(50,31))))),"profile exit");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM)&&C.mul(q(3,2)).mul(eL).lt(lL),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(o.div(u.sq()))),"high curvature");
ck(C.sq().mul(q(17,16)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(478,1000).sq()))) && C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(q(1279,225))),"middle curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,17,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witness");
const d=q(235,1000),b=q(33,10000), C2=q(415,100);
ck(q(128,31).lt(C2)&&C2.mul(u.div(q(35)).add(A.div(sk))).lt(d)&&C2.div(n0).lt(b),"drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(128)))),"heavy drift");
for (const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){
const z=o.sub(l.sq());
ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");
}
ck(o.div(u.sq()).div(o.sub(q(1,20))).lt(q(16,5)),"floor");
ck(u.div(q(35)).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(q(35))).lt(q(1,40)),"phase");

console.log("PASS: long_cycles_low_ratio_ten-01");
