globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log bound");
ck(q(48,100).lt(q(54,100).mul(o.sub(q(46,100).sq().div(two)))),"vertical real fraction");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(o.sub(q(46,100).sq().div(two))).mul(pu.div(q(16))))),"splice angle fraction");
const rows=[[16,16,40,550,5,16,1],[16,16,70,700,5,16,2],[16,16,83,600,5,20,0],[16,20,98,500,5,29,0],[16,29,120,375,7,45,0],[16,45,146,280,7,68,0],[16,68,172,200,7,97,0],[16,97,198,150,10,130,0],[16,130,220,125,10,161,0],[16,161,236,100,10,187,0]];
const covered={16:16};
for(const [K,B,a2,at,L,N,core] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(4);
 ck(!q(K).lt(sk.sq())&&(core||B<=covered[K])&&B>L&&(core||N>covered[K]),"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(119,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(84,100).mul(p)).sub(o).mul(q(716,1000)).div(fact(L)).add(em(alpha.mul(q(Math.round(4*(B-L)),4))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(716,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(q(181,100).mul(em(alpha.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(q(81,100).sub(delta).mul(em(alpha.mul(q(Math.round(4*(B-L)),4)))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(716,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 const ref=core===1?two.sub(ex(q(84,100).mul(p))):core===2?q(4,5).div(a.div(sk).add(two)):q(13,10).mul(sk).div(a); const rp=p.mul(q(79,100));const ref2=core===2&&rp.lt(o)?dn(o.div(ex(rp)).mul(o.sub(rp.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 if(core!==1)ck(V.lt(q(87,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(311,100).div(sk));
 if(!core)ck(q(0).lt(rad)&&q(Math.round(4*N)*25,36).lt(rad.sq()),"splice location");
 if(!core)covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=x=>eb(x)[0],K0=q(16),D=q(255),n=q(256),sk0=q(4),sd=q(159,10),u=q(3,5),reach=q(65,100),wide=q(67,100),pk=q(47,100),C=q(27,8),v=D.div(n);
ck(covered[16]>180,"eventual overlap");
ck(q(1000,591).lt(lo(q(591,1000).sub(q(1,16))))&&q(119,1000).mul(q(3,2)).lt(q(179,1000)),"cycle peak and variation");
ck(o.add(q(694,1000)).add(q(1,62)).lt(q(591,1000).mul(q(47,16)))&&q(16).mul(ex(q(1,6*255))).lt(pk.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(15))),"count and binomial peaks");
ck(pu.div(q(16)).lt(q(1,5))&&q(64,100).sq().mul(q(24,10)).lt(o)&&o.div(q(2).mul(q(64,100))).lt(q(79,100)),"improved core log");
const ml=q(52,100);
const phi=x=>x.sq().div(two).sub(x.sq().mul(x).div(q(3)));
ck(q(152,100).sq().mul(q(22).sq()).lt(q(49*23))&&q(28,15).lt(two),"gamma ratio");
const ps=em(q(22).mul(phi(ml))).div(o.sub(em(q(15).mul(ml))));
const cj=ex(q(5,49)).mul(ps);
ck(cj.lt(q(17,100)),"complex gamma tail");
const ang=q(17,100).add(pu.div(q(28))),co=o.sub(ang.sq().div(two));
ck(o.sub(q(17,100)).mul(co).mul(q(5,3)).div(q(101,100)).lt(q(13,10))===false && o.add(q(10,49*16)).lt(q(101,100).sq()),"outer reference real");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(ang.div(co).mul(pu.div(q(16))))),"outer reference angular");
const F=q(3,4), G0=q(7,10);
for(const [r,w,a] of [[reach,q(134,100),F],[wide,q(13,10),G0]]){
 ck(w.sq().mul(r.sq()).mul(q(23,16)).lt(q(23,22).sq()),"good-label mean");
 ck(pk.div(sk0.mul(o.sub(o.div(w)))).mul(em(q(15).mul(phi(w.sub(o))))).lt(o.sub(a)),"good-label tail");
}
const e=q(278,1000),l=q(49,100),a=q(128,1000);
ck(o.div(e).lt(lo(q(25,9).mul(q(1,2).sub(q(1,27)))))&&q(6,5).div(F).mul(e).lt(l),"high ratios");
ck(q(500).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12)))))&&q(3,2).div(F).div(q(500)).lt(l),"small ratios");
ck(C.mul(q(12,11)).div(l).lt(lo(v.mul(sd).mul(o.div(u).sub(o.div(reach))))),"outward exit");
ck(o.div(F.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(u.sq()))),"curvature bound");
function witness(e,m){const z=o.sub(e.sq());return two.div(F).mul(e.div(z).add(e.mul(o.add(e.sq())).div(q(m).mul(z.sq())))).lt(o);}
ck(witness(e,6)&&q(1000,13).lt(lo(D.div(q(25)).mul(q(1,2).sub(q(1,15)))))&&witness(q(13,1000),1),"opposing witnesses");
const cap=q(375,100), d=q(584,1000),b=q(147,10000),xn=q(1328,1000),xn2=q(1239,1000),dm=q(16,100);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(u.div(sd).add(pk.div(sk0))).lt(d)&&cap.div(n).lt(b),"generic drift");
ck(xn.lt(q(4,3).mul(v))&&q(6).lt(q(328,1000).mul(K0).add(o)),"heavy drift spacing");
ck(C.div(v).mul(xn).mul(pk).div(sk0).mul(em(q(15).mul(phi(q(328,1000))))).div(o.sub(em(q(6)))).lt(q(30,100)),"heavy drift");
ck(xn2.sq().mul(wide.sq()).mul(q(23,16)).lt(v.sq())&&q(48,10).lt(q(239,1000).mul(q(16)).add(o))&&o.lt(wide.sub(u).mul(q(16))),"near drift window");
ck(o.div(G0.mul(v)).mul(xn2).mul(pk).div(sk0).mul(em(q(15).mul(phi(q(239,1000))))).div(o.sub(em(q(48,10)))).lt(dm),"near drift");
const z=o.sub(l.sq()),tail=d.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l.sq()).div(z.sq()));
ck(two.mul(a).add(dm).add(a.mul(l).mul(dm).div(z)).add(a.mul(dm)).add(a.mul(l.sq()).mul(tail)).lt(o.sub(a)),"signed mean margin");
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sd)))).lt(q(311,100))&&u.div(sd).lt(q(1,16))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sd)).lt(q(1,16)),"floor splice");

console.log("PASS: long_cycles_k16_upper_and_edge-01");
