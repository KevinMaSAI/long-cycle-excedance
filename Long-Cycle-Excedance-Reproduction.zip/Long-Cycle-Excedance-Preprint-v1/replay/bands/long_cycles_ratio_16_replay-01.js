globalThis.text = console.log;
function gcd(a,b){while(b!==0n){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g} add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)} sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)} mul(y){return new Q(this.a*y.a,this.b*y.b)} div(y){return new Q(this.a*y.b,this.b*y.a)} pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))} lt(y){return this.a*y.b<y.a*this.b} val(){return Number(this.a)/Number(this.b)}}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),pi=q(157,50),fact=q(362880),grid=10n**12n;
const ceil=(n,d)=>q((grid*n+d-1n)/d,grid), up=x=>ceil(x.a,x.b),dn=x=>q(grid*x.a/x.b,grid);
function expS(x){
 let t=o,u=o,z=o,w=o;
 for(let i=1;i<=30;i++){t=dn(t.mul(x).div(q(i)));u=up(u.mul(x).div(q(i)));z=z.add(t);w=w.add(u)}
 return [z,w.add(up(u.mul(x).div(q(31)).div(o.sub(x.div(q(32))))))];
}
function ck(v,label){if(!v)throw Error(label)}
for(const [K,a,r0,f0,h0,l0,j0,g0] of [[256,q(27,4),13442,17140,5102,304,129,55],[512,q(15,2),10559,22345,6391,1111,552,275],[704,q(8),9605,26202,7285,2182,1179,637]]){
 const r=q(r0,100000),f=q(f0,10000),h=q(h0,10000),l=q(l0,100000),j=q(j0,100000),g=q(g0,100000);
 const b=q(4).mul(pi.pow(2)).div(a.pow(2).mul(q(K)).add(q(10)));
 function lat(m,weighted){
  let total=q(0);
  for(let u=1;u<=6;u++){
   const x=o.add(b.mul(q(u*(u+1))));
   total=total.add(ceil(BigInt(weighted?2*u+1:1)*x.b**BigInt(m),x.a**BigInt(m)));
  }
  const x=o.add(b.mul(q(42)));
  return total.add(ceil(b.b*x.b**BigInt(m-1),b.a*BigInt((m-1)*(weighted?1:13))*x.a**BigInt(m-1)));
 }
 const m=Math.floor((K-1)/2);
 ck(o.add(a.pow(2).mul(q(K)).div(pi.pow(2))).div(q(K*K)).lt(r.pow(2)),"radius");
 ck(q(2).lt(b.mul(q(26*m-12))),"integral monotone");
 ck(lat(m,true).lt(f)&&lat(m,false).lt(h)&&lat(4*K,true).lt(l)&&lat(9*K/2,true).lt(j)&&lat(5*K,true).lt(g),"lattices");
 const p=r.mul(o.add(q(3,2).mul(h))),x=r.mul(q(3,2).add(q(4,3).mul(h)));
 const ep=expS(p)[1],ex=expS(x)[1],ea=expS(p.div(two))[1],P=two.mul(ep.sub(o)),c=o.sub(P);
 const W=two.mul(ex.sub(o)).sub(q(3,2).mul(x)).mul(f).add(x.mul(j)).add(x.mul(l).div(two)).add(g),V=W.div(q(3));
 const atom=up(two.mul(p.div(two).pow(9)).mul(ea).div(fact));
 const drift=p.mul(ep).div(q(K+1)).add(atom).add(P.div(q(K))).add(q(6).mul(P).div(fact.mul(q(10*K))));
 const mismatch=q(6).mul(r).mul(o.add(g.div(q(3)))).div(q(10).mul(fact));
 ck(V.pow(2).add(W.add(drift).add(mismatch).pow(2)).lt(c.pow(2)),"central sign");
 ck(V.lt(c.mul(o.sub(q(10,3200))).sub(P.mul(q(22,280)))),"central slice");
 text({K,a:a.val(),P:P.val(),V:V.val(),W:W.val(),drift:drift.val(),mismatch:mismatch.val()});
}
for(const T of [
 [256,q(57,5),q(52,100),q(50),q(16),25,13,20,q(3),q(269,100),q(88,100),q(57,100),15,12,q(48,1000),q(166,1000),q(1,1000),q(16,1000),q(235,1000),q(144,1000),q(447,1000),q(772,1000),q(832,1000),q(45,10000),q(197,1000),q(11,10000),q(219,1000),8],
 [512,q(16),q(515,1000),q(71),q(226,10),36,14,25,q(322,100),q(272,100),q(8,7),q(16,25),24,18,q(2,100),q(158,1000),q(1,100000),q(3,1000),q(223,1000),q(65,1000),q(430,1000),q(753,1000),q(830,1000),q(32,10000),q(141,1000),q(54,100000),q(167,1000),12],
]){
 const [K,H,A,sd,sk,M0,rm,rl,Cm,Cl,capm,capl,sqrtm,sqrtl,em,el,es,am,al,lm,ll,ds,dm,gs,dl,gl,dlMid,tail]=T;
 const D=q(10*K),n=q(10*K+1),lo=(x)=>expS(x)[0];
 ck(!D.lt(sd.pow(2))&&!q(K).lt(sk.pow(2)),"understated square roots");
 ck(q(4*(M0-1)**2).lt(D)&&!A.lt(q(1,2).add(o.div(sd))),"M bounds");
 for(const [r,C,cap,root] of [[rm,Cm,capm,sqrtm],[rl,Cl,capl,sqrtl]]){
  ck(!cap.lt(H.div(q(r)))&&!cap.mul(q(K)).lt(q(root*root)),"cap");
  ck(two.add(cap).div(o.sub(q(1,2*root))).lt(C),"plateau");
 }
 ck(o.div(es).lt(lo(D.div(q(2*rm*(rm+1)))))&&o.div(em).lt(lo(D.div(q(2*rl*(rl+1))))),"pure small/middle");
 const bigLoss=q(1,2).sub(q(1,3*M0)).div(A.pow(2));
 ck(o.div(el).lt(lo(bigLoss)),"pure large");
 ck(!lm.lt(Cm.mul(em))&&Cl.mul(el).lt(ll),"amplitude");
 ck(H.div(lm).lt(lo(D.div(q(2*(rm-1)**2))))&&H.div(ll).lt(lo(D.div(q(2*(rl-1)**2)))),"low-index steps");
 for(const [C,e] of [[H,es],[Cm,em],[Cl,el]])ck(two.mul(C).mul(e).div(o.sub(e.pow(2))).lt(o),"witness");
 ck(Cm.pow(2).div(am.mul(o.sub(am))).lt(lo(D.div(q(rl**2))))&&Cl.pow(2).div(al.mul(o.sub(al))).lt(lo(o.div(A.pow(2)))),"curvature");
 const base=A.div(sd).add(o.div(sk));
 ck(H.mul(q(rm).div(n).add(o.div(sk))).lt(ds)&&H.mul(base).lt(dm)&&H.div(n).lt(gs),"drifts");
 ck(Cl.mul(base).lt(dl)&&Cl.div(n).lt(gl)&&Cm.mul(base).lt(dlMid),"plateau drifts");
 const as=H.mul(es);
 for(const [a,l,d] of [[as,as,ds],[am,lm,dm]]){
  const v=o.sub(l),tailCost=d.div(v).add(gs.div(v.pow(2)));
  ck(two.mul(a).add(d).add(a.mul(tailCost)).lt(o.sub(a)),"small or medium sign");
 }
 const den=o.sub(ll.pow(2));
 const left=al.mul(ll).mul(dlMid).div(den).add(al.mul(ll.pow(tail-1)).mul(dm).div(den));
 const tailCost=dl.div(den).add(gl.mul(o.add(ll.pow(2))).div(den.pow(2)));
 const right=al.mul(tailCost);
 const cost=two.mul(al).add(dl).add(left).add(right);
 ck(cost.lt(o.sub(al)),"large sign");
 ck(A.div(sd).add(n.div(D).mul(q(10,3)).mul(A.pow(3)).div(sd)).lt(q(1,40)),"phase stitch");
 text({K,cost:cost.val(),budget:o.sub(al).val()});
}
text("All central and outer bounds passed.");

console.log("PASS: long_cycles_ratio_16_replay-01");
