globalThis.text = console.log;
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const J=q(10,27),lam=q(63,100);
for(const [C,N,u,eta,D0,D1] of [[q(3),511,22,q(74,1000),q(244,1000),q(6,1000)],[q(2500,729),769,27,q(633,10000),q(266,1000),q(45,10000)]]){
 const A=J.add(q(1,u));
 const expo=one.div(two.mul(A).mul(A.add(q(1,u))));
 let t=one,z=one;for(let j=1;j<=14;j++){t=t.mul(expo).div(q(j));z=z.add(t)}
 assert(one.div(eta).lt(z));
 assert(C.mul(J.div(q(u)).add(q(1,N)).add(q(1,16))).lt(D0));
 assert(C.div(q(N)).lt(D1));
 assert(two.mul(C).mul(eta).div(one.sub(eta)).lt(one));
 const f=eta.div(one.sub(eta.pow(2))),g=eta.mul(one.add(eta.pow(2))).div(one.sub(eta.pow(2)).pow(2));
 assert(C.mul(g.add(lam.mul(f))).lt(lam.sub(D0)));
 assert(C.mul(one.add(D1).mul(g).add(one.sub(lam).add(D0).mul(f))).lt(one.sub(lam)));
 assert(A.div(q(u)).lt(q(1,40)));
 assert(q(N,N-1).mul(q(10,3)).mul(A.pow(3)).div(q(u)).lt(q(1,40)));
}
assert(q(473,1000).lt(one.sub(q(10,2*40**2))));
text("PASS: odd-tail edge and stitch constants through n=floor(2500 k/729)");

console.log("PASS: long_cycles_stitched_early_band-02");
