globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=128,sk=q(113,10),A=q(12,25),sd=q(39,2),xi=q(808,1000);
ck(q(100,57).lt(eb(q(57,100).sub(q(1,128)))[0]),"two-cycle maximum");
ck(q(69,100).lt(two.mul(q(1,3).add(q(1,81)))),"log two");
ck(q(77,1000).mul(q(3,2)).lt(q(116,1000)),"block mass");
ck(!two.mul(xi).lt(q(1).add(q(1,2)).add(q(116,1000))),"unweighted norm");
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
ck(pu.div(q(252)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log");
const ca=o.sub(q(18,100).sq().div(two));
ck(q(4,5).lt(q(82,100).mul(ca)),"vertical positive");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(ca).mul(pu.div(q(40))))),"splice rotation");
ck(q(4*128).mul(ex(q(1,6*383))).lt(q(4,3).mul(pl).mul(q(127))),"binomial peak");
const C=q(315,100),Ce=q(27,8),D=q(383),n=q(384);
ck(sk.sq().lt(q(K))&&sd.sq().lt(D)&&q(9).lt(A.mul(sd)),"edge endpoints");
ck(q(3).div(o.sub(o.div(two.mul(sk)))).lt(C),"plateau");
const e=q(135,1000),l=q(426,1000),a=q(155,1000);
ck(o.div(e).lt(eb(o.sub(q(2,27)).div(two.mul(A.sq())))[0]),"large outward");
ck(C.mul(e).lt(l)&&q(14).div(l).lt(eb(q(1791,392))[0]),"large ratios");
ck(C.sq().div(a.mul(o.sub(a))).lt(eb(o.div(A.sq()))[0]),"large curvature");
ck(two.mul(C).mul(e).div(o.sub(e.sq())).lt(o),"large witness");
const es=q(25,1000),ls=q(34,100),as=q(76,1000);
ck(o.div(es).lt(eb(q(1791,480))[0])&&q(14).div(ls).lt(eb(q(1791,480))[0]),"small outward");
ck(q(196).div(as.mul(o.sub(as))).lt(eb(q(1791,225))[0]),"small curvature");
ck(two.mul(ls).div(o.sub(es.sq())).lt(o),"small witness");
ck(q(7000).lt(eb(q(297,1000).mul(q(K)))[0]),"tiny drift");
const general=q(27,4),slopeS=q(18,1000),driftS=q(370,1000),slope=q(83,10000),drift=q(218,1000),left=q(466,1000);
const baseDrift=A.div(sd).add(o.div(two.mul(sk)));
ck(C.mul(baseDrift).lt(drift)&&C.div(n).lt(slope)&&general.mul(baseDrift).lt(left),"large drifts");
ck(general.mul(q(4,3*128).add(o.div(two.mul(sk)))).lt(driftS)&&general.div(n).lt(slopeS),"small drifts");
let d=o.sub(ls);
ck(two.mul(as).add(driftS).add(as.mul(driftS.div(d).add(slopeS.div(d.sq())))).lt(o.sub(as)),"small margin");
d=o.sub(l.sq());
const ev=a.mul(l).mul(left).div(d),od=a.mul(drift.div(d).add(slope.mul(o.add(l.sq())).div(d.sq())));
ck(two.mul(a).add(drift).add(ev).add(od).lt(o.sub(a)),"large margin");
ck(A.div(sd).lt(q(1,40))&&n.div(D).mul(q(10,3)).mul(A.sq().mul(A)).div(sd).lt(q(1,40)),"atan splice");
ck(o.div(A.sq()).div(o.sub(o.div(A.mul(sd)))).lt(q(49,10)),"floor correction");

const rows=[[3,510,5,0,0],[5,600,7,0,0],[7,640,8,70,3],[8,710,10,75,3],[10,770,12,75,4],[12,825,14,80,4]];
let covered=3;
for(const [B,a0,N,tilt0,L] of rows){
 ck(B<=covered,"interval overlap");
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=63;
 ck(two.lt(b.mul(q(m0*25**2-312))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=12;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0);
 const min=(a,b)=>a.lt(b)?a:b;
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2))))),x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(464,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 let W,eps,c,slice;
 if(!tilt0){
  const P=two.mul(ex(xi.mul(p)).sub(o)),xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=two.mul(ex(xc).sub(o).sub(xc)).add(q(116,1000).mul(x));
  W=up(high.mul(f).add(x.mul(j)).add(x.mul(ell).div(two)).add(g));
  let atom=o;for(let j=1;j<B;j++)atom=up(atom.mul(p.div(two)).div(q(j)));
  eps=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(P.div(q(K))).add(P.div(q(B*K))));
  c=o.sub(P);
  slice=c.mul(o.sub(pu.div(q(40)).sq().div(two))).sub(P.mul(pu.div(q(40))));
 }else{
  const al=q(tilt0,100),ea=ex(al);
  ck(ea.lt(q(3)),"tail tilt contraction");
  const tail=q(77,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
  const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
  const delta=q(464,1000).div(fact(L)),l=lat(L*K/2,0);
  eps=up(ex(xi.mul(p)).sub(o).mul(delta).add(em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o))));
  const far=o.add(delta).mul(em(al)).mul(j).add(two.add(delta).mul(em(al.mul(q(B-1)))).mul(f)).add(em(al.mul(q(B-L))).mul(l));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));
  const ref=q(4,3).div(a.div(sk).add(two));
  c=ref.sub(eps);slice=q(98,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(tilt0?two.mul(eps):eps);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const s0=a.sub(q(49,10).div(sk));
 ck(q(0).lt(s0)&&q(N).div(A.sq()).lt(s0.sq()),"join location "+B);
 covered=N;
 text({B,N,a:a.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
ck(covered>=14,"all intervals joined");
text("All exact bounds passed.");


console.log("PASS: long_cycles_all_n_k128-01");
