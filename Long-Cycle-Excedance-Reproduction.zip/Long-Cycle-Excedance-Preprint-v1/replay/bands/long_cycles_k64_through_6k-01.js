globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=64,sk=q(8),A=q(12,25),sd=q(138,10),xi=q(13,16);
const ca=o.sub(q(22,100).sq().div(two));
ck(pu.div(q(124)).mul(ex(q(5,16)).sq()).lt(q(22,100).sq()),"vertical log");
ck(q(76,100).lt(q(78,100).mul(ca)),"vertical positive");
ck(q(97,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(22,100).div(ca).mul(pu.div(q(40))))),"splice rotation");
const C=q(316,100),Ce=q(27,8),D=q(287),n=q(288);
const rows=[[3,481,4,0,0],[4,529,5,0,0],[5,572,6,0,0]];
let covered=3;
for(const [B,a0,N,tilt0,L] of rows){
 ck(B<=covered,"interval overlap");
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=31;
 ck(two.lt(b.mul(q(m0*25**2-312))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=12;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0);
 const min=(a,b)=>a.lt(b)?a:b;
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2))))),x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(1,2).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 let W,eps,c,slice;
 if(!tilt0){
  const pp=ex(xi.mul(p)).sub(o),al=q(55,100),ea=ex(al);
  const J=up(ea.add(ex(al.mul(two)).div(two)).add(q(83,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
  const pv=o.add(q(1,2).div(fact(3))).mul(pp).add(em(al.mul(q(B-3))).mul(ex(J.mul(p)).sub(o))); const P=min(two.mul(pp),pv),xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=two.mul(ex(xc).sub(o).sub(xc)).add(q(125,1000).mul(x));
  W=up(high.mul(f).add(x.mul(j)).add(x.mul(ell).div(two)).add(g));
  let atom=o;for(let j=1;j<B;j++)atom=up(atom.mul(p.div(two)).div(q(j)));
  eps=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(pp).div(q(K))).add(two.mul(pp).div(q(B*K))));
  c=o.sub(P);
  slice=c.mul(o.sub(pu.div(q(40)).sq().div(two))).sub(P.mul(pu.div(q(40))));
 }else{
  const al=q(tilt0,100),ea=ex(al);
  ck(ea.lt(q(3)),"tail tilt contraction");
  const tail=q(83,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
  const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
  const delta=q(1,2).div(fact(L)),l=lat(L*K/2,0);
  eps=up(ex(xi.mul(p)).sub(o).mul(delta).add(em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o))));
  const far=o.add(delta).mul(em(al)).mul(j).add(two.add(delta).mul(em(al.mul(q(B-1)))).mul(f)).add(em(al.mul(q(B-L))).mul(l));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));
  const ref=q(19,15).div(a.div(sk).add(two));
  const r2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); c=(ref.lt(r2)?r2:ref).sub(eps);slice=q(97,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(tilt0?two.mul(eps):eps);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const sqD=q(Math.floor(Math.sqrt(B*K-1)*10),10); ck(sqD.sq().lt(q(B*K-1)),"floor radicand"); const corr=o.div(A.sq()).div(o.sub(o.div(A.mul(sqD)))); const s0=a.sub(corr.div(sk));
 ck(q(0).lt(s0)&&q(N).div(A.sq()).lt(s0.sq()),"join location "+B);
 covered=N;
 text({B,N,a:a.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
ck(covered>=6,"all intervals joined");
text("All exact bounds passed.");

const lo=y=>eb(y)[0], K0=q(64), n0=q(192), D0=q(191),S0=q(138,10),A0=q(12,25),CH=q(318,100),CL=q(419,100);
ck(q(3).sub(q(2,79)).div(o.sub(o.div(q(16)))).lt(CH)&&q(4).div(o.sub(o.div(q(226,10)))).lt(CL),"caps");
ck(q(4*64).mul(ex(q(1,6*191))).lt(q(4,3).mul(pl).mul(q(63))),"binomial peak");
const a=q(158,1000),l=q(465,1000),e=q(146,1000),aa=q(17,1000),ll=q(20,100),ee=q(33,1000);
ck(o.div(e).lt(lo(o.div(A0.sq()).mul(q(1,2).sub(q(1,18)))))&&CH.mul(e).lt(l)&&q(6).div(l).lt(lo(q(383,72))),"high ratios");
ck(CH.sq().div(a.mul(o.sub(a))).lt(lo(o.div(A0.sq())))&&two.mul(CH).mul(e).div(o.sub(e.sq())).lt(o),"high curvature witness");
ck(o.div(ee).lt(lo(q(383,112)))&&q(6).mul(ee).lt(ll)&&q(36).div(aa.mul(o.sub(aa))).lt(lo(q(383,49)))&&q(12).mul(ee).div(o.sub(ee.sq())).lt(o),"low edge");
const d=q(315,1000),b=q(17,1000),dl=q(415,1000),bl=q(22,1000);
const BB=A0.div(S0).add(q(1,16));
ck(CH.mul(BB).lt(d)&&CH.div(n0).lt(b)&&CL.mul(BB).lt(dl)&&CL.div(n0).lt(bl),"drift");
ck(q(7000).lt(lo(q(2945,10000).mul(K0))),"heavy drift");
function margin(x,y,d,b,L=d){let z=o.sub(y.sq());return two.mul(x).add(d).add(x.mul(y).mul(L).div(z)).add(x.mul(d.div(z).add(b.mul(o.add(y.sq())).div(z.sq())))).lt(o.sub(x))}
ck(margin(a,l,d,b,dl)&&margin(aa,ll,dl,bl),"signed mean");
const cu=q(10,3).mul(A0.sq()).mul(A0).mul(n0.div(D0)), qa=q(1,40);
ck(q(40).mul(A0).sq().lt(q(369))&&cu.div(q(154,10)).lt(qa)&&cu.div(S0).sub(q(6,240)).lt(qa),"phase lower");
ck(q(6).mul(A0.div(S0).sq()).lt(q(1,100)),"atan fifth tail");
for(const [lower,upper,m,ss] of [[191,230,6,q(138,10)],[230,300,7,q(151,10)],[300,369,8,q(173,10)]]){
 const y=q(m,upper);
 ck(ss.sq().lt(q(lower))&&A0.div(ss).sub(q(3*(lower+1)).mul(q(99,100)).mul(y.sq()).mul(y)).lt(qa),"phase upper");
}
const vD=q(160), vN=q(161), sD=q(126,10), cap=q(275,100), pk=q(54,100);
ck(q(64).mul(ex(q(1,6*160))).lt(pk.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(63))),"early binomial");
ck(q(5,2).div(o.sub(o.div(q(113,10)))).lt(cap),"early plateau");
const tl=q(457,1000),ta=q(167,1000),te=q(166,1000),tl0=q(451,1000),ta0=q(122,1000),te0=q(150,1000);
ck(o.div(te).lt(lo(q(2).sub(q(4,18)).add(q(1,36)).sub(q(4,1080))))&&cap.mul(te).lt(tl)&&q(3).div(tl).lt(lo(q(160,50))),"early ratios");
ck(cap.sq().div(ta.mul(o.sub(ta))).lt(lo(q(4)))&&two.mul(cap).mul(te).div(o.sub(te.sq())).lt(o),"early high signs");
ck(o.div(te0).lt(lo(q(160,84)))&&q(3).mul(te0).lt(tl0)&&q(9).div(ta0.mul(o.sub(ta0))).lt(lo(q(160,36)))&&q(6).mul(te0).div(o.sub(te0.sq())).lt(o),"early low signs");
const dt=q(30,100),dt0=q(315,1000),bt=q(19,1000);
ck(cap.mul(q(1,2).div(sD).add(pk.div(q(8)))).lt(dt)&&q(3).mul(q(5,161).add(pk.div(q(8)))).lt(dt)&&q(3).mul(q(6,161).add(pk.div(q(8)))).lt(dt0)&&q(3).div(vN).lt(bt),"early drift");
ck(margin(ta,tl,dt,bt)&&margin(ta0,tl0,dt0,bt),"early signed mean");
const Amax=q(404,100);
ck(q(3*195*195,36*196).lt(Amax.sq())&&q(3*256,49).lt(Amax.sq()),"early splice modulus");
ck(q(1,2).div(sD).lt(q(1,8))&&q(10,24).mul(vN.div(vD)).div(sD).lt(q(1,8)),"early phase");
const b0=q(4).mul(pl.sq()).div(Amax.sq().mul(K0).add(q(10)));
function lats(m,w){let s=q(0);for(let j=1;j<=12;j++){const zz=b0.mul(q(j*(j+1)));s=s.add(q(w?2*j+1:1).mul(em(q(2*m).mul(zz).div(two.add(zz)))))}
 const zz=b0.mul(q(156));return up(s.add(em(q(2*(m-1)).mul(zz).div(two.add(zz))).div(b0.mul(q((m-1)*(w?1:27))))));}
ck(two.lt(b0.mul(q(31*25**2-312))),"early lattice");
const R0=q(162,1000),J0=q(123,10);
ck(o.add(Amax.sq().mul(K0).div(pl.sq())).div(K0.sq()).lt(R0.sq())&&J0.mul(R0).lt(two),"early R and L");
const f=lats(31,true),hh=lats(31,false),g=lats(63,true),j=lats(63,false);
const P=two.mul(ex(R0.mul(o.add(q(3,2).mul(hh)))).sub(o)),Z=two.mul(ex(R0.mul(q(3,2).add(q(4,3).mul(hh)))).sub(o));
const V=P.add(Z.mul(hh)).add(j), W=P.add(Z.mul(f)).add(g).add(o.add(j).div(J0));
ck(V.sq().add(W.sq()).lt(o)&&V.lt(q(3,4)),"early central ellipse and slice");

console.log("PASS: long_cycles_k64_through_6k-01");
