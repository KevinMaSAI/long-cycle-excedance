globalThis.text = console.log;
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const a=q(28,5),K=256, b=q(4).mul(pi.pow(2)).div(a.pow(2).mul(q(K)).add(q(10)));
const R=q(1116,10000), f=q(1036,1000),j=q(707,10000),g=q(203,10000),D=q(562,10000);
function lat(m){return three.div(one.add(two.mul(b)).pow(m)).add(q(5).add(one.add(q(6).mul(b)).div(b.mul(q(m-1)))).div(one.add(q(6).mul(b)).pow(m)))}
assert(q(2).lt(b.mul(q(26*127-12))));
assert(one.add(a.pow(2).mul(q(K)).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)));
assert(lat(127).lt(f)&&lat(384).lt(j)&&lat(512).lt(g));
assert(a.pow(2).mul(one.add(g.div(three)).pow(2)).div(q(4*K).mul(pi.pow(2))).lt(D.pow(2)));
const x=R.mul(q(3,2).add(two.mul(f).div(three)));
const P=two.mul(expUp(R.mul(one.add(two.mul(f).div(three)))).sub(one));
const W=two.mul(expUp(x).sub(one)).sub(x).mul(f).add(x.mul(j)).add(g);
const y=P.add(W.div(three)), z=P.add(W).add(D);
assert(y.lt(q(536,1000))&&z.lt(q(831,1000)));
assert(q(536,1000).pow(2).add(q(831,1000).pow(2)).lt(one));
const J=q(2,5), A=J.add(q(1,32)), H=q(5), L=q(262,100), l=q(3,5);
function eLower(x){let t=one,s=one;for(let i=1;i<=18;i++){t=t.mul(x).div(q(i));s=s.add(t)}return s}
assert(one.div(q(82,1000)).lt(eLower(one.div(two.mul(A).mul(A.add(q(1,32)))))));
assert(q(100).lt(eLower(q(1024,220))));
assert(L.mul(J.div(q(32)).add(q(1,1025)).add(q(1,16))).lt(q(1,5)));
assert(L.div(q(1025)).lt(q(26,10000)));
assert(H.mul(q(10,1025).add(q(1,16))).lt(q(362,1000)));
assert(H.div(q(1025)).lt(q(5,1000)));
assert(q(32,1025).lt(q(362,1000)));
assert(H.mul(J.div(q(32)).add(q(1,1025)).add(q(1,16))).lt(q(38,100)));
assert(q(5,2).div(one.sub(q(1,22))).lt(L));
for(const [C,e,d,m] of [[L,q(82,1000),q(1,5),q(26,10000)],[H,q(1,100),q(362,1000),q(5,1000)]]){
 const u=e.div(one.sub(e.pow(2))),v=e.mul(one.add(e.pow(2))).div(one.sub(e.pow(2)).pow(2));
 assert(two.mul(C).mul(e).div(one.sub(e)).lt(one));
 assert(C.mul(v.add(l.mul(u))).lt(l.sub(d)));
 assert(C.mul(one.add(m).mul(v).add(one.sub(l).add(d).mul(u))).lt(one.sub(l)));
}
assert(q(25,4).mul(H).lt(a.pow(2)));
assert(A.div(q(32)).lt(q(1,40)));
assert(q(1025,1024).mul(q(10,3)).mul(A.pow(3)).div(q(32)).lt(q(1,40)));
assert(q(536,1000).lt(one.sub(q(10,2*40**2))));
text("PASS: ratio-five central, outer and phase-stitch exact measurements");

console.log("PASS: long_cycles_stitched_early_band-04");
