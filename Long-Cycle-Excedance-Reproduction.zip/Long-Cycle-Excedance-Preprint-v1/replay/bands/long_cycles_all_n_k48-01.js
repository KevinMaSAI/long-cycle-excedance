globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=48,sk=q(69,10),xi=q(816,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[7,630,60,3,8],[8,661,60,3,9],[9,725,60,3,11],[11,783,60,3,13],[13,836,60,3,15],[15,863,60,3,16]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(26,100).sq().div(two));
ck(pu.div(q(92)).mul(ex(q(5,16)).sq()).lt(q(26,100).sq()),"vertical log");
ck(q(71,100).lt(q(74,100).mul(ca)),"vertical positive");
ck(q(92,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(26,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=23;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(524,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(87,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(136,1000):L===3?q(37,1000):q(524,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(104,100):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const ps=em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 if(B<8 && L===2){
  const P=min(U0.mul(abs),U.mul(abs).add(E.mul(ps))), xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=U0.mul(ex(xc).sub(o).sub(xc)).add(q(119,1000).mul(x));
  W=up(high.mul(f).add(U.mul(x).mul(j).div(two)).add((B>=4?U:U0).mul(x).mul(ell).div(q(4))).add(g));
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }else{
  const eps=up(abs.mul(delta).add(ps));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(B-1)))).mul(f)).add(E.mul(em(al.mul(q(B-L))).mul(fl)));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));let at=o;for(let j=1;j<B;j++)at=up(at.mul(p.div(two)).div(q(j)));drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(at).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  let ref=max(q(71,60).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(3,4)); if(pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  c=ref.sub(eps);slice=q(92,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const mr=Math.floor(Math.sqrt(N*K-1)/2);
 ck(4*mr*mr<=N*K-1 && N*K-1<4*(mr+1)*(mr+1),"cut index");
 const wcut=q(4*mr*mr-1,mr-1).div(sk), w1=q(4*(mr+1)*(mr+1)-1,mr).div(sk), vmax=q(4*N).mul(o.add(q(1,mr)).sq()),v2=q(4*N).mul(o.add(q(1,mr+1)).sq());
 ck(wcut.lt(a)&&(w1.lt(a)||vmax.lt(a.sq()))&&v2.lt(a.sq()),"floor splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0], pk=q(45,100),k0=q(48),sk0=q(69,10),D=q(335),n0=q(336),sp=q(183,10),v=D.div(n0),A=q(42,100),C=q(27,8);
ck(q(48).mul(ex(q(1,6*335))).lt(pk.sq().mul(two).mul(pl).mul(q(6,7)).mul(q(47))),"modal binomial");
function lp(x){return q(47).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))))}
function upL(x){return x.sq().div(two).add(x.sq().mul(x).div(q(3)))}
function geom(x,y){return x.div(o.sub(y));}
const a1=q(13,100),a2=q(13,100),a3=q(195,1000),a4=q(26,100);
ck(q(142,100).lt(q(64,45))&&q(9).lt(q(47).mul(q(21,100))),"case 1 long slope");
ck(q(285,1000).add(o).lt(q(9,7))&&q(6).lt(q(47).mul(q(285,2000))),"case 2 long slope");
ck(q(123,100).lt(q(40,33).mul(q(63,62)))&&q(5).lt(q(47).mul(q(23,200))),"case 3 long slope");
ck(q(1478,1000).lt(q(3).div(q(186,100).mul(q(12,11))))&&q(11).lt(q(47).mul(q(478,2000))),"case 4 long slope");
for(const [eps,hard,x,ge,pf,other] of [
[a1,q(11,100),q(42,100),9,q(222,1000),q(0)],
[a2,q(31,1000),q(285,1000),6,q(295,1000),q(0)],
[a3,q(8,1000),q(23,100),5,q(35,100),q(0)],
[a4,q(78,1000),q(478,1000),11,q(204,1000),q(5,4).mul(em(q(48).mul(upL(q(266,1000)))))]
]){
 ck(pk.div(sk0.mul(o.sub(o.div(o.add(x))))).lt(pf),"long prefactor");
 const fac=eps===a4?q(5,6):q(3,2);
 ck(hard.add(fac.mul(pf).mul(geom(em(lp(x)),em(q(ge))))).add(other).lt(eps),"profile error");
}
ck(q(11,15).lt(q(734,1000))&&pk.div(sk0.mul(q(266,1000))).lt(q(1,4)),"short prefactor");
ck(q(48,47).mul(q(10,9)).mul(q(5,7)).lt(q(812,1000)),"singleton suppressed derivative");
const L0=q(282,100),R0=q(186,100),oneB=q(188,1000);
for(const [e,r,h,r1,mul,sup] of [
[a1,q(9,8),q(132,100),q(7,8),o,o],
[a2,q(10,9),q(128,100),q(8,9),o,o],
[a3,q(11,10),q(50,100),q(9,10),o,em(q(47).mul(upL(oneB)))],
[a4,q(12,11),q(74,100),q(10,11),ex(q(1,2)),o]
]){
 ck(mul.mul(pk).mul(sup).div(sk0.mul(A.mul(r1).sq())).lt(h),"derivative");
 ck(o.add(h.add(two.mul(e)).div(o.sub(e))).lt(L0)&&r.mul(o.add(e)).div(o.sub(e)).lt(R0),"neighbor ratios");
}
const eH=q(156,1000),lH=q(45,100),aH=q(11,100),lL=q(48,100),aL=q(18,100);
const e1=q(91,1000),e2=q(127,1000),e3=q(112,1000);
ck(o.div(eH).lt(lo(q(2).sub(q(4,27)).add(q(1,81)).sub(q(4,3645))))&&L0.mul(eH).lt(lH),"high step");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&q(81,16).div(lH).lt(lo(v.mul(sp).mul(q(2).sub(q(50,31))))),"profile exits");
function curv(x,y,a){return x.div(a.mul(o.sub(a))).lt(lo(y));}
ck(curv(L0.mul(R0),q(4),aH),"high curvature");
const dl1=D.div(q(64)), dl2=q(8,9).sq().div(A.sq()).sub(q(1,81)), dl3=q(10,11).sq().div(A.sq()).sub(q(1,121));
for(const [base,eta,fac,minR] of [[dl1,e1,q(3,2),8],[dl2,e2,q(10,9),9],[dl3,e3,q(12,11),11]]){
 ck(o.div(eta).lt(lo(base.mul(q(1,2).sub(q(1,3*minR)))))&&C.mul(fac).mul(eta).lt(lL),"low pure region");
 ck(curv(C.sq().mul(fac),base,aL),"low curvature region");
}
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L0.add(R0).mul(eH).add(cost(eH,8,true)).lt(o),"high witness");
ck(o.div(q(77,1000)).lt(lo(o.div(A.sq()).sub(q(1,64)).mul(q(1,2).sub(q(1,24)))))&&o.div(q(46,1000)).lt(lo(D.div(q(49)).mul(q(1,2).sub(q(1,21))))),"witness loss");
ck(cost(q(77,1000),8,false).lt(o)&&cost(q(46,1000),1,false).lt(o),"low witness");
const d=q(333,1000),b=q(11,1000),C3=q(358,100),x=q(1329,1000);
ck(q(10,3).div(o.sub(o.div(q(16)))).lt(C3)&&C3.mul(q(1,2).div(sp).add(pk.div(sk0))).lt(d)&&C3.div(n0).lt(b),"drift");
ck(x.lt(q(4,3).mul(v))&&q(16).lt(q(329,1000).mul(k0).add(o)),"drift spacing");
ck(C.div(v).mul(x).mul(pk).div(sk0).mul(geom(em(lp(q(329,1000))),em(q(16)))).lt(q(1,10)),"drift below cap");
for(const [a,l] of [[aH,lH],[aL,lL]]){const zz=o.sub(l.sq());ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(zz)).add(a.mul(d.div(zz).add(b.mul(o.add(l.sq())).div(zz.sq())))).lt(o.sub(a)),"signed means");}
ck(q(1,2).div(sp).lt(q(1,16))&&q(10,24).div(v.mul(sp)).lt(q(1,16)),"phase");
ck(q(1,8).sq().lt(o)&&pu.div(q(4).mul(sk0)).lt(q(1,8)),"sharper log separation");

function hardSum(weights,err,begin,c,n=10){
 let s=q(0);for(let i=0;i<begin;i++){
 let w=o;for(let j=1;j<=i;j++)w=w.mul(weights).div(q(j));
 s=s.add(w.mul(err[i]));
 }
 let w=o;for(let j=1;j<=begin;j++)w=w.mul(weights).div(q(j));
 return s.add(c.mul(w).div(o.sub(weights.div(q(begin+1)))));
}
const ea=q(16,100000), eb0=q(2,1000), ec=q(8,100), ee=q(172,100);
ck(hardSum(o,[eb0,eb0,ec,ec,o,o,o,ee],8,q(3)).lt(q(11,100)),"hard cost case 1");
ck(hardSum(o,[ea,eb0,eb0,ec,ec,o,o,o],8,q(3)).lt(q(31,1000)),"hard cost case 2");
ck(hardSum(o,[ea,ea,eb0,eb0,ec,ec,o,o],8,q(3)).lt(q(8,1000)),"hard cost case 3");
ck(hardSum(q(1,2),[eb0,ec,ec,o,o],5,q(5)).lt(q(78,1000)),"hard cost case 4");

console.log("PASS: long_cycles_all_n_k48-01");
