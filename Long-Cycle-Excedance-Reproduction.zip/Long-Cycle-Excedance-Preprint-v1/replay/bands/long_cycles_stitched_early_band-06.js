globalThis.text = console.log;
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const a=q(53,8),K=256,b=q(4).mul(pi.pow(2)).div(a.pow(2).mul(q(K)).add(q(10)));
const R=q(132,1000),f=q(1630,1000),h=q(489,1000),l=q(84,1000),j=q(343,10000),g=q(14,1000);
function up(num,den){const QN=1000000000n;return q((num*QN+den-1n)/den,QN)}
function lat(m,w=true){let s=q(0);const mm=BigInt(m),bp=b.b**mm;
for(let j=1;j<=6;j++)s=s.add(up(BigInt(w?2*j+1:1)*bp,(b.b+b.a*BigInt(j*(j+1)))**mm));
return s.add(up(bp,b.a*(mm-1n)*(b.b+42n*b.a)**(mm-1n)*(w?1n:13n)));}
assert(q(2).lt(b.mul(q(26*127-12))));
assert(one.add(a.pow(2).mul(q(K)).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)));
assert(lat(127).lt(f)&&lat(127,false).lt(h)&&lat(512).lt(l)&&lat(640).lt(j)&&lat(768).lt(g));
const x=R.mul(q(3,2).add(q(4,3).mul(h))),p=R.mul(one.add(q(3,2).mul(h)));
const P=two.mul(expUp(p).sub(one)),c=q(485,1000);assert(c.lt(one.sub(P)));
const W=two.mul(expUp(x).sub(one)).sub(q(3,2).mul(x)).mul(f).add(x.mul(j)).add(x.mul(l).div(two)).add(g);
const V=q(138,1000),w=q(457,1000),D=q(442,10000);
assert(two.mul(a).mul(one.add(g.div(three))).div(q(6*16).mul(pi)).lt(D));
assert(W.div(three).lt(V)&&W.add(D).lt(w));
const d=q(4,1000),head=p.div(two);
const coeff=head.div(q(K+1)).mul(expUp(p)).add(head.pow(4).div(q(24)).mul(expUp(head)));
assert(two.mul(coeff).add(P.div(q(K))).add(two.mul(P).div(q(6*K))).lt(d));
assert(V.pow(2).add(w.add(d).pow(2)).lt(c.pow(2)));
const J=q(2,5),A=J.add(q(1,39)),H=q(7),L=q(281,100),lam=q(3,5),N=1537;
function eLower(x){let t=one,s=one;for(let i=1;i<=18;i++){t=t.mul(x).div(q(i));s=s.add(t)}return s}
assert(one.div(q(75,1000)).lt(eLower(one.div(two.mul(A).mul(A.add(q(1,39)))))));
assert(q(1000).lt(eLower(q(N-1,2*10*11))));
assert(L.mul(J.div(q(39)).add(q(1,N)).add(q(1,16))).lt(q(207,1000)));
assert(L.div(q(N)).lt(q(19,10000)));
assert(H.mul(q(10,N).add(q(1,16))).lt(q(484,1000)));
assert(H.div(q(N)).lt(q(5,1000)));
assert(q(48,N).lt(q(484,1000)));
assert(H.mul(J.div(q(39)).add(q(1,N)).add(q(1,16))).lt(q(52,100)));
assert(q(27,10).div(one.sub(q(1,26))).lt(L));
for(const [C,e,d,m] of [[L,q(75,1000),q(207,1000),q(19,10000)],[H,q(1,1000),q(484,1000),q(5,1000)]]){
 const u=e.div(one.sub(e.pow(2))),v=e.mul(one.add(e.pow(2))).div(one.sub(e.pow(2)).pow(2));
 assert(two.mul(C).mul(e).div(one.sub(e)).lt(one));
 assert(C.mul(v.add(lam.mul(u))).lt(lam.sub(d)));
 assert(C.mul(one.add(m).mul(v).add(one.sub(lam).add(d).mul(u))).lt(one.sub(lam)));
}
assert(q(25,4).mul(H).lt(a.pow(2)));
assert(A.div(q(39)).lt(q(1,40)));
assert(q(N,N-1).mul(q(10,3)).mul(A.pow(3)).div(q(39)).lt(q(1,40)));
assert(V.lt(c.mul(one.sub(q(10,3200))).sub(P.mul(q(22,280)))));
text("PASS: ratio-seven central geometry, amplitude drift, edge and stitch");

console.log("PASS: long_cycles_stitched_early_band-06");
