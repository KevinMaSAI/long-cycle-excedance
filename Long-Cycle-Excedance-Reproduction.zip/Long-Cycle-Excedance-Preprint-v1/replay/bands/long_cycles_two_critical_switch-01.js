globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[128,20,16,200,6,21],[128,21,17,200,6,22],[128,22,17,200,6,23],[128,23,17,200,6,24],[128,24,18,200,6,25],[128,25,18,200,6,26],[128,26,21,200,6,37],[128,37,29,200,6,68]];
const covered={128:20};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(29,10).div(sk));
 ck(q(0).lt(rad)&&q(25*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const exl=y=>eb(y)[0],exu=y=>eb(y)[1],C=q(27,8), v=q(2559,2560), sk=q(113,10), n0=q(2560), eM=q(116,1000), eH=q(26,100), eL=q(1,1000);
ck(covered[128]>=44,"overlap");
ck(o.lt(q(4).mul(q(43,100).sq()).mul(pl).mul(q(11,24)).mul(q(95,100)).mul(q(127,128))),"Fourier main");
ck(q(800).lt(exl(q(40))),"Fourier tail");
function geo(first,ratio){return first.div(o.sub(ratio));}
function expbad(x){return em(q(128).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3)))));}
const rate1=q(23,36),c1=q(277,1000), c2=q(3,10),f1=q(33,1000),f2=q(14,1000),L=q(168,100),R=q(112,100);
ck(o.add(c1).lt(q(23,18))&&q(17).lt(q(128).mul(rate1.sub(q(1,2)))),"long b2");
ck(q(14,10000).add(q(3,2).mul(geo(expbad(c1),em(q(17))))).lt(f1),"one-cycle model error");
let mx=q(62,100).sq().mul(q(255,20)).mul(q(31,30).sq());
ck(mx.lt(q(30,13).sq())&&q(12).lt(q(128).mul(q(13,30).sub(q(1,3)))),"long b3");
let x=q(31,100), sh=q(128).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3))));
ck(q(4,10000).add(q(5).mul(em(sh))).add(q(5,6).mul(geo(expbad(c2),em(q(12))))).lt(f2),"two-cycle model error");
const A=q(45,100),r1=A.mul(q(22,23)),r2=A.mul(q(29,30));
ck(exu(o).mul(A).div(sk.mul(r1.sq())).lt(q(59,100)),"one-cycle derivative");
ck(exu(q(1,2)).mul(A).div(sk.mul(r2.sq())).lt(q(36,100)),"two-cycle derivative");
for(const [h,eps,b] of [[q(59,100),f1,q(24,23)],[q(36,100),f2,q(31,30)]]){
ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L) && b.mul(o.add(eps)).div(o.sub(eps)).lt(R),"profile ratios");
}
const lH=q(44,100),lM=q(43,100), lL=q(6,1000),aH=q(14,100),aM=q(16,100);
ck(o.div(eH).lt(exl(q(25,9).mul(q(1,2).sub(q(1,90))))),"high pure");
ck(o.div(eM).lt(exl(v.div(two.mul(q(47,100)).mul(q(49,100))))),"middle pure");
ck(q(1000).lt(exl(q(2559,220))),"low pure");
ck(C.div(lH).lt(exl(v.div(two.mul(A.sq())))) && q(81,16).div(lH).lt(exl(v.mul(q(50)).mul(q(5,3).sub(q(50,31))))),"profile exit");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(exl(q(25,9))),"high curvature");
ck(C.sq().mul(q(23,22)).div(aM.mul(o.sub(aM))).lt(exl(v.div(q(47,100).sq()))) && C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(exl(q(2559,441))),"middle curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,23,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witness");
const d=q(35,100),b=q(27,10000),C2=two.mul(C);
ck(C2.mul(q(6,10).div(q(50)).add(A.div(sk))).lt(d)&&C2.div(n0).lt(b),"drift");
ck(q(7000).lt(exl(q(2995,10000).mul(q(128)))),"heavy drift");
for (const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){
const z=o.sub(l.sq());
ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");
}

console.log("PASS: long_cycles_two_critical_switch-01");
