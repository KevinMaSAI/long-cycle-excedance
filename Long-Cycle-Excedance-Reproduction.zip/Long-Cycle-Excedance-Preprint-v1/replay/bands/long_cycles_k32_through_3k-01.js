globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}

const pl=q(157,50),pu=q(22,7),K=q(32),sk=q(565,100),lo=x=>eb(x)[0];
function sc(a,RR,B,short){
 const R=q(RR,1000),b=q(4).mul(pl.sq()).div(a.sq().mul(K).add(q(10)));
 ck(o.add(a.sq().mul(K).div(pl.sq())).div(K.sq()).lt(R.sq())&&two.lt(b.mul(q(15*25**2-312))),"lattice radius");
 function latEarly(m,weighted){
 let s=q(0);for(let l=1;l<=12;l++){const u=b.mul(q(l*(l+1)));s=s.add(q(weighted?2*l+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return s.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(weighted?1:27)))));
 }
 const f=latEarly(15,true),h=latEarly(15,false),g=latEarly(short?32:40,true),j0=latEarly(short?32:40,false),j=short?f:latEarly(24,true);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 const coeff=q(1,4).add(q(1,66));
 const ext=y=>short?q(0):y.sq().mul(coeff).add(y.mul(q(2,33)));
 const P=p.mul(q(3,2)).add(ext(p)), c=o.sub(P);
 const W=x.mul(j).add(x.div(two).add(ext(x)).mul(f)).add(g), V=W.div(q(3));
 const mismatch=o.add(j0).mul(R).div(B);
 const norm=two.mul(ex(q(823,1000).mul(p)).sub(o));
 const drift=short?p.div(q(33)).add(P.div(K)).add(P.div(B.mul(K))):p.mul(ex(p)).div(q(33)).add(p.div(two).sq().mul(ex(p.div(two)))).add(norm.div(K)).add(norm.div(B.mul(K)));
 const slice=c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))));
 text({a:a.val(),V:V.val(),W:W.val(),c:c.val(),drift:drift.val(),mismatch:mismatch.val(),slice:slice.val()});
 ck(q(0).lt(c)&&V.sq().add(W.add(drift).add(mismatch).sq()).lt(c.sq())&&V.lt(slice),"signed ellipse and splice no-root slice");
}
sc(q(392,100),225,q(2),true);
sc(q(43,10),246,q(5,2),false);

const pk1=q(58,100),pk2=q(54,100),H1=q(5,2),H2=q(3),D1=q(64),D2=q(80),C5=q(292,100);
function curv(C,s,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(s))}
function wit(C,e){return two.mul(C).mul(e).div(o.sub(e.sq())).lt(o)}
function margin(al,ar,l,d,b){let z=o.sub(l.sq());
 const f=al.add(d).add(al.mul(l).mul(d).div(z)).div(o.sub(al));
 const r=ar.add(ar.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).div(o.sub(ar));
 return f.add(r).lt(o);
}
ck(K.mul(ex(q(1,6*64))).lt(pk1.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(31)))&&K.mul(ex(q(1,6*80))).lt(pk2.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(31))),"Robbins modes");
const e1=q(181,1000),l1=q(453,1000),a1=q(133,1000),d1=q(414,1000),b1=q(39,1000);
const L4=q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80));
ck(o.div(e1).lt(lo(L4))&&o.div(e1).lt(lo(q(2).sub(q(4,15))))&&H1.mul(e1).lt(l1)&&curv(H1,q(4),a1)&&wit(H1,e1),"first witnesses and ratios");
ck(H1.mul(q(1,16).add(pk1.div(sk))).lt(d1)&&H1.div(q(65)).lt(b1)&&margin(a1,a1,l1,d1,b1),"first signed margin");
const e2=q(125,1000),l2=q(376,1000),a2=q(66,1000),d2=q(475,1000),b2=q(4,100);
ck(o.div(e2).lt(lo(q(25,12)))&&H2.mul(e2).lt(l2)&&curv(H2,q(5),a2)&&wit(H2,e2),"second low brackets");
ck(H2.mul(q(5,81).add(pk2.div(sk))).lt(d2)&&H2.div(q(81)).lt(b2)&&margin(a2,a2,l2,d2,b2),"second low sign");
ck(q(13,5).sub(q(1,47)).div(o.sub(o.div(q(874,100)))).lt(C5),"cap at five");
const e5=q(171,1000),r5=q(14,1000000),al=q(18,1000),ar=q(195,1000),l5=q(1,2);
const L5=q(2).sub(q(4,15)).add(q(1,25)).sub(q(4,625));
ck(o.div(e5).lt(lo(L5))&&C5.mul(e5).lt(l5)&&q(3).div(l5).lt(lo(q(100,32))),"cap at five ratios");
ck(curv(H2,q(100,16),al)&&curv(C5,q(4),ar)&&margin(al,ar,l5,d2,b2),"cap at five sign");
ck(o.div(r5).lt(lo(q(45,4)))&&two.mul(C5).mul(e5.add(r5.div(o.sub(e5.sq())))).lt(o),"cap five witness");
ck(q(5*99*99,2*16*100).lt(q(392,100).sq())&&q(72,5).lt(q(392,100).sq()),"first S");
ck(q(3*99*99,16*100).lt(q(43,10).sq())&&q(432,25).lt(q(43,10).sq()),"second S");
ck(q(1,16).lt(q(1,8))&&q(10,24).mul(q(65,64)).div(q(8)).lt(q(1,8)),"phase");

console.log("PASS: long_cycles_k32_through_3k-01");
