globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const lo=y=>eb(y)[0],eu=y=>eb(y)[1],pl=q(157,50),pu=q(22,7), d=q(11),D=q(4799),n0=q(4800), sp=q(69), C=q(27,8),A=q(4,5),v=D.div(n0),pi2=pu.sq();
ck(q(620,7).lt(lo(q(9,2))),"log cutoff");
ck(q(12,11).sq().add(q(12,11).mul(eu(o))).lt(q(21,5)),"kernel numerator");
ck(q(2).mul(pu).mul(q(21,10)).mul(q(11,2)).lt(q(73)),"Taylor bound");
ck(q(12,11).mul(pu).lt(q(4)) && eu(q(4)).lt(q(55)),"denominator exponential");
ck(q(300).mul(q(55)).mul(q(164,100)).div(pl).lt(q(10000)),"contour prefactor");
ck(q(10000*62*25200*1000).lt(lo(q(54))),"contour error");
ck(q(5,4).add(q(8,5).div(sp)).sq().add(q(10,4800)).lt(q(164,100)),"rho bound");
ck(q(121,288).mul(q(6)).mul(q(4)).mul(pl.sq()).lt(q(100))&&q(98).lt(q(121,288).mul(q(6)).mul(q(4)).mul(pl.sq())),"short-s radial");
ck(q(10).lt(q(121,288).mul(q(4)).mul(pl.sq()).div(q(164,100))),"long-s radial");
ck(q(10,128).add(q(23,22).mul(o.add(q(10,64*11)))).lt(q(115,100))&&eu(q(115,100)).lt(q(32,10)),"vertical exponential");
ck(q(16,5).mul(q(525,1000)).div(q(331,100)).lt(q(51,100))&&q(331,100).sq().lt(q(11))&&o.lt(q(4,10).sq().mul(two).mul(pl)),"vertical derivative");
ck(q(51,100).mul(two).mul(pu).add(q(2,1000)).lt(q(33,10)),"residue ratio");
ck(q(10000).lt(lo(q(12)))&&q(10000).lt(lo(q(50))),"far-error tails");
ck(q(26).lt(q(8).mul(q(331,100)))&&q(1000).mul(o.add(q(106,100).mul(q(26)))).lt(lo(q(26)).sub(o)),"logistic correction");
ck(q(12,11).sq().mul(o.add(q(10,64*11))).lt(q(11,10).sq()),"pole radius to s");
ck(q(1000).mul(o.add(q(11,10).mul(q(26)))).lt(lo(q(26)).sub(o)),"uniform logistic correction");
ck(q(9).mul(q(62).sq()).lt(q(25,16).mul(q(400*63-1))),"splice s>=3d");
ck(o.add(q(10,33*33)).lt(q(102,100).sq())&&q(2).lt(lo(q(7,10))),"splice incomplete gamma");
ck(q(2000).lt(lo(q(77,100).mul(d)))&&q(2).lt(lo(q(49,100).mul(q(33)))),"splice G small");

const F=q(999,1000),eta=q(463,1000),lambda=q(493,1000),alpha=q(31,100),x3=q(14,10000),pk=q(45,100),sk=q(346,100);
ck(q(9,10).sq().mul(q(63,400)).lt(q(3,8).sq())&&q(8,3).lt(lo(o))&&q(1000).lt(lo(q(8))),"heavy good-label bound");
ck(sk.sq().lt(q(12))&&q(12).mul(eu(q(1,6*4799))).lt(pk.sq().mul(two).mul(pl).mul(q(99,100)).mul(q(11))),"Robbins peak");
ck(o.div(eta).lt(lo(o.div(A.sq()).mul(q(1,2).sub(q(1,165))))),"initial pure loss");
ck(o.div(x3).lt(lo(q(9).div(two.mul(A.sq())).mul(q(55,58)))),"third witness ratio");
ck(q(1000).lt(lo(D.div(q(2*16*17))))&&eta.mul(q(17,16)).div(F).lt(lambda)&&q(81,16).div(lambda).lt(lo(v.mul(sp).mul(q(5,36)))),"outward ratios");
ck(o.div(F.sq().mul(alpha).mul(o.sub(alpha))).lt(lo(o.div(A.sq()))),"curvature");
const z=o.sub(eta.sq());
ck(two.div(F).mul(eta.add(x3.mul(q(19,16).div(z).add(eta.sq().div(q(8).mul(z.sq())))))).lt(o),"opposing witness");
const ex0=q(266,100),C2=q(446,100),small=q(1,1000);
ck(ex0.lt(q(8,3).mul(v))&&q(20).lt(q(166,100).mul(q(12)).add(o)),"small drift spacing");
ck(C.div(v).mul(ex0).mul(pk).div(sk).mul(em(q(66,100).mul(q(11)))).div(o.sub(em(q(20)))).lt(small),"small drift value");
ck(q(7000,640).lt(lo(q(299,1000).mul(q(12)))),"remaining heavy drift");
const dd=q(64,100),db=q(93,100000);
ck(q(4).div(o.sub(o.div(q(978,100)))).lt(C2)&&C2.mul(A.div(sp).add(pk.div(sk))).lt(dd)&&C2.div(n0).lt(db),"large drift values");
const w=o.sub(lambda.sq()),u=o.sub(lambda);let v5=o;for(let j=0;j<5;j++)v5=v5.mul(lambda);
const late=alpha.mul(v5).mul(dd.add(q(6).mul(db)).div(u).add(db.mul(lambda).div(u.sq())));
ck(two.mul(alpha).add(small).add(alpha.mul(lambda).mul(small).div(w)).add(alpha.mul(small).div(w)).add(late).lt(o.sub(alpha)),"signed mean");
ck(o.div(A.sq()).div(o.sub(o.div(A.mul(sp)))).lt(q(8,5)),"floor bound");
ck(two.mul(A).div(sp).lt(q(1,32))&&q(10,3).mul(A.sq()).mul(A).mul(q(4801,4799)).div(sp).lt(q(1,32)),"splice phase");

console.log("PASS: long_cycles_uniform_residue_400k-01");
