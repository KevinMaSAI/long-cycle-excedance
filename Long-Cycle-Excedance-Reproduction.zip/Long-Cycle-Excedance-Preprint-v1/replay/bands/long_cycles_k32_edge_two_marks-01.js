globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}

const lo=x=>eb(x)[0],eu=x=>eb(x)[1],C=q(27,8),K=q(32),sk=q(565,100),pl=q(157,50),p=q(1,2),n0=q(96),D=q(95),sv=q(974,100),A=q(1,2),F=q(3,5);
ck(sk.sq().lt(K)&&sv.sq().lt(D)&&q(47,12).lt(q(4)),"range and beta ceiling");
ck(K.mul(eu(q(1,6*95))).lt(p.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(31))),"Robbins a");
function Phi(w,upper){const x=upper?o.sub(w):w.sub(o), cubic=x.sq().mul(x).div(q(3));return upper?x.sq().div(two).add(cubic):x.sq().div(two).sub(cubic);}
function lowerTail(w){return p.div(sk.mul(o.sub(o.div(w)))).mul(em(q(31).mul(Phi(w,false))));}
function upperTail(w){return p.div(sk.mul(o.sub(w))).mul(em(q(32).mul(Phi(w,true))));}
function bad(U,w){return lowerTail(w).div(q(U).mul(o.sub(em(q(31).mul(w.sub(o)).div(q(U))))));}
ck(bad(2,q(10,7)).lt(q(21,1000)),"U2 long");
ck(bad(3,q(30,17)).lt(q(2,1000))&&bad(3,q(3,2)).lt(q(7,1000)),"U3 long");
ck(q(68,100).lt(o.sub(lowerTail(q(6,5))))&&q(6,5).lt(q(20,17).mul(q(47,46))),"doubleton success");
ck(upperTail(q(25,28)).lt(q(68,100))&&upperTail(q(5,7)).lt(q(66,1000))&&upperTail(q(25,34)).lt(q(9,100))&&upperTail(q(10,17)).lt(q(7,1000)),"singleton success");
const bp=q(339,1000),qp=q(36,100),right=q(38,100),rp=q(64,100);
ck(rp.mul(bp).lt(two.mul(qp).mul(right))&&right.mul(qp).lt(rp.mul(bp)),"monotonic ratios A");
ck(o.div(bp).lt(q(295,100))&&q(6,5).mul(right.add(rp)).div(bp.add(qp)).lt(q(176,100))&&right.div(bp.sq()).lt(q(332,100)),"neighbors A");
for(const [den,left,u,L,R,cur] of [[q(266,1000),q(8152,10000),q(42224,100000),q(308,100),q(192,100),q(488,100)],[q(193,1000),q(4376,10000),q(38448,100000),q(228,100),q(240,100),q(455,100)]]){
ck(left.div(den).lt(L)&&q(6,5).mul(u).div(den).lt(R)&&left.mul(u).div(den.sq()).lt(cur),"neighbors B,C");
}
const eta=q(172,1000),eL=q(136,1000),lam=q(44,100),alpha=q(10,100);
ck(q(1000,136).lt(lo(q(2)))&&o.div(eta).lt(lo(q(2).sub(q(4,15)).add(q(1,25)).sub(q(4,625))))&&o.div(eta).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"pure first");
ck(q(308,100).mul(eL).lt(lam)&&q(240,100).mul(eta).lt(lam)&&C.mul(q(3,2)).div(lam).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"actual ratios");
ck(q(488,100).div(alpha.mul(o.sub(alpha))).lt(lo(q(4)))&&C.sq().mul(q(3,2)).div(alpha.mul(o.sub(alpha))).lt(lo(D.div(q(16)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R] of [[q(295,100),q(176,100)],[q(308,100),q(192,100)],[q(228,100),q(240,100)]])ck(L.mul(eL).add(R.mul(eta)).add(cost(eta,5,true)).lt(o),"high witness");
const tiny=q(17,1000),t4=q(85,1000);
ck(o.div(tiny).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&o.div(t4).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"low pure");
ck(cost(tiny,1,false).lt(o)&&cost(t4,4,false).lt(o),"low witness");
const C3=q(362,100),dd=q(51,100),bb=q(38,1000),xx=q(1319,1000),v=D.div(n0);
ck(q(10,3).div(o.sub(o.div(q(13)))).lt(C3)&&C3.mul(A.div(sv).add(p.div(sk))).lt(dd)&&C3.div(n0).lt(bb),"cap drift");
ck(xx.lt(q(4,3).mul(v))&&q(11).lt(q(319,1000).mul(K).add(o)),"lower drift threshold");
ck(C.div(v).mul(xx).mul(p).div(sk).mul(em(q(31).mul(Phi(xx,false)))).div(o.sub(em(q(11)))).lt(q(12,100)),"lower drift bound");
const z=o.sub(lam.sq());
ck(two.mul(alpha).add(dd).add(alpha.mul(lam).mul(dd).div(z)).add(alpha.mul(dd.div(z).add(bb.mul(o.add(lam.sq())).div(z.sq())))).lt(o.sub(alpha)),"signed margin");
ck(q(1,2).div(sv).lt(q(1,16))&&q(10,24).mul(n0.div(D)).div(sv).lt(q(1,16)),"phase near splice");

console.log("PASS: long_cycles_k32_edge_two_marks-01");
