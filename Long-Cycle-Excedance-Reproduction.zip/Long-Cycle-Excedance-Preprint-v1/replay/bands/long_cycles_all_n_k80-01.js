globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=80,sk=q(89,10),A=q(12,25),sd=q(154,10),xi=q(816,1000);
const ca=o.sub(q(20,100).sq().div(two));
ck(pu.div(q(156)).mul(ex(q(5,16)).sq()).lt(q(20,100).sq()),"vertical log");
ck(q(78,100).lt(q(80,100).mul(ca)),"vertical positive");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(20,100).div(ca).mul(pu.div(q(40))))),"splice rotation");
const C=q(316,100),Ce=q(27,8),D=q(287),n=q(288);
const rows=[[3,524,5,0,0],[5,565,6,0,0],[6,606,7,0,0],[7,643,8,0,0],[8,679,9,65,3],[9,712,10,65,3],[10,775,12,65,3]];
let covered=3;
for(const [B,a0,N,tilt0,L] of rows){
 ck(B<=covered,"interval overlap");
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=39;
 ck(two.lt(b.mul(q(m0*25**2-312))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=12;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0);
 const min=(a,b)=>a.lt(b)?a:b;
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2))))),x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(524,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 let W,eps,c,slice;
 if(!tilt0){
  const pp=ex(xi.mul(p)).sub(o),al=q(55,100),ea=ex(al);
  const J=up(ea.add(ex(al.mul(two)).div(two)).add(q(87,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
  const pv=o.add(q(524,1000).div(fact(3))).mul(pp).add(em(al.mul(q(B-3))).mul(ex(J.mul(p)).sub(o))); const P=min(two.mul(pp),pv),xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=two.mul(ex(xc).sub(o).sub(xc)).add(q(131,1000).mul(x));
  W=up(high.mul(f).add(x.mul(j)).add(x.mul(ell).div(two)).add(g));
  let atom=o;for(let j=1;j<B;j++)atom=up(atom.mul(p.div(two)).div(q(j)));
  eps=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(pp).div(q(K))).add(two.mul(pp).div(q(B*K))));
  c=o.sub(P);
  slice=c.mul(o.sub(pu.div(q(40)).sq().div(two))).sub(P.mul(pu.div(q(40))));
 }else{
  const al=q(tilt0,100),ea=ex(al);
  ck(ea.lt(q(3)),"tail tilt contraction");
  const tail=q(87,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
  const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
  const delta=q(524,1000).div(fact(L)),l=lat(L*K/2,0);
  eps=up(ex(xi.mul(p)).sub(o).mul(delta).add(em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o))));
  const far=o.add(delta).mul(em(al)).mul(j).add(two.add(delta).mul(em(al.mul(q(B-1)))).mul(f)).add(em(al.mul(q(B-L))).mul(l));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));
  const ref=q(13,10).div(a.div(sk).add(two));
  const r2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); c=(ref.lt(r2)?r2:ref).sub(eps);slice=q(98,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(tilt0?two.mul(eps):eps);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const sqD=q(Math.floor(Math.sqrt(B*K-1)*10),10); ck(sqD.sq().lt(q(B*K-1)),"floor radicand"); const corr=o.div(A.sq()).div(o.sub(o.div(A.mul(sqD)))); const s0=a.sub(corr.div(sk));
 ck(q(0).lt(s0)&&q(N).div(A.sq()).lt(s0.sq()),"join location "+B);
 covered=N;
 text({B,N,a:a.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
ck(covered>=12,"all intervals joined");
text("All exact bounds passed.");

const lo=y=>eb(y)[0],hC=q(317,100),lC=q(418,100),A0=q(48,100),sk80=q(89,10),s0=q(154,10),D0=q(239),n0=q(240);
ck(q(3).sub(q(2,95)).div(o.sub(o.div(q(178,10)))).lt(hC),"high plateau");
ck(q(4).div(o.sub(o.div(q(252,10)))).lt(lC),"half-load plateau");
ck(q(4*80).mul(ex(q(1,6*239))).lt(q(4,3).mul(pl).mul(q(79))),"Stirling peak");
const a=q(155,1000),l=q(45,100),e=q(141,1000),aa=q(65,1000),ll=q(306,1000),ee=q(73,1000);
ck(o.div(e).lt(lo(o.div(A0.sq()).mul(q(1,2).sub(q(1,21))))),"high pure");
ck(hC.mul(e).lt(l)&&q(12).div(l).lt(lo(q(959,288))),"high ratios");
ck(hC.sq().div(a.mul(o.sub(a))).lt(lo(o.div(A0.sq()))),"high curvature");
ck(two.mul(hC).mul(e).div(o.sub(e.sq())).lt(o),"high witness");
ck(o.div(ee).lt(lo(q(959,364)))&&lC.mul(ee).lt(ll)&&q(12).div(ll).lt(lo(q(959,84))),"low ratios");
ck(lC.sq().div(aa.mul(o.sub(aa))).lt(lo(q(959,169)))&&q(144).div(aa.mul(o.sub(aa))).lt(lo(q(959,36))),"low curvature");
ck(two.mul(lC).mul(ee).div(o.sub(ee.sq())).lt(o)&&q(24,1000).div(o.sub(q(1,1000000))).lt(o)&&q(1000).lt(lo(q(959,84))),"low witnesses");
const d=q(367,1000),b=q(175,10000);
ck(lC.mul(A0.div(s0).add(o.div(two.mul(sk80)))).lt(d)&&lC.div(n0).lt(b),"drifts");
ck(q(7000).lt(lo(q(2955,10000).mul(q(80)))),"heavy drift");
function margin(x,y,d,b,L=d){const z=o.sub(y.sq());return two.mul(x).add(d).add(x.mul(y).mul(L).div(z)).add(x.mul(d.div(z).add(b.mul(o.add(y.sq())).div(z.sq())))).lt(o.sub(x))}
ck(margin(a,l,d,b)&&margin(aa,ll,d,b),"signed margins");
ck(q(40).mul(A0).sq().lt(q(369))&&q(10,3).mul(A0.sq()).mul(A0).mul(n0.div(D0)).div(s0).lt(q(1,40)),"phase high and negative");
const w=q(7,300),ww=q(7,369),cut=q(99,100).mul(q(3));
ck(q(6).mul(A0.div(s0).sq()).lt(q(1,100))&&A0.div(s0).sub(cut.mul(n0).mul(w.sq()).mul(w)).lt(q(1,40))&&A0.div(q(173,10)).sub(cut.mul(n0).mul(ww.sq()).mul(ww)).lt(q(1,40)),"phase small positive");
const eeN=q(205),eeD=q(204),sr=q(142,10),cE=q(273,100),er=q(166,1000),lr=q(455,1000),ar=q(164,1000),erL=q(89,1000),lrL=q(268,1000),arL=q(33,1000),peak=q(53,100);
ck(q(80).mul(ex(q(1,6*204))).lt(peak.sq().mul(two).mul(pl).mul(q(39,64)).mul(q(79))),"early peak");
ck(q(5,2).div(o.sub(o.div(q(126,10)))).lt(cE),"early cap");
ck(o.div(er).lt(lo(q(2).sub(q(4,21))))&&cE.mul(er).lt(lr)&&q(3).div(lr).lt(lo(q(204,50))),"early ratios");
ck(cE.sq().div(ar.mul(o.sub(ar))).lt(lo(q(4)))&&two.mul(cE).mul(er).div(o.sub(er.sq())).lt(o),"early curvature and witness");
ck(o.div(erL).lt(lo(q(204,84)))&&q(3).mul(erL).lt(lrL)&&q(9).div(arL.mul(o.sub(arL))).lt(lo(q(204,36)))&&q(6).mul(erL).div(o.sub(erL.sq())).lt(o),"early low");
const dr=q(26,100),br=q(15,1000),drL=q(267,1000);
ck(cE.mul(q(1,2).div(sr).add(peak.div(sk80))).lt(dr)&&q(3).mul(q(5,205).add(peak.div(sk80))).lt(dr)&&cE.div(eeN).lt(br),"early drift");
ck(q(3).mul(q(6,205).add(peak.div(sk80))).lt(drL)&&q(3).div(eeN).lt(br),"early low drift");
ck(margin(ar,lr,dr,br)&&margin(arL,lrL,drL,br),"early signed margins");
const additive=q(4).div(o.sub(two.div(sr)));
const ce=q(4).sub(additive.div(sk80));
ck(q(0).lt(ce)&&q(12).lt(ce.sq()),"early center splice");
ck(q(1,2).div(sr).lt(q(1,8))&&eeN.div(eeD).mul(q(10,3)).mul(q(1,8)).div(sr).lt(q(1,8)),"early phase");

console.log("PASS: long_cycles_all_n_k80-01");
