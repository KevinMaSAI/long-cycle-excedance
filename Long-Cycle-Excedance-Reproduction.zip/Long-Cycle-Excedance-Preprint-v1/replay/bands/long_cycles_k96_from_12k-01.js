globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[96,12,93,650,5,27],[96,27,149,350,5,71],[96,71,223,150,8,162],[96,162,301,100,12,298],[96,298,377,50,12,469],[96,469,440,40,12,640],[96,640,489,30,12,791],[96,791,524,25,12,912]];
const covered={96:12};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(97,10);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(83,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(13,16).mul(p)).sub(o).mul(q(1,2)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(1,2).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(1,2).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)); const ref2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(16,5).div(sk));
 ck(q(0).lt(rad)&&q(2500*N,841).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1], C=q(27,8),v=q(1151,1152),n=q(1152), u=q(58,100),sk=q(97,10),sD=q(339,10);
ck(covered[96]>900,"coverage overlap");
ck(q(1000,573).lt(lo(q(573,1000).sub(q(1,96)))),"count peak");
ck(q(83,1000).mul(q(3,2)).lt(q(125,1000)),"count tail");
ck(q(96).mul(eu(q(1,6*1151))).lt(q(43,100).sq().mul(two).mul(pl).mul(q(11,12)).mul(q(95))),"modal binomial");
const p1=q(23,100),p2=q(16,100),p3=q(16,100),e1=q(33,1000),e2=q(12,1000);
ck(q(43,100).div(sk.mul(o.sub(q(4,5)))).lt(p1),"geometric long b2");
ck(q(43,100).div(sk.mul(o.sub(q(1).div(q(141,100))))).lt(p2),"geometric long b3");
ck(q(43,100).div(sk.mul(o.sub(q(71,100)))).lt(p3),"geometric short b1");
function uploss(x){return q(96).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3))))}
function lgloss(x){return q(95).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))))}
function geom(x,y){return x.div(o.sub(y))}
ck(q(5,4).lt(q(64,51))&&q(12).lt(q(95).mul(q(32,51).sub(q(1,2)))),"b2 slope");
ck(q(6,10000).add(q(3,2).mul(p1).mul(geom(em(lgloss(q(1,4))),em(q(12))))).lt(e1),"error singleton");
let maxb=q(62,100).sq().mul(q(127,12)).mul(q(20,19).sq());
ck(maxb.lt(q(3).div(q(141,100)).sq())&&q(12).lt(q(95).mul(q(141,300).sub(q(1,3)))),"b3 slope");
ck(q(19,27).lt(q(71,100)),"short mean");
ck(q(48,10000).add(q(5).mul(p3).mul(em(uploss(q(29,100))))).add(q(5,6).mul(p2).mul(geom(em(lgloss(q(41,100))),em(q(12))))).lt(e2),"error doubleton");
const A=q(45,100), L=q(178,100),R=q(114,100);
for(const [h,eps,m,ss,rr] of [[q(68,100),e1,q(17,16),o,A.mul(q(15,16))],[q(42,100),e2,q(20,19),q(1,2),A.mul(q(18,19))]]){
 ck(eu(ss).mul(q(43,100)).div(sk.mul(rr.sq())).lt(h),"derivative");
 ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L)&&m.mul(o.add(eps)).div(o.sub(eps)).lt(R),"neighbor ratios");
}
const eH=q(24,100),eM=q(131,1000),eL=q(6,1000),lH=q(43,100),lM=q(49,100),lL=q(31,1000),aH=q(125,1000),aM=q(20,100);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,57))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(48,100)).mul(q(51,100))))),"medium pure");
ck(o.div(eL).lt(lo(q(1151,220))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&C.mul(q(22,21)).div(lH).lt(lo(v.mul(sD).mul(o.div(u).sub(q(50,31))))),"outside profile");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM)&&C.mul(q(3,2)).mul(eL).lt(lL),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(o.div(u.sq()))),"high curvature");
ck(C.sq().mul(q(17,16)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(48,100).sq())))&&C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(q(1151,225))),"medium curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,16,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witness");
const d=q(26,100),b=q(37,10000), C2=q(417,100);
ck(q(4).div(o.sub(o.div(q(276,10)))).lt(C2)&&C2.mul(u.div(sD).add(q(43,100).div(sk))).lt(d)&&C2.div(n).lt(b),"drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(96)))),"heavy drift");
for(const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){const z=o.sub(l.sq());ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");}
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sD)))).lt(q(16,5)),"floor");
ck(u.div(sD).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sD)).lt(q(1,40)),"phase");

console.log("PASS: long_cycles_k96_from_12k-01");
