globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=32,sk=q(565,100),xi=q(823,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[9.25,400,60,3,11.25],[11.25,400,60,3,13.25],[13.25,400,60,3,15.25],[15.25,400,60,3,16],[3,439,55,2,3.25],[3.25,462,50,2,3.75],[3.75,477,60,2,4],[4,492,60,2,4.25],[4.25,507,60,2,4.75],[4.75,532,60,2,5.25],[5.25,557,60,2,5.75],[5.75,581,60,2,6.5],[6.5,614,60,2,7.25],[7.25,634,60,2,7.75],[7.75,654,60,2,8.5],[8.5,673,65,2,9],[9,683,65,2,9.25],[9.25,744,60,3,11.25],[11.25,800,60,3,13.25],[13.25,855,60,3,15.25],[15.25,872,60,3,16]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(32,100).sq().div(two));
ck(pu.div(q(60)).mul(ex(q(5,16)).sq()).lt(q(32,100).sq()),"vertical log");
ck(q(64,100).lt(q(68,100).mul(ca)),"vertical positive");
ck(q(90,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(32,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=15;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(584,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(97,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(14,100):L===3?q(46,1000):q(584,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1046,1000):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const core=a0===400;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 {
  const types=[[4,4,q(1,2)],[4,6,q(1,6)],[6,8,q(1,12)],[8,12,q(97,2000)]];
  for(let j=3;j<=Math.ceil(N);j++)types.push([4*j,4*(j+1),q(146,1000).div(fact(j))]);
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=o,wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const factor=4*B-h>=8?q(1046,1000):U0;
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1046,1000).mul(abs).add(q(764,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const eps=up(abs.mul(delta).add(ps));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=core?o.sub(abs):max(q(16,15).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(76,100)); if(!core&&pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  c=max(c,ref.sub(eps));slice=q(90,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 
 const mr=Math.floor(Math.sqrt(N*K-1)/2);
 ck(4*mr*mr<=N*K-1 && N*K-1<4*(mr+1)*(mr+1),"cut index");
 const wcut=q(4*mr*mr-1,mr-1).div(sk), w1=q(4*(mr+1)*(mr+1)-1,mr).div(sk), vm=q(Math.round(4*N),4).mul(q(4*(mr+1)*(mr+1)-1,2*mr*(mr+1)).sq()),v2=q(Math.round(4*N),4).mul(q(4*(mr+2)*(mr+2)-1,2*(mr+1)*(mr+2)).sq());
 if(!core)ck(wcut.lt(a)&&(w1.lt(a)||vm.lt(a.sq()))&&v2.lt(a.sq()),"floor splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0], D=q(95), y2=q(1,4*95);
ck(pl.sq().div(q(3)).mul(o.sub(q(6).mul(y2))).lt(q(16,5))===false,"positive arctangent correction");
ck(q(10,3).mul(q(96,95)).div(q(4)).lt(o)&&q(1,4).div(q(4).mul(q(16,5))).lt(q(1,40)),"floor phase orientation and width");
let nCover=q(3);
for(const [B,a,at,L,N] of rows)if(a!==400){
 const old=q(Math.round(4*B),4),next=q(Math.round(4*N),4);
 ck(!nCover.lt(old)&&nCover.lt(next),"interval overlap");
 nCover=next;
}
ck(!nCover.lt(q(16)),"last interval");

console.log("PASS: long_cycles_all_n_k32-01");
