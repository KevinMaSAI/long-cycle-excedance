globalThis.text = console.log;
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}


const zeros=n=>Array(n).fill(0n);
const abs=x=>x<0n?-x:x;
function choose(n,k){let a=1n;for(let j=1;j<=k;j++)a=a*BigInt(n+1-j)/BigInt(j);return a}
function rows(k,N){const F=[];let p=[1n];
 for(let j=3;j<=k;j++){const r=zeros(p.length+1);for(let i=0;i<p.length;i++){r[i+1]+=BigInt(2+i)*p[i];if(i)r[i-1]-=BigInt(i)*p[i]}p=r}F[k]=p;
 for(let n=k;n<N;n++){const r=zeros(p.length+1);for(let i=0;i<p.length;i++){r[i+1]+=BigInt(2+i)*p[i];if(i)r[i-1]-=BigInt(i)*p[i]}
 const b=lag(F,k,n);if(b)for(let j=0;j<b.length;j++){r[j+2]+=b[j];r[j]-=b[j]}F[n+1]=p=r;}
 return F}
function lag(F,k,n){const f=F[k],g=F[n+1-k];if(!g)return null;const r=zeros(f.length+g.length-1),c=choose(n,k-1);
 for(let i=0;i<f.length;i++)for(let j=0;j<g.length;j++)r[i+j]+=c*f[i]*g[j];return r}
function series(a,b,M){const z=[],d=a.length-b.length,l=q(b.at(-1));for(let i=0;i<=M;i++){
 let s=q(a[a.length-i-1]??0n);for(let j=1;j<=Math.min(i,b.length-1);j++)s=s.sub(q(b.at(-j-1)).mul(z[i-j]));z.push(s.div(l));}
 return z}
function bound(F,k,n){
const p=F[n-1],m=Math.floor((p.length-1)/2),b=series(F[n],p,4*m+1),g=series(lag(F,k,n),p,2*m);
const rhs=Array.from({length:m},(_,i)=>g[2*i+2]),R=rhs.slice();
const M=Array.from({length:m},(_,i)=>Array.from({length:m},(_,j)=>q(0).sub(b[4+2*(i+j)])));
for(let i=0;i<m;i++){const d=M[i][i];if(!q(0).lt(d))return null;for(let j=i+1;j<m;j++){
 const h=M[j][i].div(d);for(let v=i;v<m;v++)M[j][v]=M[j][v].sub(h.mul(M[i][v]));R[j]=R[j].sub(h.mul(R[i]));}}
const x=new Array(m);for(let i=m-1;i>=0;i--){let z=R[i];for(let j=i+1;j<m;j++)z=z.sub(M[i][j].mul(x[j]));x[i]=z.div(M[i][i]);}
const loss=rhs.reduce((a,y,i)=>a.add(y.mul(x[i])),q(0));const t=b[0].add(g[0]).mul(q(4));return [loss,t]}


for(const [k,n] of [[3,5],[4,9],[6,14],[11,21]]){
 const F=rows(k,n),p=F[n],L=lag(F,k,n),N=k-1,Z=q(0),I=q(1),m=p.length-1,s=q(L.at(-1),p.at(-1));
 const norm=Array.from({length:N+1},(_,j)=>q(p[m-j]??0n,p[m]));
 const A=Array.from({length:N+1},(_,j)=>j%2?Z:q(1,j+1)),u=[];
 for(let j=0;j<=N;j++){let z=j%2?Z:I;for(let h=1;h<=j;h++)z=z.sub(A[h].mul(u[j-h]));u.push(z);}
 const P=[q(m)],r=series(L,p,N);
 for(let j=1;j<=N;j++){let z=q(j).mul(norm[j]);for(let h=1;h<j;h++)z=z.add(norm[h].mul(P[j-h]));P.push(Z.sub(z));}
 for(let j=0;j<=N;j++) {
  assert(r[j].sub(s.mul(u[j])).a===0n);
  assert(P[j].add(j%2?Z:q(2)).sub(q(n).mul(u[j])).a===0n);
 }
 text("PASS: k="+k+", n="+n+" rational low-mode and endpoint quadrature identities");
}

console.log("PASS: long_cycles_low_degree_quadrature-01");
