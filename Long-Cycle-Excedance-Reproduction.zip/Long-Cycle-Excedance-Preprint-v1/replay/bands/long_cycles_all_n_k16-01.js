globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=16,sk=q(4),xi=q(84,100),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[3,430,40,2,3.25,0,0],[3.25,434,40,2,4,0,0],[4,465,40,2,4.5,0,1],[4,484,40,3,4.5,465,0],[4.5,485,40,2,4.75,0,1],[4.5,512,40,3,4.75,485,0],[4.75,490,40,2,5,0,1],[4.75,530,40,3,5,490,1],[4.75,540,40,3,5,530,0],[5,400,40,2,5.25,0,1],[5,530,40,3,5.25,400,1],[5,565,40,3,5.25,530,0],[5.25,400,40,2,5.5,0,1],[5.25,540,40,3,5.5,400,1],[5.25,581,40,3,5.5,540,0],[5.5,400,40,2,6,0,1],[5.5,550,40,3,6,400,1],[5.5,595,40,3,6,550,1],[5.5,607,40,3,6,595,0],[6,400,40,2,7,0,1],[6,565,40,3,7,400,1],[6,615,40,3,7,565,1],[6,619,40,3,7,615,0],[7,400,40,2,8,0,1],[7,610,40,3,8,400,1],[7,675,40,3,8,610,0],[8,400,40,2,10,0,1],[8,650,40,3,10,400,1],[8,723,40,3,10,650,0],[10,400,40,2,12,0,1],[10,720,40,3,12,400,1],[10,805,40,3,12,720,0],[12,400,40,2,14,0,1],[12,795,40,3,14,400,1],[12,852,40,3,14,795,0],[14,400,40,2,16,0,1],[14,865,40,3,16,400,1],[14,911,40,3,16,865,0]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(46,100).sq().div(two));
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log");
ck(q(48,100).lt(q(54,100).mul(ca)),"vertical positive");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N,low=0,skip=0] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=7;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(min(q(165,1000),q(716,1000).div(fact(Math.floor(B-1)))).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4)));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(119,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(154,1000):L===3?q(65,1000):q(716,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1065,1000):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const core=low===0;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 function typesOf(jlast){const types=[[4,4,q(1,2)]]; for(let j=4;j<8;j++){const den=j===4?q(1):q(j,4).sub(q(1,16));types.push([j,j+1,o.div(den).sub(q(4,j+1)).div(two)]);}
 for(let j=8;j<4*jlast;j++){const r=q(j,4);let v;if(j<12){v=max(o.div(r.sub(o)).sub(q(1,2)),q(591,1000).sub(o.div(r.sub(q(3,4))))).mul(q(5,32)).div(r);}else{v=q(j<16?91:36,1000).mul(q(5,32)).div(r);}
 v=min(v,q(179,1000).div(fact(Math.floor(j/4))));types.push([j,j+1,v]);}return types;}

 {
  const types=typesOf(Math.ceil(N));
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=q(0),wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const rem=q(Math.max(4,4*B-h),4); const factor=4*B-h>=8?q(1065,1000):min(U0,max(q(1065,1000),o.div(q(555,1000).mul(rem))));
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1065,1000).mul(abs).add(q(745,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let bw=q(0),t=o,pow=o, jmax=Math.floor(N-1+1/K);
  const pp=p.div(two),slot=xi.mul(p);
  for(let j=1;j<=jmax;j++){t=t.mul(pp).div(q(j));if(j>B-1)bw=bw.add(t);}
  let sum=o;for(let j=1;j<jmax;j++){pow=pow.mul(slot).div(q(j));sum=sum.add(pow);}
  drift=up(P.div(q(K)).add(P.div(q(B*K))).add(U0.mul(bw.add(pp.div(q(K+1)).mul(sum)))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const Qmax=Math.ceil(4*B)+4, Jlast=Math.ceil(B)+1, md=16, es=[[4,q(1,2)],[6,q(1,6)],[8,q(1,12)],[12,q(105,2000)]];
  for(let j=3;j<Jlast;j++)es.push([4*(j+1),q(179,1000).div(fact(j))]);
  es.push([Qmax,q(179,1000).div(fact(Jlast))]);
  const msum=es.reduce((s,[_,w])=>s.add(w),q(0)).mul(p);
  let epsDP=q(0),prod=o,dp=new Map([[0,o]]);
  const pref=new Map();
  function modLoss(h){
   if(pref.has(h))return pref.get(h);
   const r=Math.floor((4*B-h)/4);let v=q(1);
   if(r>=4)v=q(716,1000).div(fact(r));
   else if(r===3)v=q(65,1000);
   else if(r===2)v=q(154,1000);
   else if(r===1)v=max(q(154,1000),o.div(q(555,1000).mul(q(4*B-h,4))).sub(o));
   pref.set(h,v);return v;
  }
  for(let m=1;m<=md;m++){
   const tmp=new Map();
   prod=prod.mul(p).div(q(m));
   for(const [h,v] of dp)for(const [s,w] of es){let f=Math.min(Qmax,h+s);tmp.set(f,(tmp.get(f)??q(0)).add(v.mul(w)));}
   dp=tmp;
   for(const [h,v] of dp)epsDP=epsDP.add(prod.mul(v).mul(modLoss(h)));
  }
  let rem=o;for(let i=1;i<=md+1;i++)rem=rem.mul(msum).div(q(i));
  epsDP=up(epsDP.add(rem.mul(ex(msum))));
  const eps=min(epsDP,up(abs.mul(delta).add(ps)));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=core?o.sub(abs):max(q(4,5).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(79,100)); if(!core&&pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  if(low>=400){const s=q(low,25),m=q(18); function FD(z){let v=o,sum=o;for(let j=1;j<=18;j++){v=v.mul(z).div(q(j));sum=sum.add(v);}return sum.mul(em(z));}
   const J0=ex(q(50000,low*low)).mul(FD(s).add(FD(s.mul(two)).div(two.mul(o.sub(em(s.sub(q(9))))))));
   const aarg=J0.add(pu.div(s)),cos=o.sub(aarg.sq().div(two));
   if(q(0).lt(cos))ref=max(ref,q(5,3).mul(dn(o.div(ex(J0)))).mul(cos).div(pu.mul(R)));
  }
  c=max(c,ref.sub(eps));const angle=pu.div(q(32));if(core)slice=max(slice,ref.mul(o.sub(angle.sq().div(two))).sub(abs.mul(angle)).sub(eps));else slice=q(87,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);if(B<=4&&low===0)ck(V.lt(slice),"exception phase exclusion");
 
 if(!skip){
  const minD=Math.ceil(B*K)-1,maxD=Math.floor(N*19)-1,Nq=q(Math.round(4*N),4);
  let M=Math.floor(Math.sqrt(minD)/2);
  ck(4*M*M<=minD&&minD<4*(M+1)*(M+1),"minimum M");
  for(; (M===4?53:4*M*M)<=maxD; M++){
    if(M===3&&minD>=53)continue;const d=Math.min(maxD, M===3?52:4*(M+1)*(M+1)-1);
    const s1=q(d*d,M*M*K),s2=Nq.mul(q(d*d,M*M*(d+1)));
    ck(min(s1,s2).lt(a.sq()),"finite M envelope");
  }
 }
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");

console.log("PASS: long_cycles_all_n_k16-01");
