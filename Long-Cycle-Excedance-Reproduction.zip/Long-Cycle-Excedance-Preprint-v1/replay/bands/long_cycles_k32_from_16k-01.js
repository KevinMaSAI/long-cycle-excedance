globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(60)).mul(ex(q(5,16)).sq()).lt(q(32,100).sq()),"vertical log bound");
ck(q(64,100).lt(q(68,100).mul(o.sub(q(32,100).sq().div(two)))),"vertical real fraction");
ck(q(95,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(32,100).div(o.sub(q(32,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[32,16,40,550,5,16,1],[32,16,92,600,5,20],[32,20,107,500,5,28],[32,28,128,375,7,41],[32,41,151,280,7,58],[32,58,175,200,7,79],[32,79,198,150,10,102],[32,102,217,150,10,123],[32,123,234,125,10,144],[32,144,246,100,10,160],[32,160,258,100,10,176],[32,176,266,100,10,187]];
const covered={32:16};
for(const [K,B,a2,at,L,N,core] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(565,100);
 ck(!q(K).lt(sk.sq())&&(core||B<=covered[K])&&B>L&&(core||N>covered[K]),"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(97,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(823,1000).mul(p)).sub(o).mul(q(584,1000)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(584,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(q(181,100).mul(em(alpha.mul(q(B-1)))).mul(f)).add(q(81,100).sub(delta).mul(em(alpha.mul(q(B-L)))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(584,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=core?two.sub(ex(q(823,1000).mul(p))):q(16,15).div(a.div(sk).add(two)); const rp=p.mul(q(76,100));const ref2=!core&&rp.lt(o)?dn(o.div(ex(rp)).mul(o.sub(rp.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 if(!core)ck(V.lt(q(95,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(4).div(sk));
 if(!core)ck(q(0).lt(rad)&&q(10000*N,2809).lt(rad.sq()),"splice location");
 if(!core)covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0], eu=y=>eb(y)[1],K0=q(32),sk0=q(565,100),n=q(512),D=q(511),sd=q(226,10),v=D.div(n),C=q(27,8),A=q(42,100),u=q(53,100),pk=q(44,100);
ck(covered[32]>180,"eventual overlap");
ck(q(100,58).lt(lo(q(58,100).sub(q(1,32))))&&q(97,1000).mul(q(3,2)).lt(q(146,1000)),"cycle tail");
ck(o.add(q(694,1000)).add(q(1,126)).lt(q(58,100).mul(q(95,32))),"upper count tail");
const Cmin=q(555,1000);
ck(q(0).lt(q(1693,1000).sub(q(3).mul(Cmin)).sub(q(9).mul(Cmin.sub(q(1,2)).sq())))&&q(4).mul(Cmin).lt(q(1693,1000).add(q(1,2)).add(q(1,36)))&&q(1,36).lt(Cmin)&&o.div(Cmin).lt(q(181,100)),"lower count tail");
ck(pu.div(q(4).mul(sk0)).lt(q(14,100))&&q(66,100).sq().mul(q(228,100)).lt(o)&&o.div(q(2).mul(q(66,100))).lt(q(76,100)),"sharper reference log");
ck(K0.mul(eu(q(1,6*511))).lt(pk.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(31))),"binomial peak");
function geom(x,y){return x.div(o.sub(y));}
function lp(x){return q(31).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))))}
const e=q(14,1000), h=q(149,100), L=q(254,100), R=q(114,100);
ck(q(62,100).sq().mul(q(47,16)).lt(q(3,2).sq())&&q(62,100).sq().mul(q(47,16)).mul(q(11,10).sq()).lt(q(2).div(q(17,10)).sq()),"single size load");
ck(pk.div(sk0.mul(o.sub(q(10,17)))).lt(q(19,100))&&q(10).lt(q(31).mul(q(35,100))),"long tail prefactor and rate");
ck(q(8,1000).add(q(285,1000).mul(geom(em(lp(q(7,10))),em(q(10))))).lt(e),"model error");
ck(eu(o).mul(pk).div(sk0.mul(A.mul(q(9,10)).sq())).lt(h)&&o.add(h.add(two.mul(e)).div(o.sub(e))).lt(L)&&q(11,10).mul(o.add(e)).div(o.sub(e)).lt(R),"profile ratios");
const eH=q(189,1000),lH=q(49,100),aH=q(92,1000),lL=q(42,100),aL=q(14,100);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,33)))))&&L.mul(eH).lt(lH),"high rate");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&q(81,16).div(lH).lt(lo(v.mul(sd).mul(o.div(u).sub(q(50,31))))),"profile exits");
function cv(x,e,a){return x.div(a.mul(o.sub(a))).lt(lo(e));}
ck(cv(L.mul(R),o.div(u.sq()),aH),"high curvature");
for(const [b,eta,fac,r] of [[D.div(q(81)),q(55,1000),q(3,2),9],[D.div(q(100)),q(93,1000),q(11,10),10],[q(10,11).sq().div(A.sq()).sub(q(1,121)),q(112,1000),q(12,11),11]]){
 ck(o.div(eta).lt(lo(b.mul(q(1,2).sub(q(1,3*r)))))&&C.mul(fac).mul(eta).lt(lL),"low ratios");
 ck(cv(C.sq().mul(fac),b,aL),"low curvature");
}
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,10,true)).lt(o),"high witness");
ck(o.div(q(77,1000)).lt(lo(o.div(A.sq()).sub(q(1,64)).mul(q(1,2).sub(q(1,24)))))&&q(100).lt(lo(D.div(q(49)).mul(q(1,2).sub(q(1,21))))),"witness losses");
ck(cost(q(77,1000),8,false).lt(o)&&cost(q(10,1000),1,false).lt(o),"low witnesses");
const dd=q(37,100),bb=q(71,10000),C3=q(362,100);
ck(q(10,3).div(o.sub(o.div(q(13)))).lt(C3)&&C3.mul(u.div(sd).add(pk.div(sk0))).lt(dd)&&C3.div(n).lt(bb),"drift upper");
const xx=q(133,100);
ck(xx.lt(q(4,3).mul(v))&&q(11).lt(q(33,100).mul(K0).add(o)),"drift lower");
ck(C.div(v).mul(xx).mul(pk).div(sk0).mul(geom(em(lp(q(33,100))),em(q(11)))).lt(q(11,100)),"heavy drift value");
for(const [a,l] of [[aH,lH],[aL,lL]]){const z=o.sub(l.sq());ck(two.mul(a).add(dd).add(a.mul(l).mul(dd).div(z)).add(a.mul(dd.div(z).add(bb.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed margins");}
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sd)))).lt(q(4))&&u.div(sd).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sd)).lt(q(1,40)),"floor splice");


const es=[q(16,100000),q(16,100000),q(2,1000),q(2,1000),q(8,100),q(8,100),o,o];let cc=q(0);
for(let i=0;i<8;i++)cc=cc.add(es[i].div(fact(i)));
cc=cc.add(q(3).div(fact(8)).div(o.sub(q(1,9))));
ck(cc.lt(q(8,1000)),"hard-cycle omissions");

console.log("PASS: long_cycles_k32_from_16k-01");
