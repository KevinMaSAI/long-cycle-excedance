globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),nn=q(1344),DD=q(1343),sD=q(366,10),sk=q(346,100),A=q(39,50),Drel=DD.div(nn),C=q(27,8);
const lo=x=>eb(x)[0],geom=(f,r)=>f.div(o.sub(r));
ck(sD.sq().lt(DD)&&sk.sq().lt(q(12))&&q(28).lt(A.mul(sD)),"scale");
ck(q(300,7).lt(lo(q(376,100)))&&q(5,4).mul(pu).mul(q(21,10)).mul(q(476,100)).lt(q(40)),"arg and Fourier kernel");
ck(q(12,11).sq().add(q(12,11).mul(ex(o))).lt(q(42,10)),"kernel numerator");
ck(q(30).lt(lo(q(35,10)))&&ex(o).lt(q(272,100)),"small s harmonic");
const sm=q(2).add(q(148).mul(q(1,8).sub(o.div(pu.sq()))));
ck(sm.lt(q(56,10))&&q(56,10).mul(q(522,100)).lt(q(40)),"small s pole bound");
ck(q(12,11).mul(pu).lt(q(4)),"contour exp");
const floor=o.div(A.sq()).div(o.sub(o.div(A.mul(sD))));
ck(floor.lt(q(174,100)),"floor correction");
const rho2=o.div(A).add(q(174,100).div(sD)).sq().add(q(10,1344));
ck(rho2.lt(q(178,100)),"rho squared");
ck(q(300).div(pl).mul(q(178,100)).mul(ex(q(4))).lt(q(10000))&&q(150).mul(ex(q(4))).lt(q(10000)),"contour normalization");
ck(q(10000*30*3472*200).lt(lo(q(264,10))),"contour decay");
const rate=two.mul(pl.sq()).div(q(12,11).sq()),odd=r=>q(3).div(o.sub(r)).add(two.mul(r).div(o.sub(r).sq()));
ck(q(51).lt(rate.mul(q(112,36)))&&em(q(22)).mul(odd(em(q(102)))).lt(q(1,1000)),"small s far");
ck(q(198,10).sq().lt(q(36*11))&&q(12,11).sq().mul(o.add(q(10,396))).lt(q(111,100).sq()),"large s pole ratio");
const correction=x=>o.add(q(111,100).mul(x)).mul(geom(em(x),em(x)));
ck(correction(q(198,10)).lt(q(1,1000)),"logistic correction");
ck(q(10,72).add(q(23,22).mul(o.add(q(10,396)))).lt(q(122,100)),"vertical exponent");
ck(o.lt(q(121,1000).sq().mul(two).mul(pl).mul(q(11))),"gamma peak");
ck(ex(q(122,100)).mul(o.div(q(198,10)).add(q(121,1000))).lt(q(59,100)),"vertical derivative");
ck(q(59,100).mul(two).mul(pu).add(q(2,1000)).lt(q(375,100)),"residue ratio");
ck(q(92,10).lt(rate.div(q(178,100)))&&em(q(108,10)).mul(odd(em(q(108,10)))).lt(q(1,1000)),"large s far");
ck(q(5,2).sq().lt(q(112*31-1).div(A.sq().mul(q(30*30))))&&q(328,100).sq().lt(q(112*19-1).div(A.sq().mul(q(18*18)))),"splice t lower");
ck(o.add(q(10).div(sD.div(A).sq())).lt(q(102,100).sq()),"primary |p|");
ck(q(255,100).lt(lo(q(94,100)))&&q(33456,10000).lt(lo(q(122,100))),"factorial exponents");
ck(geom(em(q(1064,100)),em(q(16))).add(correction(q(46))).lt(q(3,1000))&&geom(em(q(1166,100)),em(q(16))).add(correction(q(46))).lt(q(3,1000)),"splice phase shift");
ck(q(46).lt(sD.div(A))&&pu.mul(em(q(46))).lt(q(1,1000)),"splice q");
const ph1=two.mul(A).div(sD),ph2=q(1345,1343).mul(q(10,3)).mul(A.sq()).mul(A).div(sD);
ck(ph1.add(q(4,1000).div(pl)).lt(q(1,20))&&ph2.add(q(4,1000).div(pl)).lt(q(1,20)),"phase at splice");
const reach=q(9,10),pk=q(46,100),eta=q(453,1000),lambda=q(49,100),alpha=q(27,100),C2=q(446,100),dense=q(999,1000);
ck(q(99,100).lt(o.sub(q(1,112)))&&q(12).mul(ex(q(1,6*1343))).lt(pk.sq().mul(two).mul(pl).mul(q(99,100)).mul(q(11))),"binomial peak");
for(const [km,kM,w,phi] of [[12,19,q(269,100),q(69,100)],[20,31,q(21,10),q(35,100)]]){
 ck(w.sq().lt(Drel.sq().mul(q(112,kM)).div(reach.sq())),"dense load "+km);
 ck(w.lt(lo(w.sub(o).sub(phi))),"phi "+km);
 ck(q(1000).lt(lo(phi.mul(q(km)))),"dense lower "+km);
 const sk0=km===12?sk:q(447,100);
 ck(sk0.sq().lt(q(km)),"group sqrt");
 const ht=C.div(Drel).mul(w).mul(pk.div(sk0)).mul(geom(em(phi.mul(q(km-1))),em(w.sub(o).mul(q(km)).add(o))));
 ck(ht.lt(q(1,1000)),"dense drift "+km);
}
const gg=C.div(Drel).mul(q(199,100)).mul(pk.div(sk)).mul(geom(em(q(319,100)),em(q(12))));
ck(q(199,100).lt(lo(q(7,10)))&&gg.lt(q(69,100)),"below H/2 drift");
ck(q(489,100).sq().lt(q(24))&&q(4).div(o.sub(o.div(two.mul(q(489,100))))).lt(C2),"cap");
const d=q(69,100),b=q(34,10000),near=q(1,1000);
ck(C2.mul(A.div(sD).add(pk.div(sk))).lt(d)&&C2.div(nn).lt(b),"global drift");
ck(q(4).lt(reach.sub(A).mul(sD)),"dense early offsets");
ck(o.div(eta).lt(lo(q(1,2).sub(q(1,60)).div(A.sq())))&&q(14,13).div(dense).mul(eta).lt(lambda),"first ratio");
const lowEta=q(14,100);
ck(o.div(lowEta).lt(lo(q(1343,364)))&&q(3,2).div(dense).mul(lowEta).lt(lambda),"small witnesses");
ck(o.div(dense.sq().mul(alpha).mul(o.sub(alpha))).lt(lo(o.div(A.sq()))),"curvature");
ck(q(81,16).div(lambda).lt(lo(Drel.mul(sD).mul(o.div(A).sub(o.div(reach))))),"outside dense");
const eta3=q(17,10000);
ck(o.div(eta3).lt(lo(q(9,2).div(A.sq()).mul(q(20,23)))),"third offset");
const u=o.sub(eta.sq()),v=o.sub(lowEta.sq());
const far=two.mul(eta3).div(dense).mul(o.add(q(3,13)).div(u).add(q(2,13).mul(eta.sq()).div(u.sq())));
ck(two.mul(eta).div(dense).add(far).lt(o),"high witness");
ck(two.div(dense).mul(lowEta.div(v).add(lowEta.mul(o.add(lowEta.sq())).div(v.sq()))).lt(o),"low witness");
const z=o.sub(lambda.sq());
const later=alpha.mul(lambda.sq().sq()).mul(d.add(q(5).mul(b)).div(z).add(two.mul(b).mul(lambda.sq()).div(z.sq())));
const cost=two.mul(alpha).add(near).add(alpha.mul(lambda).mul(near).div(z)).add(alpha.mul(near).div(z)).add(later);
ck(cost.lt(o.sub(alpha)),"signed margin");
text({rho2:rho2.val(),cost:cost.val()});
text("All exact eventual bounds passed.");


console.log("PASS: long_cycles_k12_to31_eventual_112_replay-01");
