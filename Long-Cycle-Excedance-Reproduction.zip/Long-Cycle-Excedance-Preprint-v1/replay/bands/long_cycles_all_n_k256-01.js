globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(508)).mul(ex(q(5,16)).sq()).lt(q(11,100).sq()),"vertical log bound");
ck(q(22,25).lt(q(89,100).mul(o.sub(q(11,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(11,100).div(o.sub(q(11,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[256,2349,162,10,18,3390],[256,3390,182,8,18,4281],[256,4281,196,8,18,4962],[256,4962,205,6,18,5433],[256,5433,211,6,18,5754],[256,5754,214,6,18,5915],[256,5915,216,5,18,6026],[256,6026,217,5,18,6087],[512,3882,208,6,18,5593],[512,5593,233,5,18,7024],[384,2349,171,10,18,3780],[384,3780,199,8,18,5121],[384,5121,218,6,18,6142],[384,6142,231,5,18,6893]];
const covered={256:2349,384:2349,512:3882};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({256:16,384:19,512:22}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(22,15).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(2).div(sk));
 ck(q(0).lt(rad)&&q(625*N,324).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=x=>eb(x)[0];
ck(q(764).lt(lo(q(27,4))) && q(1020).lt(lo(q(7))) && q(2044).lt(lo(q(39,5))),"eventual logs");
ck(covered[256]>=6075 && covered[384]>=6300 && covered[512]>=7020,"eventual overlap");
const eta=q(382,1000), A=q(999,1000),lambda=q(41,100),a=q(18,100),d=q(20,100),b0=q(22,1000000),r0=q(18,25),Dmin=q(319999),nmin=q(320000);
ck(q(16,25).mul(q(1024,1250)).lt(q(8,11).sq()),"small load threshold");
ck(q(1000).lt(lo(q(27,2))),"occupancy close");
ck(o.div(eta).lt(lo(o.div(r0.sq()).mul(q(1,2).sub(q(1,1200))))),"pure high ratio");
ck(q(1000).lt(lo(Dmin.div(q(2*16*17)))),"pure low");
ck(q(81,16).div(lambda).lt(lo(Dmin.div(nmin).mul(q(565)).mul(q(25,18).sub(q(5,4))))),"far right purity");
ck(eta.mul(q(17,16)).div(A).lt(lambda),"near right ratio");
ck(o.div(A.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(r0.sq()))),"curvature");
const odd=o.sub(eta.sq());
ck(two.div(A).mul(eta.div(odd).add(eta.mul(o.add(eta.sq())).div(q(16).mul(odd.sq())))).lt(o),"high witness");
const small=q(1,1000), smallOdd=o.sub(small.sq());
ck(two.div(A).mul(small.div(smallOdd).add(small.mul(o.add(small.sq())).div(smallOdd.sq()))).lt(o),"low witness");
ck(q(27,4).mul(r0.div(q(565)).add(q(45,1600))).lt(d) && q(27,4).div(nmin).lt(b0),"global drift");
const z=o.sub(lambda.sq());
ck(two.mul(a).add(d).add(a.mul(lambda).mul(d).div(z)).add(a.mul(d.div(z).add(b0.mul(o.add(lambda.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");
ck(o.div(r0.sq()).div(o.sub(o.div(r0.mul(q(565))))).lt(two),"floor correction");
ck(r0.add(q(10,3).mul(r0.sq()).mul(r0).mul(nmin.div(Dmin))).div(q(565)).lt(q(1,40)),"phase correction");

console.log("PASS: long_cycles_all_n_k256-01");
