globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=24,sk=q(489,100),xi=q(829,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[5.75,400,50,3,6.75],[6.75,400,50,3,7.75],[7.75,400,50,3,8.75],[8.75,400,50,3,11.25],[11.25,400,50,3,14.25],[14.25,400,50,3,17.25],[17.25,400,50,3,20.25],[20.25,400,50,3,23.25],[23.25,400,50,3,24],[3,464,50,2,3.5],[3.5,480,50,2,3.75],[3.75,507,50,2,4.5],[4.5,533,50,2,5],[5,547,50,2,5.25],[5.25,559,50,2,5.5],[5.5,572,50,2,5.75],[5.75,604,50,3,6.75],[6.75,647,50,3,7.75],[7.75,674,50,3,8.75],[8.75,753,50,3,11.25],[11.25,837,50,3,14.25],[14.25,912,50,3,17.25],[17.25,988,50,3,20.25],[20.25,1051,50,3,23.25],[23.25,1068,50,3,24]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(37,100).sq().div(two));
ck(pu.div(q(44)).mul(ex(q(5,16)).sq()).lt(q(37,100).sq()),"vertical log");
ck(q(58,100).lt(q(63,100).mul(ca)),"vertical positive");
ck(q(88,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(37,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=11;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(632,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(105,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(145,1000):L===3?q(53,1000):q(632,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1053,1000):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const core=a0===400;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 {
  const types=[[4,4,q(1,2)],[4,6,q(1,6)],[6,8,q(1,12)],[8,12,q(105,2000)]];
  for(let j=3;j<=Math.ceil(N);j++)types.push([4*j,4*(j+1),q(158,1000).div(fact(j))]);
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=q(0),wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const rem=q(Math.max(4,4*B-h),4); const factor=4*B-h>=8?q(1053,1000):min(U0,max(q(1053,1000),o.div(q(555,1000).mul(rem))));
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1053,1000).mul(abs).add(q(757,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const Qmax=Math.ceil(4*B)+4, Jlast=Math.ceil(B)+1, md=16, es=[[4,q(1,2)],[6,q(1,6)],[8,q(1,12)],[12,q(105,2000)]];
  for(let j=3;j<Jlast;j++)es.push([4*(j+1),q(158,1000).div(fact(j))]);
  es.push([Qmax,q(158,1000).div(fact(Jlast))]);
  const msum=es.reduce((s,[_,w])=>s.add(w),q(0)).mul(p);
  let epsDP=q(0),prod=o,dp=new Map([[0,o]]);
  const pref=new Map();
  function modLoss(h){
   if(pref.has(h))return pref.get(h);
   const r=Math.floor((4*B-h)/4);let v=q(1);
   if(r>=4)v=q(632,1000).div(fact(r));
   else if(r===3)v=q(53,1000);
   else if(r===2)v=q(145,1000);
   else if(r===1)v=max(q(145,1000),o.div(q(555,1000).mul(q(4*B-h,4))).sub(o));
   pref.set(h,v);return v;
  }
  for(let m=1;m<=md;m++){
   const tmp=new Map();
   prod=prod.mul(p).div(q(m));
   for(const [h,v] of dp)for(const [s,w] of es){let f=Math.min(Qmax,h+s);tmp.set(f,(tmp.get(f)??q(0)).add(v.mul(w)));}
   dp=tmp;
   for(const [h,v] of dp)epsDP=epsDP.add(prod.mul(v).mul(modLoss(h)));
  }
  let rem=o;for(let i=1;i<=md+1;i++)rem=rem.mul(msum).div(q(i));
  epsDP=up(epsDP.add(rem.mul(ex(msum))));
  const eps=min(epsDP,up(abs.mul(delta).add(ps)));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=core?o.sub(abs):max(q(29,30).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(77,100)); if(!core&&pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  c=max(c,ref.sub(eps));slice=q(88,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 
 const mr=Math.floor(Math.sqrt(N*K-1)/2);
 ck(4*mr*mr<=N*K-1 && N*K-1<4*(mr+1)*(mr+1),"cut index");
 const wcut=q(4*mr*mr-1,mr-1).div(sk), w1=q(4*(mr+1)*(mr+1)-1,mr).div(sk), vm=q(Math.round(4*N),4).mul(q(4*(mr+1)*(mr+1)-1,2*mr*(mr+1)).sq()),v2=q(Math.round(4*N),4).mul(q(4*(mr+2)*(mr+2)-1,2*(mr+1)*(mr+2)).sq());
 if(!core)ck(wcut.lt(a)&&(w1.lt(a)||vm.lt(a.sq()))&&v2.lt(a.sq()),"floor splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0];
ck(q(1000,584).lt(lo(q(584,1000).sub(q(1,24))))&&q(105,1000).mul(q(3,2)).lt(q(158,1000)),"count bound");
ck(o.add(q(694,1000)).add(q(1,94)).lt(q(584,1000).mul(q(71,24))),"propagate upper counts");
ck(q(584,555).lt(q(1053,1000))&&o.div(q(555,1000)).lt(q(181,100))&&o.sub(q(500,584)).lt(q(145,1000))&&q(584,555).sub(o).lt(q(53,1000)),"relative count budgets");
ck(pu.div(q(4).mul(sk)).lt(q(17,100))&&q(65,100).sq().mul(q(234,100)).lt(o)&&o.div(q(2).mul(q(65,100))).lt(q(77,100)),"sharper log integral");
let high=q(3);for(const [B,a,al,L,N] of rows)if(a!==400){const low=q(Math.round(4*B),4),next=q(Math.round(4*N),4);ck(!high.lt(low)&&high.lt(next),"overlap");high=next;}
ck(!high.lt(q(24)),"end coverage");

console.log("PASS: long_cycles_k24_middle-02");
