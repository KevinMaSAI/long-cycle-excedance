globalThis.text = console.log;
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const lam=q(3,5), J=q(2,5), N=871,u=29,A=J.add(q(1,u));
function eLower(x){let t=one,s=one;for(let i=1;i<=18;i++){t=t.mul(x).div(q(i));s=s.add(t)}return s}
assert(one.div(q(87,1000)).lt(eLower(one.div(two.mul(A).mul(A.add(q(1,u)))))));
assert(one.div(q(3,1000)).lt(eLower(q(N-1,2*8*9))));
assert(q(5,2).div(one.sub(q(1,22))).lt(q(262,100)));
assert(q(262,100).mul(J.div(q(u)).add(q(1,N)).add(q(1,16))).lt(q(204,1000)));
assert(q(262,100).div(q(N)).lt(q(31,10000)));
assert(q(4).mul(q(8,N).add(q(1,16))).lt(q(29,100)));
assert(q(4).div(q(N)).lt(q(5,1000)));
assert(q(4).mul(J.div(q(u)).add(q(1,N)).add(q(1,16))).lt(q(31,100)));
for (const [C,e,d,m] of [[q(262,100),q(87,1000),q(204,1000),q(31,10000)],[q(4),q(3,1000),q(29,100),q(5,1000)]]){
 const f=e.div(one.sub(e.pow(2))),g=e.mul(one.add(e.pow(2))).div(one.sub(e.pow(2)).pow(2));
 assert(two.mul(C).mul(e).div(one.sub(e)).lt(one));
 assert(C.mul(g.add(lam.mul(f))).lt(lam.sub(d)));
 assert(C.mul(one.add(m).mul(g).add(one.sub(lam).add(d).mul(f))).lt(one.sub(lam)));
}
assert(A.div(q(u)).lt(q(1,40)));
assert(q(N,N-1).mul(q(10,3)).mul(A.pow(3)).div(q(u)).lt(q(1,40)));
text("PASS: truncated occupancy and ratio-four stitch margins");

console.log("PASS: long_cycles_stitched_early_band-03");
