globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}


const pl=q(157,50),pu=q(22,7),K=q(24),sk=q(489,100),lo=x=>eb(x)[0];
const rows=[[395,261,8,7,31,1,1],[416,274,9,13,37,3,5],[430,283,10,19,43,1,3],[414,274,11,0,1,4,25]];
for(const [a0,R0,B4,m1,m2,i1,i2] of rows){
 const a=q(a0,100),R=q(R0,1000),B=q(B4,4),b=q(4).mul(pl.sq()).div(a.sq().mul(K).add(q(10)));
 ck(o.add(a.sq().mul(K).div(pl.sq())).div(K.sq()).lt(R.sq())&&two.lt(b.mul(q(11*25**2-312))),"lattice");
 function lat(m,v){let s=q(0);for(let j=1;j<=12;j++){const u=b.mul(q(j*(j+1)));s=s.add(q(v?2*j+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return s.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(v?1:27)))));}
 const f=lat(11,true),h=lat(11,false),g=lat(3*B4,true),j0=lat(3*B4,false),j=lat(3*(B4-4),true);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 let P,W,d;
 if(B4<11){
  const r=q(m1,m2);P=o.add(r).mul(p);
  W=x.mul(j).add(r.mul(x).mul(f)).add(g);
  d=p.div(q(25)).add(P.div(K)).add(P.div(B.mul(K)));
 }else{
  const u=q(1053,1000),v=q(1442,1000),z=q(181,100);
  function mask(p){return z.mul(p.div(q(25)).add(p.sq().mul(q(1,8).add(q(1,100)))));}
  P=u.mul(p).div(two).add(v.mul(p).div(q(6))).add(z.mul(p).div(q(12))).add(mask(p));
  W=u.mul(x).mul(j).div(two).add(v.mul(x).mul(lat(15,true)).div(q(6))).add(z.mul(x).mul(f).div(q(12))).add(mask(x).mul(f)).add(g);
  const ne=two.mul(ex(q(829,1000).mul(p)).sub(o));
  d=p.mul(ex(p)).div(q(25)).add(p.div(two).sq().mul(ex(p.div(two)))).add(ne.div(K)).add(ne.div(B.mul(K)));
 }
 const V=W.div(q(3)),mis=q(i1,i2).mul(o.add(j0)).mul(R).div(B),c=o.sub(P),slice=c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))));
 text({a:a.val(),W:W.val(),d:d.val(),mis:mis.val(),c:c.val(),slice:slice.val()});
 ck(q(0).lt(c)&&V.sq().add(W.add(d).add(mis).sq()).lt(c.sq())&&V.lt(slice),"sparse ellipse");
}

const pk1=q(59,100),pk2=q(54,100),C=q(5,2),H=q(3),D1=q(48),D2=q(60);
function amp(C,x,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(x))}
function wit(C,x){return two.mul(C).mul(x).div(o.sub(x.sq())).lt(o)}
function driftMain(a,b,l,d,g,dr){const z=o.sub(l.sq());
 const m=a.add(d).add(a.mul(l).mul(d).div(z)).div(o.sub(a));
 const qx=b.add(b.mul(dr.div(z).add(g.mul(o.add(l.sq())).div(z.sq())))).div(o.sub(b));
 return m.add(qx).lt(o);
}
ck(K.mul(ex(q(1,6*48))).lt(pk1.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(23)))&&K.mul(ex(q(1,6*60))).lt(pk2.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(23))),"Robbins peaks");
const e1=q(181,1000),a1=q(133,1000),d1=q(483,1000),b1=q(52,1000),l2=q(52,1000);
ck(o.div(e1).lt(lo(q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80))))&&o.div(e1).lt(lo(D1.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&amp(C,q(4),a1)&&wit(C,e1),"first pure and witness");
ck(C.div(l2).lt(lo(q(39,10)))&&C.mul(q(1,2).div(q(692,100)).add(pk1.div(sk))).lt(d1)&&C.div(q(49)).lt(b1),"first drifts");
const z0=o.sub(l2.sq()),s0=d1.add(q(3).mul(b1)).div(z0).add(two.mul(b1).mul(l2.sq()).div(z0.sq()));
ck(two.mul(a1).add(d1).add(a1.mul(l2).mul(d1).div(z0)).add(a1.mul(d1.add(b1))).add(a1.mul(l2.sq()).mul(s0)).lt(o.sub(a1)),"first sign");
const e2=q(75,1000),l=q(43,100),a2=q(12,1000),aa=q(8,1000),ar=q(155,1000),d=q(48,100),dr=q(53,100),g=q(5,100);
ck(o.div(e2).lt(lo(q(70,27)))&&H.mul(e2).lt(l)&&amp(H,q(60,9),a2)&&wit(H,e2),"small second");
ck(H.mul(q(3,61).add(pk2.div(sk))).lt(d)&&H.mul(q(4,61).add(pk2.div(sk))).lt(dr)&&H.div(q(61)).lt(g),"second drifts");
ck(amp(H,q(64,9),aa)&&driftMain(a2,a2,l,d,g,dr)&&driftMain(aa,ar,l,d,g,dr),"second signs");
function lower(w){const z=w.sub(o);return pk2.div(sk.mul(o.sub(o.div(w)))).mul(em(q(23).mul(z.sq().div(two).sub(z.sq().mul(z).div(q(3))))));}
function bad(b,w){return lower(w).div(q(b).mul(o.sub(em(q(23).mul(w.sub(o)).div(q(b))))));}
function upper(w){const z=o.sub(w);return pk2.div(sk.mul(z)).mul(em(q(24).mul(z.sq().div(two).add(z.sq().mul(z).div(q(3))))));}
ck(bad(2,q(10,7)).lt(q(42,1000))&&bad(3,q(15,8)).lt(q(4,1000))&&upper(q(5,7)).lt(q(123,1000)),"four-base tails");
ck(q(38,100).div(q(3)).lt(q(64,100).mul(q(333,1000)))&&q(64,100).mul(q(333,1000)).lt(q(76,300)),"four-base monotonicity");
ck(q(3,4).div(q(333,1000)).lt(q(226,100))&&q(5,4).mul(q(102,100)).div(q(333,1000).add(q(1,3))).lt(q(192,100)),"four-base singleton ratios");
const den=q(246,1000),right=q(459,1000);
ck(q(3,4).div(den).lt(q(305,100))&&q(5,4).mul(right).div(den).lt(q(234,100)),"four-base doubleton ratios");
ck(q(15,16).mul(right).div(den.sq()).div(ar.mul(o.sub(ar))).lt(lo(q(4)))&&q(15,16).mul(q(38,100)).div(q(333,1000).sq()).div(ar.mul(o.sub(ar))).lt(lo(q(4))),"four-base curvature");
ck(q(234,100).mul(e1).lt(l)&&H.div(l).lt(lo(q(64).mul(q(1,4).sub(q(1,5))))),"four-base outward");
const o4=q(305,100).mul(q(136,1000)).add(q(234,100).mul(e1));
ck(q(1000,136).lt(lo(q(2)))&&o4.add(q(6).mul(e1.sq()).mul(e1).div(o.sub(e1.sq()))).lt(o),"four-base witness");
ck(q(9*63*63,4*9*64).lt(q(395,100).sq())&&q(9).mul(q(5,4).sq()).lt(q(395,100).sq()),"first splice a");
ck(q(5*63*63,2*9*64).lt(q(416,100).sq())&&q(10).mul(q(5,4).sq()).lt(q(416,100).sq()),"first splice b");
ck(q(63,3).div(sk).lt(q(43,10))&&q(11).mul(q(5,4).sq()).lt(q(43,10).sq()),"second splice a");
ck(q(3*92*92,16*93).lt(q(414,100).sq()),"second splice b");
ck(q(1,2).div(q(692,100)).lt(q(1,8))&&q(10,24).mul(q(49,48)).div(q(692,100)).lt(q(1,8)),"phase");

console.log("PASS: long_cycles_k24_through_3k-01");
