globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[96,3396,159,10,18,4017],[96,4017,168,8,18,4488],[96,4488,173,8,18,4759],[96,4759,177,8,18,4990],[96,4990,179,8,18,5101],[128,4589,182,8,18,5280]];
const covered={96:3396,128:4589};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(8,5).div(sk));
 ck(q(0).lt(rad)&&q(25*N,16).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0];
ck(q(252).lt(lo(q(28,5)))&&q(316).lt(lo(q(58,10))),"eventual logs");
ck(covered[96]>=5040 && covered[128]>=5220,"eventual overlap");
const t=q(4,5),F=q(999,1000),e=q(46,100),a=q(31,100),l=q(49,100),v=q(86399,86400);
ck(q(17,20).sq().mul(q(256,900)).lt(q(1,4)),"heavy load window");
ck(o.div(e).lt(lo(o.div(t.sq()).mul(q(1,2).sub(q(1,702))))),"first outward loss");
ck(q(1000).lt(lo(q(9).div(two.mul(t.sq())).mul(q(234,237)))),"third witness loss");
ck(e.mul(q(17,16)).div(F).lt(l),"local tail ratio");
ck(q(81,16).div(l).lt(lo(v.mul(q(293)).mul(q(5,68)))),"far right loss");
ck(o.div(F.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(t.sq()))),"curvature");
const y=o.sub(e.sq());
const cost=two.div(F).mul(e.add(q(1,1000).mul(q(19,16).div(y).add(e.sq().div(q(8).mul(y.sq()))))));
ck(cost.lt(o),"high witness");
const h=q(34,100),b=q(79,1000000),tiny=q(1,1000);
ck(q(27,4).mul(t.div(q(293)).add(q(45,100).div(q(97,10)))).lt(h),"right drift");
const z=o.sub(l.sq()),u=o.sub(l);let p=o;for(let i=0;i<13;i++)p=p.mul(l);
const late=a.mul(p).mul(h.add(q(14).mul(b)).div(u).add(b.mul(l).div(u.sq())));
ck(two.mul(a).add(tiny).add(a.mul(l).mul(tiny).div(z)).add(a.mul(tiny).div(z)).add(late).lt(o.sub(a)),"signed mean");
ck(o.div(t.sq()).div(o.sub(o.div(t.mul(q(293))))).lt(q(8,5)),"floor correction");
ck(t.add(q(10,3).mul(t.sq()).mul(t).div(v)).div(q(293)).lt(q(1,40)),"phase correction");

console.log("PASS: long_cycles_dense_quadratic_witness-01");
