globalThis.text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(156)).mul(ex(q(5,16)).sq()).lt(q(20,100).sq()),"vertical log bound");
ck(q(78,100).lt(q(80,100).mul(o.sub(q(20,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(20,100).div(o.sub(q(20,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[80,12,90,650,5,22],[80,22,132,425,5,49],[80,49,186,250,7,100],[80,100,246,125,10,176],[80,176,304,75,10,272],[80,272,331,60,10,323],[80,300,367,60,16,851],[80,851,526,25,16,1752],[80,1752,666,15,16,2823],[80,2823,775,10,16,3824],[80,3824,853,8,16,4635],[80,4635,877,8,16,4896]];
const covered={80:12};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(89,10);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(87,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(816,1000).mul(p)).sub(o).mul(q(524,1000)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(524,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(524,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(13,10).div(a.div(sk).add(two)); const ref2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const dense=B>=300; const rad=a.sub((dense?q(8,5):q(18,5)).div(sk));
 ck(q(0).lt(rad)&&(dense?q(25*N,16):q(400*N,121)).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1],C=q(27,8),sk=q(89,10),A=q(45,100), mt=q(43,100),sp=q(309,10),n0=q(960),D=q(959),v=D.div(n0),u=q(55,100);
ck(q(188).lt(lo(q(53,10)))&&covered[80]>4770,"eventual overlap");
ck(q(1000,575).lt(lo(q(575,1000).sub(q(1,80))))&&q(87,1000).mul(q(3,2)).lt(q(131,1000)),"cycle tail");
ck(q(80).mul(eu(q(1,6*959))).lt(mt.sq().mul(two).mul(pl).mul(q(11,12)).mul(q(79))),"Stirling peak");
function geom(x,y){return x.div(o.sub(y))}
function upp(x){return q(80).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3))));}
function low(x){return q(79).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))));}
const e1=q(55,1000),e2=q(22,1000);
ck(q(1244,1000).lt(q(56,45))&&q(9).lt(q(79).mul(q(28,45).sub(q(1,2)))),"long singleton profile");
ck(mt.div(sk.mul(o.sub(o.div(q(1244,1000))))).lt(q(1,4)),"prefactor b2");
ck(mt.div(sk.mul(o.sub(q(71,100)))).lt(q(17,100))&&mt.div(sk.mul(o.sub(q(5,8)))).lt(q(13,100)),"other prefactors");
ck(q(62,100).sq().mul(q(95,12)).mul(q(20,19).sq()).lt(q(15,8).sq())&&q(15).lt(q(79).mul(q(8,15).sub(q(1,3)))),"long doubleton profile");
ck(q(6,10000).add(q(3,8).mul(geom(em(low(q(244,1000))),em(q(9))))).lt(e1),"error singleton");
ck(q(48,10000).add(q(5).mul(q(17,100)).mul(em(upp(q(29,100))))).add(q(5,6).mul(q(13,100)).mul(geom(em(low(q(6,10))),em(q(15))))).lt(e2),"error doubleton");
const L=q(193,100),R=q(120,100);
for (const [h,eps,r,ss,m] of [[q(76,100),e1,A.mul(q(13,14)),o,q(15,14)],[q(44,100),e2,A.mul(q(18,19)),q(1,2),q(20,19)]]){
 ck(eu(ss).mul(mt).div(sk.mul(r.sq())).lt(h),"profile derivative");
 ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L)&&m.mul(o.add(eps)).div(o.sub(eps)).lt(R),"neighbor ratios");
}
const eH=q(205,1000),lH=q(41,100),aH=q(10,100),eM=q(135,1000),lM=q(499,1000),aM=q(215,1000),eL=q(13,1000),lL=q(66,1000);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,51))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(483,1000)).mul(q(515,1000))))),"mid pure");
ck(o.div(eL).lt(lo(D.div(q(220)))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&C.mul(q(21,20)).div(lH).lt(lo(v.mul(sp).mul(o.div(u).sub(q(50,31))))),"exits");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM)&&C.mul(q(3,2)).mul(eL).lt(lL),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(o.div(u.sq()))),"high curvature");
ck(C.sq().mul(q(15,14)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(483,1000).sq())))&&C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(D.div(q(169)))),"mid curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,14,true)).lt(o)&&cost(eM,20,false).lt(o)&&cost(eL,1,false).lt(o),"witnesses");
const d=q(235,1000),b=q(37,10000),C3=q(352,100);
ck(q(10,3).div(o.sub(o.div(q(20)))).lt(C3)&&C3.mul(u.div(sp).add(mt.div(sk))).lt(d)&&C3.div(n0).lt(b),"main drift");
ck(q(1331,1000).lt(q(4,3).mul(v))&&q(26).lt(q(331,1000).mul(q(80)).add(o)),"lower drift spacing");
ck(C.div(v).mul(q(1331,1000)).mul(mt).div(sk).mul(geom(em(low(q(331,1000))),em(q(26)))).lt(q(1,100)),"lower drift magnitude");
for(const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){const z=o.sub(l.sq());ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");}
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sp)))).lt(q(18,5)),"floor");
ck(u.div(sp).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sp)).lt(q(1,40)),"phase");
const dense=q(4,5),f=q(999,1000),de=q(46,100),dl=q(49,100),da=q(31,100),dn0=q(24000),v0=q(23999,24000),s0=q(154);
ck(q(17,20).sq().mul(q(95,300)).lt(q(1,4))&&q(1000).lt(lo(q(24))),"dense lower amplitudes");
ck(o.div(de).lt(lo(o.div(dense.sq()).mul(q(1,2).sub(q(1,369))))),"dense pure");
ck(o.div(q(12,10000)).lt(lo(q(9).div(two.mul(dense.sq())).mul(q(123,126)))),"third witness");
ck(de.mul(q(17,16)).div(f).lt(dl)&&q(81,16).div(dl).lt(lo(v0.mul(s0).mul(q(5,68)))),"dense actual");
ck(o.div(f.sq().mul(da).mul(o.sub(da))).lt(lo(o.div(dense.sq()))),"dense curvature");
const z0=o.sub(de.sq());
ck(two.div(f).mul(de.add(q(12,10000).mul(q(19,16).div(z0).add(de.sq().div(q(8).mul(z0.sq())))))).lt(o),"dense witness");
const dd=q(23,100), db=q(15,100000),full=q(1,1000),u0=o.sub(dl),w0=o.sub(dl.sq());let p=o;for(let j=0;j<6;j++)p=p.mul(dl);
ck(C3.mul(dense.div(s0).add(mt.div(sk))).lt(dd)&&C3.div(dn0).lt(db),"dense drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(80)))),"dense small drift");
const late=da.mul(p).mul(dd.add(q(7).mul(db)).div(u0).add(db.mul(dl).div(u0.sq())));
ck(two.mul(da).add(full).add(da.mul(dl).mul(full).div(w0)).add(da.mul(full).div(w0)).add(late).lt(o.sub(da)),"dense margin");
ck(o.div(dense.sq()).div(o.sub(o.div(dense.mul(s0)))).lt(q(8,5)),"dense floor");
ck(dense.div(s0).lt(q(1,40))&&q(10,3).mul(dense.sq()).mul(dense).div(v0.mul(s0)).lt(q(1,40)),"dense phase");

console.log("PASS: long_cycles_k80_from_12k-01");
