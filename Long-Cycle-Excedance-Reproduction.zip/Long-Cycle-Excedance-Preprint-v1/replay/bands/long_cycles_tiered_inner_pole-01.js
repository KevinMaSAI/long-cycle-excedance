globalThis.text = console.log;
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
for(const [K,a,r,F,G,d,V,W] of [
[10,2,225,75,1,202,555,800],
[24,3,200,114,4,196,520,780],
[64,4,161,318,30,160,515,835],
[256,5,100,699,134,100,473,870]
]){
 const b=q(4).mul(pi.pow(2)).div(q(a*a*K+10));
 function lattice(m){return three.div(one.add(two.mul(b)).pow(m)).add(q(5).add(one.add(q(6).mul(b)).div(b.mul(q(m-1)))).div(one.add(q(6).mul(b)).pow(m)))}
 assert(q(2).lt(b.mul(q(26*Math.floor((K-1)/2)-12))));
 const R=q(r,1000), f=q(F,1000), g=q(G,1000), D=q(d,1000);
 assert(one.add(q(a*a*K).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)));
 assert(lattice(Math.floor((K-1)/2)).lt(f));
 assert(lattice(K-1).lt(g));
 assert(q(a*a).div(pi.pow(2).mul(q(K))).lt(D.pow(2)));
 const s=two.mul(f).div(three);
 const p=two.mul(expUp(R.mul(one.add(s))).sub(one));
 const z=two.mul(expUp(R.mul(q(3,2).add(s))).sub(one));
 const uf=z.mul(f).add(g);
 const v=p.add(uf.div(three)), w=p.add(uf).add(D.mul(one.add(g.div(three))));
 assert(v.lt(q(V,1000)));assert(w.lt(q(W,1000)));
 assert(q(V,1000).pow(2).add(q(W,1000).pow(2)).lt(one));
 assert(f.pow(2).add(f.div(three).pow(2)).lt(one));
 text({K,a,V,W,ok:true});
}

console.log("PASS: long_cycles_tiered_inner_pole-01");
