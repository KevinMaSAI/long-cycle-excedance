const text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=16,sk=q(4),xi=q(84,100),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;

const aa=x=>x.lt(q(0))?q(0).sub(x):x;
const cap=[882352943,784313727,524475526,324074076,251256239,91160178,22319961,17905597,13692186,1576387,2267073,1065241,184152,203435,111219,9062,17735,7395,1164,958,541,65,76,25];
for(const k of [14,15]){
 const d=[o];for(let j=1;j<8*k;j++)d[j]=j<k?q(0):q(j-1).mul(d[j-1]).add(d[j-k]).div(q(j));
 const u=j=>q(k).mul(d[j]);
 function cu(n,m){let v=q(0);for(let j=n;j<m;j++)v=v.add(aa(u(j).sub(u(j-1)))); return v;}
 function tail(n){return cu(n,7*k).add(q(8,7).mul(cu(7*k,8*k)));}
 let peak=q(589,1000),bot=q(533,1000),min3=q(580,1000),max3=q(584,1000);
 for(let j=2*k;j<4*k;j++){ck(bot.lt(u(j))&&u(j).lt(peak),"general d");if(j>=3*k)ck(min3.lt(u(j))&&u(j).lt(max3),"3k d");}
 const C=[77,38,102,54,15,3];
 const den=[1000,10000,1000000,10000000,100000000,1000000000];
 let vs=[];
 for(let i=0;i<C.length;i++){const L=i+2,v=tail(L*k);ck(v.lt(q(C[i],den[i])),"tail "+L);vs.push(v.val());}
 const v=cu(k+1,2*k).add(tail(2*k));
 ck(o.add(v).div(two).lt(q(780,1000)),"total");
 ck(cu(2*k,3*k).lt(q(74,1000)),"two-cycle");
 const vals=[];for(let i=0;i<24;i++){const b=4+i;const j=b<8?Math.min(2*k,Math.floor((b+1)*k/4)+1):Math.ceil((b+1)*k/4),l=b<8?Math.floor(b*k/4)+1:Math.ceil(b*k/4);let w=cu(l,j).div(two); ck(w.lt(q(cap[i],10000000000)),"quarter mass "+b);}
 text({k,tail:vs,total:v.val()});
}

ck(q(45,14).div(o.sub(q(5,43))).lt(q(15,4))&&q(43,10).sq().lt(q(56,3)),"truncated occupancy");ck(q(589,580).lt(q(1016,1000))&&q(1000,580).lt(q(1725,1000))&&q(51,580).lt(q(89,1000))&&q(38,5800).lt(q(66,10000))&&q(38*6,5800).lt(q(394,10000)),"normalized count bounds");
console.log('PASS: counts');
