const text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}



const lo=x=>eb(x)[0], C=q(27,8),pk=q(54,100),K=q(14),sk=q(374,100),pl=q(157,50),D=q(41),n=q(42),sd=q(64,10),v=D.div(n);
ck(K.mul(ex(q(1,6*41))).lt(pk.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(13))),"Robbins peak");
ck(q(15,12).lt(q(112,100).sq())&&q(19,10).lt(q(2).mul(q(15,14)).div(q(112,100))),"main mean");
const phip=z=>z.sq().div(two).sub(z.sq().mul(z).div(q(3))), phim=z=>z.sq().div(two).add(z.sq().mul(z).div(q(3)));
const geom=(x,y)=>x.div(o.sub(y));
ck(q(19,10).lt(lo(q(65,100)))&&q(2).lt(lo(q(7,10))),"log bounds");
const long=pk.div(sk.mul(o.sub(q(10,19)))).mul(geom(em(q(13,4)),em(q(117,20)))).div(two);
ck(long.lt(q(59,1000))&&pk.div(sk.mul(q(1,2))).mul(geom(em(q(39,10)),em(q(65,10)))).div(two).lt(q(3,1000)),"long union");

const hb=q(38,100),pj=q(64,100);
for(const [a,b,lf,rf,pr,L,R] of [[q(301,1000),q(36,100),o,q(6,5),o,q(333,100),q(186,100)],[q(316,1000),q(1,3),q(3,4),q(5,4),q(15,16),q(238,100),q(197,100)]]){
 ck(pj.mul(a).lt(two.mul(b).mul(hb))&&hb.mul(b).lt(pj.mul(a)),"monotone ratios");
 ck(lf.div(a).lt(L)&&rf.mul(hb.add(pj)).div(a.add(b)).lt(R)&&pr.mul(hb).div(a.sq()).lt(q(420,100)),"r≥4 ratios");
}
const pr=q(330,1000),p3=q(375,1000),a3=q(625,1000);
ck(q(2,3).div(pr).lt(q(2021,1000))&&q(4,3).mul(o.div(pr.add(q(1,2)))).lt(q(161,100)),"r=3 ratios");
ck(a3.mul(pr).lt(p3)&&q(8,9).mul(p3).div(pr.sq()).lt(q(31,10)),"r=3 curvature factor");
const eL=q(136,1000),eR=q(181,1000),e3=q(172,1000),e2=q(34,1000),l=q(46,100),l2=q(104,1000),a=q(85,1000);
ck(o.div(eL).lt(lo(q(2)))&&o.div(eR).lt(lo(q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80))))&&o.div(eR).lt(lo(q(2).sub(q(4,15)))),"first pure high");
ck(o.div(e3).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&o.div(e2).lt(lo(D.div(q(4)).mul(q(1,2).sub(q(1,6))))),"pure low");
ck(q(333,100).mul(eL).lt(l)&&q(197,100).mul(eR).lt(l)&&q(161,100).mul(e3).lt(l)&&C.mul(q(3,2)).mul(e2).lt(l),"first ratios");
ck(C.mul(q(3,2)).div(l2).lt(lo(q(39,10)))&&C.div(l2).lt(lo(q(6))),"steep second");
const zc=a.mul(o.sub(a));
ck(q(420,100).div(zc).lt(lo(q(4)))&&q(31,10).div(zc).lt(lo(D.div(q(9))))&&C.sq().mul(q(3,2)).div(zc).lt(lo(D.div(q(4)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R,e,m] of [[q(333,100),q(186,100),eR,5],[q(238,100),q(197,100),eR,4],[q(2021,1000),q(161,100),e3,3]])ck(L.mul(eL).add(R.mul(e)).add(cost(e,m,true)).lt(o),"opposing witnesses");
ck(cost(e2,1,false).lt(o),"small witness");
function nlow(w){return em(q(13).mul(phim(o.sub(w))));}
function nhigh(w){const z=w.sub(o);let L=q(0),p=z;for(let i=2;i<=7;i++){p=p.mul(z);L=i%2?L.sub(p.div(q(i))):L.add(p.div(q(i)));}return em(q(13).mul(L));}
function tail(j,beta){return geom(nhigh(q(j).div(beta)),em(q(13).mul(o.div(beta).sub(q(1,j)))));}
ck(q(14*14,4*44).lt(q(106,100).sq())&&q(56,44).lt(q(1325,1000))&&q(70,53).lt(q(1325,1000))&&q(70,64).lt(q(1325,1000)),"lattice beta ranges");
const s1=q(106,100),s2=q(124,100);
ck(o.add(tail(2,q(106,100))).lt(s1),"lattice first");
for(const [x,y] of [[o,q(115,100)],[q(115,100),q(123,100)],[q(123,100),q(1325,1000)]])ck(nlow(o.div(x)).add(tail(2,y)).lt(s2),"lattice right");
const cap=q(375,100),d=q(602,1000),right=q(68,100),dt=q(835,1000),b=q(90,1000),xx=q(130,100);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(pk).mul(s1).div(sk).lt(d)&&cap.mul(pk).mul(s2).div(sk).lt(right),"near drift");
ck(cap.mul(q(1,2).div(sd).add(pk.div(sk))).lt(dt)&&cap.div(n).lt(b),"outer drift");
ck(xx.lt(q(4,3).mul(v))&&C.div(v).mul(xx).mul(pk).div(sk).mul(geom(nhigh(xx),em(q(5)))).lt(q(45,100)),"heavy drift");
const z=o.sub(l2.sq()),later=dt.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l2.sq()).div(z.sq()));
ck(two.mul(a).add(d).add(a.mul(l2).mul(d).div(z)).add(a.mul(right)).add(a.mul(l2.sq()).mul(later)).lt(o.sub(a)),"signed comparison");
ck(q(10,3).mul(q(42,41)).div(q(4)).lt(o)&&q(316,100).lt(pl.sq().div(q(3)).mul(o.sub(q(6,4*41)))),"oriented phase");

console.log('PASS: middle_edge');
