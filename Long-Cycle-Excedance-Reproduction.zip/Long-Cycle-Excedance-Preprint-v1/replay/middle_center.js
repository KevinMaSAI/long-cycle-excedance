const text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=14,sk=q(374,100),xi=q(780,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[3,408,40,2,3.25,0,0],[3.25,442,40,2,3.5,0,0],[3.5,465,40,2,3.75,0,1],[3.5,475,40,3,3.75,465,0],[3.75,473,40,2,4,0,1],[3.75,508,40,3,4,473,0],[4,482,40,2,4.25,0,1],[4,537,40,3,4.25,482,0],[4.25,487,40,2,4.5,0,1],[4.25,552,40,3,4.5,487,1],[4.25,557,40,3,4.5,552,0],[4.5,497,40,3,5,0,1],[4.5,562,40,3,5,497,0],[5,520,40,3,5.5,0,1],[5,525,40,3,5.5,520,0],[5.5,535,40,3,6,0,1],[5.5,575,40,3,6,535,0],[6,550,40,3,7,0,1],[6,655,40,3,7,550,0],[7,572,40,3,8,0,1],[7,662,40,3,8,572,0],[8,584,40,3,10,0,1],[8,754,40,3,10,584,0],[10,591,40,3,12,0,1],[10,771,40,3,12,591,0],[12,594,40,3,14,0,1],[12,869,40,3,14,594,0],[14,592,40,3,16,0,1],[14,882,40,3,16,592,0]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(46,100).sq().div(two));
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log");
ck(q(48,100).lt(q(54,100).mul(ca)),"vertical positive");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N,low=0,skip=0] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=6;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(min(q(89,1000),q(394,10000).div(fact(Math.floor(B-1)))).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4)));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(119,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(89,1000):L===3?q(66,10000):q(394,10000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1016,1000):o.add(delta),U0=q(1725,1000),E=U0.sub(U);
 const core=low===0;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 const caps=[882352943,784313727,524475526,324074076,251256239,91160178,22319961,17905597,13692186,1576387,2267073,1065241,184152,203435,111219,9062,17735,7395,1164,958,541,65,76,25]; const T=[0,0,77e-3,38e-4,102e-6,54e-7,15e-8,3e-9];const TF=[null,null,q(77,1000),q(38,10000),q(102,1000000),q(54,10000000),q(15,100000000),q(3,1000000000)]; function mkTail(j){return j<=7?TF[j]:TF[7].mul(fact(7)).div(fact(j));}
 function typesOf(jlast){const types=[[4,4,q(1,2)]]; for(let j=4;j<4*jlast;j++)types.push([j,j+1,j<28?q(caps[j-4],10000000000):mkTail(Math.floor(j/4)).div(two)]);return types;}

 {
  const types=typesOf(Math.ceil(N));
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=q(0),wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const rem=q(Math.max(4,4*B-h),4); const factor=4*B-h>=8?q(1016,1000):min(U0,max(q(1016,1000),o.div(q(580,1000).mul(rem))));
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1016,1000).mul(abs).add(q(709,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let bw=q(0),t=o,pow=o, jmax=Math.floor(N-1+1/K);
  const pp=p.div(two),slot=xi.mul(p);
  for(let j=1;j<=jmax;j++){t=t.mul(pp).div(q(j));if(j>B-1)bw=bw.add(t);}
  let sum=o;for(let j=1;j<jmax;j++){pow=pow.mul(slot).div(q(j));sum=sum.add(pow);}
  drift=up(P.div(q(K)).add(P.div(q(4*B*K,4))).add(U0.mul(bw.add(pp.div(q(K+1)).mul(sum)))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const Qmax=Math.ceil(4*B)+4, Jlast=Math.ceil(B)+1, md=16, es=typesOf(Jlast).map(([l,h,w])=>[h,w]);
 es.push([Qmax,mkTail(Jlast).div(two)]);
 const msum=es.reduce((s,[_,w])=>s.add(w),q(0)).mul(p);
  let epsDP=q(0),prod=o,dp=new Map([[0,o]]);
  const pref=new Map();
  function modLoss(h){
   if(pref.has(h))return pref.get(h);
   const r=Math.floor((4*B-h)/4);let v=q(1);
   if(r>=4)v=q(394,10000).div(fact(r));
   else if(r===3)v=q(66,10000);
   else if(r===2)v=q(89,1000);
   else if(r===1)v=max(q(89,1000),o.div(q(580,1000).mul(q(4*B-h,4))).sub(o));
   pref.set(h,v);return v;
  }
  for(let m=1;m<=md;m++){
   const tmp=new Map();
   prod=prod.mul(p).div(q(m));
   for(const [h,v] of dp)for(const [s,w] of es){let f=Math.min(Qmax,h+s);tmp.set(f,(tmp.get(f)??q(0)).add(v.mul(w)));}
   dp=tmp;
   for(const [h,v] of dp)epsDP=epsDP.add(prod.mul(v).mul(modLoss(h)));
  }
  let rem=o;for(let i=1;i<=md+1;i++)rem=rem.mul(msum).div(q(i));
  epsDP=up(epsDP.add(rem.mul(ex(msum))));
  const eps=min(epsDP,up(abs.mul(delta).add(ps)));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=o.sub(abs);
  if(low>=400){const s=q(low*374,10000),m=q(14); function FD(z){let v=o,sum=o;for(let j=1;j<=14;j++){v=v.mul(z).div(q(j));sum=sum.add(v);}return sum.mul(em(z));}
   const J0=ex(q(50000,low*low)).mul(FD(s).add(FD(s.mul(two)).div(two.mul(o.sub(em(s.sub(q(7))))))));
   const aarg=J0.add(pu.div(s)),cos=o.sub(aarg.sq().div(two));
   if(q(0).lt(cos))ref=max(ref,q(5,3).mul(dn(o.div(ex(J0)))).mul(cos).div(pu.mul(R)));
  }
  c=max(c,ref.sub(eps));const angle=pu.div(q(32));if(core)slice=max(slice,ref.mul(o.sub(angle.sq().div(two))).sub(abs.mul(angle)).sub(eps));else slice=q(87,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 
 if(!skip){
  const minD=Math.ceil(B*K)-1,maxD=Math.floor(N*15)-1,Nq=q(Math.round(4*N),4);
  let M=Math.floor(Math.sqrt(minD)/2);
  ck(4*M*M<=minD&&minD<4*(M+1)*(M+1),"minimum M");
  for(; (4*M*M)<=maxD; M++){
    const d=Math.min(maxD, 4*(M+1)*(M+1)-1);
    const s1=q(d*d,M*M*K),s2=Nq.mul(q(d*d,M*M*(d+1)));
    ck(min(s1,s2).lt(a.sq()),"finite M envelope");
  }
 }
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
console.log('PASS: middle_center');
