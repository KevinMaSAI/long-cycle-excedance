const text = console.log;
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(15)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}


const pl=q(157,50),pu=q(22,7),K=q(14),sk=q(374,100),lo=x=>eb(x)[0];
const rows=[[279,249,8,9,37,1,1],[313,277,9,4,11,3,5],[346,305,10,23,51,1,3],[380,333,11,0,1,17,100]];
for(const [a0,R0,B4,m1,m2,i1,i2] of rows){
 const a=q(a0,100),R=q(R0,1000),B=q(B4,4),b=q(4).mul(pl.sq()).div(a.sq().mul(K).add(q(10)));
 ck(o.add(a.sq().mul(K).div(pl.sq())).div(K.sq()).lt(R.sq())&&two.lt(b.mul(q(6*25**2-312))),"lattice");
 function lat(m,v){let s=q(0);for(let j=1;j<=12;j++){const u=b.mul(q(j*(j+1)));s=s.add(q(v?2*j+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return s.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(v?1:27)))));}
 const f=lat(6,true),h=lat(6,false),g=lat(Math.floor(7*B4/4),true),j0=lat(Math.floor(7*B4/4),false),j=lat(Math.floor(7*(B4-4)/4),true);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 let P,W,d;
 if(B4<11){
  const r=q(m1,m2);P=o.add(r).mul(p);
  W=x.mul(j).add(r.mul(x).mul(f)).add(g);
  d=p.div(q(15)).add(P.div(K)).add(P.div(B.mul(K)));
 }else{
  const u=q(1065,1000),v=q(1442,1000),z=q(181,100);
  function mask(p){return z.mul(p.div(q(15)).add(p.sq().mul(q(1,8).add(q(1,68)))));}
  P=u.mul(p).div(two).add(v.mul(p).div(q(6))).add(z.mul(p).div(q(12))).add(mask(p));
  W=u.mul(x).mul(j).div(two).add(v.mul(x).mul(lat(8,true)).div(q(6))).add(z.mul(x).mul(f).div(q(12))).add(mask(x).mul(f)).add(g);
  const ne=two.mul(ex(q(84,100).mul(p)).sub(o));
  d=P.div(K).add(P.div(B.mul(K))).add(q(181,100).mul(p.div(q(30)).add(p.sq().div(q(8)))));
 }
 const V=W.div(q(3)),mis=q(i1,i2).mul(o.add(j0)).mul(R).div(B),c=o.sub(P),slice=c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))));
 text({a:a.val(),W:W.val(),d:d.val(),mis:mis.val(),c:c.val(),slice:slice.val()});
 ck(q(0).lt(c)&&V.sq().add(W.add(d).add(mis).sq()).lt(c.sq())&&V.lt(slice),"sparse ellipse");
}

for(const [N,D,a] of [[q(9,4),32,q(279,100)],[q(5,2),36,q(313,100)],[q(11,4),40,q(346,100)],[q(3),44,q(380,100)]])ck(N.mul(q(D*D,9*(D+1))).lt(a.sq()),"splice radius");
console.log('PASS: sparse_center');
