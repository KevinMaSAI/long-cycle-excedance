# The full two-cycle band for sufficiently large k

**Theorem.** If k≥10^12 and 2k≤n≤3k−2, then E_(n,k) and E_(n+1,k) have simple real roots, and their quotients by t strictly interlace. Together with the earlier onset theorem this proves the initial range k≤n≤3k−1 for each k≥10^12. The bound on k is explicit and deliberately loose.

Here E_(n,k) counts excedances of permutations whose cycles all have size ≥k. Neither the row 3k, which first allows three cycles, nor the same two-cycle interval for all smaller k is proved by this theorem.

## 1. Pole and edge representations

Write t=−q=−exp(−s) with s≥0, p_l=s+(2l+1)πi, and S_j=∑_(l∈Z) p_l^(−j) for j≥2. The logarithmic coefficient in the scaled EGF is S_j/j for j≥k, and (j−1)! S_j=∑_(r≥1)(−q)^r r^(j−1) for s>0, as proved in FIRST_TRANSITION_ALL_K.md. For any row N with 2k≤N<3k, define
    P_N = S_N+B_N,
    B_N = (N/2)∑_(a=k)^(N−k) S_a S_(N−a)/(a(N−a))
        = ∑_(a=k)^(N−k) S_a S_(N−a)/a.
The second equality is symmetry under a↔N−a, using N/(a(N−a))=1/a+1/(N−a). The scaled row satisfies E_(N,k)(−q)=(N−1)!(1+q)^N P_N.

Grouping the two Eulerian series by their total index r gives the equivalent edge form
    (N−1)! P_N = ∑_(r≥1)(−q)^r r^(N−1)(1+c_(N,r)),
    c_(N,r) = ∑_(i=1)^(r−1) (1/i) Pr(Bin(N,i/r)∈[k,N−k]).
Indeed the unnormalized contribution at i is r/[2i(r−i)] times this binomial probability: this follows from the factorial factors in the two Eulerian series, or from the two-cycle case of OCCUPANCY_ALTERNATING_SERIES.md. Split that factor into (1/2)(1/i+1/(r−i)) and apply binomial symmetry to one of the sums. Markov's inequality gives 0≤c_(N,r)≤N/k<3, since Pr(X≥k)≤N(i/r)/k.

## 2. Edge comparison without summing absolute errors over all cycle lengths

Put D=n−1, M=ceil(√D/3), S=D/M, and V_r=q^r r^D. At edge witnesses s=D/m for 1≤m≤M the outward successive ratios of V about m are ≤1/25. On D/(m+1)≤s≤D/m the corresponding ratios hold outward from m on the left and m+1 on the right. This follows from the log-ratio bounds of FIRST_TRANSITION_ALL_K.md, since M+1≤(9/25)√D, D/[2M(M+1)]≥625/162>7/2, and exp(7/2)>25. Also M≤√k and S≤3√D. Since 1≤1+c_(n,r)≤4, the edge witnesses have sign (−1)^m: all other absolute terms sum to at most (8/24)V_m.

The crucial difference of adjacent-row coefficients is exact:
    r(c_(n+1,r)−c_(n,r))
      = n/(n−k+1) ∑_(i=1)^(r−1) Pr(Bin(n−1,i/r)=k−1).             (A)
To see this, append one independent Bernoulli of parameter p=i/r. The newly accepted counts arise from X_n=k−1 and a success, or X_n=n−k+1 and a failure. Thus the acceptance probability increases by p Pr(X_n=k−1)+(1−p)Pr(X_n=n−k+1). In the weighted sum defining c, reflect i↔r−i in the second part. Together the two weights are p(1/i+1/(r−i))=1/(r−i). Multiplying by r and using
    Pr(Bin(n,p)=k−1)/(1−p)
       = [n/(n−k+1)] Pr(Bin(n−1,p)=k−1)
gives (A). The prefactor is ≤2. The Gaussian lattice estimate of GROWING_TWO_CYCLE_STRIP.md applies since k−1 and n−k are each at least k−1. The probability sum is at most (2/√k)(1+2r/√k). Hence 0≤r Δc≤(4/√k)(1+2r/√k).

At a root of P_n between the edge witnesses m and m+1, put λ=m+1/2 and form n!P_(n+1)−λ(n−1)!P_n. Its terms are
    (−1)^r V_r [(r−λ)(1+c_(n,r))+rΔc].
The two main terms from (r−λ)(1+c_(n,r)) have sign (−1)^(m+1) and magnitude at least (V_m+V_(m+1))/2. Their opposing tail is at most 4(25/576+1/48)(V_m+V_(m+1))< (3/10)(V_m+V_(m+1)), by summing (h+1/2)25^(−h). The entire Δc error is at most
    [4/√k](3+3/24+2·25/576)(V_m+V_(m+1)) < (16/√k)(V_m+V_(m+1)).
Here 1+2r/√k≤3 for r≤M and ≤3+2h on the right tail r=m+1+h. The errors sum to <(V_m+V_(m+1))/2. So P_(n+1) has sign (−1)^(m+1) at all such roots.

## 3. Central comparison by Abel cancellation between different poles

For 0≤s≤3√D put ρ=√(s²+π²), θ=atan(π/s) with θ=π/2 at zero, φ=nθ, u=s/ρ² and v=π/ρ². Pair the poles by their conjugate levels l≥0. For an individual pole p at level l, write z_p=ρ/p and let v_p=|(1/p−u)/v|≤2l+1 (the algebraic identity proving this is in the first-transition proof).

We use the following absolute bounds for every a≥k:
    ∑_p |z_p|^a < 4,             ∑_p |z_p|^a v_p < 10;
    ∑_(p, level≥10) |z_p|^a < 1/1000,
    ∑_(p, level≥10) |z_p|^a v_p < 1/200.                          (B)
For verification, ρ²≤9(3k−1)+π²<3kπ², so the Bernoulli fourth-power bound for each l≥1 is |z_p|^a≤[1+l(l+1)/6]^(−4). For the first two levels this is at most (3/4)^4 and (1/2)^4, and for l≥3 it is at most 1296/l^8. The unweighted sum is bounded by twice 1+(3/4)^4+(1/2)^4+1296(3^(−8)+3^(−7)/7). The weighted sum uses twice 1+3(3/4)^4+5(1/2)^4+3240(3^(−7)+3^(−6)/6), by the factor 2l+1≤5l/2 there. Both include the primary poles at l=0. The tail bounds use respectively 2592(10^(−8)+10^(−7)/7) and 7776(10^(−7)+10^(−6)/6). These give (B).

Let L_n=∑_(a=k)^(n−k)1/a<1. Expanding B_n as an ordered sum over poles, the identical-pole part is L_n S_n. For distinct poles p,p' at levels below 10, the normalized mixed sum satisfies
    |∑_(a=k)^(n−k) z_p^a z_(p')^(n−a)/a|
        ≤ [4/k] max(|p|,|p'|)/|p−p'| ≤ 4/√k .                   (C)
If |p'/p|≤1, factor the first product (its modulus is ≤1): the remaining geometric partial sums have magnitude at most 2/|1−p'/p|. Summation by parts with the monotone sequence 1/a gives a bound ≤4/[k|1−p'/p|]. If |p'/p|>1, reverse the order and use p/p' instead, still with weights monotone and their maximum ≤1/k. The second inequality uses |p|,|p'|≤6√k for levels below 10 (s²≤27k, |Im p|≤19π, and k≥10^12), and |p−p'|≥2π>6.

There are at most 400 mixed retained ordered pairs. Contributions involving a level ≥10 in ρ^n B_n have total absolute value ≤(4/1000+4/1000)L_n, by (B). Thus
    |P_n−(1+L_n)S_n|/ρ^(−n) < 1600/√k+ 8/1000 < 1/50.            (D)
Likewise the exact adjacent difference is
    P_(n+1)−uP_n = S_(n+1)−uS_n
        + ∑_(a=k)^(n−k) S_a [S_(n+1−a)−u S_(n−a)]/a
        + S_(n+1−k) S_k/(n+1−k).
The identical-pole terms in the sum multiply S_(n+1)−uS_n by L_n. The mixed terms for retained poles satisfy (C) with extra weight at most 19 in units v. All tail pairs in units v contribute at most (10/1000+4/200)L_n by (B). The boundary term is at most 16ρ/(πk)≤32/√k in units vρ^(−n), again by (B). Therefore
    |P_(n+1)−uP_n−(1+L_n)(S_(n+1)−uS_n)|/(vρ^(−n))
      < 30432/√k+3/100 < 1/10.                                   (E)

The nearest poles give S_n/(2ρ^(−n))=cosφ+error and (S_(n+1)−uS_n)/(2vρ^(−n))=−sinφ+error, each error having magnitude <1/4 (same bound as in FIRST_TRANSITION_ALL_K.md, since nπ²/(2ρ²)>1/2). Equations (D) and (E) then give alternating signs of P_n at φ=jπ, since 1+L_n≥1, and |cosφ|<1/4+1/100<3/10 at its central roots. Hence |sinφ|>19/20 there. At those roots (E) gives P_(n+1) sign −sinφ.

## 4. Closing the proof

At the stitch S=D/M, the phase obeys |φ(S)/π−M|<1/8, from atan(x) between x−x³/3 and x, and M≤(14/33)√D as in the first-transition proof. Use the edge witnesses m=1,...,M followed by φ=jπ, j=M+1,...,floor(n/2); their signs are (−1)^m and (−1)^j respectively. The short overlap from S to φ=Mπ if needed has no roots, since |cosφ|≥cos(π/8) and (D) gives a normalized error <3/10. Thus each consecutive bracket contains a root in the expected phase interval or edge interval. Reciprocation, the simple zero at 0, and the forced odd-row root at −1 account for the entire degree n−1, proving simplicity and one root per bracket. At a negative root the derivative sign equals the sign at the right witness. On (−1,0) the edge and central comparisons show that P_(n+1) has the opposite sign; at the odd root −1, −sin(nπ/2) gives the opposite sign from the last witness. For roots below −1 the same comparison follows by reciprocation, with positive factor −r^(−3) in the ratio. These sign conditions, degree, and positive leading coefficients imply strict interlacing after dividing out the common simple zero, as in FIRST_TRANSITION_ALL_K.md.

This proof deliberately stops before n+1=3k. New cubic (three-cycle) boundary terms enter there, and require new coefficient-difference and cancellation estimates.

