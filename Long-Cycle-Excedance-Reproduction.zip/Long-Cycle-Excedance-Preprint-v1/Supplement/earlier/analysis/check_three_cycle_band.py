from fractions import Fraction as Q
from math import factorial,prod
assert 11*(Q(40,1521)+Q(1,78))<Q(9,20)
assert 36*(3+Q(3,39)+2*Q(40,1521))<120
assert 2*(1+Q(4,5)**4+Q(4,7)**4+4096*(Q(1,3**8)+Q(1,7*3**7)))<6
assert 2*(1+3*Q(4,5)**4+5*Q(4,7)**4+10240*(Q(1,3**7)+Q(1,6*3**6)))<20
assert 8192*(Q(1,30**8)+Q(1,7*30**7))<Q(1,10**6)
assert 24576*(Q(1,30**7)+Q(1,6*30**6))<Q(1,10**5)
assert Q(220000*48*59,10**11)<Q(1,100)
assert sum(16*(Q((m-1)*6**(m-2)*20,10**6)+Q(6**(m-1),10**5)) for m in (2,3))<Q(1,50)
assert Q(1,100)+Q(1,50)+Q(1100,10**11)+Q(504,10**55)<Q(1,20)

def comp(n,m,k):
    if m==0:
        if n==0: yield ()
    else:
        for a in range(k,n-(m-1)*k+1):
            for x in comp(n-a,m-1,k): yield (a,)+x

def prob(n,rs,xs):
    return Q(factorial(n)*prod(a**b for a,b in zip(rs,xs)), sum(rs)**n*prod(map(factorial,xs)))
def coeff(n,k,m,r):
    return sum(Q(r,factorial(m)*prod(rs))*sum(prob(n,rs,xs) for xs in comp(n,m,k))
               for rs in comp(r,m,1))
count=0
for k in range(3,6):
    for n in range(3*k,4*k):
        for r in range(1,8):
            for m in (2,3,4):
                expected=sum(Q(r,factorial(m-1)*prod(rs[1:]))*sum(prob(n,rs,(k-1,)+xs) for xs in comp(n-k+1,m-1,k)) for rs in comp(r,m,1))
                assert r*(coeff(n+1,k,m,r)-coeff(n,k,m,r))==expected
                count+=1
print("PASS rational bounds and occupancy difference at",count,"exact grid points")

