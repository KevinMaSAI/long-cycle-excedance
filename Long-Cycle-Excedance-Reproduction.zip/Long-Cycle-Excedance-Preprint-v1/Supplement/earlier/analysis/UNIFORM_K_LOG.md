# Uniform O(k log k) tail from a bounded-imaginary-part projection

**Theorem.** For all integers k>=64 and n>=900(k-1) log(2(k-1)), E_(n,k) has simple real roots, and its quotient by t strictly interlaces the next quotient. This improves UNIFORM_K_LOG_SQUARED.md; the phase, edge and interlacing completion there apply unchanged after the bounds below. No finite verification of roots is used. The conjecture for the remaining rows is not settled.

Keep d=k-1 and L=log(2d)>4. Instead of bounding the analytic logarithm in absolute value and using its full Fourier series, exploit the bounded imaginary part. Define F_0(z)=Log(1+q exp(z)) on |z|<rho, where the principal branch and its analyticity are proved in UNIFORM_K_LOG_SQUARED.md. Its imaginary part has absolute value at most pi. If c_m=[z^m]F_0(z), then for each m>=1 and R0=rho(1-1/d),
    c_m R0^m = 2i integral_(t=-pi)^pi Im F_0(R0 exp(it)) exp(-imt) dt / (2pi).
Indeed F_0 has only nonnegative Fourier modes, its complex conjugate only nonpositive modes, and 2i times the imaginary part is their difference. The constant mode is irrelevant. G_s(z) is the truncation sum_(m=2)^d c_m z^m, as previously verified from the logistic coefficients.

At radius R1=rho(1+1/d), put tau=(d+1)/(d-1). The resulting averaging kernel is K_2(u)=sum_(m=2)^d tau^m exp(imu). Its absolute value is at most 9(d+1), using tau^(d+1)<=exp(64/31)<8 for d>=63. Its geometric formula and tau^2<= (32/31)^2<2 give alternative bound (tau^2+tau^(d+1))/|1-tau exp(iu)|<=5pi/|u| for 0<|u|<=pi. Splitting at pi/(d+1) as before gives average |K_2| <=9+5log(d+1)<8L. Thus
    |G_s(z)| <= 2 pi*8L < 51 L
on |z|=R1, and throughout that disk by maximum modulus. This is a parameter-uniform O(log k) estimate, rather than O(log^2 k). No bound on the real part of F_0 is needed.

Use the same radial exclusion geometry and denominator compare as in UNIFORM_K_LOG_SQUARED.md. For s<=(7/2)sqrt(n) the circular errors are at most
    1024 d n exp(102 L - n/(3d)).
For n>=900d L this decreases in n and is below 2^20 exp(-195 L)<1/100, by d^2 L<=exp(3L). When s<=12sqrt(d), the reserved radial power suppresses at least (6/49)n/d in the logarithm, and (6/49)*900>102. This absorbs the full exp(102 L) numerator penalty. The remaining exponent gives the same c>1/2 and weighted farther bound <1/4. When s>=12sqrt(d), retain the actual residue estimate <11/40, which never depended on J or the old n threshold. In both regimes the central error budget <1/3 is valid.

All other sufficient hypotheses in the previous root-count proof hold: n>=16385, D=n-1>=16d, S>=12sqrt(d), and S<=(7/2)sqrt(n); the same phase perturbation and arctangent bounds work. Thus the uniform edge signs and strict adjacent comparison complete the theorem as claimed. The rational constant replay is check_uniform_k_log.py. The unresolved parameter wedge for these estimates is k<=n<900d L, and the small k not covered elsewhere, not the entirety of a quadratic window.

