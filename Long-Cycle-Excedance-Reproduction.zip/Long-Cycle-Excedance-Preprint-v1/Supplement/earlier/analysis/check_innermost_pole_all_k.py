from fractions import Fraction as F
from math import factorial
def exp_upper(x, N=12):
    return sum(x**j/factorial(j) for j in range(N+1))+x**(N+1)/factorial(N+1)/(1-x/(N+2))
a=F(67,1000)
assert F(5,3)**5 < F(36,10)**2
assert F(36,10)*(F(1,81)+F(1,162)) < a
assert F(5,3)/6**2 < F(216,1000)**2
assert F(216,1000)*(1+2*a/3) < F(226,1000)
assert F(216,1000)*(2+2*a/3) < F(442,1000)
assert exp_upper(F(226,1000))-1 < F(255,1000)
assert exp_upper(F(442,1000))-1 < F(56,100)
assert (1+2*F(56,100))*a/3 < F(48,1000)
assert (1+2*F(56,100))*a < F(143,1000)
assert (1+a/3)**2/(9*6) < F(14,100)**2
assert F(558,1000)**2 + F(793,1000)**2 < 1
print("PASS: innermost pole estimates for all k>=6")
