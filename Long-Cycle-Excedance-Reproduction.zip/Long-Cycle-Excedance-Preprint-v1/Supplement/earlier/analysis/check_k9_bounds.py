from fractions import Fraction as Q
from math import isqrt, factorial
D=2**48
def down(q): return Q((q*D).__floor__(),D)
def up(q): return Q((q*D).__ceil__(),D)
def exp_bounds(x):
    term=ans=Q(1)
    for m in range(1,65):
        term*=x/m
        ans+=term
    return ans,ans+term*x/65/(1-x/66)
def mul(i,j):
    z=[x*y for x in i for y in j]
    return min(z),max(z)
def horner(c,w):
    ans=(0,0)
    for a in reversed(c):
        l,h=mul(ans,w);ans=l+a,h+a
    return max(abs(ans[0]),abs(ans[1]))
polys=[[1],[1],[1,-6],[1,-12],[1,-30,120],[1,-60,360],[1,-126,1680,-5040]]
step=64
qm=[tuple((down(1/b),up(1/a))) for a,b in (exp_bounds(Q(i,step)) for i in range(20*step+1))]
high=[Q(0)]*3
for i in range(20*step):
    ql,qh=qm[i+1][0],qm[i][1]
    w=(ql/(1+ql)**2,qh/(1+qh)**2)
    x=(1-ql)/(1+ql)
    r2=Q(i+1,step)**2+Q(22,7)**2
    r=Q(isqrt((r2*D**2).__floor__())+1,D)
    U=sum(((Q(5,3)**m+1)*w[1]*horner(c,w)*x**(m%2)*r2**(m//2)*r**(m%2)/factorial(m) for m,c in enumerate(polys,2)))
    j=0 if i<10*step else (1 if i<16*step else 2)
    high[j]=max(high[j],U)
assert all(a<c for a,c in zip(high,[45,19,2])),list(map(float,high))
print('U slabs certified: 45, 19, 2')
assert sum((Q(5,3)**m+1)*410**(m//2)*21**(m%2)/factorial(m) for m in range(2,9))/exp_bounds(Q(20))[0]<Q(1,8)
assert 100*Q(144,292)>45 and 100*Q(72,338)>19 and 100*Q(72,482)>2
assert Q(400*9,4*410)>Q(1,2)
assert 144*400*Q(11,4)**45*Q(2,3)**400<Q(1,100)
assert Q(8,7)/4+Q(1,100)<Q(1,3)
assert sum(Q(1,400**(8-m)*factorial(m)) for m in range(1,9))<Q(1,39000)
assert Q(401**8,39000)/exp_bounds(Q(50))[0]<Q(1,200)
assert exp_bounds(Q(6))[0]>401
assert Q(5*20,16)-6==Q(1,4)
assert 15<Q(20**2,16)
assert exp_bounds(Q(20))[0]>40000
assert (1+sum(Q(51**m,3*factorial(m)) for m in range(2,9)))/exp_bounds(Q(50))[0]<Q(1,100)
print('PASS: k=9 rational cutoff 400 margins')
