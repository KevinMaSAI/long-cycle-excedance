from fractions import Fraction as Q
from math import factorial
def lo(x):return sum(x**j/factorial(j) for j in range(65))
def hi(x):return lo(x)+x**65/factorial(65)/(1-x/66)
def T(a):
    z=hi(a)
    return z*(Q(1,2)+(z-1)/5)/(Q(594,1000)-(z-1)/4)
def D(a):return hi(a)+T(a)
K=8192; J=90; pi=Q(22,7); pl=Q(157,50); lam=Q(41,10)
assert J**2<K-1 and 900*14*Q(694,1000)<94**2
assert Q(3*94,J)<Q(32,10)
assert lo(Q(8100,2*31*32))>58
eta=Q(1,58); M0=eta/(1-eta); M1=eta/(1-eta)**2; M2=eta*(1+eta)/(1-eta)**3
assert 14*(M0+M1)<1
assert 7*(M1+M0/2)<Q(2,5)
assert 7*(Q(1001,2000)*M2+Q(1301,1000)*M1+Q(6,10)*M0)<Q(1,2)
assert Q(61,10)*(1/Q(3*J)+Q(1,K)+1/Q(J))<Q(1,10) and Q(61,10*K)<Q(1,1000)
b=4*pl**2/(9*K+10); a=K//2
f=lambda l:(2*l+1)/(1+b*l*(l+1))**a
assert sum(f(l) for l in (1,2,3))+(1+12*b)**(1-a)/(b*(a-1))<Q(4,100)
assert Q(301,100)**2>9+Q(10,K)
assert 2*Q(301,100)/5<Q(121,100)
assert Q(3,2)*(9+Q(10,K))/(pl**2*Q(K-3,K))<Q(138,100)
assert Q(37,20)*Q(63,10)*Q(33,10)/(2*pl)<Q(613,100)
assert Q(613,100)/(1-Q(613,100*J))<Q(66,10)
f32=lambda l,c:(2*l+1)/(1+c*l*(l+1))**32
tail=lambda l,c:(1+c*l*(l+1))**(-31)/(31*c)
lat=lambda c:2*(1+f32(1,c)+f32(2,c)+tail(2,c))
for c,frac,lim in [(Q(1,20),Q(3,4),Q(23,10)),(Q(3,50),Q(8,9),Q(22,10))]:
    assert frac*pl**2/(16*(9+Q(10,K)))>c and lat(c)<lim
assert pl**2/(16*(9+Q(10,K)))>Q(1,15)
assert 2*(f32(2,Q(1,15))+tail(2,Q(1,15)))<Q(1,2500)
assert 2*(f32(4,Q(1,15))+tail(4,Q(1,15)))<Q(1,10**10)
assert 4*pl**2/9>4 and pl**2>Q(98,10)
assert lo(1)>Q(2718,1000)
assert hi(1/lam)<Q(1278,1000)
assert (Q(3,2)*lam/Q(2718,1000))**3<Q(341,100)**2
assert 4/lo(3/lam)+Q(138,100)*Q(341,100)*hi(1/lam)<8
assert 4/lo(3/lam)+Q(121,100)*(lam/Q(2718,1000))*hi(1/lam)<Q(43,10)
M=lambda B:2+Q(138,100)*B
def q(B,z,tilt=lam):
    h=lo((Q(B)-1)/tilt)
    return z*(2+Q(121,100)*z)/h,z*M(B)/h
for B,z,p,w in [(Q(98,10),Q(314,100),Q(22,10),Q(58,10)),(16,4,2,Q(25,10)),(39,Q(625,100),1,Q(4,100))]:
    assert z*z>=B
    x,y=q(B,z)
    assert x<p and y<w
assert hi(Q(1,8))/2<Q(4,7) and Q(23,10)*Q(4,7)<Q(4,3)
assert Q(21,10)*hi(Q(1,8))/2<Q(12,10)
assert Q(22,10)*hi(Q(1,18))/2<Q(117,100)
assert Q(31,15)*hi(Q(1,18))/2<Q(11,10)
for S,Z,b,N,D0,U in [(Q(165,100),Q(93,100),Q(105,1000),Q(281,100),Q(91,100),Q(121,100)),
                     (Q(15,10),Q(77,100),Q(21,100),Q(29,10),Q(785,1000),Q(14,10)),
                     (Q(15,10),Q(77,100),Q(134,1000),Q(242,100),Q(785,1000),Q(111,100))]:
    u=S+Z*b
    assert Z+u*u/2/(1-u*b)<N and D0+N*b<U
assert 6*pi/J<Q(21,100) and 3*pi/J<Q(105,1000) and Q(12,J)<Q(134,1000)
assert 4/(2*J)<Q(23,1000) and 4/(3*J)<Q(15,1000)
pairs=[(Q(14,1000)+Q(46,10)*Q(66,10)/J,Q(4,100)+(Q(81,10)*Q(66,10)+4)/J)]
u=Q(121,100)
pairs.append((Q(14,1000)+((Q(12,10)+Q(203,100)*u)*3*pi+3*u*Q(43,10))/J,
Q(4,100)+Q(23,1000)+((Q(4,3)+Q(208,100)*u)*3*pi+3*u*8)/J))
u=Q(111,100)
pairs.append((Q(14,1000)+((Q(11,10)+Q(203,100)*u)*12+3*u*Q(22,10))/J,
Q(4,100)+Q(15,1000)+((Q(117,100)+Q(208,100)*u)*12+3*u*Q(58,10))/J))
assert all(a*a+b*b<1 for a,b in pairs)
print("PASS: edge T=3 and asymmetric mid-band margins")

# Middle large B: compare only the primary anchor using the faster prefix tilt.
assert D(Q(7,10))<Q(62,10) and D(Q(1,2))<Q(41,10)
assert Q(7,10)/(1+Q(7,10*K))-Q(1,2)-Q(1,18)>Q(1,7)
assert Q(21,16)<Q(115,100)**2
assert 1+2*pi<Q(27,10)**2
beta=Q(21,100)
assert hi(Q(501,1000)*beta)<Q(10,9) and hi(Q(1001,1000)*beta)<Q(124,100)
assert Q(82,10)/lo(Q(16,1)/Q(42,10))*hi((Q(205,100)+Q(501,1000))*beta+Q(41,10)**2/12*beta**2)<Q(34,100)
assert Q(66,100)*Q(9,10)>Q(59,100)
a=Q(62,10);m=Q(16275,1000)
L=Q(1,2)*(Q(713,100)+m/3)+(a*a*beta/6+2*a*m*Q(27,10)/3)/J
assert L<Q(84,10)
z=Q(84,10)*pi/J
assert Q(84,10)*(1+z/(2*(1-z/3)))<10
assert Q(1,9)+(Q(1,9)+Q(41,100))*hi(Q(1,18))<Q(67,100)
assert Q(67,100)/(1-Q(67,100)*pi/J)<Q(7,10)
assert (Q(7,10)+Q(34,100)*10)/Q(66,100)*pi/J<Q(22,100)
assert (Q(12,100)+Q(14,10)*Q(8,100))*beta+3*Q(14,10)*Q(25,10)/J<Q(166,1000)
assert (Q(134,100)*Q(124,100)-1)*Q(4,100)<Q(27,1000)
assert 4/(4*J)<Q(12,1000)
assert Q(4,100)+Q(22,100)+Q(205,1000)/Q(59,100)<Q(7,10)

# High s and beta<=1/2
assert 4*pl**2>39
assert Q(54,10)/lo(39/ (2*lam))<Q(47,1000)
assert q(39,Q(625,100))[1]<Q(4,100)
assert hi(Q(165,100)*Q(1,2)+Q(33,10)**2/48+Q(501,2000))*Q(47,1000)<Q(175,1000)
assert hi(Q(501,2000))<Q(100,77) and Q(825,1000)*Q(77,100)>Q(63,100)
assert Q(1,18)+(Q(1,18)+Q(41,100))*hi(Q(1,8))<Q(59,100)
assert Q(59,100)/(1-Q(59,100)*3*pi/J)<Q(63,100)
assert (Q(63,100)*pi*Q(112,100)/J+Q(35,100)*Q(104,100))/Q(825,1000)<Q(48,100)
assert Q(14,10)/2500+Q(28,10)*3*Q(4,100)/J<Q(5,1000)
assert Q(1175,1000)*hi(Q(1001,2000))+1<3
assert 4/(J*Q(62,10))<Q(8,1000)
assert Q(4,100)+Q(48,100)+Q(14,1000)/Q(63,100)<Q(7,10)

# beta>=1/2, split the first two factors when their norms are not small.
assert D(Q(1,10))<Q(22,10) and D(Q(1,12))<Q(21,10)
assert 49*pi*pi/(2*45**2)<Q(12,100) and 49*pi*pi/(2*90**2)<Q(3,100)
assert Q(1,16)+Q(12,100)<Q(K,5*K+1) and Q(1,16)+Q(3,100)<Q(K,10*K+1)
assert Q(1,16)+Q(1,72)+Q(1,16*72*K)<Q(1,12)
assert Q(22,10)*Q(32,10)/(2*pl)<Q(12,10)
assert Q(21,10)*Q(101,100)*Q(32,10)/(2*pl)<Q(12,10)
t=Q(6,10)
assert sum(t**(j-2)/j for j in range(2,30))+t**28/(30*(1-t))<1
assert Q(22,20)+4*Q(22,10)/(2*pl)<Q(26,10)
assert Q(22,10)**2/12<Q(41,100)
assert Q(21,20)+4*Q(21,10)*Q(101,100)/(2*pl)<Q(25,10)
assert Q(21,10)**2*Q(101,100)**2/12<Q(4,10)
assert Q(42,10)/lo((Q(K,306)-Q(41,100))/4-Q(3101,2000))<Q(3,100)
assert hi(Q(501,1000)*Q(32,10))<5 and Q(97,100)*Q(1,5)>Q(19,100)
assert Q(1,45)+(Q(1,45)+Q(41,100))*hi(Q(12,100))<Q(51,100)
assert Q(51,100)/(1-Q(51,100)*7*pi/J)<Q(6,10)
assert (Q(6,10)*pi*(1+3*Q(4,100)+Q(7,5000))/J+Q(6,100)*Q(104,100))/Q(97,100)<Q(9,100)
assert (2+Q(138,100)*Q(K,36))/lo((Q(K,36)-1)/17-Q(135,100))<Q(3,1000)
assert hi(Q(25,10)*Q(32,10)+Q(4,10)*Q(32,10)**2)*Q(1,10**10)<Q(1,1000)
assert 4/(J*15)<Q(3,1000) and Q(K,36)>15**2
assert Q(4,100)+Q(9,100)+Q(8,1000)/Q(19,100)<Q(7,10)
print("PASS: all-row margins with T=3 for k>=2^13")

