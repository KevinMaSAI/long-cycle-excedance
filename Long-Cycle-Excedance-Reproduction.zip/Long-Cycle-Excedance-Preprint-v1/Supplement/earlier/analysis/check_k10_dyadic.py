if not __debug__: raise RuntimeError('Run without -O')
import check_k6_dyadic as mod
exact=mod.sign
def rounded_sign(c,x):
    p,q=x.numerator,x.denominator
    e=q.bit_length()-1
    assert 0<=p<=q and q==1<<e
    b=24
    z=c[-1]<<b
    for a in reversed(c[:-1]):
        z=((z*p)>>e)+(a<<b)
    if z>0: return 1
    if z+len(c)-1<0: return -1
    return exact(c,x)
mod.sign=rounded_sign
from check_k6_dyadic import gamma_chart,next_intervals,verify_intervals,Fraction
from check_interlacing_general import rows
from time import perf_counter
start=perf_counter(); e=rows(576,10); f=gamma_chart(rows(8,8)[8],8)
assert f==[1,-117,951,-1107],f
pts=list(map(Fraction,('0','1/16','1/2','1')))
ints=list(zip(pts,pts[1:])); verify_intervals(f,ints)
for aux in (9,10):
    g=gamma_chart(rows(aux,aux)[aux],aux); ints=next_intervals(f,g,ints); f=g
assert f==gamma_chart(e[10],10)
for n in range(10,576):
    g=gamma_chart(e[n+1],n+1); ints=next_intervals(f,g,ints); f=g
    if n%32==0: print('Certified through pair',n,flush=True)
print('PASS: k=10 pairs 10..575, elapsed',perf_counter()-start,flush=True)
