from fractions import Fraction as Q
from math import factorial
eta=Q(1,280)
D=128**2
alpha=Q(D,2)/(Q(2*128,7)+1)/(Q(2*128,7)+2)
assert sum(alpha**j/factorial(j) for j in range(32))>280
assert Q(1,448)+Q(1,16385)<Q(1,430)
assert Q(61,10)*(Q(1,430)+Q(1,8))<Q(39,50)
S1=(1-eta)**(-2)-1
S2=(1+eta)/(1-eta)**3-1
assert 14*S1<1
assert 7*S1<Q(19,200)
assert Q(7007,2000)*(S1+S2)<Q(1,8)
b=4*Q(157,50)**2/(Q(49,4)*128+10)
assert 2-64*b-254*b*3*4<0
bound=sum((2*j+1)/(1+b*j*(j+1))**64 for j in (1,2,3))+(1+12*b)**(-63)/(63*b)
assert bound<Q(7,50)
print('PASS: uniform cut s=(7/2)sqrt(n), edge k>=64 and central farther-pole margin')

