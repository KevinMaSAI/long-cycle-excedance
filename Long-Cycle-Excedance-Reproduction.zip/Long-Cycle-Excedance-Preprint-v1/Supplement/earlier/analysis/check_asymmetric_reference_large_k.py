from fractions import Fraction as Q
from math import factorial
if not __debug__:
    raise RuntimeError("Run without -O")
def el(x):
    return sum(x**j/factorial(j) for j in range(39))
def eh(x):
    return el(x)+x**39/factorial(39)/(1-x/40)
K=2**16
R=256
pi,pilo=Q(22,7),Q(157,50)
base0,base1=Q(7,150),Q(7,50)
assert 900*17*Q(7,10)<104**2
assert Q(7,2)*104/R<Q(10,7)
assert 1+Q(7,6)*104<144
assert Q(351,100)**2-Q(49,4)>Q(10,256)
assert 2*Q(351,100)/5<Q(141,100)
assert Q(81,71)*(2*Q(5,4)+Q(141,100)*Q(243,80))<8
def moment_tail(c,l):
    return (1+c*l*(l+1))**(-31)/(31*c)
def f(c,l):
    return (2*l+1)*(1+c*l*(l+1))**(-32)
def lattice(c):
    return 2*(1+f(c,1)+f(c,2)+moment_tail(c,2))
assert pilo**2/(16*(Q(49,4)+Q(10,256)))>Q(1,20)
assert (Q(2,3)*pilo**2)/(16*(Q(49,4)+Q(10,256)))>Q(1,30)
assert (Q(6,7)*pilo**2)/(16*(Q(49,4)+Q(10,256)))>Q(1,24)
assert lattice(Q(1,30))<3 and lattice(Q(1,24))<Q(13,5)
assert 4*pilo**2/Q(49,4)>3 and 9*pilo**2/Q(49,4)>7
assert eh(Q(1,8))<Q(8,7)
assert Q(11,10)*eh(Q(1,18))<Q(6,5) and Q(13,10)*eh(Q(1,18))<Q(7,5)
assert eh(Q(10,81))<Q(17,15) and el(Q(10,9))>Q(100,33)
assert Q(17,15)*(2*Q(5,4)+Q(211,50)*Q(243,80)+Q(127,100)*27*Q(33,100))*Q(7,2)<106
assert 3*pi*(2+Q(211,50)*3+Q(127,100)*9)/el(Q(80,81))<106
assert 4*(2+Q(211,50)*4+Q(127,100)*16)/el(Q(50,27))<25
assert 4*(2+Q(141,100)*4)/el(Q(50,27))<5
assert 3*pi/R<Q(37,1000) and 6*pi/R<Q(74,1000)
for S,T,beta,N,D,U in [(2,Q(7,5),Q(37,1000),Q(37,10),Q(5,4),Q(139,100)),
                         (Q(8,5),Q(9,10),Q(74,1000),Q(5,2),1,Q(119,100))]:
    u=S+T*beta
    assert T+u*u/2/(1-u*beta)<N and D+N*beta<U
assert Q(56,5)/(1-Q(56,5*R))<12
U=Q(139,100)
Ah=Q(119,100)
p=[(base0+Q(60,R),base1+Q(196,R)),
   (base0+((Q(4,3)+Q(21,10)*U)*3*pi+Q(7,2)*U*8)/R,
    base1+Q(1,100)+((Q(12,7)+Q(57,25)*U)*3*pi+106*U)/R)]
for v,w,t in [(14,8,32),(6*pi,5,25)]:
    p.append((base0+((Q(6,5)+Q(21,10)*Ah)*v+Q(7,2)*Ah*w)/R,
              base1+Q(6,1000)+((Q(7,5)+Q(57,25)*Ah)*v+Q(7,2)*Ah*t)/R))
assert 4/(Q(17,10)*R)<Q(1,100) and Q(17,10)**2<3
assert 4/(Q(21,8)*R)<Q(6,1000) and Q(21,8)**2<7
assert all(a*a+b*b<1 for a,b in p)
print("PASS: asymmetric low/middle sign pairs")

for a,t in [(Q(1,12),Q(5,2)),(Q(1,3),Q(47,10))]:
    assert eh(a)+eh(2*a)/(2-eh(a))<t
assert 4*Q(21,100)/6<Q(1,2)
assert 36*pilo**2/Q(49,4)>Q(289,10)
assert Q(27,5)**2>Q(289,10)
assert Q(27,5)*(2+Q(211,50)*Q(27,5)+Q(127,100)*Q(289,10))/el(Q(31,9))<11
assert 8*(2+Q(211,50)*8+Q(127,100)*64)/el(Q(70,9))<Q(1,2)
assert 32*(2+Q(211,50)*32+Q(127,100)*1000)/2**123<Q(1,10**8)
a,m=Q(37,10),Q(111,5)
L=lambda a,b:a*b/2+a*a*b*b/12
E=lambda b:L(Q(27,10),b)+b+b*b/3
rr=lambda a,m,b,s:(a*a*b/6+2*a*m*s/3)/R
fact=lambda u,z:u*(1+u*z/(2*(1-u*z/3)))
geom=lambda u,z:u/(1-u*z)
beta=Q(11,100)
assert eh(beta+beta**2/3)-1<Q(121,1000)
assert L(a,beta)<Q(22,100) and eh(Q(22,100))<Q(5,4)
assert Q(31,3)<Q(13,4)**2 and rr(a,m,beta,Q(13,4))<Q(7,10)
assert Q(5,2)*pi*(Q(38,10)+(Q(995,100))*Q(42,100))/R<Q(246,1000)
u=Q(7,5)+Q(67,100)*beta
assert Q(67,100)+u*u/2/(1-u*beta)<2
assert Q(4,5)+2*beta<Q(103,100)
assert Q(4,7)*beta*Q(3,20)+Q(103,100)*Q(7,2)*(Q(8,250*R)+Q(11,R))<Q(166,1000)
assert Q(242,1000*500)<Q(1,1000)
assert Q(4,1)/(R*Q(53,10))<Q(3,1000) and Q(53,10)**2<Q(289,10)
assert Q(416,1000)<Q(758,1000)*(Q(7,10)-base1)

def relative(t,u,d,rho):
    return (t+rho*u)/(1-rho) * d/R
# B>=64, beta<=1/4
b=Q(1,4)
assert eh(b+b*b/3)<Q(100,76)
assert (Q(243,20*64)+1/el(Q(320,81)))*eh(E(b))<Q(41,100)
assert (1-Q(41,100))*Q(76,100)>Q(44,100)
assert rr(Q(37,10),Q(111,5),b,12)<Q(258,100)
assert geom(Q(568,100),pi)<Q(62,10)
assert fact(Q(1183,100),3*pi/R)<15
assert rr(Q(16,5),Q(102,5),b,12)+Q(458,100)<Q(67,10)
assert geom(Q(67,10),pi)<Q(74,10)
assert rr(Q(47,10),23,b,12)+Q(951,100)<13
assert fact(Q(13),3*pi/R)<17
assert (relative(Q(62,10),Q(74,10),pi,Q(41,100))+
        relative(15,17,pi*Q(42,100),Q(41,100)))<Q(39,100)
assert Q(1,500)+Q(26,10)*Q(7,2)*Q(1,2*R)<Q(2,100)
assert base1+Q(39,100)+Q(24,1000)/Q(44,100)<Q(7,10)

# beta in [1/4,1/2]
b=Q(1,2)
assert eh(b+b*b/3)<Q(100,55)
assert (Q(243,20)*196/K+1/el(Q(K,196)/Q(81,5)))*eh(E(b))<Q(155,1000)
assert Q(845,1000)*Q(55,100)>Q(46,100)
assert rr(Q(5,2),15,b,12)+Q(15,4)<5
assert geom(Q(5),3*pi)<Q(62,10)
assert rr(Q(16,5),Q(96,5),b,12)+Q(48,10)<Q(68,10)
assert geom(Q(68,10),3*pi)<Q(91,10)
assert relative(Q(62,10),Q(91,10),pi*Q(142,100),Q(155,1000))<Q(16,100)
assert eh(Q(7,5)*b+Q(67,100)*b*b)-1<Q(7,5)
assert Q(7,5)*Q(1,250)+Q(28,10)*Q(7,2)*Q(1,100*R)<Q(7,1000)
assert 2*(eh(b+b*b/3)-1)/500<Q(4,1000)
assert base1+Q(16,100)+Q(12,1000)/Q(46,100)<Q(7,10)

# beta >= 1/2, joint reference ratio by log convexity
b=Q(10,7)
assert eh(b+b*b/3)<Q(100,12)
for end in [Q(1,2),b]:
    assert (Q(11907,80*K)/end**2+Q(1,2**80))*eh(E(end))<Q(23,100)
assert Q(77,100)*Q(12,100)>Q(9,100)
t=Q(13,20)
assert sum(t**(m-2)/m for m in range(2,18))+t**16/(18*(1-t))<1
assert Q(27,10)*b/6<t and 2*b/6<Q(1,2)
assert Q(7,3)*b/6==Q(5,9) and 3*b/6==Q(5,7)
assert Q(5,2)*b/6==Q(25,42) and Q(16,5)*b/6==Q(16,21)
assert Q(9,8)*rr(Q(7,3),Q(63,4),b,12)+Q(28,10)<Q(42,10)
assert Q(7,4)*rr(3,Q(243,8),b,12)+Q(455,100)<Q(96,10)
assert geom(Q(42,10),3*pi)<5 and geom(Q(96,10),3*pi)<15
assert relative(5,15,pi*Q(142,100),Q(23,100))<Q(192,1000)
assert Q(21,17)*rr(Q(5,2),Q(255,16),b,12)+Q(1,2)*(Q(9,2)+Q(255,80))<Q(54,10)
assert Q(21,10)*rr(Q(16,5),Q(108,5),b,12)+Q(516,100)<Q(98,10)
assert fact(Q(54,10),7*pi/R)<7 and fact(Q(98,10),7*pi/R)<16
assert relative(7,16,7*pi/500,Q(23,100))<Q(3,1000)
assert 2*(f(Q(1,20),4)+moment_tail(Q(1,20),4))<Q(1,10**8)
assert Q(14,5)*Q(351,100)*Q(41,100)/(2*pilo)<Q(2,3)
assert Q(3,2)*Q(14,5)**2*Q(351,100)**2/12<13
big=eh(Q(49,10)*Q(41,100)+13*Q(41,100)**2)-1
assert big<70 and big/Q(41,100)<175
assert (70+Q(175,R))*Q(1,10**8)<Q(1,1000)
assert 2*(eh(b+b*b/3)-1)*Q(1,10**8)<Q(1,1000)
assert 4/(R*36)<Q(1,1000) and Q(K,49)>36**2
assert base1+Q(195,1000)+Q(3,1000)/Q(9,100)<Q(7,10)
print("PASS: exact joint margins, diagonal headroom, and relative-reference regimes for all k>=2^16")

