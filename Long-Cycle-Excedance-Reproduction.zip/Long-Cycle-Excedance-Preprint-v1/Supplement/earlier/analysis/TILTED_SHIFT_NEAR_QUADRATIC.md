# A near-quadratic initial band for long-cycle excedance roots

**Theorem.** There are effective absolute constants c>0 and k0 such that for k≥k0 and k≤n≤c k²/(log k)², E_(n,k) has simple real roots. Consecutive E_(n,k)/t strictly interlace whenever both rows are in the range. Here E_(n,k) is the excedance polynomial of permutations with all cycle lengths at least k. This is partial progress on the mother conjecture, not its resolution.

Use the exact normalized pole product, notation s,p_i,ρ,q_i,u,v,h_n,d_b,δ_b, and the finite-support partial-fraction identity proved in PARTIAL_FRACTION_POWER_BAND.md. We estimate at 0≤s≤8√n. Recall that the normalized mixed coefficient of each support is a sum over choices b_j≥k, N=n−∑ b_j; a distinguished pole i has the multiplier q_i^N (or (q_i−u)q_i^N for the centered difference), and each other pole j has a denominator 1−q_j/q_i. For h_n use N≥0, and for the adjacent difference use N≥−1, with H_(-1)=0 by interpolation. The diagonal terms are not part of these mixed errors.

## 1. Exponentially tilted variation

Let r=1+1/k and D*=∑_(b≥k) r^b |δ_b|. Then
    D* ≤ 16 e^4/k < 1296/k.
Proof: the initial portion k≤b<4k costs at most e^4 · 4/k, by the unweighted total variation bound in PARTIAL_FRACTION_POWER_BAND.md. For b≥4k use
    |δ_b| ≤ (1/b) ∑_(j=b−k+1)^(b−1)|δ_j|.
After multiplication by r^b, each fixed r^j|δ_j| in a finite partial sum on the left contributes to the upper bound at most (k−1)e/(4k)<3/4 times its weight, since b−j≤k−1 and b≥4k. Hence the partial sums are all bounded by 16 e^4/k. Taking the limit gives the claim. The rational constant 1296 uses only e<3.

The threshold n/2 below is a cut on total shift ∑ b_j, not on support size. If ∑ b_j>n/2 then
    ∏ |δ_(b_j)| < r^(−n/2) ∏ r^(b_j)|δ_(b_j)|
                 ≤ exp(−n/(4k)) ∏ r^(b_j)|δ_(b_j)|.
The last inequality follows from log(1+1/k)≥1/(2k).

## 2. Short shifts leave a large distinguished exponent

Let a=k−1 and B=n/k. As before set
    P=sup_i ∑_(j≠i)|p_j||q_j|^a/(2π|j−i|).
Uniformly on 0≤s≤8√n, P≤C√n[1+log(1+B)] for an effective absolute C, by the integral and harmonic estimates of PARTIAL_FRACTION_POWER_BAND.md.

For short shifts ∑ b_j≤n/2 we have N≥n/2. In the product of q powers keep |q_i|^(n/2) at the distinguished pole, discarding the extra |q_i|^(b_i)≤1, but keep |q_j|^a at all other poles. Sum over all indices as in the partial-fraction proof. With D=∑ |δ_b|≤4/k, the mixed short-shift contribution to h_n has absolute value at most
    D expm1(DP) ∑_i |q_i|^(n/2).
The bound for h_(n+1)−u h_n is
    v D expm1(DP) ∑_i (1+2|i|)|q_i|^(n/2).
Both sums are O(1) uniformly, by the same envelope integrals with exponent n/2 and ρ≤√(74n), for n≥8 (or simply restrict to sufficiently large n). Here expm1(x)=exp(x)−1. The larger power retained on the distinguished pole is what avoids a factor B in the centered error.

## 3. Long shifts are suppressed by the tilt

For ∑ b_j>n/2 use the preceding tilt, retaining |q_j|^a at every pole. This retention remains valid at the new N=−1 boundary: b_i−1≥k−1. The centered factor costs at most v(1+2|i|). Thus long-shift errors in h_n and in the centered difference are bounded respectively by
    exp(−B/4) D* expm1(D*P) M,
    v exp(−B/4) D* expm1(D*P) M1,
where M=∑|q_i|^a=O(√B), M1=∑(1+2|i|)|q_i|^a=O(B). The factors exp(−B/4)M and exp(−B/4)M1 are bounded by absolute constants (x exp(−x/4)≤4/e for x≥0). In both short and long calculations, enlarging the sums to all shifts and supports is done only after taking absolute values and extracting the respective uniform damping. One may start with finite pole sets, and the bounds are independent of the truncation, so convergence is as in the partial-fraction proof.

Combine the estimates: for one effective absolute C1 and nonnegative X=C1√n[1+log(1+B)]/k, the total mixed errors in units 1/k and v/k are both bounded by C1 expm1(X). If k≤n≤c k²/(log k)² with 0<c≤1, then B≤k for k≥3 and X≤3C1√c. Hence these errors can be made uniformly smaller than any fixed positive tolerance by choosing c sufficiently small. This step does not require B to tend to infinity.

## 4. Transfer to roots, including the final row

The single-pole support terms have not changed. In units 1/k and v/k the amplitude is bounded away from zero since 1/(2k−1)≤d_n,d_(n+1)≤1/k. The extra diagonal difference divided by v/k is O(1/√n), since |d_(n+1)−d_n|≤1/(k(n+1)) and ∑|q_i|^n=O(1). The primary-pair and theta comparisons and their positive fixed margins described in PARTIAL_FRACTION_POWER_BAND.md apply on 0≤s≤8√n, regardless of n/k. Choose c so the error bound above is below one quarter of the fixed tolerance, and choose k0 large enough for the diagonal and comparison errors. These are effective choices by the explicit integral, harmonic and theta bounds already given.

On s≥(n−1)/ceil(√(n−1)/8) use the unrestricted ratio occupancy argument of GROWING_RATIO_LOG_BAND.md. Its common stitch witness lies inside the central domain, with phase ceil(√(n−1)/8)π+o(1). The root-count and next-row signs from ALL_BOUNDED_RATIO_THETA.md, Section 4, apply without change: alternate witnesses on (−1,0), the reciprocal negative roots, the parity root at −1 when n is odd, and the simple zero at 0 exhaust the degree. At each nonzero root the next-row sign is opposite to the old derivative sign, so the quotients strictly interlace. The estimates concern each adjacent pair in the claimed interval, including n=k. For the final row use the preceding interlacing pair to infer its real simple roots. Enlarge k0 to ensure such a pair exists.

The remaining gap to the separate high-n theorem, of order k³(log k)³, is not resolved; the constants here are not optimized.
