from fractions import Fraction as Q
eta=Q(1,1000)
assert Q(2)*Q(17,16)/2**16<Q(1,100)
assert Q(600,99)<Q(61,10)<7
assert Q(100,99)/(2**16-1)<Q(1,100)
assert Q(1,512)+Q(1,16385)<Q(1,480)
assert Q(61,10)*(Q(1,480)+Q(1,8))<Q(39,50)
assert Q(61,10*16385)<Q(1,2000)
assert Q(7,8)-Q(39,50)==Q(19,200)<Q(1,8)
assert 14*((1-eta)**(-2)-1)<Q(3,100)
assert 14*((1+eta)*(1-eta)**(-3)-1)<Q(3,50)<Q(19,200)
print('PASS: exact uniform occupancy edge margins, k>=64, n>=16385')

