"""Exact algebraic and numerical-constant checks for GROWING_TWO_CYCLE_STRIP.md."""
from fractions import Fraction as F
from math import comb
from check_interlacing_general import rows

assert F(3,4)**4+F(1,2)**4+1296*(F(1,3**8)+F(1,7*3**7))<1
assert F(13,2)+F(7,8)+2*F(9,64)<8
assert F(24,100)<F(19,64)
assert F(8,300)**2*28<F(1,6)**2
assert F(1,4)+F(12,300*600)<F(3,10)
assert F(3,10)**2+F(19,20)**2<1
count=0
for k in range(3,11):
    E=rows(3*k-1,k)
    for n in range(2*k,3*k):
        for r in range(1,11):
            double=F()
            for a in range(k,n-k+1):
                double+=F(comb(n,a),2)*sum(i**(a-1)*(r-i)**(n-a-1) for i in range(1,r))
            expected=sum(E[n][j]*comb(n+r-j-1,n-1) for j in range(1,min(r,n-1)+1))
            assert r**(n-1)+double==expected, (k,n,r)
            count+=1
print("PASS rational constants and two-cycle coefficient identity at",count,"exact grid points")

