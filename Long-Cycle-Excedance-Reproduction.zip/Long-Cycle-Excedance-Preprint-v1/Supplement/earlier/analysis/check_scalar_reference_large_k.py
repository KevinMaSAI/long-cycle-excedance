from fractions import Fraction as Q
from math import factorial
if not __debug__:
    raise RuntimeError("Run without -O")
def el(x):
    return sum(x**j/factorial(j) for j in range(41))
def eh(x):
    return el(x)+x**41/factorial(41)/(1-x/42)
def tailnorm(a):
    u=eh(a)
    return u*(Q(1,2)+(u-1)/5)/(1-Q(406,1000)-(u-1)/4)
def gd(a):
    return eh(a)+tailnorm(a)
K=2**15
J=181
pi,pilo=Q(22,7),Q(157,50)
assert J*J<K and 900*16*Q(7,10)<101**2
assert Q(101,J)<Q(56,100) and Q(7,2)*101/J<Q(196,100)
assert 1+Q(7,6)*101<121
assert el(Q(406,1000))>Q(3,2) and el(Q(694,1000))>2
assert Q(694,1000)-Q((256-1)**2,256*(2*256-1))<Q(1,5)
for a,t,d in [(0,Q(85,100),Q(37,20)),(Q(4,15),Q(145,100),Q(28,10)),
                (Q(1,5),Q(125,100),Q(5,2)),(Q(1,7),Q(111,100),Q(23,10))]:
    assert tailnorm(a)<t and gd(a)<d
for a,d in [(Q(1,8),Q(22,10)),(Q(1,4),Q(27,10)),(Q(1,3),Q(31,10))]:
    assert gd(a)<d
assert Q(63,10)**2>(4+Q(1,K))*pi**2
assert 2+2*Q(63,50)<Q(23,5)
assert 2+6*Q(63,50)+4*Q(63,10)**2/39<14
a=Q(37,20)*Q(63,10)*Q(23,5)/(2*pilo)
assert a<Q(86,10) and a/(1-a/J)<Q(91,10)
b=4*pilo**2/(Q(49,4)*K+10)
n=K//2
def fu(l):
    return (2*l+1)/(1+b*l*(l+1))**n
assert 2*(1+12*b)<n*b*49
assert sum(fu(l) for l in (1,2,3))+(1+12*b)**(1-n)/(b*(n-1))<Q(123,1000)
b0,b1=Q(41,1000),Q(123,1000)
pairs=[(b0+Q(23,5)*Q(91,10)/J,b1+(14*Q(91,10)+4)/J)]
assert Q(4,J*Q(17,10))<Q(13,1000)
assert Q(4,J*Q(21,8))<Q(9,1000)
assert 3*pi/J<Q(53,1000) and 6*pi/J<Q(105,1000)
for D,S,T,b,N,U in [(Q(145,200),Q(14,10),Q(67,100),Q(53,1000),Q(18,10),Q(83,100)),
                      (Q(125,200),Q(125,100),Q(54,100),Q(105,1000),Q(155,100),Q(79,100))]:
    u=S+T*b
    assert T+u*u/2/(1-u*b)<N and D+N*b<U
U=Q(83,100)
pairs.append((b0+((Q(4,3)+Q(21,10)*U)*3*pi+28*U)/J,
              b1+Q(13,1000)+((Q(12,7)+Q(57,25)*U)*3*pi+106*U)/J))
U=Q(79,100)
for V,W,T in [(14,8,32),(6*pi,5,25)]:
    pairs.append((b0+((Q(6,5)+Q(21,10)*U)*V+Q(7,2)*U*W)/J,
                  b1+Q(9,1000)+((Q(7,5)+Q(57,25)*U)*V+Q(7,2)*U*T)/J))
assert all(a*a+b*b<1 for a,b in pairs)
print("PASS: sharper delta recurrence and asymmetric low/mid estimates")

lam=Q(81,10)
def mq(B,u):
    return u*(2+Q(211,50)*u+Q(127,100)*B)
assert mq(40,Q(32,5))/el(39/lam)<Q(42,10)
assert mq(160,13)/2**19<Q(1,100)
assert mq(600,25)/2**73<Q(1,10**8)
assert 159/lam>19 and 599/lam>73
assert Q(23,10)**2/12*Q(101,100)**2<Q(45,100)
assert Q(19,3)**2>40
assert Q(7,2)*Q(19,3)/J<Q(123,1000) and Q(28,J)<Q(155,1000)
beta=Q(155,1000)
u=Q(115,100)+Q(45,100)*beta
assert Q(45,100)+u*u/2/(1-u*beta)<Q(14,10)
assert Q(111,200)+Q(14,10)*Q(123,1000)<Q(73,100)
assert Q(111,200)+Q(14,10)*beta<Q(78,100)
for b,T,q,u,E,C in [(Q(123,1000),Q(73,100),11,Q(19,3),Q(167,1000),Q(726,1000)),
                      (beta,Q(78,100),Q(42,10),8,Q(78,1000),Q(640,1000))]:
    assert Q(4,7)*b*Q(3,20)+T*Q(7,2)*(u/(250*J)+q/J)<E
    assert 1-2*(eh(b+b*b/3)-1)>C
    assert Q(235,1000)+E+Q(6,1000)<C*(Q(7,10)-b1)
assert 4/(J*Q(53,10))<Q(5,1000)
lr=lambda a,b:a*b/2+a*a*b*b/12
dr=lambda a,m,b,rad:(a*a*b/6+2*a*m*rad/3)/J
assert 1+Q(7,6)*8<Q(13,4)**2
assert eh(lr(Q(22,10),beta))<Q(12,10) and eh(lr(Q(27,10),beta))<Q(126,100)
assert Q(2475,1000)+dr(Q(22,10),Q(99,10),beta,Q(13,4))<Q(275,100)
assert Q(675,100)+dr(Q(27,10),Q(162,10),beta,Q(13,4))<Q(73,10)
assert 2*pi*(Q(12,10)*Q(275,100)+Q(126,100)*Q(73,10)*3*b1)/J<Q(235,1000)

# Exact scalar P(s+iy)/P(s) and r-norm prefix correction.
assert Q(K,2*(K-1))<Q(501,1000) and 2*pilo*Q(K-1,K)*Q(41,100)**2>1
def phase(C,c,Y):
    assert C/(1-C*Y/J)<c
phase(Q(59,100),Q(61,100),3*pi)
phase(Q(47,100),Q(49,100),3*pi)
phase(Q(45,100),Q(48,100),7*pi)
assert Q(1,18)+(Q(1,18)+Q(41,100))*eh(Q(1,8))<Q(59,100)
assert Q(1,45)+(Q(1,45)+Q(41,100))*eh(Q(23,1000))<Q(47,100)
assert Q(1,90)+(Q(1,90)+Q(41,100))*eh(Q(3,100))<Q(45,100)
assert 3*pi/(6*pilo)<Q(51,100) and 9*pi*pi/(2*45**2)<Q(23,1000)
assert 49*pi*pi/(2*90**2)<Q(3,100)
a=Q(7,10)
assert sum(a**(m-2)/m for m in range(2,19))+a**17/(19*(1-a))<Q(11,10)
assert Q(22,10)*Q(196,100)/(2*pilo)<a
assert Q(11,10)*Q(22,10)**2/12<Q(444,1000)
E=lambda b:Q(1601,1000)*b+Q(444,1000)*b*b
ref=lambda b:eh(Q(501,1000)*b)
qgeom=lambda a,y:a/(1-a*y/J)
qfact=lambda a,y:a*(1+(a*y/J)/(2*(1-a*y/(3*J))))
assert Q(K,3*K+1)-Q(1,4)>Q(1,13)
assert Q(K,5*K+1)-Q(1,8)-Q(3,100)>Q(1,24)
assert Q(39,16)<Q(16,10)**2 and Q(9,2)<Q(9,4)**2
assert Q(23,1000)<Q(1,40) and Q(1,90)<Q(1,80)
assert 3*pi/45<Q(1,4) and 7*pi/90<Q(1,4)
assert Q(23,20)+Q(45,100)*Q(1,2)<Q(14,10)

for b,r,P,R in [(Q(1,4),Q(325,1000),Q(88,100),64),
                  (Q(1,2),Q(185,1000),Q(77,100),Q(K,196))]:
    assert (Q(243,20)/R+1/el(R/(2*lam)))*eh(E(b))<r
    assert ref(b)*P<1
assert Q(675,1000)*Q(88,100)>Q(59,100) and Q(815,1000)*Q(77,100)>Q(62,100)
assert Q(1,2)*(Q(496,100)+Q(152,10)/2)+dr(Q(31,10),Q(152,10),Q(1,4),11)<Q(82,10)
assert qfact(Q(82,10),3*pi)<Q(103,10)
assert ((Q(61,100)+Q(325,1000)*Q(103,10))/Q(675,1000))*pi*(1+3*b1)/J<Q(15,100)
assert Q(1,2)*(Q(45,8)+Q(45,2)/4)+dr(Q(5,2),Q(45,2),Q(1,2),11)<8
assert qfact(8,3*pi)<10
assert ((Q(49,100)+Q(185,1000)*10)/Q(815,1000))*pi*(1+3*b1)/J<Q(8,100)
assert 4/(J*8)<Q(3,1000) and 4/(J*12)<Q(2,1000)
assert Q(1,250)*Q(38,100)+Q(16,10)*Q(7,2)*Q(1,2*J)<Q(18,1000)
assert Q(1,250)+2*Q(7,2)*Q(1,100*J)<Q(5,1000)
for b,u,v in [(Q(1,4),Q(38,100),Q(16,10)),(Q(1,2),1,2)]:
    assert eh(Q(23,20)*b+Q(45,100)*b*b)-1 < min(u,v*b)
    assert Q(14,5)*Q(101,100)*b/(2*pilo)<Q(1,2)
assert b1+Q(15,100)+Q(23,1000)/Q(59,100)<Q(7,10)
assert b1+Q(8,100)+Q(11,1000)/Q(62,100)<Q(7,10)

b=Q(196,100)
assert Q(K,49)/ (2*lam)>40
for z in (Q(1,2),b):
    assert (Q(11907,80*K)/z**2+Q(1,2**40))*eh(E(z))<Q(17,100)
assert ref(b)*Q(37,100)<1 and Q(83,100)*Q(37,100)>Q(3,10)
assert Q(5,2)*b/(2*pilo)<Q(4,5)
assert Q(45,8)+Q(5,2)*dr(Q(5,2),Q(45,2),b,11)<Q(115,10)
assert qfact(Q(115,10),7*pi)<27
assert (Q(48,100)+Q(17,100)*27)/Q(83,100)<Q(62,10)
assert Q(62,10)*pi*(1+3*b1+Q(7,500))/J<Q(16,100)
assert Q(23,10)*Q(351,100)*Q(56,100)/(2*pilo)<Q(3,4)
assert 2*Q(23,10)**2*Q(351,100)**2/12<11
u=eh(Q(161,40)*Q(56,100)+11*Q(56,100)**2)-1
assert u<310 and u/Q(56,100)<560
assert (310+Q(560,J))*Q(1,10**8)<Q(1,1000)
assert eh(Q(1001,1000)*b)*Q(117,100)<10
assert 4/(J*25)<Q(1,1000)
assert b1+Q(16,100)+Q(3,1000)/Q(3,10)<Q(7,10)
print("PASS: exact scalar-reference estimates and all-row cutoff k>=2^15")

