# Uniform O(k log^2 k) tail for the long-cycle mother conjecture

**Theorem.** For every integer k>=64 and integer
    n >= 1000 (k-1) [log(2(k-1))]^2
(with natural logarithm), E_(n,k) has simple real roots and E_(n,k)/t strictly interlaces E_(n+1,k)/t. This proves a parameter-uniform high-n region; it does not prove all n>=k. No finite computation of roots or case split over individual k is used.

Set d=k-1, L=log(2d)>4, p=s+i pi, rho=|p|, q=exp(-s). In the pole normalization of EVENTUAL_ALL_FIXED_K.md,
    H(z) = exp(-a z+G_s(z))/(exp(-z)+q),   a=1/(1+q),
    E_(n,k)(-q) = n!(1+q)^(n+1) [z^n]H(z).
Here G_s is the Taylor polynomial of degree d of
    F(z) = Log(1+q exp(z)) - log(1+q) - (q/(1+q)) z .
For s>0 this follows by expanding the logistic series near zero. At s=0 it follows by continuity of the derivatives at zero. The logarithm is the principal branch within |z|<rho: to lie on the nonpositive real axis the argument would require both Im(z) an odd multiple of pi and Re(z)>=s, impossible strictly inside the disk.

## A uniform truncated-log bound

On |z|=R0=rho(1-1/d) the distance to every pole s+(2l+1)pi i is at least rho/d. Apply the elementary denominator comparison in UNIFORM_UPPER_CENTRAL_CONTOUR.md with W=exp(Re(z)-s) and delta0=min(1,rho/d); it gives |1+q exp(z)|/(1+W)>=delta0/16, because either the horizontal distance is >=delta0/2 or the distance to the nearest odd imaginary ordinate is >=delta0/2. Thus |1+q exp(z)|>=1/(16d). The upper bound is 1+exp(rho-s)<=1+exp(pi)<16d (using pi<4 and e<3). Hence the real part of the principal logarithm has absolute value at most log(16d), and its imaginary part has absolute value at most pi. Also qR0<=q(s+pi)<=pi, since exp(-s)(s+pi) decreases. On that circle
    |F(z)| <= log(16d)+2pi+1 < L+11 < 4L.

Let R1=rho(1+1/d), tau=R1/R0=(d+1)/(d-1). By Cauchy's formula for each coefficient, the evaluation of G_s at R1 exp(i theta) is the convolution of F on radius R0 with K(u)=sum_(m=0)^d tau^m exp(imu), averaged on [-pi,pi]. With d>=63, tau^(d+1)<=exp(2(d+1)/(d-1))<9, and
    |K(u)| <= min(9(d+1), (1+tau^(d+1))/|1-tau exp(iu)|)
            <= min(9(d+1), 5pi/|u|).
Indeed |1-tau exp(iu)|>=|1-exp(iu)|>=2|u|/pi. Split the integral at |u|=pi/(d+1). Its average absolute value is at most 9+5log(d+1)<8L. Consequently on |z|<=R1, by the maximum modulus principle,
    |G_s(z)| <= J=32 L^2,
uniformly for every real s>=0. This controls the partial sum itself, without summing absolute Taylor coefficients, which would lose the required uniformity.

## Central signs on the whole interval

The radius selection and denominator comparisons in UNIFORM_UPPER_CENTRAL_CONTOUR.md use only d>=63, s>=0 and rho<=4sqrt(n), not the large-s condition. For 0<=s<=(7/2)sqrt(n) they therefore give the two normalized circular errors at most
    1024 d n exp(2J-n/(3d)).
With n>=1000d L^2 this decreases in n and is <2^20 exp(4L-200L^2)<1/100 (use d^2 L^2<=exp(4L) and L>4). The primary pair is exactly (-cos phase, +sin phase) in the two normalizations, with phase
    phase = (n+1) atan(pi/s)+pi a-Im G_s(p),
where atan(pi/0)=pi/2.

For s>=12sqrt(d) invoke UNIFORM_UPPER_CENTRAL_RESIDUES.md: the normalized absolute sum of farther residues is <11/40, and the contour budget finishes both error estimates <1/3. For s<=12sqrt(d), rho^2<=145d. The absolute numerator penalty for the farther poles is at most exp(2J). Their radial suppression is (1+X)^(-(n+1)/2) with X=4pi^2 l(l+1)/rho^2. For l>=1,
    log(1+X) >= X/(1+X) >= 72/(145d+72) >= 72/(147d).
Reserve n/4 of that exponent; it suppresses exp(2J), since (6/49)(n/d)>64L^2. The remaining exponent is at least n/4. Bernoulli's inequality gives the majorant (1+c l(l+1))^-4 with c=n*pi^2/(4rho^2)>1/2. Its sum with weights 2l+1 is <1/4 by the same rational bound in POLYNOMIAL_UNIFORM_BOUND.md; the weight includes the centered comparison multiplier. Adding the 1/100 contour error proves the two comparisons <1/3 here also. Thus the central comparisons hold on the entire interval through (7/2)sqrt(n).

## Edge, phase ordering and completeness

Let D=n-1, M=ceil(2sqrt(D)/7), S=D/M. Since n>=1000d L^2, it meets n>=16385 and S>=12sqrt(d); indeed M<(3/10)sqrt(D), so S>3sqrt(D) and D>=16d. Also S<=(7/2)sqrt(n). Apply UNIFORM_CUT_SEVEN_HALVES.md: at s=D/m the edge signs are (-1)^m and at any old root in the bracket between m and m+1 the next-row sign is (-1)^(m+1). These normalizations differ from actual E by positive factors only.

At S, use the incomplete-exponential derivative bound of UNIFORM_UPPER_CENTRAL_RESIDUES.md along the vertical segment from S to S+i*pi and the fact Phi(S) is real. We get |Im G_S(p)|/pi <= (5/79)exp(5/144)+q. Also |a-1|<=q<1/10000. Because M<(3/10)sqrt(D), the arctan error at S is bounded by 2M/D+(n+1)pi^2 M^3/(3D^3)<1/100, using atan y between y-y^3/3 and y. Therefore |phase(S)/pi-(M+1)|<1/8. At s=0 the coefficients g_m of odd degree vanish by the logistic parity (or reciprocity of the cycle enumerator), so phase(0)=(n+2)pi/2.

For completeness, index the edge witnesses as j=m+1, then moving from S toward 0 take successive first hits of phase=j pi for j=M+2,...,floor((n+2)/2). They exist by continuity, and the signs are (-1)^(j+1) by the central comparison. There are floor(n/2) witnesses in all, giving floor(n/2)-1 distinct roots for -1<t<0. Reciprocity E_(n,k)(t)=t^n E_(n,k)(1/t) follows by permutation inversion, since no fixed points are allowed; t=0 is simple, and t=-1 is a root when n is odd. The coefficient of t^(n-1) is 1 (the unique permutation with n-1 excedances is the cyclic shift); reciprocity gives the coefficient of t also 1. The reciprocal pairs, zero, and parity root therefore exhaust degree n-1, all simple.

For adjacent interlacing, at a central old root between labels j and j+1, use the last hit of j pi before the next first hit of (j+1)pi to find the same unique root in a bracket with phase strictly between the levels. For the first central bracket starting from S, if there is no hit of j pi then phase(S)>j pi and the level inequality holds directly. At the old root the main-pair comparison gives |cos phase|<1/3 and the next-row sign is the sign of sin phase, namely (-1)^j. This is opposite the old derivative, whose sign is the sign on the right, (-1)^(j+1). The edge lemma gives the same opposition in the remaining brackets. For odd n, at t=-1 the centered sign is the sign of sin((n+2)pi/2), opposite the sign of the old derivative from the rightmost central witness near -1. Reciprocity transfers the comparison to t<-1, since the next row / old derivative ratio at a reciprocal root is multiplied by the positive factor -t^3. After dividing by t the ratios at nonzero old roots are unchanged. The consecutive quotients have positive leading coefficient and consecutive degrees, so alternating signs at the old roots, plus signs at infinity, give one next root in every interior and both exterior gaps. This proves strict interlacing.

The rational margin replay is check_uniform_k_log_squared.py. Separately, the existing lower band reaches c k^2/log^2(k) for sufficiently large k, so this threshold overlaps it eventually without the earlier near-quadratic bridge. The remaining unresolved problem is to replace the lower-band asymptotic constants by a proof covering all the intermediate parameter pairs. This theorem alone says nothing about those rows, and does not pretend to solve the mother conjecture.

