"""Independent exact k=6 finite certificate via disjoint rational sign brackets."""
from math import comb
from fractions import Fraction
from time import perf_counter
from check_interlacing_general import rows
import sys


def gamma_chart(row, n):
    # E_n(t)=(1+t)^n sum gamma[i]*(t/(1+t)^2)^i.
    r=row.copy()
    gam=[]
    for j in range(n//2+1):
        a=r[j]
        gam.append(a)
        for i in range(n-2*j+1):
            r[j+i]-=a*comb(n-2*j,i)
    assert not any(r) and gam[0]==0 and gam[1]==1
    a=gam[1:]
    d=len(a)-1
    assert a[-1]>0
    # X=-w/(1-w).  Multiply the gamma quotient by (1-X)^d.
    return [(-1)**i*sum(a[j]*comb(d-j,i-j) for j in range(i+1))
            for i in range(d+1)]


def sign(c, x):
    p,q=x.numerator,x.denominator
    e=q.bit_length()-1
    assert q==1<<e
    z=c[-1]
    for j,a in enumerate(reversed(c[:-1]),1):
        z=z*p+(a<<(e*j))
    return (z>0)-(z<0)


def verify_intervals(c, ints):
    assert len(ints)==len(c)-1
    assert all(0<=lo<hi<=1 and sign(c,lo)*sign(c,hi)==-1 for lo,hi in ints)
    assert all(p[1]<=q[0] for p,q in zip(ints,ints[1:]))


def next_intervals(f,g,ints):
    d=len(ints)
    assert g[0]>0 and len(g)-1 in (d,d+1)
    refined=[]
    for i,(lo,hi) in enumerate(ints,1):
        target=(-1)**i
        flo=sign(f,lo)
        for _ in range(10_000):
            if sign(g,lo)==sign(g,hi)==target:
                refined.append((lo,hi))
                break
            mid=(lo+hi)/2
            fm=sign(f,mid)
            if fm==0:
                lo,hi=(lo+mid)/2,(mid+hi)/2
                assert sign(f,lo)==flo and sign(f,hi)==-flo
            elif fm==flo:
                lo=mid
            else:
                hi=mid
        else:
            raise AssertionError(("unresolved isolate",i))
    new=[(Fraction(0),refined[0][0])]
    new.extend((a[1],b[0]) for a,b in zip(refined,refined[1:]))
    if len(g)-1==d+1:
        new.append((refined[-1][1],Fraction(1)))
    verify_intervals(g,new)
    return new


def main(limit):
    if not __debug__: raise RuntimeError("Run without -O")
    start=perf_counter()
    e=rows(limit+1,6)
    f=gamma_chart(e[6],6)
    assert f==[1,-24,39]
    ints=[(Fraction(0),Fraction(1,4)),(Fraction(1,4),Fraction(1))]
    verify_intervals(f,ints)
    for n in range(6,limit+1):
        g=gamma_chart(e[n+1],n+1)
        ints=next_intervals(f,g,ints)
        f=g
        if n%32==0: print("Certified through pair",n,flush=True)
    print(f"PASS: exactly certified pairs 6 through {limit} in {perf_counter()-start:.3f} sec")


if __name__=="__main__":
    main(int(sys.argv[1]) if len(sys.argv)>1 else 191)
