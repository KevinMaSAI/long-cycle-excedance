"""Exact rational sign-bracket certificate for the k=7 finite range."""
from check_k6_dyadic import gamma_chart, next_intervals, verify_intervals, Fraction
from check_interlacing_general import rows
from time import perf_counter
import sys

def main(limit):
    if not __debug__:
        raise RuntimeError("Run without -O")
    start=perf_counter()
    e=rows(limit+1,7)
    f=gamma_chart(e[7],7)
    assert f==[1,-54,189]
    ints=[(Fraction(0),Fraction(1,4)),(Fraction(1,4),Fraction(1))]
    verify_intervals(f,ints)
    for n in range(7,limit+1):
        g=gamma_chart(e[n+1],n+1)
        ints=next_intervals(f,g,ints)
        f=g
        if n%32==0:
            print("Certified through pair",n,flush=True)
    print(f"PASS: k=7 exactly certified pairs 7 through {limit} in {perf_counter()-start:.3f} sec")

if __name__=="__main__":
    main(int(sys.argv[1]) if len(sys.argv)>1 else 255)
