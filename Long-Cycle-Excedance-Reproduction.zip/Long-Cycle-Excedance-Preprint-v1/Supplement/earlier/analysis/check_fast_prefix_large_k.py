from fractions import Fraction as Q
from math import factorial
def lo(x):return sum(x**j/factorial(j) for j in range(65))
def hi(x):return lo(x)+x**65/factorial(65)/(1-x/66)
def T(a):
    z=hi(a)
    return z*(Q(1,2)+(z-1)/5)/(Q(594,1000)-(z-1)/4)
K=16384; J=128; pi=Q(22,7); pilo=Q(157,50); lam=Q(41,10)
assert lo(Q(694,1000))>2 and 900*15*Q(694,1000)<97**2
assert Q(97,J)<Q(76,100) and Q(7,2)*97/J<Q(8,3)
for a,D in [(Q(19,50),Q(33,10)),(Q(5,16),3),(Q(1,12),Q(21,10)),(Q(1,2),Q(41,10))]:
    assert hi(a)+T(a)<D
assert T(Q(19,50))<Q(182,100) and T(Q(5,16))<Q(157,100)
b=4*pilo**2/(Q(49,4)*K+10); a=K//2
f=lambda l:(2*l+1)/(1+b*l*(l+1))**a
assert sum(f(l) for l in (1,2,3))+(1+12*b)**(1-a)/(b*(a-1))<Q(123,1000)
assert Q(3,2)*(Q(49,4)+Q(10,K))/(pilo**2*Q(K-3,K))<Q(188,100)
assert 2+Q(3,2)*Q(63,10)**2/(pilo**2*Q(K-3,K))<Q(81,10)
assert Q(37,20)*Q(63,10)*Q(33,10)/(2*pilo)<Q(613,100)
assert Q(613,100)/(1-Q(613,100*J))<Q(65,10)
def shifted(B,z,l=lam):
    E=lo((Q(B)-1)/l)
    return z*(2+Q(141,100)*z)/E,z*(2+Q(188,100)*B)/E
assert hi(1/lam)<Q(128,100)
assert Q(33,8)**2<18 and Q(123,80)**3<Q(351,100)**2
assert Q(123,160)<Q(88,100)**2
assert Q(128,100)*(2*Q(88,100)+Q(141,100)*Q(123,80))<Q(51,10)
assert Q(128,100)*(2*Q(88,100)+Q(188,100)*Q(351,100))<11
for B,z,p,q in [(7,Q(53,20),Q(36,10),Q(94,10)),(12,Q(347,100),Q(17,10),6),(20,Q(112,25),Q(37,100),Q(175,100))]:
    assert z*z>B
    e,f=shifted(B,z)
    assert e<p and f<q
for S,Z,b,U,L in [(Q(165,100),Q(93,100),Q(74,1000),Q(111,100),Q(182,200)),
                  (Q(15,10),Q(77,100),Q(148,1000),Q(116,100),Q(157,200))]:
    a=S+Z*b
    assert L+b*(Z+a*a/2/(1-a*b))<U
assert 3*pi/J<Q(74,1000) and 6*pi/J<Q(148,1000)
assert Q(61,5)**2>Q(49,4)*12 and Q(157,10)**2>Q(49,4)*20
base0,base1=Q(41,1000),Q(123,1000)
pairs=[(base0+Q(46,10)*Q(65,10)/J,base1+(Q(81,10)*Q(65,10)+4)/J)]
U=Q(111,100)
pairs.append((base0+((Q(4,3)+Q(21,10)*U)*3*pi+Q(7,2)*U*Q(51,10))/J,
              base1+Q(19,1000)+((Q(12,7)+Q(57,25)*U)*3*pi+Q(7,2)*U*11)/J))
U=Q(116,100)
for V,P,W in [(Q(61,5),Q(36,10),Q(94,10)),(Q(157,10),Q(17,10),6),(6*pi,Q(37,100),Q(175,100))]:
    pairs.append((base0+((Q(6,5)+Q(21,10)*U)*V+Q(7,2)*U*P)/J,
                  base1+Q(12,1000)+((Q(7,5)+Q(57,25)*U)*V+Q(7,2)*U*W)/J))
assert all(a*a+b*b<1 for a,b in pairs)
assert 4/(J*Q(17,10))<Q(19,1000) and 4/(J*Q(21,8))<Q(12,1000)
assert 4/(J*Q(53,10))<Q(6,1000)
print("PASS: correlated tilted weights and ellipse margins")

assert shifted(Q(289,10),Q(27,5))[1]<Q(35,100)
assert shifted(80,9)[1]<Q(3,1000)
assert Q(7,2)*Q(5831,1000)/J<Q(16,100) and Q(5831,1000)**2>34
Ln=lambda a,b:a*b/2+a*a*b*b/12
Dr=lambda a,m,b,s:(a*a*b/6+2*a*m*s/3)/J
b=Q(16,100)
assert 1+Q(7,6)*Q(5831,1000)<Q(28,10)**2
assert hi(Ln(Q(22,10),b))<Q(121,100) and hi(Ln(Q(27,10),b))<Q(127,100)
assert Q(2475,1000)+Dr(Q(22,10),Q(99,10),b,Q(28,10))<Q(28,10)
assert Q(675,100)+Dr(Q(27,10),Q(162,10),b,Q(28,10))<Q(74,10)
assert 2*pi*(Q(121,100)*Q(28,10)+Q(127,100)*Q(74,10)*3*base1)/J<Q(338,1000)
assert 1-2*(hi(b+b*b/3)-1)>Q(632,1000)
assert hi(Q(14,10)*b+Q(67,100)*b*b)-1<Q(275,1000)
assert (hi(Q(14,10)*b+Q(67,100)*b*b)-1)/b<Q(172,100)
assert Q(275,1000)/250+Q(172,100)*Q(7,2)*Q(35,100)/J<Q(18,1000)
assert Q(363,1000)<Q(632,1000)*(Q(7,10)-base1)
assert Q(54,10)/lo(Q(289,10)/(2*lam))<Q(161,1000)
b=Q(1,4)
assert Q(161,1000)*hi(Ln(Q(27,10),b)+Q(501,1000)*b)<Q(27,100)
assert hi(Q(501,1000)*b)<Q(100,88) and Q(73,100)*Q(88,100)>Q(64,100)
assert hi(Q(1,8))<Q(8,7)
assert (Q(1,18)+(Q(1,18)+Q(41,100))*hi(Q(1,8)))/(1-Q(59,100)*3*pi/J)<Q(62,100)
assert hi(Q(1,2))+T(Q(1,2))<Q(41,10)
a=Q(41,10); m=Q(1384,100)
assert (Q(533,100)+m/2)/2+Dr(a,m,b,11)<Q(95,10)
u=Q(95,10);z=u*3*pi/J
assert u*(1+z/(2*(1-z/3)))<14
assert (Q(62,100)+Q(27,100)*14)/Q(73,100)*pi*(1+3*base1)/J<Q(21,100)
assert hi(Q(14,10)*b+Q(67,100)*b*b)-1<Q(1,2)
assert Q(1,500)+2*Q(7,2)*Q(35,100)/J<Q(22,1000)
assert base1+Q(21,100)+Q(30,1000)/Q(64,100)<Q(7,10)

assert Q(54,10)/lo(Q(K,196)/(2*lam))<Q(25,100000)
b=Q(1,2)
assert hi(Ln(Q(33,10),b))<3 and hi(Q(501,1000)*b)<Q(100,77)
assert Q(77,100)-3*Q(25,100000)>Q(76,100)
assert 1/(1-3*Q(25,100000)/Q(77,100))<Q(1002,1000)
assert Q(62,100)*Q(1002,1000)*pi*(1+3*base1)/J+Q(25,100000)*6*(1+base1)/Q(76,100)<Q(27,1000)
assert (hi(Q(14,10)*b+Q(67,100)*b*b)-1)/b<Q(28,10)
assert Q(14,10)/250+Q(28,10)*Q(7,2)*Q(3,1000)/J<Q(6,1000)
assert base1+Q(27,1000)+Q(14,1000)/Q(76,100)<Q(7,10)

assert hi(Q(1,12))+T(Q(1,12))<Q(21,10)
def series(a):
    return sum(a**(j-2)/j for j in range(2,129))+a**127/(129*(1-a))
assert series(Q(9,10))<Q(18,10) and series(Q(94,100))<Q(22,10)
assert Q(21,10)*Q(351,100)*Q(76,100)/(2*pilo)<Q(9,10)
assert Q(22,10)*Q(8,3)/(2*pilo)<Q(94,100)
assert Q(18,10)*Q(21,10)**2*Q(351,100)**2/12<Q(82,10)
assert Q(22,10)*Q(22,10)**2/12<Q(888,1000)
assert Q(K,49)>334 and shifted(334,Q(183,10),17)[1]<Q(1,10000)
u=hi(Q(147,40)*Q(76,100)+Q(82,10)*Q(76,100)**2)-1
assert u<1900 and u/Q(76,100)<2600
assert 1900*Q(1,10**8)+Q(2600,10000*J)<Q(3,1000)
assert Q(2*K,49*17)-Q(888,1000)>38
assert lo(Q(86995,10000))>Q(10000,3)
assert hi(Q(501,1000)*Q(8,3))<Q(100,26)
assert Q(997,1000)*Q(26,100)>Q(25,100)
assert Q(1,64)+(Q(41,100)+Q(1,64))*hi(Q(6,100))<Q(48,100)
assert Q(48,100)/(1-Q(48,100)*7*pi/J)<Q(54,100)
assert (Q(54,100)*pi*(1+3*base1+Q(7,500))/J+Q(6,1000)*(1+base1))/Q(997,1000)<Q(3,100)
assert base1+Q(3,100)+Q(6,1000)/Q(25,100)<Q(7,10)
print("PASS: exponential prefix comparison and all-row bounds for k>=2^14")

