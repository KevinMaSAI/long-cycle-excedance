"""Exact diagnostics of the occupancy identities and constants, not a proof of the band."""
from fractions import Fraction as Q
from functools import cache
from math import comb, factorial

@cache
def count(n, k, r):
    if not r:
        return int(n == 0)
    return sum(
        comb(r-1,j-1)*factorial(j-1)*comb(n,a)*j**a*count(n-a,k,r-j)
        for j in range(1,r+1) for a in range(k,n+1)
    )

def b(n, k, r):
    return Q(count(n,k,r), factorial(r)*r**n)

x=Q(1,1000)
s1=x/(1-x)**2+x/(1-x)
s2=x*(1+x)/(1-x)**3+Q(3,2)*x/(1-x)**2+x/(2*(1-x))
assert 40*s1 < 1 and 20*s2 < Q(1,10)
assert Q(80,10**4)*(1+20*s1)+20*Q(40,10**8)*(x/(1-x)**2+x*(1+x)/(1-x)**3) < Q(1,10)
assert sum(Q(8)**j/factorial(j) for j in range(12)) > 1000
cases=0
for k in range(3,8):
    for n in range(k,50):
        for r in range(1,10):
            a=r*b(n,k,r)
            delta=r*b(n+1,k,r)-a
            assert 1<=a<=min(r,Q(n,k)) and 20*a>=min(r,Q(n,k))
            expected=sum(
                Q(comb(n,k-1)*j**(k-1)*(r-j)**(n-k+1), r**n)*b(n-k+1,k,r-j)
                for j in range(1,r)
            )
            assert 0<=delta==expected
            if n>=2*k-1:
                lattice=sum(
                    Q(comb(n-1,k-1)*j**(k-1)*(r-j)**(n-k),r**(n-1))
                    for j in range(1,r)
                )
                assert delta<=Q(n,k*r)*lattice
                assert max(lattice-Q(r,n),0)**2 <= Q(1,k)
            cases+=1
print(f"PASS rational edge budgets; {cases} exact occupancy cases")
