import check_k6_dyadic as mod
exact=mod.sign
def rounded_sign(c,x):
    p,q=x.numerator,x.denominator
    e=q.bit_length()-1
    assert 0<=p<=q and q==1<<e
    b=24
    z=c[-1]<<b
    for a in reversed(c[:-1]):
        z=((z*p)>>e)+(a<<b)
    if z>0: return 1
    if z+len(c)-1<0: return -1
    return exact(c,x)
mod.sign=rounded_sign
from check_k6_dyadic import gamma_chart,verify_intervals,Fraction
from check_interlacing_general import rows
from sys import argv
from time import perf_counter
if not __debug__: raise RuntimeError('Run without -O')
def exponent(t):
    return t.numerator.bit_length()-t.denominator.bit_length()
def middle(a,b):
    i,j=exponent(a),exponent(b)
    if j-i>=3:
        k=(i+j)//2
        return Fraction(1<<k) if k>=0 else Fraction(1,1<<(-k))
    return (a+b)/2
def next_fast(f,g,ints):
    d=len(ints)
    assert f[0]==g[0]==1 and len(g)-1 in (d,d+1)
    refined=[]
    for i,(lo,hi) in enumerate(ints,1):
        if not lo:
            A=max(map(abs,f))
            lo=min(hi/2,Fraction(1,1<<((2*A+1).bit_length())))
            assert rounded_sign(f,lo)==1
        flo=rounded_sign(f,lo)
        target=(-1)**i
        for _ in range(10000):
            if rounded_sign(g,lo)==rounded_sign(g,hi)==target:
                refined.append((lo,hi))
                break
            mid=middle(lo,hi)
            assert lo<mid<hi
            fm=rounded_sign(f,mid)
            if fm==0:
                lo,hi=(lo+mid)/2,(mid+hi)/2
                assert rounded_sign(f,lo)==flo and rounded_sign(f,hi)==-flo
            elif fm==flo:
                lo=mid
            else:
                hi=mid
        else: raise AssertionError(('unresolved isolate',i))
    new=[(Fraction(0),refined[0][0])]
    new.extend((a[1],b[0]) for a,b in zip(refined,refined[1:]))
    if len(g)-1==d+1:
        new.append((refined[-1][1],Fraction(1)))
    verify_intervals(g,new)
    return new
def certify(k,last):
    start=perf_counter()
    e=rows(last+1,k)
    pascal=[[1]]
    for n in range(1,last+2):
        p=pascal[-1]
        pascal.append([1]+[a+b for a,b in zip(p,p[1:])]+[1])
    mod.comb=lambda n,j:pascal[n][j]
    f=gamma_chart(rows(8,8)[8],8)
    assert f==[1,-117,951,-1107],f
    pts=list(map(Fraction,('0','1/16','1/2','1')))
    ints=list(zip(pts,pts[1:])); verify_intervals(f,ints)
    for aux in range(9,k+1):
        g=gamma_chart(rows(aux,aux)[aux],aux);ints=next_fast(f,g,ints);f=g
    assert f==gamma_chart(e[k],k)
    for n in range(k,last+1):
        g=gamma_chart(e[n+1],n+1);ints=next_fast(f,g,ints);f=g
        if n%32==0: print('Certified through pair',n,flush=True)
    print(f'PASS: k={k} pairs {k}..{last}; elapsed {perf_counter()-start:.3f} s',flush=True)
if __name__=='__main__':
    if len(argv)==3: certify(int(argv[1]),int(argv[2]))
    else:
        certify(10,323)
        certify(11,440)

