from fractions import Fraction as Q
from math import factorial

def explower(x, n=18):
    return sum(x**j/factorial(j) for j in range(n))

pi_lower=Q(314,100)
assert explower(pi_lower**2/4)*Q(27,100)>3
assert explower(3*pi_lower**2/4)*Q(1,250)>5
assert explower(3*pi_lower**2/4)*Q(1,10)>Q(7,5)
assert Q(27,100)+Q(1,250)/(1-Q(1,10))<Q(3,10)
assert explower(Q(7))>1000
assert explower(Q(3,4))>2  # log(2)<3/4
assert explower(Q(4))>16
eta=Q(1,1000)
assert eta/(1-eta)**2+eta/(2*(1-eta))<Q(1,10)
assert Q(31,100)*Q(101,100)+Q(1,100)<Q(1,3)
print('PASS: exact Gaussian tail, exponential and edge margins')
