from fractions import Fraction as Q
from math import factorial

if not __debug__:
    raise RuntimeError("Run without -O")

def eh(x):
    return sum(x**j/factorial(j) for j in range(29))+x**29/factorial(29)/(1-x/30)
def cutoff(alpha,c):
    a,b=eh(alpha),eh(2*alpha)
    assert a + b/(2-a) < c

K=2**21
R=1448
pi=Q(22,7)
assert R**2<K
for alpha,c in [(Q(4,15),4),(Q(1,5),Q(16,5)),(Q(1,7),Q(14,5)),
                (Q(1,4),Q(37,10)),(Q(1,8),Q(27,10)),(Q(1,16),Q(7,3))]:
    cutoff(alpha,c)
for a,b in [(Q(1,8),Q(4,15)),(Q(1,18),Q(1,5)),(Q(1,72),Q(1,7))]:
    assert Q(1,8)+a+a/(8*K)<b
assert Q(1,8*K+1)>=Q(10,81*K)
assert 900*22*Q(7,10)<118**2 and Q(118,R)<Q(1,12)
assert Q(56,5)/(1-Q(56,5*R))<12
assert 192<275
assert Q(243,160)<Q(5,4)**2 and Q(729,160)**3<100
assert Q(81,71)*(2*Q(5,4)+Q(211,50)*Q(243,80)+Q(127,100)*10)<32
assert Q(1990,81)>22 and 15*(2+Q(211,50)*15+Q(127,100)*200)/2**22<Q(1,100)
assert Q(1)+Q(1,4*K)<Q(101,100)**2
for S,T,limit,bound,cap,A in [(2,Q(7,5),Q(7,1000),Q(51,25),20,3),
                              (Q(8,5),Q(9,10),Q(131,10000),Q(33,20),32,6)]:
    assert A*pi/R<limit and bound*A*pi<cap
    a=S+T*limit
    assert a/(1-a*limit)<bound
    assert 2*(1+Q(7,50))*cap+Q(7,2)*bound*32<275
assert Q(4**2,12)*Q(101,100)**2<Q(7,5)
assert Q(16,5)**2/12*Q(101,100)**2<Q(9,10)
assert Q(7,50)+Q(279,R)<Q(1,3)
assert Q(4,R)<Q(3,1000)
assert Q(14,5)**2/12*Q(351,100)**2<9
a=Q(49,10)+Q(9,12)
assert a*(1+(a/12)/(2*(1-a/36)))<Q(15,2)
assert Q(49,10)+Q(9*15,R)<5 and Q(5)/(1-Q(75,R))<Q(53,10)
assert Q(53,10)*(Q(15,250*R)+Q(32,R))<Q(118,1000)
assert Q(15,2)*(Q(1,12*250)+Q(1,100*R))<Q(3,1000)
assert Q(7,2)*Q(15,R)<Q(37,1000)
assert 1+Q(7,6)*118<12**2 and 1+Q(7,6)*15<Q(22,5)**2
assert 90/(2*Q(181)**2)<Q(1,700)
assert Q(1,17)-Q(1,700)>Q(1,18)
assert 3*pi*19<181
assert Q(27,8)<Q(15,8)**2
a,m=Q(37,10),Q(111,5)
rem=lambda a,m,beta,rad:(a*a*beta/6+2*a*m*rad/3)/R
L=lambda a,beta:a*beta/2+a*a*beta**2/12
tight=lambda beta,e:eh(beta+beta**2/3)-1<e
assert Q(1,2)*(Q(81,20)+Q(243,20)/6)<Q(31,10)
assert rem(a,m,Q(37,1000),Q(22,5))<Q(18,100)
assert L(a,Q(37,1000))<Q(71,1000) and eh(Q(71,1000))<Q(108,100)
assert tight(Q(37,1000),Q(39,1000))
assert 2*Q(108,100)*pi*(Q(31,10)+Q(18,100)+(Q(185,20)+Q(18,100))*Q(21,50))/R<Q(38,1000)
assert rem(a,m,Q(1,8),12)<Q(46,100)
assert L(a,Q(1,8))<Q(1,4) and eh(Q(1,4))<Q(9,7)
assert tight(Q(1,8),Q(14,100))
assert 2*Q(9,7)*pi*(Q(31,10)+Q(46,100)+(Q(185,20)+Q(46,100))*Q(21,50))/R<Q(45,1000)
a2,m2,beta=Q(7,3),Q(63,4),Q(7,24)
assert L(a2,beta)<Q(38,100) and eh(Q(38,100))<Q(147,100)
assert rem(a2,m2,beta,12)<Q(21,100)
assert (Q(35,8)+m2/19)/2<Q(261,100)
assert 2*Q(147,100)*pi*(Q(261,100)+Q(21,100))*(1+Q(21,50))/R<Q(26,1000)
assert tight(beta,Q(38,100))
assert Q(78,1000*500)<Q(1,1000)
assert Q(76,100*500)<Q(2,1000)
for extra,c in [(160,922),(53,720),(34,240)]:
    assert Q(extra,1000)<Q(c,1000)*(Q(1,3)-Q(7,50))
print("PASS: exact head-separated recurrence and joint tail margins for all k>=2^21")

