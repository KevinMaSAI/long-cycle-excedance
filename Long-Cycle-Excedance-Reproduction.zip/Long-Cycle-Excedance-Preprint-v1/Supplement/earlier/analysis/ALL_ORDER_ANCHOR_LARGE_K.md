# All-order cross-anchor coherence: all rows for k >= 2^25

**Theorem.** Every integer k>=2^25=33,554,432 and every n>=k satisfies simple real-rootedness of the long-cycle excedance polynomial E_(n,k), with strict interlacing for consecutive quotients by t. This does not solve all k. Above n>=900(k-1)log(2(k-1)) use UNIFORM_K_LOG.md. Below that threshold use the following new central estimates and the same audited edge and phase proof as CROSS_ANCHOR_LARGE_K.md. No root enumeration is used.

Let p_i=s+i_unit(2i+1)pi, rho=|p_0|, q_i=rho/p_i, B=n/k, x=sqrt(B/k), r=1+1/(16k), with 0<=s<=(7/2)sqrt(n). Let the positive reference spectral units be 2d_n and 2d_n v with v=pi/rho; other notation, exact mixed prefix identities, and tilted norm estimates are those of CROSS_ANCHOR_LARGE_K.md and its predecessor. Throughout this low-n wedge B<=900log(2k). Thus x<1/45: at k=2^25, sqrt(B)<128 and sqrt(k)>5791; log(2k)/k decreases for larger k. In particular beta=s/k<=7/90.

## An unsplit tilted anchor estimate
For 0<=c<=n+1-k and a=|q_i|<=1, the exact prefix weight satisfies
    a^(n-c) r^(-c) <= a^n + a^(k-1) r^(-(n+1-k)).
Indeed it interpolates geometrically between those endpoints; its maximum is at an endpoint, whichever way ar varies. This estimate covers either row and the centered boundary. The normalized coefficient prefactor dtilde_(N-c)/(2d_n) is <1 as in the prefix proof; with level weights w_l=2l+1 it therefore bounds the absolute mixed error by
    max_i ||B_i||_r [ sum_i w_l |q_i|^n + exp(-(B-1)/17) sum_i w_l |q_i|^(k-1) ].
Here log r>=1/(17k). The same bound can be restricted to any set of levels. The first sum is <2(1+7/50) by UNIFORM_CUT_SEVEN_HALVES.md. The second unweighted sum is <=M=2+(211/50)sqrt(B)+(127/100)B, by the previous lattice integrals (which hold already at k=2^25). By maximizing the powers of B against exp(-B/17) individually, and using e>8/3, we have
    exp(-(B-1)/17) M < 19,     sqrt(B) exp(-(B-1)/17) M < 75.
For completeness, the maxima of sqrt(B), B, B^(3/2) times exp(-B/17) are at most sqrt(17/(2e))<9/5, 17/e<51/8, and (51/(2e))^(3/2)<31, respectively. Account for exp(1/17)<=17/16. Thus the full bracket is <22.

On s<2pi sqrt(k), retain the earlier untilted low-s estimate: mixed error <272/sqrt(k)<1/20. On 2pi sqrt(k)<=s<3pi sqrt(k) and 3pi sqrt(k)<=s<6pi sqrt(k), use the existing signed norm bounds, respectively (33/sqrt(k),409/k) and (43/sqrt(k),675/k) for the log's linear part and remainder. Therefore ||B_i||_r<44/sqrt(k) in both, by exp(a)-1<=a/(1-a) and sqrt(k)>5791. The new unsplit bracket gives mixed error <968/sqrt(k)<17/100. Adding the unperturbed farther bound 7/50 and adjacent diagonal deviation <1/1000 proves the two central comparisons <1/3 in these small and middle bands.

## Translating a full pole product to a common real reference
Work now with s>=6pi sqrt(k). Instead of comparing only linearized amplitudes, temporarily let the anchor's height be a real variable y, with |y|<=3pi. Put P=s+i_unit y, P_h=s+i_unit(y+2pi h) for nonzero integer h, and define the analytic-norm factors
    f_h(y,z) = sum_(b>=k) delta_b P^b z^b/(2pi*i_unit*h P_h^(b-1)),
    F_y(z) = prod_(h!=0)(1+f_h(y,z)).
At y=(2i+1)pi this is exactly 1+B_i(q_i^(-1) z) by shifting j=i+h; at y=0 all h,-h factors are conjugates and the coefficients are real. The only actual poles used for the comparison are levels l=0 and l=1, which lie inside this y range. On the intervening real line, |y|/s<=1/(2sqrt(k)), so t_y=|P|/s<=exp(1/(8k)). In particular t_y<1+1/(4k). Denote by || || the radius-one coefficient norm in the remainder of this section.

The signed Fourier formula of the earlier proof is valid for each real y along this path, since the h-differences remain the same integers. It gives coefficient b of S_y=sum_h f_h(y) as
    delta_b (s/2)(P/s)^b E[exp(-i_unit*y*T_b) W(T_b)],
where W is the bounded, real period-one sawtooth and T_b is Gamma(shape b-1, rate s), as in the previous proof. Therefore ||S_y||<=7s/(2k) by D_(1+1/(4k))<7/k. Also ||f_h||<=7s w_h/(2pi k |h|), where w_h=(s/|P_h|)^(k-1)<=1. Every individual norm is <1/2. Let L_y=sum_h log(1+f_h(y)), the log defined by its series in the commutative coefficient algebra. Then exp(L_y)=F_y, and
    ||L_y|| <= 7s/(2k)+49s^2/(12k^2)<3/10,
by the square-sum remainder as before. At y=0 replace 7/k by D_1<3/k to get ||L_0||<1.5 beta+.75 beta^2. Therefore ||F_0-1||<=exp(||L_0||)-1<.14.

Differentiate the signed Gamma representation coefficientwise; the logarithmic derivative of its complex factor is i_unit (b/P-T_b). Its mean absolute value is at most sqrt(b)/s + b|y|/s^2, since E|T_b-b/s|<=sqrt(b)/s. As in the prior moment comparisons, the gap log(1+1/(4k))-log(t_y)>1/(16k) gives sum |delta_b| t_y^b sqrt(b)<=14/sqrt(k), and sum |delta_b| t_y^b b<=42. It follows that ||S'_y||<=7/sqrt(k)+21|y|/s<=17.5/sqrt(k). In the primary segment |y|<=pi there is a sharper gap log(1+1/(8k))-log(t_y)>1/(12k) (log(t_y)<=1/(72k)); the tilt bound 9/(2k) and maxima of the same two moments give respectively 6.75/sqrt(k) and 20.25. Since |y|/s<=1/(6sqrt(k)), this gives ||S'_y||<=81/(16sqrt(k))<5.1/sqrt(k).

To bound the log remainder derivative, differentiate the meromorphic factors explicitly. The derivative of P^b/P_h^(b-1) is that quotient times i_unit[1/P+(b-1)(2pi*i_unit*h)/(P P_h)]. Thus
    ||f'_h|| <= [7/(2pi k |h|)+42/s] w_h.
The norm bound for the difference L'_y-S'_y is 2 sum_h ||f_h|| ||f'_h||, since ||f_h||<1/2. It is at most
    49s/(6k^2) + (98/k) sum_(h!=0) w_h^2/|h|
    <= 49s/(6k^2) + (196/k) sqrt(1+s/(3sqrt(k))).
For the last inequality, Cauchy-Schwarz uses sqrt(sum h^(-2))<2. The shifted lattice of w_h^4 has sum bounded by its integral with mesh 2pi plus its maximum 1, by one-dimensional unimodality and superlevel counting. After setting u=(y+2pi h)/s in the integral, the density (1+u^2)^(-2(k-1)) has integral <=sqrt(2pi/(4k-6))<=2/sqrt(k), by the tangent substitution and Gaussian comparison. The stated remainder derivative is <.5/sqrt(k); insert beta<=7/90 and s/sqrt(k)<=(7/2)sqrt(900log(2k)), and bound the decreasing ratio sqrt(1+(7/6)sqrt(900log(2k)))/sqrt(k) at k=2^25 (numerator <13). Infinite product, log, and differentiated series converge uniformly on the y segment in this coefficient norm, since each factor and derivative has a summable w_h power tail there with k>=2^25. This justifies termwise operations and integrating the derivative.

The full product therefore satisfies
    ||F_y-F_0|| <= (10/7)|y| * (28/5)/sqrt(k) for |y|<=pi,
    ||F_y-F_0|| <= (10/7)|y| * 18/sqrt(k) for |y|<=3pi,
by ||F'_y||<=exp(||L_y||)||L'_y|| and exp(.3)<=10/7. This is all-order phase coherence, with no separate quadratic mixed-product error during the near-anchor comparison.

## Closing the high-s signs
For either N=n or N=n+1 define the real reference amplitude A_N=sum_c dtilde_(N-c)[z^c](F_0-1). For the actual anchor replace F_0 by F_y. This is the exact prefix identity rephased by q_i^n, not a truncated expansion in the product. The normalized common amplitude c_N=1+A_N/d_n>.72 by ||F_0-1||<.14 and 1/(k d_n)<2. For the near levels, use the all-order difference just proved; the coefficient prefix factor is bounded by 1/(k d_n)<2 when computing the rephased amplitude. Include the multiplier w_l for centered comparison and use w_1|q_1|^n<7/50. The two normalized near-level errors are at most
    (20/7) pi [28/5+18*3*(7/50)]/sqrt(k)<21/1000.
For actual far levels l>=2 use the unsplit tilt estimate. The earlier large-s tilted bound and x<1/45 imply ||B_i||_r<=exp((27/4)x+20x^2)-1<8x: using y=(27/4)x+20x^2<4/25, the bound exp(y)-1<=y[1+y/(2(1-y/3))] follows directly by the factorial series. For the exponent n, Bernoulli with power 32 gives |q_i|^n<=(1+l(l+1)/20)^(-32); indeed n pi^2/(16rho^2)>1/20. The weighted tail l>=2 on the upper poles is <1/500 by its first summand plus its monotone integral from 2 to infinity. In the unsplit bound the two signed halves cost <1/250. Therefore the actual far mixed error is <8(x/250+75/sqrt(k))<105/1000. The far comparison against A_N costs at most .28/500<1/1000. The adjacent diagonal deviation is <1/1000. The primary pair becomes (c_n cos(n theta), -c_(n+1) sin(n theta)), with error after division by its own positive c_N below
    7/50+(21+105+1+1)/(1000*.72) < 1/3.
No other error is omitted; the real reference amplitude in the centered row uses N=n+1, including its exact n+1 boundary. Both comparisons are uniformly proven throughout the central band. Now the same monotone phase, occupancy edge, reciprocity and parity proof as CROSS_ANCHOR_LARGE_K.md exhausts the degree and proves strict signs at all old negative roots, hence interlacing. The low n and high n theorems cover adjacent pairs across the switch.

Validation: check_all_order_anchor_large_k.py is an exact arithmetic replay of the numerical margins. The mathematical proof is analytic; the finite toy prefix checks used earlier are independent algebra diagnostics only.

