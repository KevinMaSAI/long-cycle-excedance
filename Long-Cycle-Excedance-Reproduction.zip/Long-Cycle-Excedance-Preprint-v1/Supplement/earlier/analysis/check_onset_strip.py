from itertools import product
import check_interlacing_general as base
from math import comb

def gamma_rows(k,hi):
    rows=base.rows(hi,k)
    pols={}
    for n in range(k,hi+1):
        r=rows[n].copy()
        co=[]
        for j in range(n//2+1):
            a=r[j]
            co.append(a)
            for i in range(n-2*j+1):
                r[j+i]-=a*comb(n-2*j,i)
        assert not any(r) and co[0]==0 and co[1]==1 and all(v>0 for v in co[1:])
        pols[n]=co[1:]
    return pols

def test(k,n,G):
    f,g=G[n+1],G[n]
    if len(f)==len(g)+1:
        base.certify(f,g)
    else:
        assert len(f)==len(g) and len(g)>1
        h=[f[-1]*y-g[-1]*x for x,y in zip(f,g)][:-1]
        assert h[-1]>0
        base.certify(g,h)

if __name__=="__main__":
    if not __debug__: raise RuntimeError("Run without -O")
    count=0
    for k in range(6,46):
        G=gamma_rows(k,2*k+5)
        for n in range(2*k-1,2*k+5):
            test(k,n,G)
            count+=1
        if k%5==0:
            print("PASS through k",k,"pairs",count,flush=True)
    print("PASS all",count,"pairs",flush=True)

