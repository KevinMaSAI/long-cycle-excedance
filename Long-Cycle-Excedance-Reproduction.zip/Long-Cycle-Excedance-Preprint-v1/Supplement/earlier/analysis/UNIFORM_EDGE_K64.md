# Uniform occupancy edge down to k = 64

**Lemma.** For every integer k>=64 and n>=max(k,16385), put D=n-1, M=ceil(sqrt(D)/4), S=D/M. Use the exact occupancy alternating series in OCCUPANCY_ALTERNATING_SERIES.md. Its sign at s=D/m, 1<=m<=M, is (-1)^m. At any zero in D/(m+1)<=s<=D/m, 1<=m<M, the normalized next row has sign (-1)^(m+1). This is an edge statement only, with no assertion for the central interval 0<=s<S. It is uniform in n/k.

Let H=n/k, A_n(r)=r b_(n,k)(r), and mu=H/r. The prior weighted upper bound gives A_n(r)<=min(r,H) and the full-cycle term A_n(r)>=1. If H>=2, put h=ceil(2r/H)<=r and condition the uniform permutation on all cycle lengths being at least h. Its probability p_r>=1/(2h-1), and p_j<=1/h for j>0, by the recurrence and weighted bound in GROWING_RATIO_LOG_BAND.md. For h<=j<r, the conditional expected number of j-cycles is p_(r-j)/(j p_r)<=2/j. A full cycle always passes. All lengths j>=h have expected hit counts n j/r>=2k, so the binomial lower-tail Chernoff bound gives failure probability <=exp(-n j/(8r)). For alpha=n/(8r), the union bound is
    2 sum_(j>=h) exp(-alpha j)/j <= 2 exp(-alpha h)(1/h+1/(alpha h))
    <= 2 exp(-k/4)(1+4/k)<1/100,
since 1/(1-exp(-alpha))<=1+1/alpha and k>=64. Hence A_n(r)>=(99/100) r/(2h-1). If mu<=2 this gives H/A_n(r)<61/10 (because mu(2h-1)<=4+mu<=6). If mu>2, h=1 and A_n(r)>=(99/100)r. For H<2, the trivial lower bound already gives H/A_n(r)<2. In all cases min(r,H)/7<=A_n(r)<=min(r,H).

Let D_r=r(A_(n+1)(r)-A_n(r))/A_n(r)>=0. The explicit unique deficient cycle identity in GROWING_RATIO_LOG_BAND.md and its beta lattice sum bound give, if mu<=2,
    D_r <= (H/A_n(r))(r/n+1/sqrt(k)) <= (61/10)(r/n+1/8).
For n<2k-1 this also holds because A_(n+1)=A_n=1, so D_r=0. For mu>2 the same deficient cycle identity bounded by the binomial tail gives
    D_r <= (100/99)/(exp(n/(8r))-1) <= (100/99)/(exp(k/4)-1)<1/100.
All these bounds involve A_n in the denominator, not a separate bound on b without the factor r. The lattice estimate used for mu<=2 comes from integrating the unimodal binomial mass of Bin(n-1,p)=k-1 (integral 1/n), adding one maximum mass <=1/sqrt(k), and applying A_(n-k+1)(r-j)<=(n-k+1)/k inside the deficient cycle identity; see the previous proof for the explicit cancellation.

Set eta=1/1000. The pure exponential magnitudes V_r(s)=exp(-rs)r^D have outward successive ratios <=eta at a witness or on either outward side of its bracketing pair, by CENTRAL_CUTOFF_FOUR.md for n>=16385. At distance a>=1 from an index i=m or m+1 on the corresponding outward side, A_n(r)/A_n(i)<=7(a+1). At a witness, relative opposing tails are bounded by 14 sum_(a>=1)(a+1)eta^a<3/100, proving the witness sign.

At an old zero between successive witnesses subtract lambda=m+7/8 times the normalized old series from the normalized next series. The summands become (-1)^r V_r A_n(r) (r-lambda+D_r). Since M/n<1/480, for r equal to a main index or a distance a>=0 from it we have
    D_r <= 39/50+a/2000.
Indeed r/n <= 1/480+a/n, n>=16385 and k>=64, and the alternative mu>2 bound is even smaller. The main terms r=m,m+1 therefore have the same sign (-1)^(m+1). Their combined magnitude is at least (19/200)(V_m A_n(m)+V_(m+1) A_n(m+1)), since 7/8-39/50=19/200 and 1-7/8=1/8. At the two outward tails, |r-lambda+D_r|<=2(a+1), giving an error in units of the combined weight strictly below 14 sum_(a>=1)(a+1)^2 eta^a<3/50. This is smaller than 19/200. The next-row sign at the old zero is proved. The subtraction is legitimate because the old normalized row is zero at that point and both normalizing factors are positive.

The older proof required k>=10^8 to make the entire first-difference term small in absolute value. Here re-centering at m+7/8 and using D_r>=0 save the right-hand main term. The improved lower bound for A also decreases the comparison constant. No finite root checks were needed. The exact arithmetic margins are replayed by check_uniform_edge_k64.py. Outside this lemma the central pole and transition regimes still require separate work, so the lemma does not assert the mother conjecture for k>=64.

