# A polynomially growing ratio for long-cycle excedance roots

Let E_(n,k)(t) enumerate excedances of permutations whose cycles all have length at least k. There are effectively computable absolute constants c>0 and k0 such that for k≥k0 and k≤n≤c k^(4/3)/(log k)^(2/3), E_(n,k) has simple real roots, and consecutive E_(n,k)/t strictly interlace whenever both rows are in the range. In particular this gives the band n≤k^(1+δ) for every fixed δ<1/3 and sufficiently large k. It does not reach the large-n bound or settle the parent conjecture.

## Normalization and diagonal support

Set t=−exp(−s), s≥0. For i∈Z let p_i=s+(2i+1)π sqrt(−1), ρ=|p_0|, q_i=ρ/p_i, u=Re q_0 and v=π/ρ. The normalized row from GROWING_K_REDUCTION.md is
    h_n=[z^n] ∏_i g_k(q_i z)=ρ^n E_(n,k)(t)/(n!(1−t)^n),
    g_k(y)=exp(∑_(a≥k) y^a/a)=∑_(a≥0)d_a y^a.
Here d_0=1, d_a=0 for 0<a<k, and d_a for a≥k is the probability that a uniform permutation on a labels has no cycles shorter than k, by the cycle-index exponential formula. In fact 1/(2k−1)≤d_a≤1/k for a≥k: the cycle containing the first label gives a d_a=1+∑_(j=k)^(a−k)d_j; induction gives the upper bound from 1+(a−2k+1)/k≤a/k when a≥2k, and the lower bound from 1+(a−2k+1)/(2k−1)=a/(2k−1). For k≤a≤2k−1 use d_a=1/a.

For b≥k set δ_b=d_b−d_(b−1) (where k≥2), and D=∑_(b=k)^(n+1)|δ_b|. From b d_b−(b−1)d_(b−1)=d_(b−k) and 0≤d_a≤1/k for a>0, we have |δ_b|≤1/(kb) for b>k. Also δ_k=1/k, so D≤[1+log((n+1)/k)]/k. Exactly,
    g_k(y)−1 = (∑_(b≥k) δ_b y^b)/(1−y).
In the pole product, the single-pole support contribution to h_n is d_n ∑_i q_i^n; to h_(n+1)−u h_n it is
    d_(n+1) ∑_i(q_i−u)q_i^n + u(d_(n+1)−d_n)∑_i q_i^n.

## Mixed support via divided differences

Expand the pole product by its finite support sets S of distinct poles. For each mixed S, |S|≥2, expand the δ factors of the numerator and let N=n−∑_(j∈S)b_j. For N≥0, the remaining coefficient is the complete homogeneous polynomial
    H_N(q_S)=∑_(i∈S) q_i^N /∏_(j∈S, j≠i)(1−q_j/q_i).
This is simply partial fractions of ∏_(i∈S)(1−q_i z)^(−1); the q_i are distinct and nonzero. At N=−1 the expression on the right is zero: written over Vandermonde differences it is ∑_(i∈S)q_i^(|S|−2)/∏_(j≠i)(q_i−q_j), the coefficient of degree |S|−1 in the interpolation polynomial of x^(|S|−2). Thus for all tuples with N≥−1 the centered adjacent coefficient H_(N+1)−u H_N is given by the same formula with factor q_i−u. Terms with N<−1 contribute nothing. In particular the new onset boundary N=−1 has not been dropped.

Write a=k−1, M=∑_i |q_i|^a, M1=∑_i (1+2|i|)|q_i|^a and P=sup_i∑_(j≠i) |p_j||q_j|^a/(2π|i−j|). Since |q_j|≤1 and each b_j≥k, the product ∏|q_j|^(b_j)|q_i|^N is bounded by ∏|q_j|^a even when N=−1. Also |1−q_j/q_i|^(−1)=|p_j|/(2π|i−j|) and
    |q_i−u|≤|q_i−q_0|+|q_0−u|≤(1+2|i|) v.
For the first term in this last inequality, |q_i−q_0|=2π|i|/|p_i|. With i distinguished in the partial fraction, summing freely over b_i costs D and over each other b_j costs D. For each fixed i, the sum over nonempty finite sets of other poles is at most exp(DP)−1, by the product bound ∏(1+x_j)≤exp(∑x_j) for x_j≥0. Therefore the mixed errors satisfy
    |err h_n|≤D M (exp(DP)−1),
    |err(h_(n+1)−u h_n)|≤v D M1 (exp(DP)−1).
One can first apply the calculation to any finite pole truncation. The bounds below show summability independent of that truncation. The normalized analytic products converge on closed disks of radius less than 1 because ∑_i |q_i|^k<∞, so coefficient passage is justified. No cancellation between different supports was assumed.

## Uniform bounds and signal scales

Use 0≤s≤8√n. Pair indices l and −l−1, l≥0. Then |p_i|²=ρ²+4π²l(l+1), and |q_i|^e≤(1+(2πl/ρ)^2)^(−e/2)=f_e(l) for e>0. The decreasing envelope satisfies
    ∑_(l≥1) f_e(l) ≤ ∫₀^∞ f_e,
    ∑_(l≥1) l f_e(l) ≤ ∫₀^∞ (x+1) f_e(x) dx.
For e>2 the integrals of f_e and x f_e are at most (ρ/(2π))√[π/(2(e−2))] and exactly (ρ/(2π))²/(e−2), respectively. The first uses x=(ρ/(2π))tan θ and cos θ≤exp(−θ²/2) on [0,π/2). For k≥8 this gives M=O(1+ρ/√k), M1=O(1+ρ²/k) and W=∑_i |q_i|^(a−1)=O(1+ρ/√k), with absolute effective constants. For P, use |p_j|=ρ/|q_j| and split the normalized sum at J=ceil(W). The distances ≤J cost at most 2∑_(j=1)^J 1/j≤2(1+log J); the distances >J cost at most W/J≤1. Hence P=O(ρ[1+log(1+ρ/√k)]).

With B=n/k≥1 and L=1+log(1+B), ρ≤√(74n), so M=O(√B), M1=O(B) and P=O(√n L). We sharpen the earlier logarithmic estimate on D using a block contraction. For b≥2k,
    δ_b=(d_(b−k)−d_(b−1))/b=−(1/b)∑_(j=b−k+1)^(b−1) δ_j  (b≥2k).
For the initial block k≤b≤2k−1, δ_k=1/k, and the others are negative with total absolute sum 1/k−1/(2k−1)<1/k. For b≥2k, any fixed j≥k appearing on the right has b between j+1 and j+k−1; the sum of its weights 1/b over these b≥2k is <1/2, since there are k−1 terms, each ≤1/(2k). Thus summing the recurrence in absolute values for 2k≤b≤n+1 bounds the tail variation by one half of the entire variation through n+1. It follows that D≤4/k uniformly, even when n/k is unbounded. This also justifies using the full δ series up to the unit circle in absolute value, though finite coefficients suffice here.

Consequently DP=O(L√(B/k)). For B≤k^(1/3) this tends uniformly to zero and exp(DP)−1≤2DP for large k. The two errors in units 1/k and v/k are therefore at most C B L/√k and C B^(3/2)L/√k for one absolute effective C. For B≤c k^(1/3)/(log k)^(2/3) with c≤1, the second is at most 2C c^(3/2) once k is large, using L≤2 log k. The first is bounded by the second since B≥1. Choose c small enough that this common bound fits the fixed theta sign margins below. The diagonal extra term has relative magnitude O(ρ/n)=O(1/√n) in units v/k: |d_(n+1)−d_n|≤1/(k(n+1)), |u|≤1 and ∑|q_i|^n=O(1) by the same integral estimate with e=n. Thus it does not affect sign transfer.

## Sign transfer and ordering

For self-contained normalization in the transfer, the comparison functions for ∑ q_i^n/2 and ∑ (q_i−u)q_i^n/(2v) are those of Section 3 of ALL_BOUNDED_RATIO_THETA.md, since ∑ q_i^n=ρ^n S_n and ∑(q_i−u)q_i^n=ρ^(n+1)(S_(n+1)−(u/ρ)S_n). Fix T=8. For n large the approximants are cos(φ), −sin(φ) for s≤n^(2/5), and C(φ,τ), ∂_φ C(φ,τ) otherwise. Here φ=n atan(π/s), using π/2 at s=0, and τ≤exp(−2π²/64)<1. Section 3 bounds both errors uniformly in n and s; in its far-pole majorant take exponent n and ratio L=1 rather than exponent k. There is a fixed positive lower bound on C/cos(φ) (using its continuous extension at the zeros) and on the absolute derivative at all half-integer phases; its second derivative has a fixed finite bound. In particular all comparison margins are independent of k and B. Dividing h_n by 2d_n and the adjacent difference by 2v d_(n+1), the mixed errors are bounded by 2C c^(3/2) and the diagonal and comparison errors tend uniformly to zero, using d_j≥1/(2k−1). Choose c so the former bound is less than one quarter of the error tolerance constructed in Section 4 of ALL_BOUNDED_RATIO_THETA.md, and then take k0 large enough for the latter errors to fit the remaining tolerance. This gives the central witness sign (−1)^j at φ=jπ, and next-row sign −sign(sin φ) at a zero of h_n in the central range. At a zero the subtraction u h_n does not change the sign of the next row. h_j is a positive multiple of E_(j,k)(t).

The edge comparison of GROWING_RATIO_LOG_BAND.md, Sections 1–2, already holds uniformly in B, for k≥10^8, with the same T=8. In particular no new growth of its constants is required. With d=n−1, m=ceil(√d/8) and S=d/m, the last edge witness is within the central domain s≤8√n. Its phase is mπ+o(1) uniformly. The root count and the adjacent-row sign transfer of Section 4 of ALL_BOUNDED_RATIO_THETA.md therefore apply, including the possible short sliver when that last edge witness lies just before mπ, the center root at −1 when n is odd, and reciprocal negative roots. The first n=k row is allowed, and at the final row use the preceding pair to establish simple real roots by strict interlacing. For a pair require both n and n+1 in the asserted band, so the bound on D and the diagonal terms is always available. Take k0 large enough for the band to include k+1. The cutoff is effective by the uniform analytic estimates and the explicit sign choices in the two cited proofs, but no practical cutoff is claimed.

## Audit notes

The stronger bound D≤4/k crucially uses the coefficient difference recurrence with a tail starting at b=2k, not the coarser logarithmic estimate. The latter would require a larger power of log k in the theorem statement. For mixed support the centered calculation at N=−1 is essential; dropping the N=−1 tuples would omit the next row's new support. The differing diagonal weights d_n and d_(n+1) require the displayed extra term, which is controlled independently. The earlier low/high ranges are unchanged, and the full parent conjecture remains open.
