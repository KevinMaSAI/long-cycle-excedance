from check_k6_dyadic import gamma_chart,next_intervals,verify_intervals,Fraction
from check_interlacing_general import rows
from time import perf_counter
if not __debug__: raise RuntimeError('Run without -O')
start=perf_counter(); e=rows(320,8); f=gamma_chart(e[8],8)
assert f==[1,-117,951,-1107],f
pts=list(map(Fraction,('0','1/16','1/2','1')))
ints=list(zip(pts,pts[1:])); verify_intervals(f,ints)
for n in range(8,320):
    g=gamma_chart(e[n+1],n+1); ints=next_intervals(f,g,ints); f=g
    if n%32==0: print('Certified through pair',n,flush=True)
print('PASS: k=8 pairs 8..319, elapsed',perf_counter()-start,flush=True)
