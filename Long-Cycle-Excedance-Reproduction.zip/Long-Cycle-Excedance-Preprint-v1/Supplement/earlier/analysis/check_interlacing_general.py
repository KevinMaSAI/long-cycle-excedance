"""Exact consecutive interlacing replay; Python 3.9+, stdlib only."""
from math import comb
import sys

def euler(limit):
    rows=[[1]]
    for n in range(1,limit+1):
        r=[0]*n
        for j,c in enumerate(rows[-1]):
            r[j]+=(j+1)*c
            if j+1<n: r[j+1]+=(n-1-j)*c
        rows.append(r)
    return rows

def rows(limit,k):
    a=euler(k-1)[-1]
    E=[[1]]+[[0]*(n+1) for n in range(1,k)]
    for n in range(k,limit+1):
        row=[0]*(n+1)
        for j,c in enumerate(E[-1]):
            row[j]+=j*c
            row[j+1]+=(n-1-j)*c
        for j,c in enumerate(E[n-k]):
            for i,v in enumerate(a):
                row[j+i+1]+=comb(n-1,k-1)*c*v
        assert row==row[::-1] and row[1]==row[-2]==1
        E.append(row)
    return E

def signed_remainder(f,g,scale):
    # Degree gap is exactly one, so the classical pseudo-remainder
    # uses exactly two multiplications by the divisor's positive lc.
    d=len(g)-1
    r=f.copy()
    b=g[-1]
    assert b>0 and len(r)==len(g)+1
    for i in (1,0):
        c=r[-1]
        r=[x*b for x in r]
        for j,x in enumerate(g): r[j+i]-=c*x
        assert r.pop()==0
    h=[]
    for x in r:
        q,rem=divmod(-x,scale)
        assert rem==0
        h.append(q)
    return h

def certify(f,g):
    scale=1
    while len(g)>1:
        assert len(f)==len(g)+1 and g[-1]>0 and f[-1]>0
        h=signed_remainder(f,g,scale)
        assert len(h)==len(g)-1 and h[-1]>0
        scale=g[-1]**2
        f,g=g,h
    assert len(g)==1 and g[0]>0 and len(f)==2 and f[-1]>0

if __name__=="__main__":
    if not __debug__: raise RuntimeError("Run without -O")
    nmax=int(sys.argv[1]) if len(sys.argv)>1 else 127
    k=int(sys.argv[2]) if len(sys.argv)>2 else 4
    e=rows(nmax+1,k)
    G={}
    for n in range(k,nmax+2):
        row=e[n].copy()
        co=[]
        for j in range(n//2+1):
            a=row[j]
            co.append(a)
            for i in range(n-2*j+1):
                row[j+i]-=a*comb(n-2*j,i)
        assert not any(row) and co[0]==0 and co[1]==1 and all(v>0 for v in co[1:])
        G[n]=co[1:]
    for n in range(k,nmax+1):
        f,g=G[n+1],G[n]
        if len(f)==len(g)+1:
            certify(f,g)
        else:
            assert len(f)==len(g) and len(g)>1
            h=[f[-1]*y-g[-1]*x for x,y in zip(f,g)][:-1]
            assert h[-1]>0
            certify(g,h)
    print(f"PASS: strict interlacing E_n/t with E_(n+1)/t for k={k}, each n={k}..{nmax}")

