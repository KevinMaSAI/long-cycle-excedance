from fractions import Fraction as Q
from math import factorial
def lo(x): return sum(x**i/factorial(i) for i in range(33))
def hi(x): return lo(x)+(x**33/factorial(33))/(1-x/34)
assert hi(Q(21,10))<9 and lo(Q(7,10))>2
assert Q(-1)+Q(1,2)*(1+Q(21,20*63))+Q(7,20)<-Q(1,8)
assert 1+Q(5,144)+Q(5,144*63)<Q(21,20)
assert Q(1024*144)<2**18 and Q(2**18,126**25)<Q(1,100)
assert Q(11,40)+Q(1,100)<Q(1,3)
print('PASS: explicit uniform upper-central contour margins')

