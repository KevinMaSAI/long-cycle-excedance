# Geometric-first exact dyadic interlacing replayer

Use python -B check_fixed_k_dyadic_fast.py K LAST to verify adjacent pairs K..LAST, inclusive (for K>=8 and LAST>=K). The degrees, base charts, sign patterns, disjoint brackets and transfer back to t are as in check_k6_dyadic.py and its proof. An auxiliary family of single-cycle Eulerian rows establishes the initial chart at n=K; the code checks that this final auxiliary chart equals the actual chart with minimum length K.

Two performance changes do not alter the certification logic:
- All binomial coefficients reused in the chart are computed by Pascal's integer recurrence. Horner evaluates an exact one-sided dyadic enclosure with width at most degree times 2^-24, and falls back to exact evaluation if it cannot certify the sign.
- For a bracket with lower endpoint zero, f(0)=1 and A=max_i |f_i|. All x<=1/(2A+1) satisfy |f(x)-1|<=A*x/(1-x)<=1/2. Replacing the lower endpoint by the smaller of half the upper endpoint and a dyadic number not exceeding 1/(2A+1) preserves the bracket. When the floors of the dyadic endpoint base-2 logarithms differ by at least three, use the power of two at their midpoint exponent, strictly inside the bracket. Otherwise use the ordinary midpoint. This never affects the sign argument. Failure to find any needed sign or a strict isolating bracket raises an exception, not PASS.

