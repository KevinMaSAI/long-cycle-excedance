from check_onset_strip import gamma_rows,test
from check_interlacing_general import euler,rows
from time import perf_counter
from math import comb
if not __debug__: raise RuntimeError("run without -O")
start=perf_counter()
A=euler(126)
for k in range(3,64):
    n=2*k+1
    r=[0]+A[n-1]+[0]
    for i,a in enumerate(A[k-1]):
        for j,b in enumerate(A[k]):
            r[i+j+2]+=comb(n,k)*a*b
    assert r==rows(n,k)[n]
    test(k,2*k,gamma_rows(k,n))
    if k%10==0: print("PASS through",k,flush=True)
print("PASS 61 pairs k=3..63; seconds",perf_counter()-start,flush=True)


