# Explicit large-k cutoff improved to 2^28 by exact anchor prefixes and phase coherence

**Theorem.** For every k>=2^28=268,435,456 and every n>=k, the long-cycle excedance polynomial E_(n,k) has simple real roots. Consecutive quotients E_(n,k)/t strictly interlace. This is not a proof for all k. The upper wedge n>=900(k-1) log(2(k-1)) is UNIFORM_K_LOG.md. Here the lower wedge is proved analytically without root or k enumeration.

Use the notation of EXPLICIT_LARGE_K_LOWER_WEDGE.md: p_i=s+(2i+1)pi*i_unit, rho=|p_0|, q_i=rho/p_i, theta=atan(pi/s), u=Re q_0, v=pi/rho, g(y)=sum d_a y^a and delta=(1-y)(g-1). We use D_1<3/k, D_r<4/k for r=1+1/(16k), D_(1+1/(4k))<7/k, d_n>=1/(2k-1), and the signed Fourier estimate there. For k<=n<900(k-1)log(2(k-1)), put B=n/k, x=sqrt(B/k), and restrict the central computation to 0<=s<=(7/2)sqrt(n). Then rho<=4sqrt(n), and x<1/120: B<=900log(2k) with B<18270 at the lower cutoff, and log(2k)/k decreases. Also rho<=(351/100)sqrt(n).

## Exact prefix summation at each anchor
Let f_ij(z)=delta(q_j z)/(1-q_j/q_i), B_i=prod_(j!=i)(1+f_ij)-1 and S_i=sum_(j!=i) f_ij. Write dtilde_m=d_m for m>=k and 0 otherwise, so sum_(a<=m) delta_a=dtilde_m by telescoping. Partial fractions with anchor i assign q_i^(n-a-c) to the term of anchor degree a and combined nonanchor degree c, and delta(q_i z) supplies q_i^a. Since these cancel in the exponent, summing over a first gives the following exact expressions:
    mixed h_n = sum_i sum_(c<=n-k) q_i^(n-c) dtilde_(n-c) [z^c]B_i;
    mixed (h_(n+1)-u h_n) = sum_i (q_i-u) sum_(c<=n+1-k) q_i^(n-c) dtilde_(n+1-c) [z^c]B_i.
The latter includes total a+c=n+1 exactly because the complete-homogeneous partial fraction at remaining degree -1 vanishes for each support of size >=2. There is no boundary term omitted. Absolute convergence follows from the same summable pole-norm majorants as in the prior proof, or here directly from n-c>=k-1 and dtilde<=1/k. All argument applies termwise to finite pole sets before taking their limit. This prefix summation improves the norm prefactor to (1/k)/(2d_n)<1 in primary units 2d_n and 2d_n v, for both S_i and the full higher-order remainder B_i-S_i.

For any uniform bound C_1 on ||B_i||_1 and C_r on ||B_i||_r (or on either part), split the sum at c=n/3. For c<=n/3 the anchor decay is at least |q_i|^(2n/3) and the per-anchor bound is C_1. For c>n/3 one uses |q_i|^(k-1) and the additional weight r^(-n/3)<=exp(-B/51), multiplying C_r. For centered bounds the normalized multiplier is <=2l+1 at level l; for uncentered it is <= the same. The Gaussian integrals of the earlier proof give at exponent a the sums M_1<=2+6I_0+4I_1, where for a>=.999b+2 the simple upper bounds I_0<=rho/(5sqrt(b)) and I_1<=rho^2/(39b) follow from pi>157/50. For a=2n/3 use b=2n/3, giving M_short<91/10. For a=k-1 use b=k and obtain M_long<=2+(211/50)sqrt(B)+(127/100)B. Differentiating the monomials times exp(-B/51) gives
    M_long exp(-B/51)<40,   sqrt(B) M_long exp(-B/51)<287,
    B M_long exp(-B/51)<2600.
The comparisons use e>8/3 and the rational bounds in the companion script. In the short piece restricted to l>=2 there is a much smaller bound M_short_far<1/10. Bernoulli's inequality with power 16 gives |q_i|^(2n/3)<=(1+l(l+1)/16)^(-16), by (2n/3)pi^2/(8rho^2)>1/16. Twice the l=2 summand plus twice the integral from 2 to infinity equals 2[5(16/22)^16+(16/15)(16/22)^15]<1/10; the summand as a continuous function decreases from 2. In particular sum_(l>=2)(2l+1)|q_i|^n over upper poles alone is <1/20.

## Low and intermediate s comparisons
For s<2pi sqrt(k), rho<=7sqrt(k). The grouped absolute norm bound improves to sum_(j!=i)||f_ij||_1<= (rho/(2pi)) D_1 sum_j |q_j|^(k-1) <(84/5)/sqrt(k), using sum <=2(1+7/5); hence ||B_i||_1<17/sqrt(k). Without any split, n-c>=k-1 and M_1<=2+6(7/5)+4*49/39<16 give normalized mixed error <272/sqrt(k)<1/50.

For 2pi sqrt(k)<=s<3pi sqrt(k), the signed norm with t=1+1/(4k) gives ||S_i||_r<33/sqrt(k) and logarithm remainder <409/k (rho<=10sqrt(k)). For 3pi sqrt(k)<=s<6pi sqrt(k), r*rho/s<1+1/(8k). The delta tail recurrence with this tilt gives D_t<9/(2k), using exp(1/4)<9/7, exp(1/8)<8/7. Thus ||S_i||_r<43/sqrt(k) and log remainder <=675/k (rho<=20sqrt(k)). In these log bounds the individual norms of f_ij are <1/2 because rho/k<=4x. In general if R_i=sum log(1+f_ij)-S_i, the bound
    ||B_i-S_i||_r <= ||R_i||_r + (||S_i||_r+||R_i||_r)^2 exp(||S_i||_r+||R_i||_r)/2
follows from the exponential Taylor remainder. In the first and second intermediate intervals it is respectively <1000/k and <1700/k by the stated bounds and exp(y)<=1/(1-y). The prefix split then gives normalized mixed error throughout <(491/10)(43/sqrt(k)+1700/k)<13/100. The diagonal coefficient deviation for the adjacent row is <4/sqrt(n)<1/1000, as in the prior proof. The normalized unperturbed farther poles are <7/50 by UNIFORM_CUT_SEVEN_HALVES.md. The low and middle bands therefore both have central errors <1/3 in the old units.

## High s phase coherence including the centered comparison
For s>=6pi sqrt(k), r*rho/s<1+1/(13k), and the delta recurrence yields D_t<77/(20k): exp(1/13)<27/25, exp(2/13)<7/6 give 175/(46k)<77/(20k). Thus ||S_i||_r<(27/4)x and ||R_i||_r<20x^2, by rho<=4sqrt(n). The displayed exponential remainder is <47x^2 using ||S_i||+||R_i||<7x and x<1/120. The prefix split, with the long bound retaining B instead of discarding it, gives normalized error of B_i-S_i at most
    (47/k)[(91/10)B+2600]<30/1000.

For the linear part, define F_(i,b)=sum_(j!=i) q_j^b/(1-q_j/q_i). The signed Fourier proof gives the exact representation, not just its magnitude,
    F_(i,b) = rho^b/(2s^(b-1)) E[exp(-i_unit*y_i*T_b) W(T_b)],
where y_i=Im p_i, T_b has gamma density proportional to t^(b-2) exp(-st) on t>0, and W(t)=2{t}-1 almost everywhere. This follows from the Abel limit of the signed harmonic Fourier sum over j-i; its absolute value is bounded by pi before division by pi*i_unit, justifying dominated convergence. The mean and variance of T_b are (b-1)/s and (b-1)/s^2 by direct integration, so E|T_b-b/s|<=sqrt(b)/s.

For either N=n or N=n+1, the linear anchor amplitude after factoring q_i^n is
    A_(i,N)=sum_b dtilde_(N-b) delta_b q_i^(-b) F_(i,b).
For the centered row the same amplitude with N=n+1 is multiplied by (q_i-u). Define a single real comparison amplitude
    A_N=(s/2)sum_b dtilde_(N-b) delta_b E[W(T_b)].
Since dtilde<=1/k and D_1<3/k, |A_N|/d_n<3s/k<88/1000, so c_N=1+A_N/d_n is positive and >.912. In the near levels l=0 and 1, |y_i| is pi or 3pi and s>=2|y_i|sqrt(k). Write t_i=|p_i|/s. For each b the phase difference between exp(i_unit*b atan(y_i/s)-i_unit*y_i*T_b) and 1 is bounded in mean absolute value by |y_i|sqrt(b)/s+b|y_i|^3/(3s^3). The amplitude change t_i^b-1 is <=t_i^b b y_i^2/(2s^2). Since log t_i<=1/(8k), the gap to log(1+1/(4k)) exceeds 1/(16k). The D_t<7/k estimate and maxima of sqrt(b) exp(-b/(16k)), b exp(-b/(16k)) therefore give sum |delta_b| t_i^b sqrt(b)<=14/sqrt(k) and sum |delta_b| t_i^b b<=42. With dtilde<=1/k and 2k d_n>1 this proves
    |A_(i,N)-A_N|/d_n <= 14|y_i|/sqrt(k)+42[y_i^2/(2s)+|y_i|^3/(3s^2)] <=25|y_i|/sqrt(k).
Both normalized near-level phase errors are thus <=25pi(1+3*7/50)/sqrt(k)<7/1000, including the (2l+1) multiplier and the actual |q_i|^n weights by the previous unperturbed farther bound.

For the actual linear part at l>=2, the tilted short/long prefix split and ||S_i||_r<(27/4)x give normalized error <(27/4)(x/10+287/sqrt(k))<124/1000. For replacing the same far terms by the common A_N, the error is at most (3s/k)/20<5/1000 using the far unperturbed bound. It follows that the full normalized models are c_n cos(n theta) and -c_(n+1) sin(n theta), with unperturbed farther contributions bounded by each c_N*(7/50) and total remaining relative-to-old-units errors at most (7+124+5+30+1)/1000 =167/1000. Since 167/1000 < .912(1/3-7/50), dividing each row by its own positive c_N yields central errors <1/3 throughout the high-s band as well. The coefficient difference on the adjacent diagonal was included in the last 1/1000.

## Completion and audit
Now apply the unshifted n theta stitch, edge comparison at S=(n-1)/ceil(2sqrt(n-1)/7), reciprocity, parity at -1, and degree exhaustion exactly as in EXPLICIT_LARGE_K_LOWER_WEDGE.md. The common amplitudes are positive so they do not change signs at old zeros or witnesses. The phase remains the same strictly increasing phase along decreasing s, even though the normalizations change between intervals. High and low wedges meet without an uncovered pair; the estimates of the lower pair use B=n/k, so n+1 may already lie in the high-n range. No per-k sweep is needed. The main remaining gap is the set of k below this still very large threshold, not a failure of the proved interval.

Audit: the companion check_cross_anchor_large_k.py provides exact rational margins and 164 direct toy-pole identities for the new prefix formula, including centered bsum=n+1. The toy identities are a check of algebra, not the evidence for any real-root assertion.

