from check_interlacing_general import rows
from math import comb
def T(P,n,r):
    return sum(p*comb(n+r-i-1,n-1) for i,p in enumerate(P[:r+1]) if p)
checked=0
for k in range(3,31):
    e=rows(81,k)
    for n in range(k,81):
        a,b=0,0
        for r in range(1,81):
            c,d=T(e[n],n,r),T(e[n+1],n+1,r)
            assert c>0 and d>0
            if r>1:
                checked+=1
                assert d*a>b*c,(k,n,r)
            a,b=c,d
print('PASS: occupancy adjacent amplitude ratios increasing, diagnostic checks',checked)
