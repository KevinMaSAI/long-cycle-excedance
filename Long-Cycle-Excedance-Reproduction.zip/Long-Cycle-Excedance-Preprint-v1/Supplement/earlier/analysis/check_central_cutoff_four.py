from fractions import Fraction as Q
from math import factorial
b=4*Q(157,50)**2/(16*128+10)
assert 2-64*b-254*b*12 < 0
s=sum((2*l+1)/(1+b*l*(l+1))**64 for l in (1,2,3))
assert s+(1+12*b)**(-63)/(63*b)<Q(7,25)
assert Q(16384,2*33*34)>7
assert sum(Q(7)**r/factorial(r) for r in range(25))>1000
print('PASS: exact primary-pair remainder and cutoff-four edge ratio')
