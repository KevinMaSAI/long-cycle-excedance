# Minimum cycle length six: analytic cutoff 192

The analytic part below proves simple real roots of E_(n,6) and strict interlacing of E_(n,6)/t with E_(n+1,6)/t for n≥192. To complete all n≥6, certify pairs 6≤n≤191 using python -B check_interlacing_general.py 191 6. Consult the execution log for whether the exact part has finished. The integer script is the same signed gamma-remainder certificate used for k=4,5. The signed remainder positivity criterion and the transfer back to the quotient are explained in the preceding proof files.

## Contour

Use the normalized H, ρ, a, u, v and B in EVENTUAL_ALL_FIXED_K.md. Put q=exp(−s), ρ=√(s²+π²), and write G_s(z)=∑_(m=2)^5 g_m z^m. The quartic proof bounds |g_m|≤q/m! for m≤4 and bounds |g_2|≤1/8, |g_3|≤1/60, |g_4|≤1/192. The new coefficient is
    g_5=q(1−11q+11q²−q³)/(120(1+q)^5).
In fact |1−11q+11q²−q³|≤(1+q)^3: the difference for the positive branch is 14q−8q²+2q³≥0; for the negative branch the sum is 2−8q+14q²>0. Therefore |g_5|≤q/[120(1+q)²]≤1/480, and |g_5|≤q/120 also holds.

Take a circle radius R∈[9ρ/5,2ρ] at distance greater than 1/4 from all pole moduli. The same exclusion geometry as K5_INTERLACING.md applies, since the smaller endpoint is still ≥7ρ/4 and the interval length ρ/5>1/2. Its denominator bound gives |H|/|Res_p H|≤32 exp(U), with
    U=∑_(m=2)^5 (2^m+1)|g_m|ρ^m.
For s≤1 the universal bounds above give U<51, using ρ²<11, ρ<10/3. For 1≤s≤3 also use (1+q)^(-2)≤(21/22)^2 (e³<21), and note that exp(−s)ρ^m decreases for m≤5 since ms/(s²+π²)≤m/(2π)<1. Bounding this latter expression at s=1 with q≤3/8 gives U<101. The same monotonicity and the bounds at s=3,8,16 give, respectively, U<44 for s≥3, U<8 for s≥8, and U<1/10 for s≥16 (all strict checks are in check_k6_bounds.py).
The relative circle error in units B is ≤16ρ exp(U)(5/9)^n, and in units Bv the extra factor is at most (14/9)ρ/π, from |1/z−u|≤1/R+u. For 0≤s≤3 these are <160(11/4)^101(5/9)^192<1/100. For 3≤s≤3√n use ρ≤4√n and bound both by 144n(11/4)^44(5/9)^n<1/100, checking at 192 and using decrease thereafter.

There are no farther poles inside R when s≤3 (2ρ≤2√19<3π). In 3≤s≤8, a farther pair has normalized radial suppression (1+x)^(-(n+1)/2), x=4π² l(l+1)/ρ² with l≥1. Reserve exponent 3n/8; then x≥36/37 and log(1+x)≥2x/(2+x)≥36/55, so the reserved suppression beats exp(U), since 72·36/55>44. The remaining exponent n/8 bounds the weighted sum over pairs by ∑_(l≥1)(2l+1)/(1+c l(l+1))^4 where c=nπ²/(8ρ²)>1/2 (Bernoulli). This sum is <1/4 by POLYNOMIAL_UNIFORM_BOUND.md. In 8≤s≤16, use x≥72/266, reserve exponent n/4 and use log(1+x)≥x/(1+x); 48·72/338>8 beats exp(U). The same bound on the remaining weighted sum follows since c=nπ²/(4ρ²)>1/2. For s≥16 in the central region, ρ²≤9n+π² and c=(n+1)π²/(2ρ²)>1/2 with no reserved power; the numerator penalty is at most exp(1/10)≤10/9. Together the contour and pole errors are less than 1/3, in both units, exactly as required in EVENTUAL_ALL_FIXED_K.md. The centered pole multiplier bound (2l+1) is included throughout.

## Edge

Use M=ceil(√n/3), S=n/M as in EVENTUAL_ALL_FIXED_K.md, its same witness and outward-ratio design. For n≥192, x=√n≥55/4, M≤(67/165)x and S≥(165/67)x>33. All short-cycle deletion weights g_m are positive here: 1−11q+11q²−q³>0 when 0<q<1/20, and the lower-degree signs are the same as for k=5. The fixed-k edge moments are
    T_j(l)=j![z^j] exp((l+β)z+∑_(m=2)^5 g_m z^m),   β=1−a≤q.
For l≥1, compare to l^n by expansion to get relative excess ≤exp(q∑_(m=1)^5 n^m/m!)−1, and 1 as lower ratio. For the adjacent ratio use the derivative recurrence and T_j(l)≥(l+β)T_(j−1)(l), to get
    0≤T_(n+1)(l)/T_n(l)−l≤q∑_(m=1)^5 n^(m−1)/(m−1)!.
Both sums times q are at most q n^5/100<1/200: as a function of x, x^10 exp(−165x/67)/100 decreases above 55/4, and there it is at most 14^10(3/8)^33/100. This establishes condition (B) with 1/100 errors.

For the zero moment use the multinomial termwise bound, as in the k=5 proof and using (m h)!/h! ≤ j^((m−1)h) when mh≤j:
    T_j(0)≤[q^(1/5)(1+√j+j^(2/3)+j^(3/4)+j^(4/5))]^j.
For j=n,n+1 the logarithm of the large parenthesis after q^(1/5) is at most (2/5)x. Replace j by x²+1; for x=55/4 the sum is <169<exp(11/2), and its logarithmic slope is at most (8/5)x/(x²+1)<2/5 thereafter. At any witness index m≤M, V_m=q^m m^n and
    s(j/5−m) ≥ n²/(5M)−n ≥ n x(33/67−4/55).
The first inequality uses s≥n/M and j/5−m≥n/5−M>0. Thus T_j(0)/V_m≤exp(−n x/100), since (33/67−4/55)−(2/5)(193/192)>1/100. Even with prefactor M+2≤n this gives the required <1/100. The exact edge conclusions of EVENTUAL_ALL_FIXED_K.md now apply.

## Phase and cutoffs

At S, |β|≤e^(−S) and |G_s(p)|≤q∑_(m=2)^5 ρ^m/m!; hence the normalized phase perturbation beyond the old arctan and constant shift parts is at most q[1+(1/π)∑ ρ^m/m!]. Every term decreases for s≥33 and the bound at 33 is <1/100. Use exactly the same atan bounds at S and parity argument at zero as in EVENTUAL_ALL_FIXED_K.md to stitch the edge and central witnesses. The first/last phase hit argument counts all roots and yields strict next-row comparison at each nonzero old root, hence strict quotient interlacing. The analytic and finite ranges share the row n=192. The explicit inequalities used here are independently replayable with check_k6_bounds.py, which is not by itself a proof for the finite pairs.
