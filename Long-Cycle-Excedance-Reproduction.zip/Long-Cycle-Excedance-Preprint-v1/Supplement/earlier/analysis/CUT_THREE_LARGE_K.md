# Smaller central region: all rows for k >= 2^13

**Theorem.** For every integer k>=8192 and n>=k, E_(n,k) has simple real zeros. Consecutive quotients by t strictly interlace. No per-k or root sweep is used. The upper wedge n>=900(k-1)log(2(k-1)) is UNIFORM_K_LOG.md, which remains unchanged. This document proves the lower wedge; it supersedes the cutoff 2^14 in FAST_PREFIX_LARGE_K.md. The full conjecture remains unresolved.

Use the notation and exact prefix identities of the preceding notes, with B=n/k, beta=s/k, x=sqrt(B/k), rho=|s+i*pi|, and w_l=2l+1. Now use 0<=s<=3sqrt(n) for the central region. Then rho<3.01sqrt(n), beta<=3x<3.2, sqrt(k)>90; the last cap follows from sqrt(900log(2*8192))<94 and the decrease of log(2k)/k. Within this context all usual log estimates use actual norm caps where needed.

## Occupancy edge at the new split
Let D=n-1, M=ceil(sqrt(D)/3), S=D/M. Use the exact occupancy representation and A_n(r) between min(r,n/k)/7 and min(r,n/k), and the difference estimate from UNIFORM_EDGE_K64.md. For n>=8192, sqrt(D)>90, and the outward pure magnitude ratios at witnesses and from either outer side of a bracket are at most exp(-D/[2M(M+1)]) <1/58=:eta. Indeed D/[2M(M+1)]>=90^2/[2*(90/3+1)*(90/3+2)] by monotonicity. At witnesses the tail comparison 14 sum_(a>=1)(a+1)eta^a<1 gives the sign (-1)^m as before.

At an old zero bracketed by m and m+1 use lambda=m+1/2 for the centered subtraction. The nonnegative adjustment D_r=r(A_(n+1)(r)-A_n(r))/A_n(r) satisfies D_r<=.1+a/1000 at either main index or distance a outward, since M/n<1/(3*90)+1/8192, sqrt(k)>90 and the existing estimate is <=(61/10)(r/n+1/sqrt(k)) or <.01. Therefore left and right main term magnitudes are at least .4 and .5 times their own weight, of the same intended sign. The left-outward loss relative to the left main weight is at most 7 sum (a+.5)eta^a<.4, using D_r>=0. The right-outward loss is at most 7 sum (1+a/2)(1.001a+.6)eta^a<.5 using m+1>=2 and the amplitude ratio bound. This yields the old-root next-row sign uniformly even when n/k varies. All sums are rational geometric moment formulas in the replay.

At the stitch S the phase n atan(pi/S) differs from M*pi by less than pi/8: use M<(1/3+1/90)sqrt(D)<.345sqrt(D) in M/D+n*pi^2 M^3/(3D^3). S<=3sqrt(n). This supplies the same first/last-hit, parity and degree argument as before after establishing central signs. It also covers the lowest n=k=8192; n>=16385 is no longer necessary.

## Uniform radial improvements
The centered exponent-n upper-half farther weight is <.04 by the monotonic bound of CENTRAL_CUTOFF_FOUR.md at n=8192 and s<=3sqrt(n), comparing the first three levels plus integral from 3 with b=4(157/50)^2/(9*8192+10). Its unweighted version is <.014 by w_l>=3 at farther levels. Thus full n-lattice weights are at most 2.08 and <2.03, respectively. The exponent-n two-half tail at l>=2 is <1/2500, and at l>=4 is <10^(-10), by Bernoulli with exponent 32 and lattice parameter 1/15 (n*pi^2/(16rho^2)>1/15) and first term plus integral. The general weighted integral of FAST_PREFIX_LARGE_K.md yields exponent-(k-1) bounds M_1<=2+1.38B, M_0<=2+1.21sqrt(B).

For the ordinary tilted norm use r=1+1/(4k), lambda=41/10 and Q_j(B)=M_j exp(-(B-1)/lambda). Keep the same unsplit endpoint bound. For B>=4 the two long factors sqrt(B)Q_j are <4.3 (value), <8 (centered): the sqrt(B) term is decreasing there (evaluate at 4), and bound the other powers at their individual maxima using e>2.718 and exp(1/lambda)<1.278. From B>=9.8 the bounds improve to 2.2 and 5.8, from B>=16 the weighted bound is <2.5, and from B>=39 it is <.04, by monotonic evaluation. These are statements about continuous B, not a grid of root cases.

## Low s and first two middle bands
Use the same absolute low-s bound as FAST_PREFIX_LARGE_K.md, with sqrt(k)>90: rho<6.3sqrt(k) gives lattice sums <4.6 and 8.1, harmonic factor <=4.6/2+1, and D_1<1.85/k gives mixed ||B_i||_1<6.6/sqrt(k). Thus asymmetric errors are below .014+4.6*6.6/90 and .04+(8.1*6.6+4)/90. Their squares sum to less than one.

For 2pi sqrt(k)<=s<3pi sqrt(k) and 3pi sqrt(k)<=s<6pi sqrt(k) use the same tilted radii t=1+.38/k and t=1+(5/16)/k and delta limits as FAST_PREFIX_LARGE_K.md. The respective signed S_i and squared log remainder caps are (1.65beta,.93beta^2) and (1.5beta,.77beta^2). The linear tail after peeling z^k is .91beta and .785beta. In the first band beta<.105; stationary factor norms <1/2, so the nonlinear remainder is <2.81beta^2 and ||U_i||_r<1.21beta. Since B>4, atom's anchor exponent n-k>=(3/4)n, so the weighted and unweighted atom lattice sums are <2.3 and <2.1 using Bernoulli power 32 and lattice parameter 1/20; multiply by (4/7)beta to get respective constants 4/3 and 1.2 times beta. The pair
    [.014+((1.2+2.03*1.21)*3pi+3*1.21*4.3)/90,
     .04+.023+((4/3+2.08*1.21)*3pi+3*1.21*8)/90]
is inside the ellipse. Diagonal .023 uses n>4k.

For the second band B>9.8, n-k>=(8/9)n, Bernoulli lattice parameter 3/50 gives weighted sum <2.2 and unweighted <31/15 (farther multiplier >=3). The atom uses exp(1/18)/2 times beta, so constants 1.17 and 1.1 suffice, respectively. When B<=16 we have beta<=12/sqrt(k)<.134, hence nonlinear remainder <2.42beta^2 and ||U_i||_r<1.11beta. The ellipse pair
    [.014+((1.1+2.03*1.11)*12+3*1.11*2.2)/90,
     .04+.015+((1.17+2.08*1.11)*12+3*1.11*5.8)/90]
works. The diagonal .015 uses n>9k. For B>=16 instead use the primary relative coherence below. Throughout the second band beta<.21, so ||U_i||_r<1.4beta by the same log computation now with nonlinear constant 2.9; all individual log factors still <1/2.

## Middle s with B>=16: compare only the primary pair
Let P0=P(s), use the exact scalar formula from SCALAR_REFERENCE_LARGE_K.md and exponential prefix comparison of FAST_PREFIX_LARGE_K.md. For the reference and near difference use the stronger tilt R=1+1/(2k) only on F_y (do not change the earlier tail tilt r). Then D_R<4.1/k by the sharpened delta recurrence and log R>=1/(2.1k). Therefore kappa_R:=2kD_R R^(-n/2)<8.2 exp(-B/4.2), and with beta<.21 and B>=16, Rref=kappa_R||F_0||_R/P0<.34. Indeed log ||F_0||_R<=2.05beta+(4.1)^2 beta^2/12 and P0>=exp(-.501beta)>.90. So c_N/P0>.66 and c_N>.59. Upper P0<=exp(1.001beta)<1.24, useful for subtracting the common reference from the far multipliers.

On the primary path |y|<=pi, s>=3pi sqrt(k), hence log(|s+i*y|/s)<=1/(18k), and |y|sqrt(k)/s<=1/3. With t=1+.7/k, the gap to R*|s+i*y|/s exceeds 1/(7k); D_t<6.2/k. Moment triple is (a,C,m)=(6.2,7.13,16.275) by sup sqrt(b) exp(-b/(7k))<1.15sqrt(k), sup b exp(-b/(7k))<(21/8)k. The factor norm is <1/2 since a beta/(2pi)<1/2. Use the earlier differentiated log bound with sqrt(1+s/(3sqrt(k)))<2.7 (s<6pi sqrt(k)), to obtain log derivative factor <8.4 and thus ||F_y-F_0||_R/||F_0||_R<10|y|/sqrt(k). The scalar P relative increment is <.7|y|/sqrt(k), as its log coefficient is bounded by 1/9+(1/9+.41)exp(1/18)<.67. The exact prefix difference then gives relative primary error <=(.7+.34*10)/.66*pi/sqrt(k)<.22.

For far l>=1 use the original r=1+1/(4k) and strip atom, U_i as above. The atom costs <.12beta since the weighted exponent n-k>=8n/9 lattice minus its primary pairs has total <.2. For U_i the far exponent-n two-half weight is <.08 and shifted sqrt(B)Q_1<2.5; hence actual far mixed <(.12+1.4*.08)*beta+3*1.4*2.5/sqrt(k)<.166. Ref subtraction <.027 because c_N in [.66*.90,1.34*1.24] yields |c_N-1|<.675 and upper-half exponent-n farther weight <.04. Diagonal <.012 since B>=16. Thus total normalized error in both units <.04+.22+.205/.59<.7.

## High s, beta<=1/2
Here s>=6pi sqrt(k) implies B>39. Keep r=1+1/(4k) for all purposes in this band. Use fast prefix kappa<5.4exp(-B/8.2)<.047 from D_r<2.7/k. For all |y|<=3pi, r*|s+i*y|/s<1+.38/k, because log ratios are at most 1/4+1/8 and sufficient strict gap to log(1+.38/k). Hence D_t<3.3/k, all factor norms <1/2, log ||F_y||_r<=1.65beta+(3.3)^2 beta^2/12. Since P0>=exp(-.501beta)>.77, kappa||F_y||_r/P0<.175 uniformly including y=0. Hence c_N/P0>.825 and c_N>.63. For each near F_y-F_0 use scalar evaluation and both absolute prefix errors rather than a weighted derivative. The scalar relative increment is <.63|y|/sqrt(k) since log factor is <=1/18+(1/18+.41)exp(1/8)<.59. Thus near relative error after dividing by c_N is bounded by
    [.63*pi*1.12/sqrt(k)+.35*1.04]/.825 <.48,
using upper-half w_1 |q_1|^n<=.04 and upper-half full weight <1.04.

For the actual far l>=2 raw product, use r*rho/s<1+4/(15k) since s>=6pi sqrt(k). Thus D_t<2.8/k, full log cap <=1.4beta+.67beta^2 as before, giving ||B_i||_r<1.4 and <2.8beta at beta<=.5. The original r shifted sqrt(B)Q_1<.04 at B>=39 and exponent-n two-half tail <1/2500 yield actual far mixed error <.005. Reference subtraction <.001 since |c_N-1|<=1.175 exp(1.001*.5)+1<3 and exponent-n upper-half farther tail at l>=2 is <1/5000. Diagonal <.008. Total <.04+.48+.014/.63<.7.

## High s, beta>=1/2: finite exceptional factors and four coherent levels
Change to r'=1+1/(16k) and lambda'=17. Fast prefix kappa'<4.2exp(-B/34) by D_(r')<2.1/k. Here B>=k beta^2/9, so s/sqrt(k)>45 and |y|<=7pi gives log(|s+i*y|/s)<.12/k. For .5<=beta<=1, take t=1+1/(5k), since log(r' times ratio)<(.0625+.12)/k, giving D_t<2.5/k. The product log cap is 1.25beta+(2.5)^2 beta^2/12 <=2.6beta+.41beta^2 (uses beta<=1), with factor norms <1/2.

For beta>=1, s/sqrt(k)>90, the log ratio is <.03/k. Hence r' times that ratio <1+1/(10k) and D_t<2.2/k. Some factor norms may exceed one. Use the following direct norm argument instead of taking their logs. If f factors are bounded by M/|h|, M<=1.2, separate h=+1,-1. The remaining factors have norm <=.6, where the log remainder is bounded by the square (verified finite log series plus tail). The two separated factors contribute at most (1+M)^2<=exp(2M). The signed sum of the remaining factors is bounded in norm by ||S_y||+2M. Therefore the full product has norm at most exp(||S_y||+4M+sum ||f_h||^2), without using logs of the exceptional factors. With a=2.2 use M<=a beta/(2pi), signed term a beta/2 and square sum a^2 beta^2/12. Since beta<3.2, M<1.2. This gives ||F_y||_(r')<=exp(2.6beta+.41beta^2) for the entire beta>=.5 range. It applies also at y=0.

Consequently kappa'||F_y||_(r')/P0 <=4.2 exp(3.101beta+(.41-k/306)beta^2)<.03, by beta>=.5 and the derivative of that exponent (negative there); evaluate .5 at k=8192. Hence c_N>=.97P0>.19 since P0>=exp(-.501beta)>.20. The exact scalar ratio from SCALAR_REFERENCE_LARGE_K.md gives relative increment <.6|y|/sqrt(k) for |y|<=7pi since s/sqrt(k)>45 and e^(d y^2/(2s^2))<=e^.12. The upper-half angular sum on l<=3 is at most pi(1+3*.04+7/5000); the full weighted n sum is <=1.04. Using two prefix errors .03P0 each, relative near error is
    [ .6pi*(1+3*.04+7/5000)/sqrt(k) +.06*1.04 ]/.97 <.09.

For the actual far B_i, r'*rho/s<1+1/(12k) and D_t<2.1/k; apply the same split of h=+-1, bounding M<=2.1*1.01beta/(2pi)<1.2 (rho/s<1.01). Thus ||B_i||_(r')<exp(2.5beta+.4beta^2). In the full-n part this is <200000 multiplied by the two-half tail at l>=4 below 10^(-10), so <.001. In the shifted part use its dependence on beta: Q_1(B) is decreasing for B>=k beta^2/9>=8192/36. Therefore
    exp(2.5beta+.4beta^2) Q_1(B)
    <= [2+1.38(8192/9) beta^2] exp(2.5beta+(.4-8192/153)beta^2+1/17).
The log derivative is <=2/beta+2.5+2(.4-8192/153)beta<0 for beta>=.5, so evaluation at .5 gives <.003. Thus actual far <.004. Subtracting the positive common ref far tail adds <.001, since c_N<=1.03exp(1.001*3.2) and the exponent-n tail there is <10^(-10). Diagonal <.003 by sqrt(n)>90*15. Total normalized error is <.04+.09+.008/.19<.7.

The center comparisons meet the pairwise ellipse or symmetric .7 condition throughout. Applying the edge at T=3, monotone unshifted phase, parity, reciprocity and degree argument gives the theorem, with no lost transition pairs at the upper n threshold. check_cut_three_large_k.py replays the rational margins only.

