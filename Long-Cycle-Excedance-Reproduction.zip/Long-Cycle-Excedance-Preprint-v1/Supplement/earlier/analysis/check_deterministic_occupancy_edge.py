from fractions import Fraction as F
from math import factorial

assert 27**2-4*32*6 < 0
assert 1+F(3,4)+F(3,4)**2/2 > 2
assert F(1,256)+F(1,4097) < F(1,240)
assert F(1,11)**2 < F(1,120) < F(11,120)**2
assert F(27,4)*(F(1,240)+F(11,120)) < F(65,100)
assert F(27,4)*12/4097 < F(2,100)
assert F(16,240) < F(65,100) and F(16,4097) < F(2,100)
x=F(4096,2*17*18)
assert sum(x**j/factorial(j) for j in range(13)) > 500
q=F(1,500)
assert 8*(1/(1-q)**2-1) < 1
assert 8*((1+q)/(1-q)**3-1) < F(15,100)
print("PASS: deterministic occupancy and all-k edge constants")
