from fractions import Fraction as Q
from math import factorial
def low(x): return sum(x**m/factorial(m) for m in range(33))
def high(x): return low(x)+x**33/factorial(33)/(1-x/34)
assert 3**4<126 and 2*Q(22,7)+1<8
assert Q(2*64,62)<Q(21,10) and high(Q(21,10))<9
assert Q(9,4)+5<8
assert 145*63>=144*63+10 and 147*63>=145*63+72
assert 1000*Q(6,49)>64 and Q(1000*9,4*145)>Q(1,2)
assert 1024*1000<2**20 and Q(1000,3)-64>200
assert Q(2**20,2**3184)<Q(1,100)
assert Q(2,7)+Q(1,128)<Q(3,10)
assert Q(6,10*128)+Q(2*10,3*128)*Q(3,10)**3<Q(1,100)
assert high(Q(5,144))<Q(11,10)
assert Q(1,100)+Q(5,79)*Q(11,10)+Q(2,10000)<Q(1,8)
print('PASS: uniform O(k log^2 k) analytic tail margins')

