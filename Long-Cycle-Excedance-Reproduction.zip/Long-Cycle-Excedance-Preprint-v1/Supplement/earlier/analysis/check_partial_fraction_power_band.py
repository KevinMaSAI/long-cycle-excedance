"""Exact algebra diagnostics for the power band, not a replacement for its proof."""
from fractions import Fraction as F
from itertools import combinations
from math import prod

def rows(k, n):
    d=[F(1)]+[F(0)]*(k-1)
    delta=F(0)
    for b in range(k,n+1):
        d.append(((b-1)*d[-1]+d[b-k])/b)
        diff=d[b]-d[b-1]
        if b>=2*k:
            assert diff == -sum(d[j]-d[j-1] for j in range(b-k+1,b))/b
        assert F(1,2*k-1)<=d[b]<=F(1,k)
        delta+=abs(diff)
        assert delta<=F(4,k)
    return d

def homogeneous(q,n):
    if n<0: return F(0)
    h=[F(1)]+[F(0)]*n
    for v in q:
        for i in range(1,n+1):
            h[i]+=v*h[i-1]
    return h[n]

count=0
for m in range(2,8):
    for q in combinations([F(-1),F(-3,4),F(-2,3),F(-1,6),F(1,4),F(1,2),F(2,3),F(1)],m):
        u=F(5,12)
        den=[prod(1-w/v for j,w in enumerate(q) if i!=j) for i,v in enumerate(q)]
        for n in range(-1,8):
            h=homogeneous(q,n)
            assert h==sum(v**n/d for v,d in zip(q,den))
            assert homogeneous(q,n+1)-u*h==sum((v-u)*v**n/d for v,d in zip(q,den))
            count+=1

def multiply(x,y,n):
    z=[F(0)]*(n+1)
    for i,v in enumerate(x):
        for j,w in enumerate(y[:n-i+1]): z[i+j]+=v*w
    return z

def shifts(m,k,n):
    if not m:
        yield ()
    elif n>=m*k:
        for b in range(k,n-(m-1)*k+1):
            for tail in shifts(m-1,k,n-b): yield (b,)+tail

grouped=0
for k in range(2,10):
    nmax=4*k+2
    d=rows(k,nmax)
    for q in [(F(-1),F(1)),(F(-3,5),F(2,3),F(1))]:
        direct=[F(1)]
        for v in q:
            direct=multiply(direct,[F(0)]+[d[b]*v**b for b in range(1,nmax+1)],nmax)
        for n in range(k,nmax):
            u=F(1,5)
            by_parts=F(0)
            for bs in shifts(len(q),k,n+1):
                N=n-sum(bs)
                weight=prod((d[b]-d[b-1])*v**b for b,v in zip(bs,q))
                by_parts+=weight*sum(
                    (v-u)*v**N/prod(1-w/v for j,w in enumerate(q) if i!=j)
                    for i,v in enumerate(q))
            assert by_parts==direct[n+1]-u*direct[n]
            grouped+=1
coeffs=0
for k in range(2,33):
    rows(k,6*k)
    coeffs+=5*k+1
print(f"PASS: {count} partial fractions, {grouped} grouped centered differences, {coeffs} coefficient checks")
