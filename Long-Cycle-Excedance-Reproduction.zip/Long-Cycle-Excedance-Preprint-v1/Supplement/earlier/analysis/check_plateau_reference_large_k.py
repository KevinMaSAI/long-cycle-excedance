from fractions import Fraction as Q
from math import factorial
def lo(x):return sum(x**i/factorial(i) for i in range(65))
def hi(x):return lo(x)+x**65/factorial(65)/(1-x/66)
K=2048; J=45; pi=Q(22,7); p=Q(157,50); lam=Q(201,100)
def M(t):return t/(1-t),t/(1-t)**2,t*(1+t)/(1-t)**3
def odd(t): return [a-2**j*b for j,(a,b) in enumerate(zip(M(t),M(t*t)))]
assert J*J<K-1 and 900*12*Q(694,1000)<87**2 and Q(5,2)*87/J<Q(484,100)
assert lo(Q(K,312))>200*(1+Q(312,K))
assert Q(19,6)*Q(100,99)<Q(13,4) and 3*Q(100,99)<Q(13,4)
assert Q(13,4)*Q(100,99)<Q(33,10)
assert lo(Q(J*J,2)/(Q(2,5)*J+1)/(Q(2,5)*J+2))>14
assert lo(Q(K-1,12))>100
assert Q(33,10)*(Q(2,5)/J+Q(1,K)+Q(1,J))<Q(105,1000) and Q(33,10*K)<Q(2,1000)
eta=Q(1,14)
assert Q(13,4)*(2*M(eta)[0]+M(eta)[1])<1
o0,o1,o2=odd(eta)
assert Q(13,4)*(o1+Q(46,100)*o0)<Q(355,1000)
assert Q(13,4)*(Q(334,1000)*o2+Q(1217,1000)*o1+Q(645,1000)*o0)<Q(54,100)
o0,o1,o2=odd(Q(1,100))
assert Q(13,4)*(Q(501,1000)*o2+Q(2649,2000)*o1+Q(645,1000)*o0)<Q(54,100)
b=4*p*p/(Q(25,4)*K+10); a=K//2
f=lambda l,b=b,a=a:(2*l+1)/(1+b*l*(l+1))**a
I=lambda l,b=b,a=a:(1+b*l*(l+1))**(1-a)/(b*(a-1))
assert sum(f(l) for l in (1,2,3))+I(3)<Q(6,1000)
assert 2*(f(3)+I(3))<Q(1,10**14)
assert Q(251,100)**2>Q(25,4)+Q(10,K)
assert Q(3,2)*(Q(25,4)+Q(10,K))/(p*p*Q(K-3,K))<Q(96,100)
assert Q(K-1,K)/(16*(4+Q(1,K)))>Q(1,65)
def g(l,c):return (1+c*l*(l+1))**(-32)
def I32(l,c):return (1+c*l*(l+1))**(-31)/(31*c)
c=Q(1,65)
assert 2*(1+sum((2*l+1)*g(l,c) for l in (1,2,3))+I32(3,c))<Q(51,10)
assert Q(63,10)**2>(4+Q(1,K))*pi*pi
assert Q(37,20)*Q(63,10)*Q(255,100)/(2*p)<Q(475,100)
assert Q(475,100)/(1-Q(475,100*J))<Q(54,10)
assert (Q(2,1000)+Q(31,10)*Q(54,10)/J)**2+(Q(6,1000)+(Q(51,10)*Q(54,10)+4)/J)**2<1
assert 4*p*p/Q(25,4)>Q(63,10) and 9*p*p/Q(25,4)>Q(1419,100)
assert (Q(5,6)*p*p)/(16*(Q(25,4)+Q(10,K)))>Q(1,13)
assert 2*(1+3*g(1,Q(1,13))+5*g(2,Q(1,13))+I32(2,Q(1,13)))<Q(21,10)
assert Q(1,10)*Q(4,7)<Q(6,100) and Q(1,30)*Q(4,7)<Q(2,100)
assert hi(Q(1,8))/2<Q(4,7)
assert Q(7,10)-Q(694,1000)>0 and lo(Q(3,5)-Q(1,K))>Q(5,3)
assert 1+Q(694,1000)+1/Q(K)<Q(3,5)*(3-Q(1,K))
assert Q(406,1000)+(hi(Q(1,2))-1)/4<Q(4,7)
assert Q(4,7)*Q(245,100)<=Q(14,10)
assert Q(1,5)/lo(1/lam)<Q(122,1000)
assert Q(28,10)/lo(8/lam)<Q(53,1000)
for B,r in [(Q(63,10),Q(122,1000)),(8,Q(53,1000))]:
    assert 1/lo((B-1)/lam)<r and Q(1,6)/lo((B-2)/lam)<r
def T(a):
    z=hi(a)
    return z*(Q(1,2)+(z-1)/5)/(Q(594,1000)-(z-1)/4)
def D(a):return hi(a)+T(a)
assert D(Q(4,5))<Q(81,10) and D(Q(16,25))<Q(54,10) and T(Q(16,25))<Q(35,10)
assert Q(4,5)/(1+Q(4,5*K))-Q(5,8)>Q(1,6)
c=Q(1,82)
assert Q(K-1,K)*p*p/(16*(50+10/Q(K)))>c
assert 2*(1+g(1,c)+g(2,c)+g(3,c)+I32(3,c)/7)<Q(32,10)
assert Q(41,10)*Q(101,100)*Q(21,10)/(2*p)<Q(139,100)
assert Q(245,100)*Q(101,100)*Q(21,10)/(2*p)<Q(83,100)
assert Q(41,10)**2*Q(101,100)**2/12<Q(143,100)
assert Q(54,10)**2*Q(101,100)**2/12<Q(25,10)
for S,T0,b,lin,Mx in [(Q(139,100),Q(143,100),Q(158,1000),Q(83,100),Q(133,100)),
                       (Q(27,10),Q(25,10),Q(21,100),Q(175,100),Q(45,10))]:
    u=S+T0*b
    assert lin+b*(T0+u*u/2*hi(u*b))<Mx
assert Q(5,2)*Q(283,100)/J<Q(158,1000) and 3*pi/J<Q(21,100)
assert Q(1,6)+(Q(1,6)+Q(41,100))*hi(Q(1,8))<Q(83,100)
assert Q(83,100)/(1-Q(83,100)*pi/J)<Q(9,10)
def q(B,z):
    h=lo((Q(B)-1)/lam)
    return z*(2+Q(101,100)*z)/h,z*(2+Q(96,100)*B)/h
for B,z,u,v in [(Q(63,10),Q(251,100),Q(82,100),Q(145,100)),(8,Q(283,100),Q(43,100),Q(85,100))]:
    t,w=q(B,z); assert t<u and w<v
L=lambda a,b:a*b/2+a*a*b*b/12
for B,b,a,u,v,cap,Rref,c0,U,V,ev,ec in [
    (Q(63,10),Q(158,1000),Q(133,100),Q(82,100),Q(145,100),Q(122,1000),Q(19,100),Q(74,100),22,Q(44,100),Q(67,1000),Q(12,100)),
    (8,Q(21,100),Q(45,10),Q(43,100),Q(85,100),Q(53,1000),Q(97,1000),Q(81,100),23,Q(244,1000),Q(117,1000),Q(237,1000))]:
    assert cap*hi(Q(2551,1000)*b+Q(141,100)*b*b)<Rref
    assert (1-Rref)/hi(Q(501,1000)*b)>c0
    assert ((Q(9,10)+Rref*U)/(1-Rref))*pi/J<V
    assert (Q(2,100)+a*Q(4,1000))*b+Q(5,2)*a*u/J<ev
    assert (Q(6,100)+a*Q(12,1000))*b+Q(5,2)*a*v/J<ec
    assert ((1+Rref)*hi(Q(1001,1000)*b)-1)*Q(6,1000)<Q(3,1000)
    assert (Q(2,1000)+V+(ev+Q(1,1000))/c0)**2+(Q(6,1000)+V+(ec+Q(39,1000))/c0)**2<1
for b,rad,z,v in [(Q(158,1000),Q(184,100),Q(131,10),22),(Q(21,100),Q(204,100),Q(135,10),23)]:
    a=Q(81,10); m=Q(18225,1000)
    assert ((Q(867,100)+m/2)/2+(a*a*b/6+2*a*m*rad/3)/J)<z
    assert z*(1+z*pi/J/(2*(1-z*pi/(3*J))))<v
assert 4/(J*Q(251,100))<Q(36,1000) and Q(251,100)**2>Q(63,10)
assert 4/(J*Q(25,10))<Q(36,1000)
print("PASS: alternating edge and joint mid-band margins for k>=2048")

assert D(Q(57,100))<Q(47,10)
assert 9*p*p/Q(25,4)>Q(1419,100) and 6*pi/J<Q(42,100)
b=Q(42,100)
assert hi(Q(235,100)*b+Q(188,100)*b*b)<Q(375,100)
assert Q(49,10)/lo(Q(1419,100)/lam)<Q(43,10000)
assert 1/lo(Q(1319,100)/lam)<Q(43,10000)
assert hi(Q(501,1000)*b)<Q(100,81)
assert Q(43,10000)*Q(375,100)/Q(81,100)<Q(2,100)
assert Q(98,100)*Q(81,100)>Q(79,100)
assert Q(67,100)/(1-Q(67,100)*pi/J)<Q(71,100)
assert (Q(71,100)*pi/J+Q(4,100))/Q(98,100)<Q(92,1000)
assert (2+Q(96,100)*Q(1419,100))/lo(Q(1319,100)/lam)<Q(23,1000)
assert (hi(Q(235,100)*b+Q(188,100)*b*b)-1)*(Q(12,1000)+Q(23,1000))<Q(97,1000)
assert (Q(102,100)*hi(Q(1001,1000)*b)-1)*Q(6,1000)<Q(4,1000)
assert 4/(J*Q(376,100))<Q(24,1000)
assert Q(6,1000)+Q(92,1000)+Q(125,1000)/Q(79,100)<Q(7,10)

assert Q(54,10)/lo(Q(56)/Q(41,10))<Q(1,100000)
assert Q(59,100)/(1-Q(59,100)*3*pi/J)<Q(68,100)
assert (Q(68,100)*pi*Q(1018,1000)/J+Q(8,100000)*Q(1006,1000))/Q(9999,10000)<Q(5,100)
assert Q(745,100)**2<56
assert 4/(J*Q(745,100))<Q(12,1000)
assert Q(6,1000)+Q(5,100)+Q(14,1000)/Q(76,100)<Q(7,10)
# Strongly suppressed far lattice at exponent n, not the coarse Bernoulli-32 bound.
assert 2*(f(3)+I(3))<Q(1,10**14)
assert Q(25)*pi*pi/(2*Q(45,2)**2)<Q(245,1000) and Q(25)*pi*pi/(2*45**2)<Q(61,1000)
assert Q(1,16)+Q(245,1000)<Q(5,16)/(1+Q(5,16*K))
assert Q(1,16)+Q(61,1000)<Q(1,8)/(1+Q(1,8*K))
assert D(Q(5,16))<3 and D(Q(1,8))<Q(22,10)
assert Q(22,10)*Q(484,100)/(2*p)<Q(18,10)
assert Q(21,10)*Q(101,100)*Q(484,100)/(2*p)<Q(18,10)
assert Q(22,20)+6*Q(22,10)/(2*p)<Q(33,10)
assert Q(21,20)+6*Q(21,10)*Q(101,100)/(2*p)<Q(31,10)
assert Q(42,10)/lo((Q(K,1)/(Q(25,4)*17)-Q(75,100))/4-Q(2001,2000))<Q(112,1000)
assert Q(42,10)/lo(Q(K,1)/(Q(25,4)*17)-Q(41,100)-Q(3801,1000))<Q(1,1000)
assert Q(888,1000)/hi(Q(501,1000))>Q(53,100)
assert Q(999,1000)/hi(Q(501,1000)*Q(484,100))>Q(87,1000)
assert Q(2,45)+(Q(2,45)+Q(41,100))*hi(Q(245,1000))<Q(63,100)
assert Q(63,100)/(1-Q(63,100)*5*pi/J)<Q(81,100)
assert (Q(81,100)*pi*Q(103,100)/J+Q(224,1000)*Q(1006,1000))/Q(888,1000)<Q(32,100)
assert Q(1,45)+(Q(1,45)+Q(41,100))*hi(Q(61,1000))<Q(49,100)
assert Q(49,100)/(1-Q(49,100)*5*pi/J)<Q(6,10)
assert (Q(6,10)*pi*Q(103,100)/J+Q(2,1000)*Q(1006,1000))/Q(999,1000)<Q(46,1000)
assert hi(Q(207,100))-1<7 and 7*(Q(1,10**14)+(2+Q(96,100)*81)/lo(80/Q(41,10)))<Q(1,1000)
assert hi(Q(31,10)*Q(484,100)+Q(4,10)*Q(484,100)**2)*Q(1,10**14)<Q(1,1000)
assert (2+Q(96,100)*Q(4*K,25))/lo((Q(4*K,25)-1)/17-Q(35,10))<Q(1,1000)
assert 4/(J*9)<Q(1,100) and 4/(J*18)<Q(5,1000)
assert Q(6,1000)+Q(32,100)+Q(12,1000)/Q(53,100)<Q(7,10)
assert Q(6,1000)+Q(46,1000)+Q(8,1000)/Q(87,1000)<Q(7,10)
print("PASS: split-series prefix and all-row bounds for k>=2^11")

