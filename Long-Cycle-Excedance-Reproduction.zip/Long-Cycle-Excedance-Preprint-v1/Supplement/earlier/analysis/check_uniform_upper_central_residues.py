from fractions import Fraction as Q
from math import factorial
def low(x): return sum(x**i/factorial(i) for i in range(33))
def up(x): return low(x)+(x**33/factorial(33))/(1-x/34)
assert Q(79,10)**2<63 and Q(12,5)**2<6
assert up(Q(5,16))<Q(7,5)
assert Q(44,7)*(Q(7,79)+Q(1,10000))<Q(9,16)
assert 1+Q(1,126)+Q(10,288)*Q(64,63)**2<Q(21,20)
assert up(Q(21,20))<Q(29,10)
assert Q(44,7)*(Q(5,79)*Q(29,10)+Q(1,10000))<Q(6,5)
assert Q(2,63)+Q(1,63**2)<Q(1,30)
assert Q(30,31)*2*Q(157,50)**2/(Q(49,4)+Q(10,128))>Q(3,2)
assert Q(7,5)/low(Q(39,5))<Q(1,10)
assert 3/low(Q(39,16))+Q(50,9)/low(Q(33,5))<Q(11,40)
print('PASS: uniform actual farther-residue bound, k>=64, s>=12 sqrt(k-1)')

