from fractions import Fraction as Q
from math import factorial
x=Q(64,31)
assert sum(x**j/factorial(j) for j in range(33))+x**33/factorial(33)/(1-x/34)<8
assert Q(32,31)**2<2 and 16*Q(22,7)<51
assert Q(900)*Q(6,49)>102 and Q(900*9,4*145)>Q(1,2)
assert 1024*900<2**20 and Q(900,3)-102-3==195
assert Q(2**20,2**(195*4))<Q(1,100)
assert 900*63*4>16385
print('PASS: stronger uniform O(k log k) analytic tail margins')

