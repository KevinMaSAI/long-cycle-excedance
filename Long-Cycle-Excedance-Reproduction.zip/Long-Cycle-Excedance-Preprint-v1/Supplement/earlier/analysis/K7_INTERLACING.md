# Minimum cycle length seven: analytic cutoff 256

The analytic argument gives simple real zeros and strict adjacent quotient interlacing for k=7 and every n≥256. For 7≤n≤255 use the exact dyadic replay check_k7_dyadic.py, with completion recorded separately. The sign argument follows EVENTUAL_ALL_FIXED_K.md and K6_INTERLACING.md; all replacement hypotheses are verified below.

## Coefficients and contour

Use q=e^(−s), w=q/(1+q)², x0=(1−q)/(1+q). Then w'=−w x0, x0'=2w. By the logistic series in QUADRATIC_HIGH_RANGE.md, g_(m+1)=−g_m'/(m+1) for s>0. In particular g_5=w x0(1−12w)/120 and
    g_6=w(1−30w+120w²)/720.
Indeed differentiating the g_5 product and using x0²=1−4w gives the displayed polynomial. Rational continuity gives the same formula at zero. The quadratic on 0≤w≤1/4 takes value 1 at both ends and minimum −7/8, so |g_6|≤w/720≤q/720, also |g_6|≤1/2880. Thus all m=2..6 have |g_m|≤q/m! by the preceding k=5,6 proofs. For q<1/40 the g_m are all positive: g_6's quadratic is ≥1−30w>0, and the earlier coefficient signs also hold.

Set ρ=|s+π i|. Choose R∈[3ρ/2,5ρ/3] at distance >1/4 from the moduli of the poles. This interval has length ρ/6>1/2. The pole moduli within 1/4 of it are ≥3ρ/2−1/4>7ρ/5. For radii at least 7ρ/5 the derivative in positive imaginary coordinate of sqrt(s²+y²) is at least sqrt(1−25/49)>2/3, since s≤ρ. Thus the relevant distinct moduli are separated by >4, and their excluded intervals of width 1/2 cannot cover the admissible interval. The primary pair lies inside. The denominator comparison of K5_INTERLACING.md gives |H|/|Res_p H|≤32 exp(U), where
    U=∑_(m=2)^6 [(5/3)^m+1] |g_m|ρ^m.
For 0≤s≤1 use the uniform individual bounds from K6_INTERLACING.md and |g_6|≤1/2880 with ρ²≤11 and ρ≤10/3, giving U<71. For s≥1 the bound formed with q/m! is decreasing, since exp(−s)ρ^m has log derivative −1+ms/(s²+π²)<0 for m≤6. At s=1,3,8,16 use upper bounds for (ρ²,ρ,q) respectively (11,10/3,3/8), (19,9/2,1/20), (74,9,(3/8)^8), (266,17,(3/8)^16). These give U<71,33,9,1/8 respectively. The accompanying rational script replays all comparisons.

The circle errors in units B and Bv are ≤16ρ exp(U)(2/3)^n times at most max(1,(5/3)ρ/π), since |1/z−u|≤1/R+u. For s≤3 this is < 170(11/4)^71(2/3)^256<1/100. For 3≤s≤3√n use ρ≤4√n and bound by 144 n(11/4)^33(2/3)^n<1/100, checking at 256 and then monotonic decrease.

There are no farther poles inside R for s≤3. For 3≤s≤8 reserve n/4 of the radial exponent (n+1)/2. Its factor beats exp(U): log(1+8π²/ρ²)≥36/55 as in K6_INTERLACING.md and 64·36/55>33. For 8≤s≤16 the same reservation works using log(1+8π²/ρ²)≥72/338 and 64·72/338>9. In both subranges the remaining radial power gives the Bernoulli fourth-power bound with c=nπ²/(4ρ²)>1/2. Hence the weighted farther sum is <1/4, as in POLYNOMIAL_UNIFORM_BOUND.md. When s≥16 and s≤3√n the same <1/4 sum bound applies with the full radial exponent, c=(n+1)π²/(2ρ²)>1/2, and the numerator penalty is at most exp(1/8)≤8/7. Since (8/7)/4+1/100<1/3, both normalized central inequalities of EVENTUAL_ALL_FIXED_K.md hold. The multiplier 2l+1 for the centered comparison is included in all farther sums.

## Edge and phase

Put x=√n≥16, M=ceil(x/3), S=n/M. Then S≥(48/19)x>40. As in K6_INTERLACING.md, positivity at s≥S gives the moment conditions for l≥1 once q∑_(m=1)^6 n^m/m!≤qn^6/600<1/200. The ratio error uses the smaller sum with powers m−1. Use decreasing x^12 exp(−48x/19)/600 and bound it at x=16 by 16^12(3/8)^40/600.

For the zero edge term the same multinomial argument gives, j=n,n+1,
    T_j(0)≤[q^(1/6)(1+√j+j^(2/3)+j^(3/4)+j^(4/5)+j^(5/6))]^j.
Writing the expression after q^(1/6) as F(j), log F(j)≤(73/200)x: use j≤x²+1, then bound F(257)<311<exp(146/25) at x=16, and log slope at most (5/3)x/(x²+1)<73/200 thereafter. For x∈[16,18] one has M=6, so
    s(j/6−m)/(nx) ≥ (x/36−1/x) ≥ 16/36−1/16,
at any m≤M, since s≥S and j/6−m>0. For x>18 use M≤x(1/3+1/18), so the lower bound is at least 3/7−1/18. Both numbers exceed (73/200)(257/256)+1/200. This gives T_j(0)/V_m≤exp(−nx/200) with V_m=q^m m^n, and (M+2)exp(−nx/200)≤n exp(−n sqrt(n)/200)<1/100 (check at 256 and monotonic decrease). This verifies the separate zero moment condition. The edge signs therefore follow by the existing one- and two-dominant-term argument.

At S the perturbation to the usual normalized phase, after the constant limiting shift, is ≤q[1+∑_(m=2)^6 ρ^m/(π m!)]<1/100 by decrease and the bounds at 40. The usual arctan estimate and parity endpoint apply as in K6_INTERLACING.md. The same first-hit/last-hit reasoning completes all n≥256, with row 256 shared by the finite check.
