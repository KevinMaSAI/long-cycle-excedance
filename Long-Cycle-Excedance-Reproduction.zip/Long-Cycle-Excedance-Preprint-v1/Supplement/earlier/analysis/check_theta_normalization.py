"""Exact truncated-nome check: Jacobi normalization used in the bounded-ratio proof."""
from collections import defaultdict
degree=48
def mul(a,b):
    c=defaultdict(int)
    for (q,x),v in a.items():
        for (j,y),w in b.items():
            if q+j<=degree:
                c[q+j,x+y]+=v*w
    return {key:value for key,value in c.items() if value}
rhs={(0,1):1}
for m in range(1,degree//2+1):
    rhs=mul(rhs,{(0,0):1,(2*m,0):-1})
    rhs=mul(rhs,{(0,0):1,(2*m,0):-2,(2*m,2):4,(4*m,0):1})
def T(j):
    if j==0: return [1]
    a,b=[1],[0,1]
    for k in range(1,j):
        c=[0]+[2*v for v in b]
        for i,v in enumerate(a): c[i]-=v
        a,b=b,c
    return b
lhs={}
l=0
while l*(l+1)<=degree:
    for i,v in enumerate(T(2*l+1)):
        if v: lhs[l*(l+1),i]=v
    l+=1
assert lhs==rhs
print("PASS: exact theta2 normalization through nome degree",degree)

