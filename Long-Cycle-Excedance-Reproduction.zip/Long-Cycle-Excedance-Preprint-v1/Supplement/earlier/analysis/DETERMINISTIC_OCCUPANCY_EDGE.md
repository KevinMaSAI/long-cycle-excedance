# A deterministic occupancy lower bound and an edge lemma for every k

## Statement
For all integers n>=k>=3 and r>=1, let A_n(r)=r times the probability that every cycle of a uniform permutation of r labels receives at least k hits in n independent uniform label draws. Then
    max(1,(8/27) min(r,n/k)) <= A_n(r) <= min(r,n/k).
Moreover for every n>=max(k,4097), put D=n-1, M=ceil(sqrt(D)/4). At t=-exp(-D/m), 1<=m<=M, E_(n,k) has sign (-1)^m. At *any* zero t=-exp(-s) with D/(m+1)<s<D/m, 1<=m<M, E_(n+1,k)(t) has sign (-1)^(m+1). This includes all k>=3 and does not use a sweep. It does not settle the central interval or the full conjecture.

## A deterministic lemma
Take arbitrary integer label weights w_i>=0, total W>=k, maximum L>=1, over r labels. Let A be r times the probability of every cycle having weight at least k. Then A>=W/(2k+L-2). Prove the stronger induction with any fixed cap L across all subinstances. For a random order v_1,...,v_r, put X_j=sum_{i<=j} w_(v_i) and A(S)=|S| times the corresponding probability on a label subset S. The length of the cycle of a uniform distinguished label is uniform on 1,...,r; given length j the subset is the first j labels of the random order, and the complementary permutation is uniform. The full cycle contributes 1. Using induction on the complement gives
    A >= 1 + sum_(j=1)^(r-1) E[1_(k<=X_j<=W-k) (W-X_j)/(r-j)]/(2k+L-2).
Given the first j labels, the displayed average weight of the remaining labels equals E[w_(v_(j+1)) | first j labels]. For any realized order, the sum of these next weights over legal cuts j is at least W-(2k+L-2). If this lower bound is nonpositive there is nothing to check. Otherwise the first index l crossing k satisfies X_l<=k+L-1<=W-k, so the legal cuts are nonempty. The last legal cut u is followed by X_(u+1)>=W-k+1, including the possibility u=r-1. The next weights telescope to X_(u+1)-X_l >= W-2k-L+2. This proves the induction, including r=1 (W<=L). For W<k the probability can simply be bounded below by zero.

One can replace every weight by min(w_i,k) without changing the event. If the original W>=k the truncated total is still >=k. With cap L=k, for the occupancy model this yields
    A_n(r) >= r E[min(Bin(n,1/r),k)]/(3k-2).
For g(p)=E[min(Bin(n,p),k)], the second derivative of the Bernstein polynomial is n(n-1) times the Bernstein average of the second differences of the discrete truncation, so g is concave. It is nondecreasing by binomial coupling, and g(0)=0. Thus g(p)>=g(k/n) min(1,np/k). At p=k/n, using mean k and variance <=k,
    g(k/n)=k-E|Bin(n,k/n)-k|/2>=k-sqrt(k)/2.
Set x=1/sqrt(k). Then (3-2x^2)/(1-x/2)<27/8 because 32x^2-27x+6>0 (negative discriminant). The upper bound is the weighted occupancy upper bound in GROWING_RATIO_LOG_BAND.md; the full cycle gives A_n(r)>=1.

There is also a different bound in the high mean regime. For given weights let h be the number of labels of weight >=k. If every cycle meets those labels, every cycle passes. For h>=1 the probability of no cycle disjoint from these labels is h/r: form a permutation on the h labels, then insert the remaining labels in any fixed order, choosing an insertion position or a new singleton uniformly at each step. The choice set at size i is of cardinality i and exactly one choice starts a new cycle. Uniformity follows by deletion/insertion, and no new cycle is equivalent to all final cycles meeting a heavy label. The product over i=h+1,...,r telescopes. For h=0 the lower bound is zero. Averaging gives A_n(r)/r >= Pr(Bin(n,1/r)>=k).

## Edge proof
Use the exact alternating series E_(n,k)(-exp(-s))/(1+exp(-s))^n = sum_(r>=1) (-1)^r V_r A_n(r), with V_r=exp(-rs)r^(n-1) as in OCCUPANCY_ALTERNATING_SERIES.md. Put mu=n/(kr) and D_r=r[A_(n+1)(r)-A_n(r)]/A_n(r). The marked deficient-cycle identity and lattice bound from GROWING_RATIO_LOG_BAND.md give
    D_r <= (27/4)(r/n+1/sqrt(k))  when mu<=2,
since n/(k A_n(r))<= (27/8) max(1,mu). This also covers zero differences for n<2k-1. When mu>2, writing u=n/(8r)>k/4>=3/4, Chernoff and the heavy-label bound give A_n(r)/r>=1-exp(-u). The marked-cycle sum with b bounded by 1 and each binomial mass bounded by exp(-uj) is at most 1/(exp(u)-1). Hence
    D_r <= 1/[(1-exp(-u))(exp(u)-1)] < 16r/n.
Here exp(3/4)>2 and exp(u)-1>=u. Both arguments preserve D_r>=0.

Whenever r is a main witness or bracket index or is a distance a>=0 from one, r/n<=1/240+a/n, because M<=sqrt(D)/4+1 and sqrt(D)>=64. In the mu<=2 case, 1/sqrt(k)<=sqrt(2r/n). The tangent line for the square root at 1/120 gives
    sqrt(2r/n)<=sqrt(1/120)+a/(n sqrt(1/120)) < 11/120 + 11a/n
(the final strict inequality holds also at a=0). Thus in both cases D_r<.65+.02a, using n>=4097.

At a witness s=D/m or outside the two bracketing indices m,m+1 for D/(m+1)<=s<=D/m, successive ratios of V_r in each outward direction are at most eta=1/500. Indeed log(1+1/j)-1/j <= -1/[2j(j+1)] by integration, and -log(1-1/j)-1/j >= 1/(2j^2). At the first right step from a main index j, s>=D/j; at the first left step s<=D/j. These inequalities give exponent at least D/[2M(M+1)] in absolute value and the outward steps only improve by log concavity of r^D. Since sqrt(D)>=64 this exponent is at least 4096/(2*17*18), whose exponential exceeds 500. For an outward step of distance a, the amplitude ratio A_n(r)/A_n(i)<= (27/8)(1+a)<4(1+a) by the two-sided comparison. The two witness tails are bounded relatively by 8 sum_(a>=1)(a+1) eta^a < 1.

At a zero in a bracket subtract m+4/5 times the old normalized row from the next normalized row. The summands are (-1)^r V_r A_n(r)(r-m-4/5+D_r). The two main terms have the same sign (-1)^(m+1), with relative margin at least .15 for each. On an outward tail at distance a its multiplier is bounded in absolute value by 2(a+1). In units of the sum of the two main V_r A_n(r), the two tails therefore cost at most 8 sum_(a>=1)(a+1)^2 eta^a < .15. This proves the claim. The rational constants are independently replayed in check_deterministic_occupancy_edge.py.

## Scope
This removes the lower bound k>=64 from the earlier edge result and lowers its sufficient first row from 16385 to 4097 (with eta=1/500 here). It controls the signs in the outer negative-root brackets, not the central signs, global degree count, or the unresolved all-row interval below k=1024. The sign-transfer proof does not assume monotonicity of A_n(r) in r.
