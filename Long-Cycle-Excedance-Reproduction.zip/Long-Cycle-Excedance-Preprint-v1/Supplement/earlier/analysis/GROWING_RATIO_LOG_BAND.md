# Growing-ratio band for long-cycle excedance polynomials

**Theorem.** There are effective absolute constants c>0 and k0 such that for every k≥k0, all rows k≤n≤c k(log k)^(2/3) have simple real roots, and consecutive quotients E_(n,k)/t strictly interlace when both rows lie in this range. The logarithm is natural. This is not the full conjecture.

We reuse the exact normalized pole and occupancy formulas of ALL_BOUNDED_RATIO_THETA.md and its classical theta comparison and root-count argument, with the following replacements. Notation: A_n(R)=R b_(n,k)(R), where b is the probability every cycle of a uniform permutation on R labels has at least k hits after n iid uniform label draws.

## 1. Uniform occupancy estimates

**Weighted upper bound.** For arbitrary nonnegative label weights of total W, the probability p that every cycle has weight at least k satisfies Rp≤W/k. For W<k this is trivial; otherwise induct on R, with R=1 immediate. The size of the cycle containing a fixed label is uniform, and using a uniformly chosen label instead gives a uniform complement S conditional on its size. The complement permutation is uniform. The full cycle contributes 1 to Rp; induction bounds the rest by 1/k times the sum over nonempty proper S of
    w(S) 1_(k≤w(S)≤W−k) / (|S| binom(R,|S|)).
Use the beta integral for the reciprocal denominator, ∫₀¹ u^(|S|−1)(1−u)^(R−|S|)du, and expand w(S) over labels i∈S. Let Z_u be the weight of a Bernoulli(u) subset, and f(x)=min(x,W−k). Differentiating the finite expectation of f gives the sum over i of E[f(Z_(-i,u)+w_i)−f(Z_(-i,u))]. Each difference is nonnegative and equals w_i when Z_(-i,u)+w_i≤W−k. This bounds the integrand and integration gives W−k, proving the upper bound.

**Two-sided comparison.** For H=n/k≥1 and k≥3,
    1≤A_n(R)≤min(R,H),   A_n(R)≥min(R,H)/20.
The one-cycle contribution gives the first lower bound and the weighted upper bound applies conditionally on the realized label occupancies. For H<4 the stronger lower bound follows from A_n≥1. For H≥4 let h=ceil(4R/H)≤R. Write p_j for the probability a uniform permutation on j labels has no cycles shorter than h; p_0=1 and p_j=0 for 0<j<h. The recurrence j p_j=∑_(a=0)^(j−h)p_a yields p_j≥1/(2h−1) for j≥h: for j≤2h−1 use p_0, and thereafter use 1+(j−2h+1)/(2h−1). The weighted upper bound also gives p_j≤1/h for j>0. Conditional on all cycle lengths being at least h, the expected number of cycles of length j<R is p_(R−j)/(j p_R)≤2/j, by marking a j-cycle. A full cycle cannot fail. For any remaining j≥h, the mean hit count μ=nj/R≥4k, so by the binomial lower-tail Chernoff bound the failure probability is at most e^(−μ/4), using (1−k/μ)^2/2≥9/32. With λ=n/(4R), the conditional expected number of failures is at most
    2∑_(j≥h) e^(−λj)/j ≤ 2e^(−k)(1/h+1/(λh)) ≤ 2e^(−k)(1+1/k)<1/2.
Here λh≥k and 1/(1−e^(−λ))≤1+1/λ. Thus A_n(R)≥R/[2(2h−1)]≥R/(4h)≥min(R,H)/20.

**Relative first difference.** For k≥3,
    0≤R(A_(n+1)(R)−A_n(R))≤40(R/n+1/√k) A_n(R).
For n<2k−1 the difference is zero. Otherwise mark the unique previously deficient cycle, with k−1 hits, into which the new hit lands. The expected number 1/j of j-cycles times hit probability j/R cancels the normalization factor R in A. The full cycle does not contribute since n≥k. The remaining draws conditional on the hit count of the marked cycle are uniform on its complement. We obtain
    ΔA = ∑_(j=1)^(R−1) Pr(Bin(n,j/R)=k−1) b_(n−k+1,k)(R−j).
If H/R≤2, the weighted upper bound and Pr(Bin(n,p)=k−1)/(1−p)=n Pr(Bin(n−1,p)=k−1)/(n−k+1) give
    ΔA≤ (n/(kR))∑_(j=1)^(R−1) Pr(Bin(n−1,j/R)=k−1).
This lattice sum is at most R/n+1/√k. The integral is 1/n by the beta integral, and the excess of the sum over R times the integral is at most the peak, by measuring each superlevel interval and counting its lattice points. For a=k−1, b=n−k≥a and D=a+b, Stirling's bounds give a peak at most e^(1/(12D))√(D/(2πab))≤1/√k for k≥3, using D/(ab)≤2/a and k exp(1/(12a))/(π a)<1. Consequently RΔA≤H(R/n+1/√k); dividing by A_n(R)≥min(R,H)/20 gives the relative bound since H/R≤2. If H/R>2, bound the b factor by 1 and each binomial mass by e^(−nj/(8R)), using n j/R>2k. Then A_n(R)≥R/20 gives RΔA/A_n(R)≤20/(e^(k/4)−1)≤40/√k (use e^(k/4)−1≥k/4 and k≥4, and e^(3/4)−1≥3/4+(3/4)^2/2 when k=3). Thus the relative estimate holds even when n/R is arbitrarily large. We do not need an absolute bound RΔA uniform in n/R.

## 2. Edge with a fixed cutoff

Set T=8, η=1/1000, D=n−1, M=ceil(√D/T), S=D/M. When √D≥2T the outward successive ratios of V_r=e^(−sr)r^D from witness m at s=D/m and from the pair m,m+1 on D/(m+1)≤s≤D/m are ≤e^(−T²/8)<η, via the ratio calculation in ALL_BOUNDED_RATIO_THETA.md. At distance a≥1 outward from i=m or m+1, A_n(r)/A_n(i)≤20 max(1,r/i)≤20(1+a). The witness tails relative to the main term are ≤40∑_(a≥1)(1+a)η^a<1, so the signs are (−1)^m.

At a zero in a pair bracket subtract (m+1/2)(n−1)!P_n from n!P_(n+1) in the occupancy normalization. The two main terms from (r−m−1/2)A_n(r) have the same sign (−1)^(m+1), of combined magnitude (V_m A_n(m)+V_(m+1) A_n(m+1))/2. In units of that sum without 1/2, opposing tails are bounded by 20∑_(a≥1)(1+a)(a+1/2)η^a<1/10. For the difference term rΔA, at each of the two main indices r≤M≤√n, the relative bound is ≤80/√k; at distance a outward from either it is ≤80/√k+40a/k, since r≤√n+a and n≥k. In the same units the absolute contribution is therefore bounded by 80/√k + 20∑_(a≥1)(1+a)(80/√k+40a/k)η^a<1/10 for k≥10^8. The next row therefore has sign (−1)^(m+1) at any such root. This edge argument needs no upper bound on n/k.

## 3. Central Abel bound without pole truncation

Put L=(n+1)/k. Use p,ρ,z_p,u,v and B_(n,m) from ALL_BOUNDED_RATIO_THETA.md in 0≤s≤8√n. For each pole at conjugate level l≥0 let d_p=2l+1 and b_l=(1+4l(l+1)/(74L))^(−4). Then |z_p|^a≤b_l for a≥k≥8 and |(1/p−u)/v|≤d_p, as in that proof. Define U=∑_p b_l and V=∑_p d_p² b_l. These satisfy U≤C√L and V≤C L^(3/2) with C=10^5, for example: with J=ceil(√(74L/4))≤6√L, use b_l≤1 up to J and b_l≤(J/l)^8 above J, then bound the sums of l^(−8) and l^(−6) over l>J by the integrals from J, using d_p≤3l for l≥1.

For every mixed tuple use fixed-length-pair Abel summation, traversing the interval with geometric ratio of modulus ≤1. Preserve the initial normalized product in the bound: it is ≤∏ b_l, one factor for each coordinate of the tuple. The geometric partial sums are bounded by 2 max(|p|,|p′|)/|p−p′|≤(ρ/π) max_i d_(p_i), since distinct poles are separated by at least 2π and |p_i|≤ρ d_(p_i). The terminal weight plus total variation of the length weight is ≤3/k^(m−1), before the 1/(m−1)! prefactor, by the monotone or decreasing-then-increasing weight calculation in the bounded-ratio proof. In the normalized adjacent difference the extra factor (1/p_m−u)/v is independent of lengths and costs at most d_(p_m). Either max_i d_(p_i), or that maximum times d_(p_m), is at most ∑_i d_(p_i)², whose weighted sum over all tuples is m V U^(m−1). There are at most (Lk)^(m−2) choices of other lengths. The total mixed errors for value and difference, in the respective units ρ^(−n) and vρ^(−n), are therefore each bounded by
    (3ρ/(π k)) ∑_(m≥2) L^(m−2) m V U^(m−1)/(m−1)! ≤ (6ρ V U/(π k)) exp(L U).
The all-identical pole contributions retain the same common positive scalar A_n^*≥1 multiplying S_n and S_(n+1)−uS_n. The boundary a_m=k in the difference costs at most (ρ/(πk))∑_(m≥2) L^(m−2) U^m/(m−1)! ≤ (ρ U²/(πk))exp(L U), by the boundary count in the bounded-ratio proof. Thus both total errors are ≤C′ L^(5/2) exp(C L^(3/2))/√k with an absolute effective C′, since ρ≤√(74Lk).

## 4. Conclusion and limitations

Choose c=(4C)^(−2/3). For L≤c(log k)^(2/3) the last error tends to zero uniformly, bounded by C′ c^(5/2)(log k)^(5/3)k^(−1/4). The theta comparison and positive product margin from Section 3 of ALL_BOUNDED_RATIO_THETA.md now use T=8 independently of k,n; bound the tails of S_n and its difference by the same pole majorant with exponent n and L=1. The errors tend to zero uniformly as n→∞. The sign and root-count argument of Section 4 of that proof applies: the stitch offset is o(1) since M=O(√n); the edge and central signs alternate, reflection gives the opposite half, and the signs of the next row at the roots give strict quotient interlacing. For the final row use its strict interlacing with the previous row, whose pair still has L=(n+1)/k in range. Choose k0 large enough to make c(log k)^(2/3)≥2, so the claimed band contains at least one pair. All thresholds are effective by the explicit bounds above and fixed-theta error algorithm; no practical numerical threshold or outside audit is asserted.

This narrows the unsolved range for asymptotically large k, but does not meet the high-n cutoff from POLYNOMIAL_UNIFORM_BOUND.md. The full conjecture remains unresolved.
