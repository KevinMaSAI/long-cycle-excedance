# Uniform upper-central signs including the circular integral

Let k>=64, d=k-1 and n>=144 d log(2d), with log natural. On 12sqrt(d)<=s<=(7/2)sqrt(n) the two normalized sign inequalities (A) of EVENTUAL_ALL_FIXED_K.md hold for the actual restricted polynomial, with the exact phase. This closes the circular-integral job for UNIFORM_UPPER_CENTRAL_RESIDUES.md. It does not cover s<12sqrt(d) or the small n regimes.

Put rho=|s+i pi| and delta=1/(8d). Choose R in [rho(1+1/(2d)),rho(1+1/d)] more than delta from the pole moduli. To justify the choice, any relevant pole modulus is >=rho(1+1/(2d))-delta>=rho(1+1/(3d)). Hence the derivative of sqrt(s^2+y^2) for increasing y at these moduli is at least 1/(2sqrt(d)): use s<=rho and 1-(1+u)^(-2)>=u for 0<=u<=1/3. The moduli there are consequently separated by at least pi/sqrt(d), and the disjoint exclusions of length 2 delta cannot cover the candidate interval of length rho/(2d)>2 delta. The primary residues are enclosed.

At z=x+iy on the circle, put W=exp(s-x); the denominator modulus divided by q(1+W) is |1+W exp(-iy)|/(1+W). If |s-x|>=delta/2 this is at least tanh(delta/4)>=delta/8 by the reverse triangle inequality. Otherwise the distance of y from a nearest odd multiple y0 of pi is at least delta/2, by the radius exclusion. It is at most pi by nearest choice. Use |1+W exp(-iy)|^2=(1-W)^2+4W sin^2((y-y0)/2), and 2 sqrt(W)/(1+W)>=1/2, to get ratio at least delta/16. Since exp(a(s-x))<=1+W, the resulting bound is |H(z)|/|Res_(p_0) H|<=128d exp(2J), where J bounds |G_s| on |z|<=rho(1+1/d). Dividing the coefficient integrals by B and Bv introduces factors at most 64d rho (rho/R)^n and max(1,2 rho/pi), respectively, both with exp(2J). With rho<=4sqrt(n) and log(1+1/(2d))>=1/(3d), both contour errors are at most
    1024 d n exp(2J - n/(3d)).

Write w0=rho(1+1/d). From s>=12sqrt(d), pi^2<10 and sqrt(1+u)<=1+u/2,
    w0/s <= (1+1/d)(1+5/(144d)) <= 1+21/(20d).
The logistic series bound is J<=sum_(r>=1) exp(-rs)/r * sum_(m=2)^d (rw0)^m/m!. For rs<=2d use the full exponential sum and r(w0-s)<=21/10, giving at most 9(1+log(1+2d/s)). For rs>2d the inner sum is <=2^d exp(rw0/2); hence its contribution is at most exp(-rs/8)/r, since log(2)<7/10 and the displayed bound on w0/s. The latter total is <1. For d>=63, 1+sqrt(d)/6<=d/2 and e<3, so 1+log(1+2d/s)<=log(2d), and J<=10 log(2d).

Thus the contour error is at most 1024 d n (2d)^20 exp(-n/(3d)). This decreases in n in the stated domain and at n=144d log(2d) is below 2^18 (2d)^(-25)<1/100. The exact normalized main pair is (-cos phase, +sin phase). By UNIFORM_UPPER_CENTRAL_RESIDUES.md the weighted remainder within the circle is <11/40. Their sum with the contour error is <1/3, proving (A) throughout the specified subrange. No enumeration over k is used.

Together with UNIFORM_CUT_SEVEN_HALVES.md, the upper-central and edge estimates now overlap for every k>=64 and n>=144d log(2d). The remaining central part s<12sqrt(d), and rows below this bound in n, still prevent a full uniform theorem. This document does not claim all roots are real from the upper-central signs alone.

