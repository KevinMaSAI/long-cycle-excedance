# Quadratic sufficient lower cutoff for the high-n regime

**Theorem.** There exist effective absolute constants C and k0 such that if k≥k0 and n≥C k², the long-cycle excedance polynomial E_(n,k) has simple real roots and E_(n,k)/t strictly interlaces E_(n+1,k)/t. This improves the sufficient high-n cutoff from order k³(log k)³ to order k² for large k. It does not combine with the low-n cutoff c k²/(log k)² to prove the mother conjecture.

We use H,G_s,p,ρ,a,u,v,B and the phase ψ of POLYNOMIAL_UNIFORM_BOUND.md, Sections 1–2. Write h_n=[z^n]H. In the contour argument only the truncated perturbation, farther pole bounds and the outer range change. The goal is the same relative inequalities
    |h_n/B+cos ψ|<1/3,  |(h_(n+1)−u h_n)/(Bv)−sin ψ|<1/3
now for 0≤s≤4√n. The absolute constants below need not be small.

## 1. Bounds for the truncated perturbation

For s>0 the pole power-sum identity or the Taylor series of the scaled logistic derivative yields
    g_m=−(1/m!) ∑_(r≥1)(−exp(−s))^r r^(m−1), m≥2.
Indeed the derivative 1/(1+exp(z−s)) equals ∑_(r≥0)(−exp(−s))^r exp(rz) locally at z=0. Integrating its coefficient of z^(m−1) gives the pole coefficient before deleting the short cycles. In particular for w≥0,
    sup_(|z|≤w)|G_s(z)| ≤ ∑_(r≥1) (exp(−rs)/r) ∑_(m=2)^(k−1) (rw)^m/m!.
All rearrangements here involve only finitely many m and exponentially summable r.

For s≤√k and w≤ρ(1+1/k), the pole estimate of POLYNOMIAL_UNIFORM_BOUND.md, Section 1 gives O(log k+ρ)=O(√k+log k): keep the harmonic sum rather than bounding it by k. This also includes s=0.

For √k≤s≤16k take w=ρ(1+1/k). For k sufficiently large w/s≤9/8. Also w−s≤s/k+π²/s since (ρ−s)(1+1/k)≤π²/s. Thus for r≤4k/s, r(w−s)≤4+4π². Bound the inner exponential sum by exp(rw); the resulting prefix is ≤exp(4+4π²)(1+log(1+4k/s)). For r>4k/s, use ∑_(m≤k)(rw)^m/m!≤2^k exp(rw/2), so the summand is ≤exp(−rs/4)/r: indeed k log 2≤rs log(2)/4 and 1−(9/8)/2−log(2)/4>1/4. Sum the geometric tail. Therefore |G_s|≤C0 (1+log(1+k/s)) throughout this disk. Combining both regimes shows uniform bounds
    sup_(|z|≤ρ(1+1/k))|G_s(z)|≤C1(√k+log k),
    ρ² sup_(|z|≤ρ(1+1/k))|G_s(z)|≤C2 k²,    0≤s≤16k.
For the second inequality, when s≤√k use ρ²≤k+π², and otherwise use log(1+k/s)≤k/s, ρ²≤2s² for k large and s≤16k.

For s≥16k, on the square with half-side L=2π ceil(ρ/π) use |z|≤4(s+7)≤8s, as in the old proof. The binomial-like cutoff ∑_(m≤k)(r|z|)^m/m!≤16^k exp(r|z|/16) gives each series summand ≤exp(−rs/4)/r, since k log16 < s/4. Hence |G_s|≤2 exp(−s/4) throughout the square when k is large.

## 2. Contour and pole errors

For 0≤s≤16k, use the circular radius choice in POLYNOMIAL_UNIFORM_BOUND.md, Section 2, now with S0=16k. Its geometric argument only requires ρ≤5S0/4, k≥4 and candidate interval length exceeding 1/(2S0), all satisfied for large k. The denominator bound is unchanged with this S0. The relative contour error, in both units, is at most
    200 S0³ exp(2 C1(√k+log k)−n/(4k)).
This is <1/100 uniformly for n≥Ck² and large k. Any farther pole pair inside the circle receives a numerator penalty ≤exp(2 C2 k²/ρ²). The radial factor has at least power n/2 of (1+4π² ℓ(ℓ+1)/ρ²)^(-1). Reserve n/4 of that power: since log(1+8π²/ρ²)≥8π²/(9ρ²), the exponent from the reserved radial power and the numerator penalty together is at most (2 C2 k²−2π² n/9)/ρ². Choose C≥9 C2/π² so this is nonpositive. In the remaining radial bound include the factor 2ℓ+1 for the centered difference. As in the old proof, Bernoulli bounds the total by ∑_(ℓ≥1)(2ℓ+1)/(1+c1 ℓ(ℓ+1))^4 where c1=nπ²/(4ρ²)>1/2 once C is sufficiently large (ρ≤17k). This sum is <1/4 by the same rational majorant. The asserted relative inequalities follow.

For 16k≤s≤4√n use the square. Its contour estimate from Section 2 of the old proof applies with |G_s| small and ρ≤5√n; any change of the absolute constant in the bound O(n 2^(−n)) still makes the error <1/100. The weighted farther pole sum, before the numerator factor exp(4 exp(−s/4)), is at most
    ∑_(ℓ≥1) (2ℓ+1)[1+4π² ℓ(ℓ+1)/(16n+π²)]^(−(n+1)/2).
As n→∞ it tends to ∑_(ℓ≥1)(2ℓ+1) exp(−π² ℓ(ℓ+1)/8). Uniform summability and an effective threshold follow from Bernoulli to the fourth power, as above: for n≥16, each term is bounded by (2ℓ+1)/(1+c0 ℓ(ℓ+1))^4 with c0=1/8, which has an effective O(ℓ^-7) majorant. The limiting sum is <3/10: the term ℓ=1 is <27/100, the term ℓ=2 is <1/250, and successive ratios after ℓ=2 are at most (7/5)exp(−3π²/4)<1/10 (see rational replay). Thus for n large the sum is <31/100, leaving room for small numerator and contour errors. This proves both relative bulk inequalities on the whole interval.

## 3. Occupancy edge with n/k² bounded below

In the exact occupancy series of OCCUPANCY_ALTERNATING_SERIES.md the row at t=−exp(−s) has the sign of ∑_(r≥1)(−1)^r V_r b_n(r), where V_r=exp(−sr)r^n and b_n(r)=b_(n,k)(r). Let M=ceil(√n/4), S=n/M. For n large, at witness s=n/m (1≤m≤M), or outward from the pair m,m+1 for n/(m+1)≤s≤n/m, successive outward ratios of V_r are ≤η=1/1000. Indeed the standard ratio calculation from GROWING_RATIO_LOG_BAND.md with exponent n gives upper bound exp(−n/[2M(M+1)]) which tends to exp(−8); n may be chosen so the exponent is at most −7, and exp(7)>1000 by the finite exponential series.

For r≤2M, and n≥Ck² with C enlarged sufficiently, n/r≥2k (use 2M≤√n for n large). If every label is hit at least k times, every cycle is accepted. Hence Chernoff plus a union bound yields
    1−b_n(r)≤r exp(−n/(8r)) ≤√n exp(−√n/8)
uniformly for r≤2M. Also 0≤b_(n+1)(r)−b_n(r)≤1−b_n(r); at every r we have 0≤b_n(r)≤1. At a witness, the main term is ≥(1−√n exp(−√n/8))V_m and opposite tails are ≤2η V_m/(1−η), so the sign is (−1)^m.

At a zero in a pair bracket, subtract (m+1/2) times its normalized series from the normalized next-row series. The two main terms from (r−m−1/2)b_n(r) have sign (−1)^(m+1) and combined magnitude ≥(1−√n exp(−√n/8))(V_m+V_(m+1))/2. Relative to V_m+V_(m+1), the first opposing tail is ≤∑_(h≥1)(h+1/2)η^h<1/10. The added term r(b_(n+1)(r)−b_n(r)) is ≤n exp(−√n/8) at r≤2M, with relative V sum ≤1/(1−η). For r>2M use r as the coefficient bound; the relative tail is at most ∑_(h≥M)(M+h)η^h, since r starts beyond 2M while the right main index is ≤M. Both contributions tend uniformly and effectively to zero. Consequently the next row has sign (−1)^(m+1) at any old root in an edge bracket. All normalized series used here differ from their actual rows by positive factors, so the centered comparison is valid at the old root regardless of normalization.

## 4. Stitch and conclusion

Here S≤4√n and S≥16k when n≥Ck² for sufficiently large absolute C and k; use M≤√n/2 and S≥2√n. At S, small G and 1−a≤exp(−S) give |ψ(S)/π−(M+1)|<1/8 for n,k sufficiently large, by the same atan estimates as in POLYNOMIAL_UNIFORM_BOUND.md. Explicitly, (n+1)atan(π/S)/π differs from M by at most M/n+(n+1)π²M³/(3n³), which goes uniformly to zero. At s=0 ψ=(n+2)π/2. Thus use the same successive first phase hit and last phase hit argument as in EVENTUAL_ALL_FIXED_K.md, Section 4: the edge indices m=1,…,M correspond to bulk labels j=m+1 and signs (−1)^(j+1), and the relative errors below 1/3 fix signs at witnesses and next-row signs at zeros. The number of brackets and symmetry exhaust the degree; odd n has its central root at −1 and t=0 is simple. Strict quotient interlacing follows by the derivative-sign criterion of INTERLACING.md. All estimates or series tails above supply finite threshold searches; no claim is made about the convenience of the constants.

The previous low-n theorem ends at c k²/(log k)². The uncovered interval is now within the near-quadratic scaling, not a full extra power of k. This is a partial theorem only.
