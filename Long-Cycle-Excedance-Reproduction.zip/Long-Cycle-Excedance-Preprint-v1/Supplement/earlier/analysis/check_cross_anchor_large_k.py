from fractions import Fraction as Q
from math import factorial
import sys

if not __debug__:
    raise RuntimeError("Run without -O")

def eh(x):
    return sum(x**j/factorial(j) for j in range(33))+x**33/factorial(33)/(1-x/34)

K=2**28
root=2**14
B=Q(18270)
x=Q(136,root)
pilo,pihi=Q(157,50),Q(22,7)
assert eh(Q(1,4))<Q(9,7) and eh(Q(1,8))<Q(8,7)
assert eh(Q(1,13))<Q(27,25) and eh(Q(2,13))<Q(7,6)
assert eh(Q(1,2))<Q(5,3)
assert Q(175,46)<Q(77,20)
assert Q(1,16)+Q(1,72)+Q(1,16*72*K)<Q(1,13)
assert Q(1,16)+Q(1,18)+Q(1,16*18*K)<Q(1,8)
assert (8*pilo*Q(999,1000))>25 and 4*pilo**2*Q(999,1000)>39
assert 4<=Q(K,1000) and 2<=Q(2*K,3000)
assert (Q(351,100)**2-Q(49,4))*256>10
assert Q(49,40)**2>Q(3,2)
assert 2+Q(211,50)*Q(49,40)+Q(127,100)*Q(3,2)<Q(91,10)
assert 2+6*Q(7,5)+4*Q(49,39)<16
assert Q(84,5)/(1-Q(84,5)/root)<17
assert Q(153,16)<Q(31,10)**2 and Q(459,16)<Q(27,5)**2
M=2+Q(211,50)*Q(31,10)+Q(127,100)*Q(153,8)
Mhalf=2*Q(31,10)+Q(211,50)*Q(153,8)+Q(127,100)*Q(27,5)**3
M1=2*Q(153,8)+Q(211,50)*Q(27,5)**3+Q(127,100)*Q(153,4)**2
assert M<40 and Mhalf<287 and M1<2600
assert B==900*29*Q(7,10) and B<136**2 and x<Q(1,120)
assert Q(77,40)*Q(7,2)<Q(27,4)
assert Q(77,20)**2*16/12<20
assert Q(27,4)+20*Q(1,120)<7
assert 20+Q(49,2)/(1-Q(7,120))<47
assert Q(2,3)*pilo**2/(8*(Q(49,4)+Q(10,256)))>Q(1,16)
assert 2*(5*Q(16,22)**16+Q(16,15)*Q(16,22)**15)<Q(1,10)
assert (Q(21,2)*x)<Q(88,1000)
assert 25*pihi*(1+3*Q(7,50))<112
assert Q(112,root)<Q(7,1000)
assert Q(27,4)*(x/10+Q(287,root))<Q(124,1000)
assert Q(21,2)*x/20<Q(5,1000)
assert Q(47,K)*(Q(91,10)*B+2600)<Q(30,1000)
assert Q(4,root)<Q(1,1000)
assert Q(167,1000)<(1-Q(88,1000))*(Q(1,3)-Q(7,50))
assert 409+Q(34**2,2)/(1-Q(34,root))<1000
assert 675+Q(44**2,2)/(1-Q(44,root))<1700
assert 49*100<409*12 and Q(409,root)<1 and Q(675,root)<1
assert Q(491,10)*(Q(43,root)+Q(1700,K))<Q(13,100)
assert Q(7,50)+Q(13,100)+Q(1,1000)<Q(1,3)
assert Q(16*17,root)<Q(1,50)
print("PASS: exact uniform cross-anchor margins at k>=2^28")

def conv(a,b,L):
    return [sum(a[j]*b[i-j] for j in range(i+1)) for i in range(L+1)]
def product(seq,L):
    out=[Q(1)]+[Q(0)]*L
    for v in seq: out=conv(out,v,L)
    return out

L=25
points=list(map(Q,("1/2","-1/3","1/4","1/5")))
u=Q(1,9)
count=0
for k in (3,4,5,6):
    d=[Q(1)]
    for m in range(1,L+1):
        d.append(sum(d[:max(0,m-k+1)])/m if m>=k else Q(0))
    delta=[Q(0)]*k+[d[k]]+[d[b]-d[b-1] for b in range(k+1,L+1)]
    full=product([[d[a]*q**a for a in range(L+1)] for q in points],L)
    mixed=[full[m]-d[m]*sum(q**m for q in points) for m in range(L+1)]
    anchor=[]
    for i,qi in enumerate(points):
        P=product([[Q(1)]+[delta[b]*qj**b/(1-qj/qi) for b in range(1,L+1)]
                   for j,qj in enumerate(points) if i!=j],L)
        P[0]-=1
        anchor.append(P)
    for n in range(k,L):
        ordinary=adjacent=Q(0)
        for qi,P in zip(points,anchor):
            ordinary+=sum(d[n-b]*qi**(n-b)*P[b] for b in range(0,n-k+1))
            adjacent+=(qi-u)*sum(d[n+1-b]*qi**(n-b)*P[b] for b in range(0,n+2-k))
        assert ordinary==mixed[n]
        assert adjacent==mixed[n+1]-u*mixed[n]
        count+=2
print(f"PASS: {count} exact toy-pole prefix identities, including the adjacent boundary")

