from fractions import Fraction as Q
from math import factorial
if not __debug__:
    raise RuntimeError("Run without -O")

def eh(x):
    return sum(x**j/factorial(j) for j in range(33))+x**33/factorial(33)/(1-x/34)

k=2**25
root=5791
pilo=Q(157,50)
pihi=Q(22,7)
assert root**2<k and 128*45<root
assert 900*26*Q(7,10)<128**2
assert 2+2*Q(7,50)+19<22
assert Q(968,root)<Q(17,100) and Q(272,root)<Q(1,20)
assert Q(7,50)+Q(17,100)+Q(1,1000)<Q(1,3)
mid=Q(43)+Q(675,root)
assert mid/(1-mid/root)<44
assert 33+Q(409,root)<mid
assert Q(51,16)<Q(9,5)**2 and Q(153,16)**3<31**2
assert Q(17,16)*(2+Q(211,50)*Q(9,5)+Q(127,100)*Q(51,8))<19
assert Q(17,16)*(2*Q(9,5)+Q(211,50)*Q(51,8)+Q(127,100)*31)<75
alpha=Q(27,4)+Q(20,45)
assert alpha/45<Q(4,25)
assert alpha*(1+Q(4,25)/(2*(1-Q(4,75))))<8
beta=Q(7,90)
assert Q(3,2)*beta+Q(3,4)*beta**2<Q(61,500)
assert eh(Q(61,500))-1<Q(14,100)
assert Q(7,2)*beta+Q(49,12)*beta**2<Q(3,10)
assert Q(7,6)*beta<Q(1,2)
assert 1+Q(7,6)*128<13**2
assert (Q(49,6)*beta+196*13)/root<Q(1,2)
assert Q(27,8)+Q(81,8)/6<Q(51,10)
assert Q(51,10)+Q(1,2)==Q(28,5)
assert 7+Q(21,2)+Q(1,2)==18
assert Q(20,7)*pihi*(Q(28,5)+18*3*Q(7,50))/root<Q(21,1000)
assert pilo**2/(16*(Q(49,4)+Q(10,256)))>Q(1,20)
assert 5*Q(20,26)**32+Q(20,31)*Q(20,26)**31<Q(1,500)
assert 8*(Q(1,250*45)+Q(75,root))<Q(105,1000)
assert Q(28,100)*Q(1,500)<Q(1,1000)
assert Q(4,root)<Q(1,1000)
assert Q(128,1000)< Q(72,100)*(Q(1,3)-Q(7,50))
print("PASS: exact all-order phase coherence margins at k>=2^25")

