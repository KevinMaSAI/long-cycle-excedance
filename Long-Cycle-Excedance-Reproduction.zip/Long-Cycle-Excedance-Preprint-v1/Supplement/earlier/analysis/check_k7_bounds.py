from math import factorial
from fractions import Fraction as Q
def U(r2,r,q):
    return sum((Q(5,3)**m+1)*q*r2**(m//2)*r**(m%2)/factorial(m) for m in range(2,7))
def el(x):
    return sum(x**m/factorial(m) for m in range(25))
assert sum((Q(5,3)**m+1)*Q(11)**(m//2)*Q(10,3)**(m%2)*g for m,g in enumerate([Q(1,8),Q(1,60),Q(1,192),Q(1,480),Q(1,2880)],2))<71
for rr,R,q,cap in [(11,Q(10,3),Q(3,8),71),(19,Q(9,2),Q(1,20),33),(74,9,Q(3,8)**8,9),(266,17,Q(3,8)**16,Q(1,8))]:
    assert U(rr,R,q)<cap
assert 170*Q(11,4)**71*Q(2,3)**256<Q(1,100)
assert 144*256*Q(11,4)**33*Q(2,3)**256<Q(1,100)
assert 64*Q(36,55)>33 and 64*Q(72,338)>9 and Q(256*9,4*266)>Q(1,2)
assert Q(8,7)/4+Q(1,100)<Q(1,3)
assert sum(Q(1,256**(6-m)*factorial(m)) for m in range(1,7))<Q(1,600)
assert Q(16**12,600)*Q(3,8)**40<Q(1,200)
assert (1+17+41+65+85+102)==311<el(Q(146,25))
for a,b,t in ((1,2,17),(2,3,41),(3,4,65),(4,5,85),(5,6,102)):
    assert 257**a<t**b
assert min(Q(16,36)-Q(1,16),Q(3,7)-Q(1,18))>Q(73,200)*Q(257,256)+Q(1,200)
assert el(Q(256*16,200))>25600
assert Q(3,8)**40*(1+sum(Q(41**m,3*factorial(m)) for m in range(2,7)))<Q(1,100)
print("PASS: k=7 exact rational bulk, edge and stitch margins")
