from fractions import Fraction as Q
from math import isqrt, factorial
D=2**48
def down(q): return Q((q*D).__floor__(),D)
def up(q): return Q((q*D).__ceil__(),D)
def exp_bounds(x):
    term=ans=Q(1)
    for m in range(1,65):
        term*=x/m
        ans+=term
    return ans,ans+term*x/65/(1-x/66)
def mul(i,j):
    z=[x*y for x in i for y in j]
    return min(z),max(z)
def horner(c,w):
    ans=(0,0)
    for a in reversed(c):
        l,h=mul(ans,w);ans=l+a,h+a
    return max(abs(ans[0]),abs(ans[1]))
polys=[[1],[1],[1,-6],[1,-12],[1,-30,120],[1,-60,360]]
step=64
qm=[tuple((down(1/b),up(1/a))) for a,b in (exp_bounds(Q(i,step)) for i in range(18*step+1))]
hi0=hi1=Q(0)
for i in range(18*step):
    ql,qh=qm[i+1][0],qm[i][1]
    w=(ql/(1+ql)**2,qh/(1+qh)**2)
    x=(1-ql)/(1+ql)
    r2=Q(i+1,step)**2+Q(22,7)**2
    r=Q(isqrt((r2*D**2).__floor__())+1,D)
    U=sum(((Q(5,3)**m+1)*w[1]*horner(c,w)*x**(m%2)*r2**(m//2)*r**(m%2)/factorial(m) for m,c in enumerate(polys,2)))
    if i<10*step: hi0=max(hi0,U)
    else: hi1=max(hi1,U)
assert hi0<32 and hi1<9,(float(hi0),float(hi1))
print('U slabs certified: 32, 9')
assert sum((Q(5,3)**m+1)*334**(m//2)*19**(m%2)/factorial(m) for m in range(2,8))/exp_bounds(Q(18))[0]<Q(1,8)
assert 80*Q(144,292)>32 and 80*Q(72,406)>9
assert Q(320*9,4*334)>Q(1,2)
assert 144*320*Q(11,4)**32*Q(2,3)**320<Q(1,100)
assert Q(8,7)/4+Q(1,100)<Q(1,3)
assert sum(Q(1,320**(7-m)*factorial(m)) for m in range(1,8))<Q(1,4900)
assert Q(17**14,4900)*Q(321,320)**7/exp_bounds(Q(85,2))[0]<Q(1,200)
assert exp_bounds(Q(23,4))[0]>290
assert Q(85,14)-Q(23,4)>Q(3,10)
assert 2*Q(23,4)+3<Q(17**2,16)
assert exp_bounds(Q(16))[0]>32000
assert (1+sum(Q(44**m,3*factorial(m)) for m in range(2,8)))/exp_bounds(Q(85,2))[0]<Q(1,100)
print('PASS: k=8 rational cutoff 320 margins')
