# A reusable central cutoff of 4 sqrt(n)

For n≥128 and 0≤s≤4 sqrt(n), the unperturbed farther conjugate pairs in the normalized pole model, including the centered adjacent multiplier bound 2l+1, have total absolute magnitude less than 7/25. The exponent can be either n or n+1:
    sum_(l≥1) (2l+1) [1+4π² l(l+1)/(s²+π²)]^(−n/2) < 7/25.

Take b=4(157/50)²/(16·128+10). For fixed A>0, n log(1+A/(16n+10)) is increasing: setting x=A/(16n+10), its derivative is at least log(1+x)−x/(1+x)>0. Thus the sum is at most its bound at n=128 with π≥157/50, π²<10, giving terms f(l)=(2l+1)(1+b l(l+1))^(−64). For the tail l≥4 use ∫_3^∞ f(x) dx=(1+12b)^(−63)/(63b). The function is decreasing for x≥3 because the numerator of its derivative is 2(1+b x(x+1))−64b(2x+1)²=2−64b−254b x(x+1), already negative at 3. Rational arithmetic verifies the claimed sum margin.

The ratio-free occupancy proof in GROWING_RATIO_LOG_BAND.md can also use the cutoff T=4 for n≥16385 rather than its stated T=8: with D=n−1 and M=ceil(sqrt(D)/4) the ratio exponent D/(2M(M+1))≥16384/(2·33·34)>7. Then η=1/1000 remains valid, and the rest of the bounds do not depend on T. This sharper estimate uses M≤sqrt(D)/4+1, rather than the earlier coarser M+1≤2sqrt(D)/T. The same S=D/M lies in the central domain and has the same phase stitching limit.

Consequently the existing bridge and initial near-quadratic band can be run with an elementary primary-pair error budget: allow <7/25 from unperturbed farther pairs, and require all other relative errors to sum to <1/3−7/25. The central theta comparison is then unnecessary in these regimes. In the bridge, keep the exact primary pair and use the coefficient cancellation only to control the weighted farther poles. This gives the same asymptotic coverage and a larger error budget, not a new overall numerical K or a resolution of any small-k gap by itself.
