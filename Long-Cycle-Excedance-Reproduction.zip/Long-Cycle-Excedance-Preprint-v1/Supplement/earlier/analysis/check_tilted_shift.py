"""Exact rational diagnostics for the tilted-variation recurrence and long-shift rule."""
from fractions import Fraction as F
from itertools import product

coefficient_checks = 0
for k in range(2,28):
    r = 1 + F(1,k)
    d = [F(1)] + [F(0)]*(k-1)
    var = F(0)
    for b in range(k,10*k+1):
        d.append(((b-1)*d[-1]+d[b-k])/b)
        delta = d[b]-d[b-1]
        if b>=4*k:
            assert delta == -sum(d[j]-d[j-1] for j in range(b-k+1,b))/b
        var += r**b*abs(delta)
        assert var < F(1296,k)
        coefficient_checks += 1
    for j in range(k,10*k):
        contraction = sum(r**(b-j)/b for b in range(max(j+1,4*k),j+k))
        assert contraction < F(3,4)

boundary_checks = 0
for k in range(2,8):
    r = 1 + F(1,k)
    q = (F(-4,5), F(1,2), F(1))
    for bs in product(range(k,k+4), repeat=3):
        for n in range(k,2*sum(bs)+1):
            N=n-sum(bs)
            for i in range(3):
                if sum(bs)*2<=n:
                    assert N>=n//2
                    assert abs(q[i])**(N+bs[i]) <= abs(q[i])**(n//2)
                elif N>=-1:
                    assert r**sum(bs) >= r**(n//2)
                    assert abs(q[i])**(N+bs[i]) <= abs(q[i])**(k-1)
                boundary_checks += 1
print(f"PASS: {coefficient_checks} tilted recurrence checks; {boundary_checks} shift-split checks")
