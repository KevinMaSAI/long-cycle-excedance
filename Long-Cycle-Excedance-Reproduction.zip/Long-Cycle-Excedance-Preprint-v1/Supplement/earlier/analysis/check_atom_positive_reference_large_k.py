from fractions import Fraction as Q
from math import factorial
if not __debug__:
    raise RuntimeError("Run without -O")

def eh(x):
    return sum(x**j/factorial(j) for j in range(31))+x**31/factorial(31)/(1-x/32)
K=2**20
R=2**10
pi,pilo=Q(22,7),Q(157,50)
for a,c in [(Q(4,15),Q(5,2)),(Q(1,5),2),(Q(1,7),Q(8,5))]:
    assert eh(2*a)/(2-eh(a))<c
assert 900*21*Q(7,10)<116**2 and Q(116,R)<Q(1,8) and Q(7,2)*116/R<Q(2,5)
assert Q(7,50)+Q(197,R)<Q(1,3)
assert Q(7,50)+Q(196,R)<Q(1,3)
assert Q(56,5)/(1-Q(56,5*R))<12

def f(j,c):
    return (2*j+1)*(1+c*j*(j+1))**(-32)
def tail(a,c):
    return (1+c*a*(a+1))**(-31)/(31*c)
def m(c):
    return 2*(1+f(1,c)+f(2,c)+tail(2,c))
c=Q(1,40)
assert pilo**2/(32*(Q(49,4)+Q(10,256)))>c
assert Q(6,7)*pilo**2/(16*(Q(49,4)+Q(10,256)))>Q(1,24)
assert 9*pilo**2>7*Q(49,4)
assert m(c)<Q(7,2) and m(Q(1,24))<Q(13,5)
assert 2*(f(2,c)+tail(2,c))<Q(3,20)
assert eh(Q(1,8))/2<Q(4,7) and Q(7,2)*Q(4,7)==2
assert eh(Q(1,18))*Q(13,10)<Q(7,5)
for A,S,T,beta,c0,D,lim in [
    (3,2,Q(7,5),Q(1,100),Q(7,2),Q(5,4),Q(13,10)),
    (6,Q(8,5),Q(9,10),Q(19,1000),Q(23,10),1,Q(21,20))]:
    assert A*pi/R<beta
    a=S+T*beta
    assert T+a*a/2/(1-a*beta)<c0 and D+c0*beta<lim
for atom,eta,A in [(2,Q(13,10),3),(Q(7,5),Q(21,20),6)]:
    assert (atom+2*(1+Q(7,50))*eta)*A*pi+Q(7,2)*eta*32<193

assert Q(7,2)*15/R<Q(52,1000)
beta=Q(52,1000)
assert Q(14,5)**2*Q(101,100)**2/12<Q(67,100)
a=Q(7,5)+Q(67,100)*beta
assert Q(67,100)+a*a/2/(1-a*beta)<Q(19,10)
assert Q(4,5)+Q(19,10)*beta<Q(9,10)
assert Q(4,7)*beta*Q(3,20)+Q(9,10)*Q(7,2)*(Q(15,250*R)+Q(32,R))<Q(104,1000)
a=Q(49,10)+Q(9,8)
assert a*(1+(a/8)/(2*(1-a/24)))<10
assert 10*(Q(1,8*250)+Q(1,100*R))<Q(6,1000)

a,m=Q(37,10),Q(111,5)
rem=lambda a,m,b,s:(a*a*b/6+2*a*m*s/3)/R
L=lambda a,b:a*b/2+a*a*b*b/12
assert 1+Q(7,6)*116<12**2 and 1+Q(7,6)*15<Q(22,5)**2
assert rem(a,m,beta,Q(22,5))<Q(24,100) and L(a,beta)<Q(1,10)
assert 2*Q(10,9)*pi*(Q(31,10)+Q(24,100)+(Q(185,20)+Q(24,100))*Q(21,50))/R<Q(51,1000)
assert eh(beta+beta**2/3)-1<Q(55,1000)
assert rem(a,m,Q(1,8),12)<Q(65,100) and L(a,Q(1,8))<Q(1,4)
assert 2*Q(9,7)*pi*(Q(31,10)+Q(65,100)+(Q(185,20)+Q(65,100))*Q(21,50))/R<Q(64,1000)
assert 90/(2*Q(128)**2)<Q(1,350) and Q(1,17)-Q(1,350)>Q(1,18)
assert 3*pi*13<128
a,m,beta=Q(7,3),Q(63,4),Q(2,5)
assert (Q(35,8)+m/13)/2<Q(28,10)
assert rem(a,m,beta,12)<Q(29,100) and L(a,beta)<Q(54,100)
assert eh(Q(54,100))<Q(172,100)
assert 2*Q(172,100)*pi*(Q(28,10)+Q(29,100))*(1+Q(21,50))/R<Q(47,1000)

assert eh(beta+beta**2/3)<Q(100,63)
assert eh(L(Q(27,10),beta))-1<Q(9,10)
assert Q(1000,81)>12 and Q(243,4000)+Q(1,4096)<Q(61,1000)
assert Q(63,100)-Q(9,10)*Q(61,1000)>Q(57,100)
assert 2*(Q(100,63)-1)/500<Q(3,1000)
assert Q(4,R)<Q(4,1000)
assert Q(160,1000)<Q(89,100)*(Q(1,3)-Q(7,50))
assert Q(77,1000)<Q(57,100)*(Q(1,3)-Q(7,50))
print("PASS: exact margins for leading-atom and positive reference at k>=2^20")

