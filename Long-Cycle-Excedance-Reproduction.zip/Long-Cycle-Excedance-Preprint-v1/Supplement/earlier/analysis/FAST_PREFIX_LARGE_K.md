# Exponentially accurate prefix reference: all rows for k >= 2^14

**Theorem.** For all integers k>=16384=2^14 and n>=k, E_(n,k) has simple real roots, and consecutive quotients after division by t strictly interlace. This is a uniform partial theorem, not a full proof for every k. There is no root enumeration. The upper range n>=900(k-1)log(2(k-1)) is already UNIFORM_K_LOG.md. Below that threshold use the following improvements to SCALAR_REFERENCE_LARGE_K.md and ASYMMETRIC_REFERENCE_LARGE_K.md.

Use their notation B=n/k, x=sqrt(B/k), beta=s/k, rho, q_i, d_n, F_y, P_N, and positive primary units 2d_n, 2d_n v. In the central range s<=(7/2)sqrt(n), we have x<.76 and beta<8/3, using sqrt(900log(2*16384))<97 and monotonicity of log(2k)/k. The centered unperturbed farther lattice bound .123 and value bound .041 continue to hold at n>=16384: apply the same monotonic-in-n bound as SCALAR_REFERENCE_LARGE_K.md with n=16384 and an integral remainder from level 3. The exponent-n two-half tail at levels l>=2 is <1/250, and at l>=4 is <10^(-8), as in ASYMMETRIC_REFERENCE_LARGE_K.md. The ellipse condition, exact centered N=n+1 prefix, parity, reciprocity, and the occupancy edge at n>=16385 are unchanged. The only case n=16384 here has n=k and a single cycle (its row and adjacent comparison are the single-cycle Eulerian chain; more generally the previously proved n<=2k+1 theorem applies), so the slight edge threshold poses no gap. The companion check_fast_prefix_large_k.py replays rational margins and does not compute roots.

## Keep the radial weights together
At exponent a>2 set C=4pi^2/rho^2, g(l)=(1+C l(l+1))^(-a/2). For l>=1,
    (2l+1)g(l) <= (3/2) integral_(l-1)^l (2u+1)g(u) du,
because g decreases and (2l+1)/(2l)<=3/2. Including both halves of the lattice gives total at most 2+3/[C(a/2-1)]=2+3rho^2/[2pi^2(a-2)]. At a=k-1, use rho^2<=(49/4)n+10 to bound this by M_1=2+1.88B. The unweighted sum M_0=2+1.41sqrt(B) is unchanged.

For low s<2pi sqrt(k), use rho<6.3sqrt(k) and the same bound M_1<8.1, M_0<4.6 at this rho. For each anchor i, sum_(j!=i)|q_j|^(k-1)/|i-j| <=M_0/2+1<3.3, treating |j-i|=1 separately. Thus absolute product bound ||B_i||_1<6.5/sqrt(k) by D_1<1.85/k and exp(y)-1<=y/(1-y). The value and centered errors are at most .041+4.6*6.5/128 and .123+(8.1*6.5+4)/128, strictly inside the ellipse.

In the rest of the low and middle range use the stronger tilt r=1+1/(4k), lambda=41/10, so log r>=1/(lambda k). With Q_j=M_j exp(-(B-1)/lambda), the unsplit endpoint formula bounds the shifted factor by Q_j and the full-n factor by 2.1 (value), 2.28 (centered). The power maxima against exp(-B/lambda) give sqrt(B)Q_0<5.1 and sqrt(B)Q_1<11. For B>=7, >=12, >=20 the pairs of bounds improve to (3.6,9.4), (1.7,6), (.37,1.75), respectively. Indeed all the contributing weighted powers are decreasing after 7, and evaluate at the endpoints. All margins follow from exact rational exponential enclosures.

For 2pi sqrt(k)<=s<3pi sqrt(k), r*rho/s<1+(.38)/k by sqrt(1+u)<=1+u/2 and the slack .38-1/4-1/8. The improved recurrence of SCALAR_REFERENCE_LARGE_K.md gives D_t<3.3/k and D_t-t^k/k<1.82/k at t=1+.38/k. Thus the signed linear and log remainder bounds are 1.65beta and .93beta^2, and the peeled-atom linear remainder <=.91beta. With beta<.074 the nonlinear remainder is <2.65beta^2, so ||U_i||_r<1.11beta after peeling. For 3pi sqrt(k)<=s<6pi sqrt(k) take t=1+(5/16)/k, since 5/16>1/4+1/18 including the cross term. The respective D_t and tail limits are 3/k and 1.57/k, giving 1.5beta, .77beta^2 and .785beta; beta<.148 yields nonlinear remainder <2.5beta^2 and ||U_i||_r<1.16beta. In both bands rho/s<1.01 and per-factor norm <1/2, as required in the squared log remainder. The bounds for the atom itself are unchanged (4/3,12/7 first; 6/5,7/5 second), since its anchor power is n-k and B>3 or B>7.

In the first band the upper error pair is
    [.041+((4/3+2.1*1.11)*3pi+3.5*1.11*5.1)/128,
     .123+.019+((12/7+2.28*1.11)*3pi+3.5*1.11*11)/128].
The second band uses
    [.041+((1.2+2.1*1.16)*V+3.5*1.16*P)/128,
     .123+.012+((1.4+2.28*1.16)*V+3.5*1.16*W)/128],
where (V,P,W)=(12.2,3.6,9.4) through B=12, (15.7,1.7,6) for 12<=B<=20, and (6pi,.37,1.75) for B>=20. Here beta<=3.5sqrt(B)/sqrt(k) gives the caps V in the first two ranges; diagonal caps use n>3k or n>7k. Every pair is strictly within the ellipse.

## Fast prefix-to-evaluation inequality
For N=n or n+1 let P_N(H)=sum_c dtilde_(N-c)[z^c]H/d_n as before; H is supported at c>=k. If B>=2, c<=n/2 implies k<=N-c<=n. By telescoping delta without dropping the coefficient tilt,
    |d_(N-c)-d_n| <= sum_(j>=N-c+1)|delta_j| <=D_r r^(-n/2).
If c>n/2 then |dtilde_(N-c)/d_n-1|<=1. Since d_n>=1/(2k-1) and kD_r>=1 by the delta_k term, in both parts after incorporating the coefficient weight r^c we obtain the single bound
    |P_N(H)-H(1)| <= 2k D_r r^(-n/2) ||H||_r.
The two parts are disjoint so their coefficient norms are not charged twice. This is exponential in B, replacing the earlier O(1/B) error. Write kappa for that upper prefactor.

## High s, beta<=1/2
Keep r=1+1/(4k), lambda=41/10. Since s>=6pi sqrt(k), B>28.9; for this whole range sqrt(B)Q_1(B)<.35 by monotonicity beyond 28.9 and evaluation there. For B>=80 the bound improves to .003. Also r*rho/s<1+4/(15k) by comparing 1/4+1/72 and the small cross term. Hence D_t<2.8/k, norm log cap for B_i is 1.4beta+.67beta^2, and individual factors have norm <1/2 since beta<=.5. These arithmetic estimates apply also when only using the weaker exponent-n far tail <1/250. For beta<=.25 the actual tilted norm B_i is <.5 and <2beta, and for beta<=.5 it is <1.4 and <2.8beta, by monotonicity of the exponential ratio for positive Taylor coefficients. Thus actual far scaled errors are <.022 in the first region, and <.006 in the second region when beta>=1/4 (then B>=k/196>80). The real reference subtraction at levels l>=2 is bounded by 2||F_0-1||_1/500 as before, and is <.002 or <.004, respectively, using the old exponent beta+beta^2/3. Diagonal deviation is <.006 for all high s and <.004 when B>=k/196.

Since D_r<2.7/k, kappa<5.4 exp(-B/(2lambda)). As in SCALAR_REFERENCE_LARGE_K.md let P0=P(s), c_N=1+P_N(F_0-1), and Rref=kappa||F_0||_r/P0. Then c_N/P0>=1-Rref, and P0>=exp(-.501 beta). For beta<=1/4, kappa<.161, ||F_0||_r<=exp(1.35beta+.6075beta^2), so Rref<.27, P0>.88 and c_N>.64. The exact scalar formula gives |F_y(1)-P0|/P0<.62 |y|/sqrt(k) for |y|<=3pi: log factor is <.59 by s>=6pi sqrt(k) and the Gamma derivative estimate; the small exponential increment at sqrt(k)>=128 gives .62.

To estimate the tilted difference take t=1+1/(2k): gap to r*|s+i*y|/s is >1/(9k) since log r<=.25/k and log(|s+i*y|/s)<=.125/k. Improved D_t<4.1/k gives weighted moments (a,C,m)=(4.1,5.33,13.84) by sup sqrt(b) exp(-b/(9k))<1.3sqrt(k) and sup b exp(-b/(9k))< (27/8)k. All factors have norm <1/2. The standard signed plus log-remainder derivative, with |y|sqrt(k)/s<=1/2 and square-root ratio <11/128, has factor <9.5 in units 1/sqrt(k). Thus ||F_y-F_0||_r/||F_0||_r <14 |y|/sqrt(k) by the factorial exponential inequality. The normalized near coherence is <.21 using coefficient (.62+.27*14)/.73 and angular weight pi(1+3*.123). Including the far errors gives .123+.21+.030/.64<.7.

For 1/4<=beta<=1/2, B>=k/196 gives kappa<.00025. On both near segments |y|<=3pi use t=1+.38/k, as log r+log(|s+i*y|/s)<=.375/k. With D_t<3.3/k and factor norms <1/2, log cap is 1.65beta+(3.3)^2 beta^2/12, so ||F_y||_r<3 (also ||F_0||_r<3). P0>.77, c_N>.76, P0/c_N<1.002. Relative coherence needs no weighted derivative here: use the scalar evaluation increment with factor .62, and the absolute prefix error <=.00025*6 in norm units before dividing by c_N. The near error is <.027, including the coefficient sum of upper-half weighted n lattice <=1+.123. Total is <.123+.027+.014/.76<.7.

## High s, beta>=1/2
Reduce the tilt to r'=1+1/(16k), with lambda'=17. By the exponentially accurate prefix inequality kappa'<10 exp(-B/34) (D_(r')<2.1/k). Since B>=(4/49)k beta^2>=k/49>334, all four levels l<=3 have |y|<=7pi and s/sqrt(k)>=64. Here log(|s+i*y|/s)<.06/k; hence r'*|s+i*y|/s<1+1/(8k). Improved D_t<2.2/k bounds each log factor by M<.94 via beta<8/3 and pi>157/50. Since sum_(m>=2).94^(m-2)/m<2.2, the tilted log norm <=1.1beta+.888beta^2. Combining with P0>=exp(-.501 beta) and the correlation of B and beta gives, for all these levels and y=0,
    kappa'||F_y||_(r')/P0 <10 exp(1.601beta+(.888-2k/(49*17))beta^2)
                        <=10 exp(1.601beta-38beta^2)<.003.
The last exponent decreases for beta>=.5. Thus c_N>=.997P0>.25. Also, from the scalar product log increment, 1/s<=1/(64sqrt(k)), d y^2/(2s^2)<.06 and 1/sqrt(2pi d)<.41/sqrt(k) give log factor .48, hence relative scalar increment <.54 |y|/sqrt(k). Use the prefix inequality on H=F_y-F_0; it incurs at most .006 P0 on that difference. Including the first four upper-half angular weights, relative near error is
    <= [ .54*pi*(1+3*.123+7/500)/sqrt(k)+.006(1+.123)]/.997 <.03.

For the far l>=4 terms r'*rho/s<1+1/(12k) (1/16+1/72 plus cross term). With D_t<2.1/k, the individual factor norm is <.9 by rho<3.51sqrt(n), x<.76 and pi>157/50. The log remainder coefficient is <1.8 times the square sum because sum_(m>=2).9^(m-2)/m<1.8. Thus the log norm is <3.675x+8.2x^2, giving ||B_i||_(r')<1900 and <2600x by monotonicity of the positive exponential power coefficients. With the tighter M_1=2+1.88 B the r' shifted sqrt(B)Q_1(B)<.0001 for B>=334 by monotone evaluation there with lambda'=17. Thus far actual error <.003 using exponent-n tail below 10^(-8). Reference far subtraction <.001 since c_N<=1.003P0<16 by P0<=exp(s/(k-1)). Diagonal deviation <.002 because B>=k/49>334. Relative error <.123+.03+.006/.25<.7.

The low/mid ellipse and high symmetric .7 errors prove the sign comparisons at witnesses and every old zero. With the same degree, parity, and edge reasoning, and the analytic upper wedge, this proves all n and adjacent pairs for k>=2^14.

