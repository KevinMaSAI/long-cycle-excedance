"""Rational bounds and exact identity checks for the full two-cycle band."""
from fractions import Fraction as F
from math import comb, factorial
from check_interlacing_general import rows

U=2*(1+F(3,4)**4+F(1,2)**4+1296*(F(1,3**8)+F(1,7*3**7)))
W=2*(1+3*F(3,4)**4+5*F(1,2)**4+3240*(F(1,3**7)+F(1,6*3**6)))
assert U<4 and W<10
assert 2592*(F(1,10**8)+F(1,7*10**7))<F(1,1000)
assert 7776*(F(1,10**7)+F(1,6*10**6))<F(1,200)
assert F(640,10000)+F(8,1000)<F(2,25)
assert F(6432,10000)+F(3,100)<F(7,10)
assert F(7,10)+F(64,10**12)<F(7,5)
assert 4*(F(25,576)+F(1,48))<F(3,10)
assert 4*(3+F(3,24)+2*F(25,576))<16
assert 5*(1+F(1,24)+F(25,576))<6
assert F(3,10)+F(22,10000)<F(1,2)

def pmf(n,j,p):
    return comb(n,j)*p**j*(1-p)**(n-j)

def c2(n,k,r):
    return sum(F(1,i)*sum(pmf(n,j,F(i,r)) for j in range(k,n-k+1)) for i in range(1,r))

def c3(k,r):
    n=3*k
    total=F()
    for i in range(1,r):
        for j in range(1,r-i):
            h=r-i-j
            prob=F(factorial(n),factorial(k)**3)*F(i*j*h,r**3)**k
            total+=F(r,6*i*j*h)*prob
    return total

num=0
for k in range(3,11):
    E=rows(3*k,k)
    for n in range(2*k,3*k):
        for r in range(1,11):
            x,y=c2(n,k,r),c2(n+1,k,r)
            assert 0<=x<=3 and 0<=y<=3
            assert r*(y-x)==F(n,n-k+1)*sum(pmf(n-1,k-1,F(i,r)) for i in range(1,r))
            m=n+1
            c=y+(c3(k,r) if m==3*k else F(0))
            calc=r**(m-1)*(1+c)
            expected=sum(E[m][j]*comb(m+r-j-1,m-1) for j in range(1,min(r,m-1)+1))
            assert calc==expected
            num+=1
print("PASS bounds, adjacent binomial difference and cubic-onset identity on",num,"exact grid points")

