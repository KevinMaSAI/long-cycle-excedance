from fractions import Fraction as Q
from math import factorial
if not __debug__:
    raise RuntimeError("Run without -O")
def eh(x):
    return sum(x**j/factorial(j) for j in range(33))+x**33/factorial(33)/(1-x/34)
K=2**18
R=512
pi=Q(22,7)
assert 900*19*Q(7,10)<110**2
assert Q(110,R)<Q(11,50) and Q(7,2)*110/R<Q(19,25)
assert Q(7,50)+Q(286,R)<Q(7,10) and Q(4,R)<Q(8,1000)
assert Q(56,5)/(1-Q(56,5*R))<12
for A,S,T,beta,Lim,cap in [(3,2,Q(7,5),Q(37,2000),Q(211,100),20),
                            (6,Q(8,5),Q(9,10),Q(37,1000),Q(7,4),33)]:
    assert A*pi/R<beta and Lim*A*pi<=cap
    u=S+T*beta
    assert u/(1-u*beta)<Lim
    assert 2*(1+Q(7,50))*cap+Q(7,2)*Lim*32<282

a=Q(37,10); m=Q(111,5); b=Q(103,1000)
L=lambda a,b:a*b/2+a*a*b*b/12
Rder=lambda a,m,b,d:(a*a*b/6+2*a*m*d/3)/R
assert 1+Q(7,6)*110<12**2 and 1+Q(7,6)*15<Q(22,5)**2
assert Q(7,2)*15/R<b
u=Q(7,5)+Q(67,100)*b
assert Q(67,100)+u*u/2/(1-u*b)<2 and Q(4,5)+2*b<Q(101,100)
assert Q(4,7)*b*Q(3,20)+Q(101,100)*Q(7,2)*(Q(15,250*R)+Q(32,R))<Q(231,1000)
assert Rder(a,m,b,Q(22,5))<Q(48,100)
assert L(a,b)<Q(21,100) and eh(Q(21,100))<Q(124,100)
assert 2*Q(124,100)*pi*(Q(31,10)+Q(48,100)+(Q(185,20)+Q(48,100))*Q(21,50))/R<Q(12,100)
assert eh(b+b*b/3)-1<Q(113,1000)
assert Q(226,1000*500)<Q(1,1000)
assert Q(360,1000)<Q(774,1000)*(Q(7,10)-Q(7,50))

b=Q(1,4)
assert eh(b+b*b/3)-1<Q(5,16)
assert L(a,b)<Q(535,1000) and eh(Q(535,1000))<Q(171,100)
assert Rder(a,m,b,12)<Q(129,100)
assert 2*Q(171,100)*pi*(Q(31,10)+Q(129,100)+(Q(185,20)+Q(129,100))*Q(21,50))/R<Q(186,1000)
u=Q(7,5)+Q(67,100)*b
assert eh(u*b)-1<Q(1,2) and u/(1-u*b)<Q(26,10)
assert Q(1,500)+Q(26,10)*Q(7,2)*Q(1,100*R)<Q(3,1000)
assert Q(5,8*500)<Q(2,1000)
assert Q(199,1000)<Q(375,1000)*(Q(7,10)-Q(7,50))

b=Q(19,25)
assert eh(b+b*b/3)<Q(100,38)
assert eh(L(Q(27,10),b))<4
assert Q(K,196)/Q(81,5)>80
assert Q(243,20)*196/K+Q(1,2**80)<Q(93,10000)
assert Q(38,100)-3*Q(93,10000)>Q(35,100)
assert 1-3*Q(93,10000)/Q(38,100)>Q(92,100)
assert 2*(Q(100,38)-1)/500<Q(7,1000)
assert 90/(2*Q(128)**2)<Q(1,350) and 3*pi*13<128
assert Q(1,17)-Q(1,350)>Q(1,18)
assert Q(K,6*K+1)-Q(1,8)-Q(1,350)>Q(1,27)
assert eh(Q(1,6))+eh(Q(1,3))/(2-eh(Q(1,6)))<3
assert Q(27,2)*Q(3,8)==Q(9,4)**2
a,m=Q(7,3),Q(63,4)
assert Rder(a,m,b,12)<Q(58,100)
assert (Q(35,8)+m/13)/2+Q(58,100)<Q(17,5)
assert Q(17,5)/(1-Q(17,5)*3*pi/R)<Q(37,10)
a,m=Q(3),Q(243,8)
assert Rder(a,m,b,12)<Q(143,100)
assert (Q(27,4)+m/13)/2+Q(143,100)<6
assert Q(6)/(1-6*3*pi/R)<7
assert (Q(37,10)+28*Q(93,10000)/Q(38,100))/Q(92,100)<Q(48,10)
assert Q(48,10)*pi*(1+Q(21,50))/R<Q(42,1000)
u=Q(49,10)+9*Q(11,50)
assert u*(1+(u*Q(11,50))/(2*(1-u*Q(11,50)/3)))<18
assert 18*(Q(11,50*250)+Q(1,100*R))<Q(17,1000)
assert Q(7,50)+Q(42,1000)+Q(32,1000)/Q(35,100)<Q(7,10)
assert 2*Q(7,10)**2<1
print("PASS: exact joint-error and relative-reference margins for all k>=2^18")

