# Occupancy coefficient ratio: exact recurrence and a failed strengthening

Put C_n(r)=[t^r] E_(n,k)(t)/(1-t)^n, so C_n(r)=r^n b_(n,k)(r) for r>=1. Dividing the excedance recurrence by (1-t)^(n+1), the two Eulerian derivative terms combine to t times the derivative of E_(n,k)(t)/(1-t)^n. The lag factor is t A_(k-1)(t)/(1-t)^k=sum_(j>=1) j^(k-1)t^j. For n>=k and r>=1 the coefficient recurrence is therefore
    C_(n+1)(r) = r C_n(r) + binom(n,k-1) sum_(j=1)^r j^(k-1) C_(n+1-k)(r-j).
Here omitted lower activity rows are zero except C_0(0)=1. A possible way to sharpen the edge comparison is to order C_(n+1)(r)/C_n(r) in r directly. This would order the two dominant weights in the centered difference but would not, by itself, control the tails or the central zeros.

Diagnostic: exact binomial coefficient extraction agrees with strict increase of that ratio on the tested grid k=3..30, n=k..80 and r=1..80 (142674 adjacent comparisons). This is not a proof. The stronger assertion that the correction C_(n+1)(r)/C_n(r)-r increases is false. At n=2k-1 the recurrence gives that correction as binom(2k-1,k-1) sum_(j=1)^(r-1) [j(r-j)/r^2]^(k-1). Its value at r=3 relative to r=2 is 2(8/9)^(k-1), less than 1 as soon as k>=7 (k=7 already gives 524288<531441). This is not a counterexample to the root conjecture or to increase of the full ratio.

