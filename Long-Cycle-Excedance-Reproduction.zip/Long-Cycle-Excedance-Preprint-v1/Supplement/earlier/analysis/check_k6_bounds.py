from fractions import Fraction as Q
from math import factorial

def exp_lower(x, terms=25):
    return sum(x**j/factorial(j) for j in range(terms))

def U(r2, r, q, extra=1):
    return q*(5*Q(r2,2)+9*Q(r2*r,6)+17*Q(r2*r2,24)+33*Q(r2*r2*r,120)*extra)

assert 5*Q(11,8)+9*Q(11,18)+17*Q(121,192)+33*Q(1210,1440)<51
assert U(11,Q(10,3),Q(3,8),Q(21,22)**2)<101
assert U(19,Q(9,2),Q(1,20))<44
assert U(74,9,Q(3,8)**8)<8
assert U(266,17,Q(3,8)**16)<Q(1,10)
assert exp_lower(Q(3))>20 and Q(11,4)**3<21
assert 160*Q(11,4)**101*Q(5,9)**192<Q(1,100)
assert 144*192*Q(11,4)**44*Q(5,9)**192<Q(1,100)
assert Q(193,192)*Q(5,9)<1
assert 72*Q(36,55)>44 and 48*Q(72,338)>8
assert Q(192*9,8*74)>Q(1,2) and Q(192*9,4*266)>Q(1,2)
assert Q(10,9)/4+Q(1,100)<Q(1,3)
assert sum(Q(1,(192**(5-m))*factorial(m)) for m in range(1,6))<Q(1,100)
assert 14**10*Q(3,8)**33/100<Q(1,200)
assert exp_lower(Q(11,2))>169
j=Q(55,4)**2+1
assert j<14**2 and j**2<34**3 and j**3<52**4 and j**4<68**5
assert Q(33,67)-Q(4,55)-Q(2,5)*Q(193,192)>Q(1,100)
assert 192*Q(3,8)**26<Q(1,100)
assert Q(3,8)**33*(1+sum(Q(34**m,3*factorial(m)) for m in range(2,6)))<Q(1,100)
print('PASS: k=6 exact rational bulk, edge and stitch inequality margins')
