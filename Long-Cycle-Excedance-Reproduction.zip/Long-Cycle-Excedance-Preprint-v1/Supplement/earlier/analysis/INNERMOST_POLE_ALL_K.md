# The innermost pole range for every k >= 6

**Lemma.** For integers n>=k>=6 and 0<=s<=sqrt(k), set
t=-exp(-s) and phi=n atan(pi/s), continuously at s=0.
At any phase witness with |cos(phi)|=1 the sign of E_(n,k)(t)
is the sign of cos(phi). At any zero in this range,
sin(phi) is nonzero and the sign of E_(n+1,k)(t) is the sign
of -sin(phi). The conclusions are local and require no finite sweep.
They do not settle the rest of the central interval.

Use the exact cycle pole formula and partial-fraction prefix
identity from GROWING_K_REDUCTION.md, EXPLICIT_LARGE_K_LOWER_WEDGE.md
and CROSS_ANCHOR_LARGE_K.md. Write p_i=s+i_unit(2i+1)pi,
rho=|p_0|, q_i=rho/p_i, u=s/rho, v=pi/rho, and
h_N=rho^N E_(N,k)(t)/(N!(1+exp(-s))^N).
Let g(z)=exp(sum_(a>=k) z^a/a)=sum_a d_a z^a,
delta=(1-z)(g-1), and dtilde_m=d_m for m>=k and 0 otherwise.
The recurrence m d_m=sum_(j=0)^(m-k) d_j gives
1/(2k-1)<=d_m<=1/k for m>=k by induction, with initial values
1/m for k<=m<2k. The difference relation
m delta_m=d_(m-k)-d_(m-1) gives |delta_m|<=1/(km) for m>k.
Also ||delta||_1<2/k: the first coefficient is 1/k, the absolute
sum from k+1 to 2k-1 telescopes to 1/k-1/(2k-1), and the relation
m delta_m=-sum_(j=m-k+1)^(m-1) delta_j for m>=2k bounds the entire
remainder by half the absolute tail from k+1 onward. This last
comparison holds for each finite prefix first.

At anchor i put B_i=prod_(j!=i)(1+delta(q_j z)/(1-q_j/q_i))-1.
The exact old-row mixed term is sum_(i,c) q_i^(n-c)
dtilde_(n-c)[z^c]B_i. The exact mixed part of h_(n+1)-u h_n is
sum_(i,c) (q_i-u)q_i^(n-c)dtilde_(n+1-c)[z^c]B_i.
The prefix identity includes the c=n+1-k contribution because the
support-size-at-least-two complete-homogeneous partial fraction
at degree -1 vanishes. These formulas follow first with finitely
many poles and then by absolute convergence, also justified by
the bounds below. Norms are absolute coefficient sums.

## Uniform small-s lattice and amplitude bounds
For upper-half levels l>=1 the ratio squared is
(1+4pi^2 l(l+1)/(s^2+pi^2))^(-1). Its (k-1)/2 power is bounded by
the value at s^2=k. That bound decreases in k: for A>0,
the derivative of (k-1)log(1+A/(k+pi^2)) is positive using
log(1+x)>x/(1+x). Thus the weighted upper-half far sum at power k-1
is bounded by the k=6 comparison
    sum_(l>=1) (2l+1)|q_l|^(k-1)
      < 3.6 sum_(l>=1)(2l+1)^(-4) <= 3.6(1/81+1/162)<.067.
Here (1+6/pi^2)^(5/2)<(5/3)^(5/2)<3.6, and the decreasing-function
integral is from 1 to infinity after the first term. The corresponding
unweighted sum is <.067/3. Also rho/(pi k) decreases in k at s^2=k
and is <.216 by checking k=6 and pi^2>9.

The exact factor denominator satisfies
1/|1-q_j/q_i|=|p_j|/(2pi |i-j|).
Thus the logarithm of the elementary product majorant
1+||B_i||_1 is at most (rho/(pi k)) sum_(j!=i) |q_j|^(k-1)/|i-j|.
At i=0 or -1 this implies ||B_i||_1< exp(.226)-1<.255, using just
the other primary pole and the two far halves. At any other anchor
the bound ||B_i||_1<exp(.442)-1<.56 follows using both primary poles
and both far halves. The product norm bounds hold without taking a
complex logarithm. They follow from the product of 1+factor norms.

## Witnesses and next-row signs
Normalize the value by 2d_n and, for n>=2k-1, normalize
h_(n+1)-u h_n by 2v d_(n+1). In either unit each primary mixed
error is bounded (after combining the conjugate pair) by
2*.255=.51 because dtilde/d_N<2 and |q_0|=1.
At a nonprimary level the ratio |q_i-u|/v<=2l+1:
its square is (pi^4+s^2 y^2)/(pi^2(s^2+y^2)) with |y|=(2l+1)pi.
The mixed prefix uses n-c>=k-1 and the diagonal has exponent n.
Consequently the outer errors of diagonal plus mixed terms are
<.048 in the value unit and <.143 in the centered unit, by bounding
each lattice with multiplier 1+2*.56. The centered diagonal also
has u(d_(n+1)-d_n) sum_i q_i^n. Its ratio in centered units is bounded by
    (s/pi) ((2k-1)/(k(n+1))) (1+.067/3) < .14
using n>=2k-1 and s<=sqrt(k), k>=6.

The resulting value differs from cos(phi) by less than .558, and
the centered value differs from -sin(phi) by less than .793. For
n<2k-1 both rows have no mixed terms; instead normalize each row
by its own d_N, then subtract u times the normalized old row. The
diagonal mismatch is absent in these units and the same bounds hold.
The witness sign now follows. At an old zero |cos(phi)|<.558, and
.558^2+.793^2<1 implies |sin(phi)|>.793. The subtracted old row
is zero there, and division by the positive units preserves signs.
This proves the local assertion. Exact arithmetic margins are in
check_innermost_pole_all_k.py.

## Scope
This removes the large-k requirement uniformly for 0<=s<=sqrt(k),
equivalently -1<=t<=-exp(-sqrt(k)), for every k>=6. By reciprocity
one can reflect the corresponding interval across -1 if desired.
There is no conclusion about uniqueness in a bracket, all roots
of a row, or about k>=6 outside the specified s range.
