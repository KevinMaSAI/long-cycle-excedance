"""Verify every exact finite transition (2k-1,2k), 3<=k<64."""
from check_onset_strip import gamma_rows, test
from check_interlacing_general import euler, rows
from math import comb
from time import perf_counter
if not __debug__: raise RuntimeError("run without -O")
start=perf_counter()
A=euler(125)
for k in range(3,64):
    # Independently confirm the two-cycle decomposition used in the proof.
    expected=[0]*(2*k+1)
    for j,c in enumerate(A[2*k-1]): expected[j+1]=c
    for j,c in enumerate(A[k-1]):
        for h,b in enumerate(A[k-1]):
            expected[j+h+2]+=(comb(2*k,k)//2)*b*c
    R=rows(2*k,k)
    assert R[2*k]==expected
    assert R[2*k-1]==[0]+A[2*k-2]+[0]
    test(k,2*k-1,gamma_rows(k,2*k))
    if k%10==0: print("PASS through k",k,flush=True)
print("PASS all 61 transition pairs, k=3..63; seconds",perf_counter()-start,flush=True)

