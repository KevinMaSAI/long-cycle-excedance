from fractions import Fraction as Q
from math import isqrt, factorial
D=2**48
def down(q): return Q((q*D).__floor__(),D)
def up(q): return Q((q*D).__ceil__(),D)
def exp_bounds(x):
    term=ans=Q(1)
    L=max(64,2*int(x)+4)
    for m in range(1,L+1):
        term*=x/m
        ans+=term
    return ans,ans+term*x/(L+1)/(1-x/(L+2))
def mul(i,j):
    z=[x*y for x in i for y in j]
    return min(z),max(z)
def horner(c,w):
    ans=(0,0)
    for a in reversed(c):
        l,h=mul(ans,w);ans=l+a,h+a
    return max(abs(ans[0]),abs(ans[1]))
from sys import argv
def polys_to(d):
    P=[1]
    for m in range(2,d+1):
        yield m,P
        H=[(j+1)*a for j,a in enumerate(P)]
        if m%2:
            H.append(0)
            for j,a in enumerate(P): H[j+1]-=(4*j+6)*a
        P=H
def radius(s):
    r2=s*s+10
    return r2,Q(isqrt((r2*D**2).__floor__())+1,D)
def tail(d):
    for t in range(max(d+1,4),10*d+100):
        E=exp_bounds(Q(t))[0]
        r2,r=radius(Q(t))
        if E>2**(d-1) and sum((Q(4,3)**m+1)*r2**(m//2)*r**(m%2)/factorial(m) for m in range(2,d+1))<E/8:
            return t
    raise AssertionError('tail not located')
def bulk(d):
    t=tail(d)
    step=32
    pp=list(polys_to(d)); mm=[(m,c,(Q(4,3)**m+1)/factorial(m)) for m,c in pp]
    qm=[(down(1/b),up(1/a)) for a,b in (exp_bounds(Q(i,step)) for i in range(t*step+1))]
    u_max=Q(0)
    n_min=Q(2*(t*t+10),9)
    for i in range(t*step):
        ql,qh=qm[i+1][0],qm[i][1]
        w=(ql/(1+ql)**2,qh/(1+qh)**2)
        x=(1-ql)/(1+ql)
        r2,r=radius(Q(i+1,step))
        u=sum(c*w[1]*horner(P,w)*x**(m%2)*r2**(m//2)*r**(m%2) for m,P,c in mm)
        u_max=max(u_max,u)
        if i>=9*step: n_min=max(n_min,4*u*(2*r2+72)/144)
    return t,u_max.__floor__()+1,n_min.__floor__()+1
def certify(d):
    t,um,n_min=bulk(d)
    x=max(15,isqrt(n_min))
    while True:
        n=x*x
        s=Q(5*x,2); E=exp_bounds(s)[0]
        A=s/d-Q(1,4)
        a,r=radius(s)
        if (n>=n_min and s>=t and s>=2*d and n>Q(4*d,5)**2 and A>0 and exp_bounds(A)[0]>Q(3*(n+1),d)
            and exp_bounds(Q(n,32)-Q(3,2))[0]>n+1 and 170*n*Q(11,4)**um*Q(20,23)**n<Q(1,100)
            and sum(Q((n+1)**m,factorial(m)) for m in range(1,d+1))<E/200
            and 1+sum(a**(m//2)*r**(m%2)/(3*factorial(m)) for m in range(2,d+1))<E/100
            and exp_bounds(Q(n,20))[0]>100*n):
            print(f'k={d+1} N={n} (tail s={t}; U<{um}; radial minimum {n_min})',flush=True)
            break
        x+=1
if not __debug__: raise RuntimeError('Run without -O')
for k in (map(int,argv[1:]) if len(argv)>1 else range(8,14)):
    certify(k-1)
