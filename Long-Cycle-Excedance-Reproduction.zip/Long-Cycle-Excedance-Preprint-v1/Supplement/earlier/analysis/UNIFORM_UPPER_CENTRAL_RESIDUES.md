# Uniform actual farther-residue bound on the upper central subrange

Let k>=64, d=k-1, n>=128, 12 sqrt(d)<=s<=(7/2)sqrt(n), q=exp(-s), p_l=s+(2l+1)pi i, rho=|p_0|. For any circle containing the primary poles and with R<=rho(1+1/d), the absolute sum of all its farther conjugate-pair contributions is <11/40 in the B and Bv normalizations of ALL_N_LARGE_K_BRIDGE.md. This is an explicit uniform bound for the actual restricted-polynomial residues, not merely for the unperturbed ones. It does not bound the circular integral.

Use the exact pole cancellation identity
    G_s(p_l)-G_s(p_0) = -Phi(p_l)+Phi(p_0) -(p_l-p_0)q/(1+q),
where Phi(z)=sum_(r>=1) F_d(rz)/r and F_d(z)=exp(-z)sum_(j=0)^d z^j/j!. Termwise differentiation is permitted on compact subsets of Re(z)>0, since d is fixed and polynomial factors in r are dominated by exponential decay. Since F_d'(z)=-exp(-z)z^d/d!, at 0<=y<=Y
    |Phi'(s+iy)| <= exp(d Y^2/(2s^2)) (1/s+1/sqrt(2 pi d)).
In fact, pull out (1+Y^2/s^2)^(d/2) from sum_(r>=1) exp(-rs)(rs)^d/d!. The latter lattice sum is at most its integral with mesh s plus the maximum, by unimodality and superlevel interval counting: the integral is 1/s, and the maximum is at most 1/sqrt(2 pi d) by Stirling. This proves the derivative bound with no asymptotic threshold beyond the given assumptions.

Integrate on the vertical segment from p_0 to p_l. The absolute exponent in the residue modulus ratio is at most
    2 pi l [ exp(d((2l+1)pi)^2/(2s^2)) (1/s+1/sqrt(2 pi d)) + q ].
Here 1/s+1/sqrt(2 pi d)<5/79 and q<1/10000, since s>=12sqrt(d), d>=63. For l=1 the exponential power is <=5/16, so the whole bound is <9/16. For any enclosed pole use |p_l|<=rho(1+1/d), which gives d((2l+1)pi)^2/(2s^2) <= 1+1/(2d)+pi^2(1+1/d)^2/288 <21/20. The same expression is then <(6/5)l. The factor exp(-ia(y_l-pi)) has modulus one and has no effect on these bounds.

For the radial factor, X=4pi^2 l(l+1)/rho^2<1/30 for each such pole, so log(1+X)>=(30/31)X. Since rho^2<=(49/4)n+10, n>=128 and pi>157/50, we get (n+1) log(1+X)/2 >=(3/2)l(l+1). Including the centered multiplier bound 2l+1, the absolute total from farther pairs is no greater than
    3 exp(-39/16) + sum_(l>=2) (2l+1) exp((6/5)l-(3/2)l(l+1)).
The series starts at 5 exp(-33/5) and has successive ratio at most (7/5)exp(-39/5)<1/10. Therefore the total is below 11/40, as the rational replay confirms.

No restriction on n/k is used. The remaining jobs for a uniform full proof include a sufficient circular integral bound and the perturbations on s<12 sqrt(k-1), then handling transitions/stitching there. The radius may require a different geometry argument in those jobs. No conclusion about an entire polynomial is asserted solely from this residue bound.

