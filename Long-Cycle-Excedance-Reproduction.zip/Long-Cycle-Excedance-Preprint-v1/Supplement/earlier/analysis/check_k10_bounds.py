from fractions import Fraction as Q
from math import isqrt, factorial
D=2**48
def down(q): return Q((q*D).__floor__(),D)
def up(q): return Q((q*D).__ceil__(),D)
def exp_bounds(x):
    term=ans=Q(1)
    for m in range(1,65):
        term*=x/m
        ans+=term
    return ans,ans+term*x/65/(1-x/66)
def mul(i,j):
    z=[x*y for x in i for y in j]
    return min(z),max(z)
def horner(c,w):
    ans=(0,0)
    for a in reversed(c):
        l,h=mul(ans,w);ans=l+a,h+a
    return max(abs(ans[0]),abs(ans[1]))
polys=[[1],[1],[1,-6],[1,-12],[1,-30,120],[1,-60,360],[1,-126,1680,-5040],[1,-252,5040,-20160]]
step=64
qm=[tuple((down(1/b),up(1/a))) for a,b in (exp_bounds(Q(i,step)) for i in range(23*step+1))]
high=[Q(0)]*5
for i in range(23*step):
    ql,qh=qm[i+1][0],qm[i][1]
    w=(ql/(1+ql)**2,qh/(1+qh)**2)
    x=(1-ql)/(1+ql)
    r2=Q(i+1,step)**2+Q(22,7)**2
    r=Q(isqrt((r2*D**2).__floor__())+1,D)
    U=sum(((Q(5,3)**m+1)*w[1]*horner(c,w)*x**(m%2)*r2**(m//2)*r**(m%2)/factorial(m) for m,c in enumerate(polys,2)))
    j=sum(i>=a*step for a in (3,8,12,18))
    high[j]=max(high[j],U)
assert all(a<c for a,c in zip(high,[65,60,54,22,2])),list(map(float,high))
assert sum((Q(5,3)**m+1)*539**(m//2)*24**(m%2)/factorial(m) for m in range(2,10))/exp_bounds(Q(23))[0]<Q(1,8)
assert 144*Q(144,148+72)>60 and 144*Q(144,308+72)>54 and 144*Q(144,668+72)>22 and 144*Q(72,539+72)>2
assert Q(576*9,4*539)>Q(1,2)
assert 144*576*Q(11,4)**65*Q(2,3)**576<Q(1,100)
assert sum(Q(1,576**(9-m)*factorial(m)) for m in range(1,10))<Q(1,350000)
assert Q(577**9,350000)/exp_bounds(Q(60))[0]<Q(1,200)
assert exp_bounds(Q(32,5))[0]>577 and Q(5*24,18)-Q(32,5)>Q(1,4)
assert 2*Q(32,5)+3<Q(24**2,16)
assert exp_bounds(Q(28))[0]>57600
assert (1+sum(Q(61**m,3*factorial(m)) for m in range(2,10)))/exp_bounds(Q(60))[0]<Q(1,100)
print('PASS: k=10 rational cutoff 576 margins')
