# k=7 execution and independent audit

Result: every E_(n,7), n≥7, has simple real roots, and adjacent quotients by t strictly interlace. The all-k conjecture still has an unchecked smaller-k region, starting at k=8.

Analytic n≥256: K7_INTERLACING.md. Exact rational comparison constants: python -B check_k7_bounds.py, PASS. The proof uses the exact g_6 formula, contour modulus separation for R∈[3ρ/2,5ρ/3], and different farther-residue estimates on s∈[3,8], [8,16], and [16,3√n]. It treats the zero edge moment separately (split √n≤18 from √n>18). The ordinary and centered adjacent estimates are both covered. The same first/last phase ordering and full reciprocal root count as in the preceding proof files apply.

Finite pairs 7..255: python -B check_k7_dyadic.py 255, PASS in 228.259 seconds on LAPTOP-P5KH33SJ. The base row has chart polynomial 1−54x+189x², with two disjoint sign-changing brackets split at 1/4. Subsequent chart brackets are exact dyadic rational sign witnesses, using the method audited in K6_EXECUTION_LOG.md; no numerical root approximation supplies evidence. The overlap is row 256. Additional exact check: python -B check_central_cutoff_four.py, PASS for the separate reusable 4√n lemma (not required in the k=7 proof).

Reverse audit: recomputed the sign of g_6, denominator radius rules, normalization of the pole comparison, each radial reserve budget, the q-scaled moment estimates, parity and the degree stitch. No outside review. Aggregate model usage unavailable. No public contact, publication, expense or deletion.
