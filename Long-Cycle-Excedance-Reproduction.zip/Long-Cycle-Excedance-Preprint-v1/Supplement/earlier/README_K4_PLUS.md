# Long-cycle excedances, research extension

- K4_INTERLACING.md: fixed k=4, all n≥4, simple real roots and strict consecutive interlacing after division by t.
- K5_INTERLACING.md: fixed k=5, all n≥5, same results.
- EVENTUAL_ALL_FIXED_K.md: for every fixed k≥4 a fully explicit (very conservative) N(k) and proof for n≥N(k), in addition to the single-cycle ranges. This does not settle all (n,k).
- PROOF.md, INTERLACING.md, INTERLACING_REPLAY.md: earlier k=3 proof and the reusable root-sign and signed remainder lemmas.
- SOURCES.md: primary sources and previously invalid shortcuts. Rechecked SymCat and Davis's research status for the extension, still no all-k proof found in the sources searched. No external publication or peer review.

Exact finite replays (Python 3.9+, standard library, do not use -O):
    python -B check_interlacing_general.py 127 4
    python -B check_interlacing_general.py 127 5
Optional k=3:
    python -B check_interlacing_general.py 63 3

Research notes: the k=4 cubic perturbation helps the farther-pole estimates and makes the edge moments nonnegative. The k=5 quartic can have either sign; using a pole-avoiding radius instead of the square and splitting the quartic residue comparison into three ranges gives a workable threshold. For every fixed k, bounding the deleted cycle generating polynomial in modulus gives eventual dominance but its constants grow with k. A possible remaining route is to work directly with the truncated log at each pole and analyze oscillatory convolutions, so that k can grow with n. This route is exploratory and is not used as a theorem.

