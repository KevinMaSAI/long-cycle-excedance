# A pole-product reduction for the unsolved growing-k range

Here is an exact structural identity, not a proof of interlacing in the remaining range. Fix s≥0, q=e^(−s), and let P_s={s+(2j+1)π i : j∈Z}. Define
    g_k(w)=exp(sum_(m≥k) w^m/m),  |w|<1.
Then for k≥2
    sum_(n≥0) E_(n,k)(−q) z^n/[n!(1+q)^n]
         = product_(p∈P_s) g_k(z/p)            (|z|<min |p|).
Proof: the scaled Eulerian generating function is (1+q)/(e^(−z)+q). Its logarithmic derivative is 1/(1+q e^z), whose poles p have residue −1. For fixed s and every m≥2, integrate this derivative divided by z^m over the square of half-side L=2π j, taking L→∞ past s+1. The derivative is bounded uniformly on the square boundaries: the horizontal denominator equals 1+q e^x, and on the vertical sides the reverse triangle inequality gives a uniform positive lower bound for large L. The integral tends to zero since m≥2. The residue at zero equals the coefficient of z^(m−1) in the derivative, while other residues are −p^(−m). Hence the coefficient of z^m in the untruncated Eulerian logarithm is (sum_p p^(−m))/m. Deleting the degrees below k gives the identity by summing the convergent log expansions; sum_p |p|^(−k)<∞, so the exchanges are normally convergent on compact subsets of the disc. The normalized constant term on both sides is 1.

The factor g_k is independent of s, has nonnegative coefficients, and for k≤n<2k its nth coefficient is exactly 1/n. In the range n comparable to k, mixed contributions from the nearest conjugate factors may be amenable to oscillatory-sum estimates more uniform than the global exponential bound in EVENTUAL_ALL_FIXED_K.md. No required sign estimate for this range is yet established. In particular, absolute triangle bounds on the mixed terms alone do not automatically certify adjacent-row signs.

