# Second two-cycle transition, all k

**Theorem.** For every k≥3, E_(2k,k)/t strictly interlaces E_(2k+1,k)/t. Hence the initial proved range for the Alexandersson excedance conjecture is k≤n≤2k+1 for every k≥3. All zeros in these rows are simple, including the common zero at t=0 before taking the quotient. The proof covers k≥64 analytically and 3≤k≤63 with exact integer certificates.

## Normalization and central estimates

Use the pole notation of FIRST_TRANSITION_ALL_K.md. At t=−exp(−s)=−q, set
    S_j= sum_(l∈Z)(s+(2l+1)πi)^(−j),   j≥2,
    n=2k,   D=n−1.
The log generating series has coefficients S_j/j for j≥k, so the rows n,n+1 are respectively positive multiples of
    P=S_n+S_k²/k ,
    Q=S_(n+1)+a_k S_k S_(k+1),  a_k=(2k+1)/(k(k+1)).
Indeed the larger row has only the cycle types (2k+1) and (k,k+1). Its exact polynomial form is t A_(2k)+binom(2k+1,k)t² A_(k−1) A_k. In terms of Q and P the positive multiplicative factors are (n+1)!(1+q)^(n+1)/(n+1) and n!(1+q)^n/n respectively.

Assume k≥64. Let ρ=√(s²+π²), θ=atan(π/s) (π/2 at s=0), φ=nθ, u=s/ρ², v=π/ρ². In 0≤s≤3√D the farther-pole estimates of FIRST_TRANSITION_ALL_K.md apply to S_n/S_(n+1) with index n instead of 2k−1: the contribution of all farther pairs has magnitude less than 1/4 in the following two relative units:
    S_n/(2ρ^(−n)) = cosφ + error ,
    (S_(n+1)−u S_n)/(2vρ^(−n)) = −sinφ + error .
For clarity, the multiplier for a farther pole is |(1/p_l−u)/v|≤2l+1; after Bernoulli the weighted sum is bounded by sum_(l≥1)(2l+1)/(1+c l(l+1))^4 with c=nπ²/(2ρ²)>1/2. Its bound 3/16+5/256+40(3^(−7)+3^(−6)/6) is below 1/4.

For the lower index k, the same method has c=kπ²/(2ρ²)>1/4, because ρ²≤9(2k−1)+π²<2kπ². It gives
    |S_k| < (13/5)ρ^(−k),
    |S_(k+1)−u S_k| < (9/4)·2vρ^(−k).
For the unweighted sum of farther pairs in units 2ρ^(−k), the bound is
    (2/3)^4+(2/5)^4+256(3^(−8)+3^(−7)/7)<3/10 .
For the weighted sum in units 2vρ^(−k), it is
    3(2/3)^4+5(2/5)^4+640(3^(−7)+3^(−6)/6)<5/4 .
Both use l(l+1)≥l² past the first two terms and, in the weighted case, 2l+1≤(5/2)l. The primary contribution adds at most 1 in those respective units.

Consequently P in units 2ρ^(−n) differs from cosφ by less than 1/4+169/(50k)<31/100. At a zero of P, |sinφ|>19/20 (since √(1−(31/100)^2)>19/20), so the central single-cycle difference above has sign −sinφ and magnitude greater than 7/10 in units 2vρ^(−n). To compare at this same zero, subtract uP from Q before bounding:
    Q−uP=(S_(n+1)−uS_n)+a_k S_k(S_(k+1)−uS_k)+(a_k−1/k)uS_k² .
At a root of P, we have the stronger bound |S_k|<(111/50)ρ^(−k). Indeed cos²(kθ)=(1+cosφ)/2<131/200<(81/100)², and the unweighted farther relative error is <3/10. Since 0<a_k<2/k and 0<a_k−1/k<1/k, the total correction in units 2vρ^(−n) is bounded above by
    999/(100k) + (111/50)^2 ρ/(2πk) < 7/10 .
Here u/v=s/π≤ρ/π, ρ²≤18k+1, π>3, the bound decreases with k, and at k=64 it holds even replacing √(18·64+1) by 34. This proves that Q has sign −sinφ at all central zeros of P. Also P has sign (−1)^j at central witnesses φ=jπ.

## Edge estimates

Let M=ceil(√D/3), S=D/M, and V_r=q^r r^D for positive integers r. Since √D≥11, M≤(14/33)√D and M+1≤(17/33)√D. As shown for the first transition, at s=D/m the successive outward ratios about m are at most exp(−D/[2M(M+1)])<1/9. At D/(m+1)≤s≤D/m the same bound applies to the outward ratios starting at m on the left and m+1 on the right; this uses the log ratio inequalities stated in FIRST_TRANSITION_ALL_K.md and their monotonicity with the index. The numerical comparison follows from D/[2M(M+1)]≥1089/476>9/4 and exp(9/4)>9, as in the first transition proof.

Define w=k−1,
    β=(2k−1)/k · binom(2w,w)/4^w ,
    W_r=sum_(i=1)^(r−1) (4i(r−i)/r²)^w .
The absolutely convergent Eulerian series (j−1)! S_j=sum_(r≥1)(−q)^r r^(j−1) gives exactly
    (n−1)! P = sum_(r≥1)(−1)^r V_r [1+β W_r/r],
    n! Q     = sum_(r≥1)(−1)^r V_r [r+α β W_r],   α=(2k+1)/(k+1).
To verify the second, group the product S_k S_(k+1) by the total of its two series indices. The extra factor compared to the square S_k² is one index, whose weighted average at total r is r/2 by symmetry. Taking account of both row factorials and the coefficient a_k, the new quadratic coefficient at each r is therefore αr times its old value. This exact relation is why the two double-cycle terms can be bounded after, rather than before, subtraction.

The Gaussian and central binomial bounds from FIRST_TRANSITION_ALL_K.md give W_r≤1+r√π/(2√w) and β≤2/√(3w+1)<3/20. Here w≥63, so √π/(2√w)<1/8; also (√π/2)M/√w<(9/10)(14/33)√(2+1/63)<11/20. Thus W_r≤31/20 for r≤M, and W_(m+1+h)≤31/20+h/8 when m<M. At an edge witness, P has sign (−1)^m: the main term has magnitude at least V_m in units (n−1)! P, while the others together have at most V_m·(2/8)[1+(3/20)(1+1/8)]<V_m.

Now take a zero of P in the pair interval with 1≤m<M, and put λ=m+1/2. Subtraction gives
    n!Q−λ(n−1)!P
        = sum_(r≥1)(−1)^r V_r [r−λ+β W_r(α−λ/r)] .
In the unperturbed part the central terms have combined magnitude (V_m+V_(m+1))/2 and common sign (−1)^(m+1). The outward tails cost at most
    (V_m+V_(m+1)) sum_(h≥1)(h+1/2)9^(−h)
      = (V_m+V_(m+1))·13/64.
For the perturbation, at r=m we have 0≤α−λ/m≤1 and at r=m+1 the multiplier is positive (use α≥3/2). Hence the r=m+1 perturbation has the target sign (−1)^(m+1) and can be dropped when bounding adverse terms. For the left tail r=m−h≥1, write α−λ/r=α−1−(h+1/2)/r; its absolute value is at most h+1/2. For the right tail r=m+1+h it is at most 2. Therefore the adverse contribution in units V_m+V_(m+1) is at most
    (3/20) max{(31/20)(1+13/64), (31/10)/8 + (1/4)(9/64)} < 19/64 .
The first bound combines the m term and the left tail in units V_m; the second bounds the right tail in units V_(m+1). Since the single-cycle main margin is 1/2−13/64=19/64, Q has the desired sign (−1)^(m+1).

## Stitch and finite proof

The stitching offset obeys |φ(S)/π−M|<1/8 using atan y between y−y³/3 and y, exactly as in FIRST_TRANSITION_ALL_K.md with n replacing N. In detail the offset lies between −nπ²M³/(3D³) and M/D, using n≤2D, π²<10, M≤(14/33)√D and √D≥11. The phase decreases strictly in s. Use the M edge witnesses and φ=jπ for j=M+1,...,k (the last at −1). They have alternating signs (−1)^j with j=m on the edge. The k−1 intervening roots in (−1,0), their reciprocals, and zero account for degree n−1, and are all simple. If φ(S) is slightly below Mπ, the bound |P/(2ρ^(−n))−cosφ|<31/100 excludes zeros on that extra short bridge. Thus every central bracket from j to j+1 has its root at jπ<φ<(j+1)π.

At each root on (−1,0), the derivative in t of E_(n,k) has the sign of the right endpoint witness. The matching estimates for Q give the opposite sign. The reciprocal identities transfer this strict opposite-sign comparison to the negative roots below −1, as in FIRST_TRANSITION_ALL_K.md. There is no root at −1 in this even row. The opposite signs give strict quotient interlacing and exhaust the next degree. The separate zero at zero is simple since the linear coefficient is 1.

Run python -B check_second_transition.py for the exact finite complement k=3,...,63. The script independently checks the explicit (k,k+1) formula against the insertion recurrence; the signed gamma remainder test is the exact certificate of INTERLACING_REPLAY.md. The next pair (2k+1,2k+2) is not proved here uniformly over k.

