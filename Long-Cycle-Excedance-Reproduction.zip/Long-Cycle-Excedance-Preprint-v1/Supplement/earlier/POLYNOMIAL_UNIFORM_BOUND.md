# A polynomial-size simultaneous range for the long-cycle excedance conjecture

Let E_(n,k)(t) enumerate excedances in permutations whose cycle lengths are all at least k. The following gives a simultaneous range for growing k. It does not settle the all-pairs conjecture.

**Theorem.** For every integer k≥4, put S0=32k log(2k). For all integers n≥ceil(1000 S0³), E_(n,k) has n−1 distinct real roots and the quotients E_(n,k)/t and E_(n+1,k)/t strictly interlace. Thus one may let k grow with n, subject to the displayed cubic-logarithmic bound. The cutoff replaces the previous exponential-in-a-power-of-k bound. Previously obtained complete cases and the single-cycle range also remain valid.

## 1. Notation and a bound for the exponential perturbation

For s≥0 set q=e^(−s), a=1/(1+q), δ=1−a, ρ=√(s²+π²), p=s+iπ, u=s/ρ², v=π/ρ², and d=k−1. In the notation of EVENTUAL_ALL_FIXED_K.md,
    H(z)=exp(−az+G_s(z))/(exp(−z)+q), h_n=[z^n]H,
    E_(n,k)(−q)=n!(1+q)^(n+1)h_n.
Here G_s(z)=sum_(m=2)^d g_m z^m is the negative of the deleted short-cycle terms of degrees 2 to d, in the scaled variable. In particular |g_m|≤q. Moreover,
    g_m=−(1/m)sum_(p_j) p_j^(−m),  p_j=s+(2j+1)πi, j∈Z.
The pole identity is proved in GROWING_K_REDUCTION.md: it follows by the residue theorem for the scaled Eulerian logarithmic derivative 1/(1+q e^z). Its terms are absolutely summable at m≥2.

In the region 0≤s≤S0, and for |z|≤(1+1/k)ρ, use
    |G_s(z)| ≤ e sum_(m=2)^d (1/m)(2+4ρ/(π√m)) ≤ 6k+8ρ ≤ 16 S0 .
For the first inequality, the sum of (ρ/|p_j|)^m over the two nearest poles is 2. The remaining sum is at most
    2 sum_(l≥1)(1+4π²l²/ρ²)^(−m/2)
    ≤ (ρ/π) integral_0^∞ (1+x²)^(−m/2) dx .
This follows from the integral bound for a decreasing positive function. The integral is at most 4/√m. For m=2,3 it is at most π/2; for m≥4 Bernoulli gives (1+x²)^(m/2)≥(1+(m/4)x²)^2, whose reciprocal integral is π/(2√m). Also (1+1/k)^m≤e<3, sum_(m=2)^d 1/m≤k and sum_(m≥2) m^(−3/2)≤2. Finally ρ≤S0+4≤(5/4)S0 and 6k≤S0 for k≥4.

In the region s≥S0, the square with half-side L=2π ceil(ρ/π) has |z|≤4(s+7). Throughout it
    |G_s(z)|≤d exp(−s) [4(s+7)]^d ≤ d exp(−s/2)<1/100.
Indeed 4(s+7)≤8s, and k log(8s)≤s/2 there. At s=S0 this last inequality follows from 8S0=256k log(2k)≤(2k)^8 and S0/(2k)=16 log(2k); beyond S0 the derivative on the left is k/s<1/2. The small constant follows from d≤k, S0≥64k and e>2.

## 2. Uniform bulk bounds

Assume n≥1000 S0³ and 0≤s≤3√n. With B=2|Res_p H|ρ^(−n−1), and
    φ=(n+1)atan(π/s)+πa−Im G_s(p),
we show the same two bulk error inequalities as in EVENTUAL_ALL_FIXED_K.md:
    |h_n/B+cosφ|<1/3;
    |(h_(n+1)−u h_n)/(Bv)−sinφ|<1/3.       (1)
The leading terms follow from the simple poles at p and its conjugate. The ratio of the extra pole multiplier 1/z−u to v has absolute value at most 2l+1 on p_l=s+(2l+1)πi. This is a consequence of the algebraic identity
    |(1/p_l−u)/v|²=((2l+1)² (s/π)²+1)/((s/π)²+(2l+1)²).
A farther pair contributes relative magnitude at most its multiplier bound times
    exp(Re G_s(p_l)−Re G_s(p))(1+4π² l(l+1)/ρ²)^(−(n+1)/2).
The linear exponential has the same modulus at all poles because their real parts are equal.

If s≥S0, use the square from Section 1. On its horizontal sides the denominator modulus equals q(1+exp(s−Re z)); on its vertical sides it is at least half this value. The latter follows from L−s≥π and the reverse triangle inequality. Also exp(a(s−Re z))≤1+exp(s−Re z). The contour errors are at most 16 n exp(1/50)2^(−n)<1/100 in both relative units: compare contour length 8L, minimum modulus L≥2ρ, and the multiplier bound (1/L+|u|)/v≤3ρ/(2π); use ρ≤4√n. The sum of farther pole-pair errors is at most (50/49) times
    sum_(l≥1)(2l+1)/(1+c l(l+1))^4 < 1/4,
where the displayed strict inequality is for the sum without 50/49, c=(n+1)π²/(2ρ²)>1/2, and the prefactor uses exp(1/50)≤50/49. For the sum apply Bernoulli to the fourth root of the reciprocal radial ratio, then bound the first two terms by 3/16 and 5/256 and the rest by 40(3^(−7)+3^(−6)/6). This gives (1) for s≥S0.

If s≤S0, choose a radius R∈[ρ(1+1/(2k)),ρ(1+1/k)] at distance greater than η=1/(4S0) from every pole. To justify the choice, consider the moduli of poles within η of the interval. They are below 2ρ, and their squared moduli at different positive imaginary levels are separated by at least 8π²; so any two distinct relevant moduli differ by at least 2π²/ρ>1/S0. The excluded intervals in radius therefore have length 2η, are disjoint and have positive gaps. They cannot cover the candidate interval, whose length ρ/(2k)>2η. Thus both primary poles are inside and none lies on the circle.

On this circle |e^(−z)+q|≥q(1+e^(s−Re z))/(100 S0). Indeed either |s−Re z|≥η/2, giving the ratio ≥tanh(η/4)≥η/8, or the distance in imaginary part from a nearest odd multiple of π is ≥η/2 and ≤π. In the latter case the ratio is at least exp(−η/4)sin(η/4)≥η/16. These small-argument inequalities follow from exp(x)≥1+x, exp(−x)≥1−x, and sin x≥x−x³/6. Hence |H|/|Res_p H|≤100 S0 exp(32 S0) on the circle by Section 1. The relative integral errors, weighted or not, are at most
    200 S0³ exp(32 S0−n/(4k)) < 1/100.
Use |z|=R, circumference 2πR, ρ≤(5/4)S0, extra factor divided by v at most 2ρ/π, and log(1+1/(2k))≥1/(4k). For the last inequality use S0≥k, n≥1000 S0³, giving exponent ≤32 S0−250 S0².

To bound farther residue pairs for s≤S0, the exponential numerator ratio is at most exp(32 S0). From the power (n+1)/2 in the radial part, reserve a power n/4 for the smallest positive radial increment 8π²/ρ². Since ρ²≤(25/16)S0², its logarithm obeys log(1+8π²/ρ²)≥1/(2S0²), using log(1+x)≥x/(1+x) and 8π²/ρ²≥1/S0². The global extra factor is therefore at most exp(32 S0−n/(8S0²))≤exp(−93 S0). The remaining power is at least n/4, so the same fourth-power Bernoulli sum applies with c=nπ²/(4ρ²)>1/2 (n≥1000 S0³). Thus the residue error is <1/4 here as well. This proves (1) with explicit bounds and without assuming phase monotonicity.

## 3. Uniform edge bounds and the stitch

Use M=ceil(√n/3), S=n/M as in the preceding proofs, so S≥2√n, S≤3√n, M≤(11/24)√n, and M+1≤(7/12)√n. We show the edge moment hypotheses (B) and the zero-mode bound of EVENTUAL_ALL_FIXED_K.md under the new n cutoff. For details of the resulting sign comparisons we refer to its Section 3, since those comparisons use only these hypotheses and the outward ratios of q^l l^n.

Put X=√n. We have
    log(n+1) ≤ X/(16k).
To verify, first evaluate the inequality at X=8S0=256k log(2k): log(X²+1)≤2log(2X)≤16log(2k), since 2X≤512k²≤(2k)^8. Above that point the log derivative 2X/(X²+1) is less than 1/(16k). Under the claimed bound on n, X is indeed at least 8S0.

For s≥S and l≥0, put T_j(l)=j![z^j] exp((l+δ)z+G_s(z)). The exact edge series is j!h_j=sum_(l≥0)(−q)^l T_j(l). For l≥1, 0≤j≤n+1, expanding the perturbations and bounding the factorial ratios gives
    |T_j(l)/l^j−1| ≤ exp(d(n+1)^d e^(−2X))−1<1/100.
Also differentiating the moment EGF and using this inequality gives
    |T_(n+1)(l)/T_n(l)−l| ≤ 2d²(n+1)^d e^(−2X)<1/100 .
These are the calculations of (B) in the preceding proof. Here (n+1)^d e^(−2X)≤e^(−X) by the displayed log bound, and d≤k, X≥8S0≥512k give both numerical bounds (the exponent inside the first exponential is <1/200).

For l=0 use the circle of radius exp(s/(2d)) on the moment EGF (not on H). Then for j=n,n+1, m≤M and V_m=q^m m^n, Cauchy's estimate yields
    |T_j(0)|/V_m ≤ exp(d+j log j−s(j/(2d)−m))≤ exp(−n).
Indeed M≤n/(4d), j log j≤nX/(8k), and s(j/(2d)−m)≥nX/(2d)≥nX/(2k), while d≤n and X≥512k. Including the factor M+2≤n gives <1/100. Thus all the edge sign inequalities of the preceding proof apply verbatim.

At the stitch S≥S0, exp(−S) and |G_S(p)| are below 1/100 each. The same atan estimates give |φ(S)/π−(M+1)|<1/8. At s=0 the phase is (n+2)π/2 because the odd-degree cycle terms vanish at t=−1. The first/last phase hit argument of EVENTUAL_ALL_FIXED_K.md now uses (1) and these edge signs. It counts all roots by reciprocal symmetry and shows E_(n+1,k)/E′_(n,k)<0 at every nonzero root of E_(n,k), which proves the theorem.

**What remains.** For k≥6, the theorem does not cover all pairs below this new threshold, including the region n comparable to k immediately above the first possible two-cycle rows. It is an all-k bound, not the full conjecture.

