# First two-cycle transition, uniformly in the minimum cycle length

**Theorem.** For every integer k≥3, E_(2k,k)(t) has only simple real roots, and E_(2k-1,k)(t)/t strictly interlaces E_(2k,k)(t)/t. Thus the conjecture, including every adjacent pair across the onset of two cycles, holds up to row n=2k for every k. This does not prove the pair (2k,2k+1) for unrestricted k.

The proof below is uniform for k≥64. A 61-case exact signed-remainder certificate covers 3≤k≤63. The statistic is excedance and the normalization is the same as PROOF.md.

## 1. Exact representation

Let N=2k−1 and D=2k−2=N−1. At t=−q=−exp(−s), s≥0, define
    p_l=s+(2l+1)πi  (l∈Z),    S_j=sum_l p_l^(−j) (j≥2).
The log-coefficient pole identity in GROWING_K_REDUCTION.md is absolutely convergent. In rows N and N+1 the normalized coefficients are precisely
    E_(N,k)(−q)/[N!(1+q)^N] = S_N/N,
    E_(N+1,k)(−q)/[(N+1)!(1+q)^(N+1)]
       = [S_(N+1)+S_k²/k]/(N+1).
Indeed the only partitions of the row size into lengths ≥k are (2k−1) and, in the next row, (2k) or (k,k). In the log of the EGF the length j term is S_j z^j/j; the new quadratic term is S_k²/(2k²). In the unscaled polynomial form this is
    E_(2k−1,k)=t A_(2k−2),
    E_(2k,k)=t A_(2k−1)+(1/2) binom(2k,k)t² A_(k−1)².

For s>0 we also have
    (j−1)! S_j = sum_(r≥1) (−q)^r r^(j−1).
This follows by expanding the scaled Eulerian log derivative 1/(1+q exp z) near z=0 and extracting its z^(j−1) coefficient.

Write Q=S_(N+1)+S_k²/k. We will prove Q has sign opposite to E′_(N,k)(t) at every nonzero negative root t of E_(N,k).

## 2. Central regime

Put ρ=√(s²+π²), θ=atan(π/s) (π/2 at s=0), v=π/ρ², u=s/ρ², and φ=Nθ. Assume 0≤s≤3√D and k≥64. The contribution of the nearest pair is 2ρ^(−N) cos φ to S_N and −2vρ^(−N) sin φ to S_(N+1)−u S_N. For a farther conjugate pair indexed by l≥1, its relative contribution in the first expression, and in the second relative to 2vρ^(−N), is bounded by
    (2l+1)(1+4π² l(l+1)/ρ²)^(−N/2).
For the first expression the factor 2l+1 is unnecessary, but harmless. For the second use
    |(1/p_l−u)/v|²=((2l+1)²(s/π)²+1)/((s/π)²+(2l+1)²)≤(2l+1)².
By Bernoulli the bound is at most (2l+1)/(1+c l(l+1))^4 with c=Nπ²/(2ρ²)>1/2: indeed ρ²≤9(N−1)+π². The sum over l≥1 is less than 1/4, by bounding the first two terms by 3/16 and 5/256 and the tail by 40(3^(−7)+3^(−6)/6).

To bound the perturbation, the absolute magnitude of S_k is less than (8/3)ρ^(−k). For this, use the same unweighted Bernoulli bound on the farther terms with c=kπ²/(2ρ²)>1/4 because ρ²<18k. The sum of the bounds over l≥1 is at most
    (2/3)^4+(2/5)^4+256[3^(−8)+3^(−7)/7] < 1/3 .
Adding the primary bound 1 in units 2ρ^(−k) proves the claimed estimate. Hence the contribution of S_k²/k in units 2vρ^(−N) is at most
    32ρ/(9π k) ≤ (32√2)/(9√k)<7/10 .
At a root of S_N, the first error estimate gives |cos φ|<1/4. The quantity |sin φ| is then >19/20. Thus S_(N+1) at that root has sign −sin φ and magnitude > (7/10)·2vρ^(−N). The perturbation does not change that sign. Also S_N has sign (−1)^j at every witness φ=jπ.

## 3. Edge regime

Let M=ceil(√D/3) and S=D/M. Write V_r=q^r r^D, r≥1. Since √D≥11, M≤(14/33)√D and M+1≤(17/33)√D. For a witness s=D/m, 1≤m≤M, both outward first ratios about index m are at most exp(−D/[2M(M+1)])<1/9. For the interval D/(m+1)≤s≤D/m, m<M, the analogous outward first ratios away from the pair (m,m+1) obey the same bound. These follow from the monotonicity of V_(r+1)/V_r=q(1+1/r)^D in r, the upper-ratio log inequality x−log(1+x)≥x²/[2(1+x)], and the lower-ratio inequality log(1−x)+x≤−x²/2. An empty left tail requires no bound. For a pair interval the left ratio is largest at s=D/m, and the right ratio largest at s=D/(m+1). The numerical bound follows from D/[2M(M+1)]≥1089/476>9/4 and e^(9/4)>(8/3)^2(1+1/4+1/32)>9. Further outward ratios are still smaller.

At a witness s=D/m the series for S_N therefore has sign (−1)^m because the other absolute terms sum to at most 2V_m/8. At a root in the pair interval consider
    (N)! S_(N+1)−(m+1/2)(N−1)! S_N
      = sum_(r≥1) (−1)^r(r−m−1/2)V_r .
The two dominant terms agree in sign, (−1)^(m+1), with combined magnitude (V_m+V_(m+1))/2. The other terms together have absolute value at most
    (V_m+V_(m+1)) sum_(h≥1)(h+1/2) 9^(−h)
    = (13/64)(V_m+V_(m+1)).
So (N)! |S_(N+1)| > (19/64)(V_m+V_(m+1)) at that root.

To control the exact double-cycle correction, apply the series for S_k twice, group terms with total index r, and disregard their signs. For w=k−1,
    |S_k²| ≤ (4^(−w)/(w!)²) sum_(r≥1) V_r W_r,
    W_r=sum_(a=1)^(r−1) (4a(r−a)/r²)^w.
Since 4a(r−a)/r²=1−(2a−r)²/r², compare W_r to the Gaussian sum on the integers. It is bounded by 1+r/√w: a unimodal Gaussian sum on the integers is at most its maximum plus its integral over the real line, and the integral here is r√π/(2√w)<r/√w. To see the sum-integral comparison, choose an integer maximizing the Gaussian values, compare each other value with the integral on the unit segment toward that integer (the endpoint toward the chosen integer has the larger value), and use real unimodality on each segment.

Since M/√w≤14√2/33<3/5, W_r≤8/5 for r≤M, and W_(m+1+h)≤8/5+h/7 for 1≤m<M (using √w≥√63>7). Summing the geometric bounds around m and m+1 gives
    sum V_r W_r ≤ ((8/5)(9/8)+(1/7)(9/64))(V_m+V_(m+1)).
Finally
    (N)!/(k(w!)²4^w) = ((2k−1)/k) binom(2w,w)/4^w
        ≤ 2/√(3w+1) < 2/13.
The central binomial bound follows by induction in w, starting at 0, because (2w+1)²(3w+4)≤(2w+2)²(3w+1). Therefore
    (2/13)((8/5)(9/8)+(1/7)(9/64)) < 19/64
shows (N)! S_k²/k is smaller than the edge lower bound for (N)! |S_(N+1)| at an S_N root. The sign of Q is again the same as that of S_(N+1).

## 4. Stitch and interlacing

At S=D/M, the phase satisfies |φ(S)/π−M|<1/8. Indeed atan y is between y−y³/3 and y for y≥0, so the offset lies between −Nπ²M³/(3D³) and M/D. Here N≤2D, π²<10 and M≤(14/33)√D with √D≥11, giving both bounds strictly within 1/8. Since S≤3√D, the central estimates apply from S down to s=0.

Label the edge witnesses by j=m=1,...,M and use φ=jπ for j=M+1,...,k−1 in the central region. These latter values exist uniquely because φ is strictly decreasing in s, φ(0)=Nπ/2 and the stitch offset is <1/8. Moving from t close to 0 toward −1 these witnesses have signs (−1)^j in sequence. Between consecutive ones there are k−2 distinct roots; reciprocal symmetry gives k−2 more, and there is a root −1 (N odd) and the root 0. This exhausts the degree N−1 and shows all are simple. The bulk root in the bracket from witness j to j+1 has φ strictly between jπ and (j+1)π. For the bracket starting at S, if φ(S)<Mπ, then on the extra bridge interval |cos φ|≥cos(π/8)>1/4 so S_N cannot vanish; this covers the only stitch ambiguity.

At an edge root the derivative of E_(N,k) has sign (−1)^m from the right endpoint in t, while Q has sign (−1)^(m+1). At a bulk root the derivative sign is (−1)^j from the right endpoint, and Q has the sign of −sin φ, which is opposite. At −1 the derivative sign is (−1)^(k−1) from the last witness and −sin(Nπ/2) is opposite. All these derivative-sign conclusions use simplicity and uniqueness within each bracket. Reciprocation transfers the strict opposite-sign ratio for the two rows from (−1,0) to (−∞,−1): for a nonzero root r, the ratio at 1/r is −r^(−3) times the ratio at r, and −r^(−3)>0. This follows by differentiating E_(N,k)(t)=t^N E_(N,k)(1/t) and using the same identity with grade N+1 for the next row.

Dividing both rows by t does not alter the quotient of the next row's value by the preceding derivative at a nonzero root. The opposite-sign comparison and the degree increase by one give one root of E_(N+1,k)/t in every inner interlacing interval and one in each outer interval, by the leading signs at ±∞. These account for the whole degree, and give strict interlacing including simplicity of the new row. Its separate zero at 0 is simple since the linear coefficient of E_(N+1,k) is 1.

## 5. Exact finite certificate

Run python -B check_first_transition.py, standard-library Python 3.9 or later, without -O. It independently confirms the displayed two-cycle decomposition against the insertion recurrence for k=3,...,63, then checks strict interlacing by the exact signed gamma remainder certificate explained in INTERLACING_REPLAY.md. Both rows have full gamma degree and the sign checks cover the reciprocal transformation and distinguish strict interlacing from mere weak interlacing. Earlier rows n<2k are single Eulerian cycles and obey strict quotient interlacing by the Eulerian derivative recurrence.

