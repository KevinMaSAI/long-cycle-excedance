# A growing strip inside the two-cycle regime

For the long-cycle excedance polynomials E_(n,k), write n=2k+d.

**Theorem.** For integers k≥3 and d≥0 satisfying 300(d+2)≤√k, E_(n,k) and E_(n+1,k) have simple real roots, and their quotients by t strictly interlace. Thus, for sufficiently large k, the already proved initial interval through 2k+1 extends simultaneously through row 2k+floor(√k/300)−1. The admissible additional width tends to infinity with k; this is not a result for the entire two-cycle band n<3k.

## 1. Two representations

As in FIRST_TRANSITION_ALL_K.md, put −q=−exp(−s)=t, with s≥0, p_l=s+(2l+1)πi, and S_j=∑_(l∈Z) p_l^(−j) for j≥2. Logarithmic coefficients of the scaled generating function are S_j/j for j≥k, and for s>0
    (j−1)! S_j = ∑_(r≥1)(−q)^r r^(j−1).
Here 2k≤n<n+1<3k; this follows immediately from the hypothesis (in particular k≥360000). Both rows therefore consist of one- and two-cycle contributions only. For a row N=2k+e, e=d or d+1, define
    B_N=(N/2)∑_(a=k)^(N−k) S_a S_(N−a)/(a(N−a)),
    P_N=S_N+B_N.
The factor 1/2 is necessary because the convolution lists the two cycles in order, even when their lengths are the same. By the exponential formula
    E_(N,k)(−q)=(N−1)!(1+q)^N P_N.
Grouping the two Eulerian series by total index r, and writing b=N−a, gives
    (N−1)! P_N = ∑_(r≥1)(−q)^r r^(N−1) (1+c_(N,r)),
    c_(N,r) = N(N−1)/(2r) ∑_(a=k)^(N−k) 1/(ab)
              · ∑_(i=1)^(r−1) Pr(Bin(N−2,i/r)=a−1).
This follows by using (N−1)!·N/[2a!b!]=binom(N,a)/2; after factoring r^(N−1), the powers of i/r and 1−i/r have sum N−2 and their binomial coefficient is binom(N−2,a−1). In particular these coefficients c are nonnegative, with c_(N,1)=0.

## 2. Uniform binomial estimate

For A=a−1, C=b−1 and m=A+C=N−2, let f(p)=Pr(Bin(m,p)=A). The maximum is at p0=A/m. Standard Stirling inequalities
    √(2πr)(r/e)^r ≤ r! ≤ exp(1/(12r))√(2πr)(r/e)^r   (r≥1)
give f(p0)≤exp(1/(12m))√[m/(2πAC)]≤2/√k, using A,C≥k−1, m/(AC)=1/A+1/C≤2/(k−1), and k≥3. Furthermore, for 0<p<1,
    log(f(p0)/f(p))=m ∫_(p0)^p (u−p0)/(u(1−u)) du ≥ 2m(p−p0)^2.
For p<p0 the orientation of the integral reverses and the numerator is negative, giving the same inequality; in either direction use u(1−u)≤1/4. Hence
    ∑_(i=1)^(r−1) f(i/r) ≤ (2/√k)(1+2r/√k).
Indeed the sum of Gaussian values on the integers is at most its maximum plus the integral (compare each other value with the neighboring unit interval toward a largest lattice value). The integral of exp(−2m(x/r−p0)^2) is r√(π/(2m))≤2r/√k, because m≥k.

Define B=9(d+2)/√k≤3/100. Since N≤3k and a,b≥k, the coefficient formula now implies, for both rows,
    0 ≤ c_(N,r) ≤ B(1/r + 2/√k).                         (A)

## 3. Edge witnesses and signed comparison

Put D=n−1, M=ceil(√D/3), S=D/M, and V_r=q^r r^D. We have M≤(14/33)√D≤√k and M+1≤(17/33)√D, since √D≥11 and D<3k. Exactly as in FIRST_TRANSITION_ALL_K.md, at s=D/m, 1≤m≤M, outward successive ratios of V_r from m are bounded by 1/9. On D/(m+1)≤s≤D/m the same ratios are bounded by 1/9 outward from the pair m,m+1. In detail, the first right ratio at s=D/m is at most exp(−D/[2m(m+1)]), from x−log(1+x)≥x²/[2(1+x)]. The first left ratio is at most exp(−D/[2m²]) from log(1−x)+x≤−x²/2. On the pair interval maximize the left ratio at s=D/m and the right ratio at s=D/(m+1); subsequent ratios decrease outward. The uniform exponent is ≥1089/476>9/4 and exp(9/4)>9.

At the edge witness s=D/m the principal term of (n−1)!P_n has sign (−1)^m and magnitude at least V_m. The others have magnitude at most (2/8)(1+3B)V_m<V_m by (A). At a root of P_n in a pair interval set λ=m+1/2 and subtract:
    n!P_(n+1)−λ(n−1)!P_n
      = ∑_(r≥1)(−1)^r V_r [r−λ + r c_(n+1,r)−λ c_(n,r)].
The two single-cycle central terms agree in sign, (−1)^(m+1), and have combined magnitude (V_m+V_(m+1))/2. The signed single-cycle tails have absolute sum at most (13/64)(V_m+V_(m+1)), using ∑_(h≥1)(h+1/2)9^(−h)=13/64. Use (A), m+1≤M≤√k and λ≤M to bound the absolute double-cycle multiplier by B[1+2r/√k+λ/r+2λ/√k]. For r=m,m+1 this is ≤(13/2)B. On the left r=m−h≥1 it is ≤(13/2+h)B (since λ/r=1+(h+1/2)/r); on the right r=m+1+h it is ≤(7+2h)B. Hence the total double-cycle error, relative to V_m+V_(m+1), is less than
    B(13/2 + 7/8 + 2·9/64) < 8B ≤ 24/100 < 19/64,
the remaining single-cycle margin. This proves sign (−1)^(m+1) for P_(n+1) at the P_n root.

## 4. Central witnesses and signed comparison

For 0≤s≤3√D put ρ=√(s²+π²), θ=atan(π/s) (π/2 at 0), φ=nθ, u=s/ρ², v=π/ρ². In units 2ρ^(−n) the value S_n is cosφ with error <1/4; in units 2vρ^(−n), S_(n+1)−uS_n is −sinφ with error <1/4. These are the primary plus farther conjugate estimates in FIRST_TRANSITION_ALL_K.md: the latter terms are bounded by the sum of (2l+1)/(1+c l(l+1))^4 for l≥1, with c=nπ²/(2ρ²)>1/2. Its bound is 3/16+5/256+40(3^(−7)+3^(−6)/6)<1/4.

For any length a≥k, the same power estimate in units 2ρ^(−a) bounds the unweighted farther sum using c=aπ²/(2ρ²)>1/6. Indeed ρ²≤9(3k−1)+π²<3kπ². The sum is at most
    (3/4)^4+(1/2)^4+1296(3^(−8)+3^(−7)/7)<1 .
It follows that |S_a|≤4ρ^(−a). Therefore
    |B_N| ≤ [24(e+1)/k] ρ^(−N),     N=2k+e, e=d,d+1.
In units 2ρ^(−n), the difference of P_n from cosφ is thus bounded by 1/4+12(d+1)/k<3/10. In particular the witnesses φ=jπ alternate in sign. At a P_n root, |cosφ|<3/10 and |sinφ|>19/20, so the single-cycle difference S_(n+1)−uS_n has magnitude >7/10 in units 2vρ^(−n) and sign −sinφ. In those units the remaining difference B_(n+1)−uB_n has magnitude at most
    12(2d+3)ρ/(π k) ≤ [8√28 (d+2)]/√k < 1/6,
using u≤1/ρ, π>3 and ρ²<28k. Thus P_(n+1) has sign −sinφ at each central root of P_n.

## 5. Stitch and degree count

At S=D/M the difference φ(S)/π−M lies between −nπ²M³/(3D³) and M/D by the elementary arctangent bounds; these are within ±1/8 using M≤(14/33)√D and √D≥11. Now take the edge witnesses labeled by m=1,...,M and the central witnesses with φ=jπ, j=M+1,...,floor(n/2). The phase is strictly decreasing in s, and φ(0)=nπ/2. The witnesses occur in decreasing order in t, with signs (−1)^j. The last witness is at −1 if n is even, and lies to its right otherwise. The floor(n/2)−1 intervening roots in (−1,0), their reciprocals, zero, and −1 when n is odd account for degree n−1 and imply simplicity. Here reciprocity E_(n,k)(t)=t^n E_(n,k)(1/t) follows by inversion of permutations without fixed points. The linear coefficient is 1, since a permutation with exactly one excedance must consist of a single cycle (each cycle of length ≥2 contributes at least one) and that cycle is uniquely determined: after the smallest entry, all other entries must appear in decreasing order.

For the first central bracket the possibly extra bridge with φ slightly below Mπ contains no zero because |cosφ|≥cos(π/8)>3/10. Thus a central root between witnesses j and j+1 has phase between jπ and (j+1)π. The derivative in t of E_(n,k) at each root in (−1,0) has the sign of the witness on its right. The above signs of P_(n+1) are opposite. At the odd-row root −1 the derivative has the sign of the last witness (−1)^((n−1)/2), opposite to −sin(nπ/2). Reciprocal symmetry transfers the strict ratio to roots below −1 with multiplier −r^(−3)>0, as in FIRST_TRANSITION_ALL_K.md. Since division by t preserves each such sign ratio, the alternating signs and the outer degree signs give strict interlacing of the quotients. The new row again has a simple root at zero. This finishes the simultaneous-strip proof.

The remaining middle interval is not uniformly covered. In particular, the strip does not give the unrestricted pair 2k+1→2k+2 for all k≥6: it proves that pair when 900≤√k, as well as many successive pairs for much larger k. Closing the gap for all k requires an additional argument.

