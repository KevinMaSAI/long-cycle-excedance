from math import comb, gcd, lcm
from itertools import permutations
from fractions import Fraction
from functools import reduce
import sys

def diff_step(p,n):
    q=[0]*(len(p)+1)
    for j,x in enumerate(p): q[j]+=j*x; q[j+1]+=(n-1-j)*x
    return q

def euler(N):
    A=[[1]]
    for n in range(1,N+1):
        q=[0]*n
        for j,x in enumerate(A[-1]):
            q[j]+=(j+1)*x
            if j+1<n: q[j+1]+=(n-1-j)*x
        A.append(q)
    return A

def times_into(q,p,r,c):
    for i,a in enumerate(p):
        for j,b in enumerate(r):
            if a*b: q[i+j]+=c*a*b

def recurrence(N,k,A):
    R=[[1]]
    for n in range(1,N+1):
        q=diff_step(R[-1],n)
        if n>=k: 
            if len(q)<n+1: q += [0]*(n+1-len(q))
            times_into(q,[0]+A[k-1],R[n-k],comb(n-1,k-1))
        R.append(q)
    return R

def egf(N,k,A):
    R=[[1]]
    for n in range(1,N+1):
        q=[0]*(n+1)
        for m in range(k,n+1):
            times_into(q,[0]+A[m-1],R[n-m],comb(n-1,m-1))
        R.append(q)
    return R

def brute(n,k):
    q=[0]*(n+1)
    for p in permutations(range(n)):
        seen=set()
        for i in range(n):
            if i in seen: continue
            j=i; m=0
            while j not in seen:
                seen.add(j); m+=1; j=p[j]
            if m<k: break
        else: q[sum(j>i for i,j in enumerate(p))]+=1
    return q

def gamma(p,n):
    r=list(p)
    g=[]
    for i in range(n//2+1):
        g.append(r[i])
        for j in range(n-2*i+1): r[i+j] -= g[-1]*comb(n-2*i,j)
    assert not any(r)
    return g

def trim(p):
    while p and p[-1]==0: p.pop()
    return p

def division(p,q):
    r=list(p); out=[0]*max(0,len(p)-len(q)+1)
    while r and len(r)>=len(q):
        d=len(r)-len(q); c=r[-1]/q[-1]; out[d]=c
        for j,v in enumerate(q): r[d+j]-=c*v
        trim(r)
    return trim(out),r

def primitive(p):
    if not p: return []
    v=lcm(*(q.denominator for q in p))
    p=[int(q*v) for q in p]
    d=abs(reduce(gcd,p))
    return [Fraction(q//d) for q in p]

def sturm(p):
    p=trim(list(map(Fraction,p)))
    dp=[j*p[j] for j in range(1,len(p))]
    if not dp: return [p],p
    a,b=p,dp
    while b: a,b=b,primitive(division(a,b)[1])
    sq,r=division(p,a)
    assert not r
    seq=[sq,[j*sq[j] for j in range(1,len(sq))]]
    while True:
        r=division(seq[-2],seq[-1])[1]
        if not r: return seq,sq
        seq.append(primitive([-v for v in r]))

def var(vals):
    x=[v>0 for v in vals if v]
    return sum(a!=b for a,b in zip(x,x[1:]))

def negative_count(p):
    s,q=sturm(p)
    return var(a[-1]*(-1)**(len(a)-1) for a in s)-var(a[0] for a in s),len(q)-1

N=int(sys.argv[1]) if len(sys.argv)>1 else 22
A=euler(N)
for k in (2,3,4):
    U,V=recurrence(N,k,A),egf(N,k,A)
    assert U==V
    for n in range(min(N,8)+1): assert U[n]==brute(n,k)
    if k==3:
        for n in range(3,N+1):
            assert U[n]==U[n][::-1]
            g=gamma(U[n],n)
            assert g[0]==0 and g[1]==1
            r,d=negative_count(g[1:]); assert r==d==len(g)-2
        for n in range(3,min(N,8)+1): print(n,U[n])
    if k==4 and N>=8:
        print("k4 gamma n4/7/8:",*[gamma(U[n],n) for n in (4,7,8)])
print("PASS",N)



