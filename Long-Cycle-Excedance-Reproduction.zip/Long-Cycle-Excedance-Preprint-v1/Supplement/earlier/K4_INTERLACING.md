# Minimum cycle length four: strict consecutive interlacing

We write E_(n,k) for the polynomial in the original question, and use the coefficient sign argument in INTERLACING.md (the preceding k=3 proof). Here we give and verify every required change for k=4.

**Theorem.** For every n≥4, E_(n,4) has n−1 distinct real zeros, including zero, and E_(n,4)/t strictly interlaces E_(n+1,4)/t. Thus both parts of the excedance conjecture hold for k=4.

## 1. New generating function

In the generating function of Section 1 of INTERLACING.md one more short cycle is forbidden. Its weight is t A_2(t)=t(1+t). Hence at t=−q=−e^(−s), the same normalization gives
    H(z)=exp(−az+bz²+cz³)/(exp(−z)+q),
    c=q(1−q)/(6(1+q)^3)≥0,
with a,b unchanged. Thus E_(n,4)(−q)=n!(1+q)^(n+1)h_n, h_n=[z^n]H. Degree, simple zero at zero, and reciprocal identity follow as before from the increasing n-cycle and inversion, for n≥4. For n≥128 we prove the two coefficient estimates of the preceding argument with the modified phase
    φ=(n+1)atan(π/s)+πa−2πbs−πc(3s²−π²).

## 2. Central estimates

Let ρ=√(s²+π²), p=s+iπ, u=s/ρ² and v=π/ρ². The residue factors and normalization B=2|Res_p H|ρ^(−n−1) are exactly as in the preceding proof, with the cubic included. Its chosen phase gives the same leading terms −B cosφ and Bv sinφ for h_n and h_(n+1)−u h_n. The cubic can only improve the relative residue magnitudes of the farther poles, since Re(s+i jπ)^3=s³−3s j²π² decreases as j increases (s≥0). Consequently the sum of farther pairs, weighted by (1/z−u)/v or by 1, is still <1/4 when s≤3√n, by the same Bernoulli estimate:
    3/16+5/256+40(3^(−7)+3^(−6)/6)<1/4.
There is no reliance on a hypothetical interlacing of the lag term.

For 0≤s≤3 use a rectangle with real edges ±X and imaginary edges ±Y, X=2ρ, Y=2π. The horizontal denominator estimate holds because Y is a multiple of 2π; on the vertical sides X−s≥π. The primary pair is inside and no pole is on the rectangle. We have X<9, Y<7, ρ/min(X,Y)<5/7 (use π>3). On the rectangle, |Re z³|≤max(X³,2Y³)≤729: for x≥0 the minimum of x³−3xy² over the whole positive half-line is −2|y|³ and the maximum on x∈[0,X] is at most X³; negate to treat x<0. At p we may use |Re p³|≤27+9π²<117. Since c≤1/60, b≤1/8,
    |H(z)|/|Res_p H| ≤ 2 exp((X²+π²)/8+(729+117)/60) < 2 exp(26).
For the bound on c put w=(1−q)/(1+q); then c=w(1−w²)/24, whose maximum on [0,1] is 1/(36√3)<1/60. For the denominator the same comparison exp(a(s−Re z))≤1+exp(s−Re z) holds as before.

Write D=min(X,Y) for the minimum contour modulus. Relative to B, the contour error is at most (2(X+Y)/π)exp(26)(ρ/D)^(n+1). For the weighted error divide the factor 1/z−u by v: the extra factor is at most (ρ/D+1)ρ/π <3. Both errors are <1/100: the resulting bound is at most 32·3^26(5/7)^128<1/100. This uses X+Y<16 and π>3.

For s≥3 use the square of the preceding proof, L=2π ceil(ρ/π). The denominator comparison is unchanged. Now
    |H|/|Res_p H| ≤ 2 exp[b(L²+π²)+c(2L³+3sπ²)] ≤ 2e^40 .
The bound |Re z³|≤2L³ was shown by the same cubic extremum; subtracting Re p³ gives an upper bound 2L³+3sπ². For 3≤s≤5, L≤4π; use b≤q/2, c≤q/6, s e^(−s)≤3e^(−3), π²<10, π³<32 and e³>20. The exponent is at most (85+64·32/3+15)/20<40. For s≥5, L<2s+13. Each term of
    e^(−s)[((2s+13)²+10)/2 + (2(2s+13)³+30s)/6]
is decreasing there, and the value at 5 is below 40 using e^5>128. So the relative contour errors are bounded as in Section 2 of the preceding proof by 16 n e^40 2^(−n), both <1/100 for n≥128 (use e<3 and verify at 128). This proves both inequalities (2) of that proof with the modified φ.

## 3. Edge estimates

For n≥128, use M=ceil(√n/3) and S=n/M exactly as before; M≤(11/24)√n, M+1≤(7/12)√n, and S≥(24/11)√n>24. With δ=1−a, set
    B_j(y)=j![z^j]exp(yz+bz²+cz³).
The exact alternating-series expansion remains j!h_j=sum_(l≥0)(−q)^l B_j(l+δ). For l≥1 and s≥S,
    l^n≤B_n(l+δ)≤(101/100)l^n,
    l≤B_(n+1)(l+δ)/B_n(l+δ)≤l+1/100.
Indeed all coefficients in the moment expansion are nonnegative. The extra contribution to the exponential upper bound for the first ratio is n³c: the complete exponent nδ+n²b+n³c is ≤n³q<1/200. The bound n³ exp(−(24/11)√n) decreases for n≥128, and at 128 use 128³(3/8)^24<1/200. For the next ratio differentiate the exponential, giving
    B_(n+1)(y)=y B_n(y)+2bn B_(n−1)(y)+3cn(n−1)B_(n−2)(y).
The nonnegative recurrence also gives B_j≥y B_(j−1). Since y≥l≥1, the ratio excess over l is at most q+qn+qn(n−1)/2≤n³q<1/100.

The l=0 calculation uses the coefficientwise bound
    B_j(δ) ≤ (δ+√(jb)+(j²c)^(1/3))^j
           ≤ (1+√j+j^(2/3))^j q^(j/3).
For each moment term with degrees 2h and 3g, compare the corresponding term of the multinomial expansion using (2h)!/h!≤j^h and (3g)!/g!≤j^(2g). For j=n,n+1, log(1+√j+j^(2/3))≤2log(√n+2)≤√n/2: the first inequality follows from j^(2/3)≤j and √(n+1)≤√n+1, and the second by the value at √n=11 and derivatives thereafter. The value at 11 follows from e^(11/4)>13, using e>8/3 and e^(3/4)>1+3/4+(3/4)²/2. Also m≤M≤n/12. Hence j/3−m≥n/4. For V_m=q^m m^n and j=n,n+1 we have B_j(δ)/V_m≤exp(−n√n/30), by the same final arithmetic as the preceding proof. Including the factor M+2≤n gives total l=0 error <1/100.
    
All other estimates for the edge depend only on n,m and q, not on c. In particular the geometric ratios of V_l=q^l l^n outward are bounded by 1/6. Together with the moment inequalities just established this proves the same edge signs: at s=n/m the sign of E_(n,4) is (−1)^m, and at its root between n/(m+1) and n/m the sign of E_(n+1,4) is (−1)^(m+1), from the same subtraction (n+1)!h_(n+1)−(m+1/2)n!h_n.

## 4. Phase and root order

The phase at s=0 is (n+2)π/2 since c=0 there. At S, the extra correction to φ(S)/π has absolute value ≤e^(−S)(3S²+π²)/6. The combined small exponential correction from a,b,c is at most (1+S+(3S²+10)/6)e^(−S)<1/100 for S≥24, by monotonicity and e>2. Thus the preceding stitch inequality |φ(S)/π−(M+1)|<1/8 still holds.

For completeness the new phase is decreasing for n≥128. We have
    |c′| = q|1−4q+q²|/[6(1+q)^4] ≤ q/6 .
The upper derivative bound after dividing by π is therefore −(n+1)/(s²+π²)+2s e^(−s)+(3s²+π²)e^(−s)/6. Multiplying the two positive terms by s²+π² gives a bound <49 for all s≥0: expand the polynomial and use π²<10 and max s^j e^(−s)=(j/e)^j ≤(j/2)^j. The negative term wins. Thus the same counting and sign assignments of Section 4 of INTERLACING.md apply. They show that every root is simple and real and that E_(n+1,4)(r)/E′_(n,4)(r)<0 at each nonzero root, ending the analytic proof.

## 5. Finite range

The standard-library command
    python -B check_interlacing_general.py 127 4
uses the exact insertion recurrence with t A_3(t)=t(1+4t+t²). It applies the signed gamma remainder check certified in INTERLACING_REPLAY.md. This checks the 124 consecutive pairs n=4,...,127, including (127,128). (Do not use Python -O.) The code verifies the input gamma expansions and signed remainders; it uses no approximation of any root.

Scope: all n≥4 at k=4. Higher k is addressed separately; this theorem alone says nothing about k≥5.

