# Three-cycle band and first four-cycle row

**Theorem.** For every integer k≥10^22 and 3k≤n≤4k−1, E_(n,k)(t) and E_(n+1,k)(t) have simple real roots and their quotients by t strictly interlace. Combined with TWO_CYCLE_BAND_AND_CUBIC_ONSET.md, the initial proved range for these k is k≤n≤4k. The bound is conservative. Neither the smaller-k gaps nor the rows beyond 4k are settled here.

## 1. Exact representations

Use the logistic poles p_l=s+(2l+1)πi, S_a=∑ p_l^(−a) for a≥2, t=−q=−exp(−s), and the scaled log generating coefficients S_a/a for a≥k. These were proved in GROWING_K_REDUCTION.md and FIRST_TRANSITION_ALL_K.md. Normalize a row of size N by writing E_(N,k)(−q)=(N−1)!(1+q)^N P_N. Its contribution from m allowed cycles is
    B_(N,m) = [N/m!] ∑_(a_1+...+a_m=N; a_i≥k) ∏_i S_(a_i)/a_i
            = [1/(m−1)!] ∑_(a_i≥k; sum=N) ∏_i S_(a_i) / ∏_(i<m) a_i.    (1)
The equality follows by N=∑ a_i and symmetry in the ordered lengths. In particular B_(N,1)=S_N. For n in the theorem P_n=∑_(m=1)^3 B_(n,m); at n+1 the only possible extra term is B_(4k,4)=S_k^4/(6k³).

For s>0, use (a−1)!S_a=∑_(r≥1)(−q)^r r^(a−1) to group by the total r of the cycle indices. Equivalently use the occupancy formula in OCCUPANCY_ALTERNATING_SERIES.md:
    (N−1)!P_N = ∑_(r≥1)(−q)^r r^(N−1) A_N(r),
    A_N(r)=1+∑_(m≥2)c_(N,m,r),
    c_(N,m,r)= [r/m!]∑_(i_1+...+i_m=r; i_j≥1) 1/(∏ i_j) Pr(X_j≥k for all j),
where X is multinomial with N trials and cell probabilities p_j=i_j/r (not the logistic poles). All expansions are absolutely convergent for q<1 before grouping. If N<4k only m=2,3 can appear. For m=2 the symmetrized formula and Markov's inequality in TWO_CYCLE_BAND_AND_CUBIC_ONSET.md give c_(N,2,r)≤N/k≤4. For m=3, the event is bounded by the expectation of ∏ X_j/k³, which equals (N)_3 ∏ p_j/k³. Here (N)_j denotes a falling factorial. Counting at most r²/2 ordered compositions of r into 3 positive parts gives c_(N,3,r)≤16/3. Thus for the old row 1≤A_n(r)<11 uniformly in r.

## 2. Edge difference via occupancy

For each fixed m≥2, the probability in c can increase on adding one trial only when exactly one cell was at k−1 and that cell receives the new ball, with all other counts already ≥k. By symmetry,
    r Δc_(m,r) = [r/(m−1)!] ∑_(sum i=r) [1/(∏_(j>1)i_j)]
                    Pr(X_1=k−1, X_j≥k for j>1),                   (2)
where Δ denotes the increase from n to n+1, and X has n trials. This even applies when n<mk≤n+1, so includes the first four-cycle term automatically.

Bound the probability in (2) by E[1_(X_1=k−1)∏_(j>1)X_j]/k^(m−1). Counting ordered distinguished trials in the m−1 other cells shows this expectation equals
    (n)_(m−1) ∏_(j>1)p_j · Pr(Bin(n−m+1,p_1)=k−1).
After cancellation of the index factors and bounding the number of compositions with fixed i_1 by r^(m−2)/(m−2)!, we get
    0≤rΔc_(m,r) ≤ 4^(m−1)/[(m−1)!(m−2)!] · ∑_(i=1)^(r−1) Pr(Bin(n−m+1,i/r)=k−1).
The first and other binomial counts at this event are each ≥k−1 for 2≤m≤4, since n≥3k. The Stirling peak and Gaussian lattice estimates of GROWING_TWO_CYCLE_STRIP.md therefore bound the sum by (2/√k)(1+2r/√k). Adding m=2,3,4 gives
    0≤r (A_(n+1)(r)−A_n(r)) ≤ (36/√k)(1+2r/√k),                  (3)
since 4+8+16/3<18.

Put D=n−1, M=ceil(√D/3), S=D/M, V_r=q^r r^D. We have M≤√k and M+1≤(7/20)√D, using D<4k and √D≥120. The successive ratios of V outward from m at s=D/m, or outward from the pair m,m+1 on D/(m+1)≤s≤D/m, are at most 1/40. This is the same log-ratio argument as in FIRST_TRANSITION_ALL_K.md, with exponent D/[2M(M+1)]≥200/49>4 and e^4>40. Thus the edge witnesses alternate correctly: the other terms total at most (22/39)V_m<V_m at witness m.

At a zero between witnesses m,m+1 subtract λ(n−1)!P_n from n!P_(n+1), λ=m+1/2. The resulting weights relative to (−1)^r V_r are (r−λ)A_n(r)+rΔA(r), where ΔA=A_(n+1)−A_n. The two central terms from the first part have common target sign (−1)^(m+1) and magnitude at least (V_m+V_(m+1))/2. The outward terms of that part cost at most
    11(40/1521+1/78)(V_m+V_(m+1)) < (9/20)(V_m+V_(m+1)).
For the second part use (3), r≤M≤√k on the two main terms and left tail, and r≤√k+h on the right tail. Its absolute contribution is at most
    (36/√k)(3+3/39+2·40/1521)(V_m+V_(m+1)) < (120/√k)(V_m+V_(m+1)).
For k≥10^22 this leaves positive margin. At the root the subtraction term vanishes, giving the required sign of P_(n+1).

## 3. Central cancellations

For 0≤s≤3√D put ρ=√(s²+π²), θ=atan(π/s) (π/2 at 0), φ=nθ, u=s/ρ² and v=π/ρ². For a pole p at conjugate level l≥0 put z_p=ρ/p and w_p=|(1/p−u)/v|≤2l+1. For every a≥k, since ρ²≤9(4k−1)+π²<4kπ², the fourth-power Bernoulli estimate gives |z_p|^a≤[1+l(l+1)/8]^(−4) for l≥1. Consequently
    U_a=∑_p |z_p|^a<6,   W_a=∑_p |z_p|^a w_p<20.
The corresponding sums restricted to levels l≥30 are <10^(−6) and <10^(−5). For the total sums use the first two farther bounds (4/5)^4 and (4/7)^4, then 4096/l^8; for W use the respective weights 3,5, and 5l/2 for l≥3. The tail bounds follow from 8192(30^(−8)+30^(−7)/7) and 24576(30^(−7)+30^(−6)/6). All estimates count both conjugate poles.

For m=2,3, the all-identical-pole contribution to (1) is L_(n,m) S_n, with L_(n,m)≥0 equal to the sum of the scalar weights 1/[(m−1)!∏_(i<m)a_i]. Each L_(n,m)≤16, by at most (4k)^(m−1) choices and a_i≥k. To compare consecutive rows, subtract uP_n from P_(n+1). In (1), terms in the next row with a_m≥k+1 correspond bijectively to lengths of the old row by subtracting one from a_m. The interior difference thus uses the same scalar weights, with the last factor replaced by S_(a_m+1)−uS_(a_m). Its all-identical-pole part is L_(n,m)(S_(n+1)−uS_n). Boundary terms with a_m=k exist only in the next row and are treated below.

For mixed pole tuples (not all identical) at retained levels l<30, choose any two coordinate poles p≠p′ and fix the other m−2 lengths. The varying lengths a,b have fixed total. Each normalized pole factor in the sum has modulus ≤1. Use summation by parts along the pair, orienting so the geometric ratio p′/p or p/p′ has modulus ≤1. Its geometric partial sums are bounded by 2 max(|p|,|p′|)/|p−p′|≤4√k, since |p|≤7√k for retained levels, |p−p′|≥2π and k≥10^22. The scalar weight extends over a consecutive integer interval. It is monotone if the pair includes the last (unweighted) coordinate, and otherwise is a positive constant times 1/[a(C−a)] for fixed C. The latter decreases then increases. Its total variation plus terminal value is at most 3/k^(m−1), including the factor 1/(m−1)! and using the maximum weight. Thus the bound for each choice of the other lengths is 12√k/k^(m−1). Summing over their at most (4k)^(m−2) choices gives ≤48/√k for a fixed retained tuple. For the interior difference the multiplier from the last pole in units v is at most 59, independent of lengths. There are at most 60²+60³<220000 retained tuples in the two sums. The total retained mixed errors, normalized by ρ^(−n) for values and vρ^(−n) for the difference, are each bounded by (220000·48·59)/√k<1/100.

Mixed terms containing a level ≥30 are estimated by a union bound over its position and the absolute sums U and W. Both value and weighted difference are bounded by
    ∑_(m=2,3) 16[(m−1)·10^(−6)·6^(m−2)·20+10^(−5)·6^(m−1)] < 1/50.
For the unweighted case one may still use this numerical bound, replacing 20 by 6 and 10^(−5) by 10^(−6). The boundary terms a_m=k have total coefficient weight ≤1/k for m=2 and 2/k for m=3 (at most 4k choices of the other free length). Their size in the difference, in units vρ^(−n), is at most (6²+2·6³)ρ/(πk)≤1100/√k. If n+1=4k the extra term S_k^4/(6k³) is bounded in the same units by 504/k^(5/2). Hence with A=1+L_(n,2)+L_(n,3)≥1, we have
    |P_n−A S_n| < ρ^(−n)/20,
    |P_(n+1)−uP_n−A(S_(n+1)−uS_n)| < vρ^(−n)/20.                 (4)

As in FIRST_TRANSITION_ALL_K.md, the farther-pole error for S_n relative to 2ρ^(−n), and for S_(n+1)−uS_n relative to 2vρ^(−n), is <1/4, since nπ²/(2ρ²)>1/2. Their nearest-pole terms in these units are cosφ and −sinφ. Equation (4) proves sign (−1)^j at φ=jπ and excludes a zero wherever |cosφ|≥3/10. At a central root |sinφ|>19/20, and the normalized difference has the sign of −sinφ. This is the sign of P_(n+1) at that root.

## 4. Stitch and conclusion

At S=D/M the offset |φ(S)/π−M| is <1/8 by the arctangent bounds used in FIRST_TRANSITION_ALL_K.md. Use the edge witnesses m=1,...,M and the central witnesses φ=jπ for j=M+1,...,floor(n/2). They alternate in order. If the first central bracket has a short part where φ<Mπ, no root lies there, because |cosφ|≥cos(π/8)>3/10. The brackets give floor(n/2)−1 roots in (−1,0); their reciprocals, zero, and −1 for odd n fill degree n−1. All are simple. At each bracketed root the derivative has the sign of the witness on its right, opposite to the signs of P_(n+1) just proved. At −1 in an odd row, −sin(nπ/2) is opposite the derivative sign from the last witness. Reciprocation transfers the same strict ratio below −1, and dividing by t preserves it at nonzero roots. The degree increase by one yields strict consecutive interlacing, as in the first-transition proof. A permutation with one excedance is a single cycle with a unique descending tail after its minimum, so the linear coefficient is 1 and the zero at 0 of both rows is simple.

Above 4k, four non-equal cycle lengths and more terms enter. The edge and bulk constants here were chosen for at most three cycles in the old row; they do not establish the next regime or the full conjecture.

