# Minimum cycle length five: strict consecutive interlacing

**Theorem.** For every n≥5, E_(n,5)(t) has n−1 distinct real roots. The quotients by t strictly interlace consecutively.

This proof uses the root-sign framework of INTERLACING.md and the first/last phase hit argument of EVENTUAL_ALL_FIXED_K.md. It verifies the bulk and edge estimates at the much smaller explicit threshold n≥128, and uses exact integer checks below it.

## 1. Quartic perturbation and a circular contour

In the notations of the k=4 proof, delete the 4-cycle weight t A_3(t)=t(1+4t+t²). The scaled function is now
    H(z)=exp(−az+bz²+cz³+dz⁴)/(exp(−z)+q),
    d=q(1−4q+q²)/(24(1+q)^4).
In particular |d|≤1/192: with w=(1−q)/(1+q) the expression is (1−w²)(3w²−1)/192, whose numerator is between −1 and 1. Also |d|≤q/24 since |1−4q+q²|≤(1+q)². This coefficient is nonnegative when s≥3 because q=e^(−s)<1/4. The quantities p, ρ, u, v, B, the phase formula φ=(n+1)atan(π/s)+πa−Im(b p²+c p³+d p⁴), and the sign conditions we need are as in EVENTUAL_ALL_FIXED_K.md.

For each s, integrate on a circle of radius R in [7ρ/4,2ρ] with distance >1/4 from every pole. Such a radius exists: among the radii of poles whose moduli can come within 1/4 of this interval, any two distinct moduli are separated by more than 4. In fact those moduli are at least 3ρ/2, where the derivative of √(s²+y²) in y≥0 is at least √(1−(2/3)²)>2/3, and the positive imaginary parts of poles are separated by 2π>6. The excluded intervals of radii are therefore disjoint intervals of width 1/2 with a positive gap between them; they cannot cover the connected interval of length ρ/4≥π/4>1/2. The primary pair lies strictly inside.

At any point z=x+iy of this circle the denominator has modulus at least q(1+e^(s−x))/32. Indeed, if |s−x|≥1/8, the reverse triangle inequality gives the ratio ≥tanh(1/16)>1/32, using e^(1/8)≥1+1/8. Otherwise the distance from y to a nearest odd multiple of π is ≥1/8 and ≤π. With W=e^(s−x), the ratio is then at least [2√W/(1+W)] sin(1/16)>1/32. The square of |1+W exp(−iy)| is (1−W)^2+4W sin²((y−y0)/2) for odd y0/π. Use 2√W/(1+W)≥exp(−1/16)≥15/16 and sin(1/16)≥1/16−(1/16)^3/6 for the last strict comparison. As before, exp(a(s−x))≤1+exp(s−x).

## 2. Central estimates for 0≤s≤3√n

The main pole terms are unchanged in normalized form: −B cos φ in h_n and Bv sin φ in h_(n+1)−u h_n. The contour comparison gives
    |H|/|Res_p H| ≤ 32 exp(U),  U=5bρ²+9cρ³+17|d|ρ⁴.
For 0≤s≤3 use ρ²<19, ρ<9/2, b≤1/8, c≤1/60 and |d|≤1/192 to give U<57. For s≥3 use b≤q/2, c≤q/6 and |d|≤q/24. Each e^(−s)ρ^j is decreasing for j≤4 because js/(s²+π²)≤j/(2π)<1. At s=3 we may therefore bound U by (5·19/2+9·19·(9/2)/6+17·19²/24)/20<22, using e³>20.

The circle integral error in units B is at most 16 exp(U) ρ(ρ/R)^n. For the weighted error in units Bv the extra factor is at most (11/7)ρ/π. For 0≤s≤3 both are at most 171(11/4)^57(4/7)^128<1/100, using e<11/4. For 3≤s≤3√n both are at most 144 n·3^22(4/7)^n<1/100 for n≥128, using ρ≤4√n, and verifying the bound at 128. No pole is missed by a boundary crossing because R is chosen separately at each s, and the algebraic bounds do not require R to be continuous.

At 0≤s≤3 there are no other enclosed poles (2ρ≤2√19<3π). For s≥5, the quartic contribution only decreases farther pole magnitudes. For a pole s+i jπ inside, (j²+1)π²≤3s²+5π²≤6s² as R≤2ρ and s≥5. Hence
    Re(s+i jπ)^4−Re(s+iπ)^4
        =(j²−1)π²[(j²+1)π²−6s²]≤0 .
Since d≥0 and the quadratic and cubic likewise only decrease the farther magnitudes, the estimate <1/4 in the k=3 proof applies.

If 3≤s≤5, allow the quartic enhancement at most exp(17|d|ρ⁴)<e^13 (decreasing bound in s as above). From the pole ratio Bernoulli with eighth power, the weighted sum before this prefactor is at most
    sum_(l≥1)(2l+1)/(1+c0 l(l+1))^8,
    c0=(n+1)π²/(4ρ²)>8,
since n≥128, π²>9 and ρ²≤35. Its term l=1 is at most 3/17^8; all others together at most (3/8^8)(2^(−15)+2^(−14)/14) using the integral bound on the decreasing series. Even multiplying their sum by 3^13 gives <1/4. Thus both normalized inequalities (A) of EVENTUAL_ALL_FIXED_K.md hold.

## 3. Edge estimates for s≥S=n/M

Here q<e^(−24), and b,c,d≥0. Define B_j(x)=j![z^j] exp(xz+bz²+cz³+dz⁴). For l≥1,
    l^n≤B_n(l+δ)≤(101/100)l^n ,
    l≤B_(n+1)(l+δ)/B_n(l+δ)≤l+1/100 .
The first excess is bounded by exp(nδ+n²b+n³c+n⁴d)−1 as before. For n≥128 the exponent is ≤ n⁴q/20, from 1/n³+1/(2n²)+1/(6n)+1/24<1/20. The bound n⁴e^(−(24/11)√n)/20 decreases for n≥128 and at 128 is less than 128⁴(3/8)^24/20<1/200. For the next ratio the derivative recurrence adds 4dn(n−1)(n−2)B_(n−3) to the k=4 formula. Use B_j≥(l+δ)B_(j−1) to bound the ratio excess by q[1+n+n²/2+n³/6]≤n⁴q/20.

As before compare terms of a multinomial expansion, now also using (4h)!/h!≤j^(3h) when 4h≤j:
    B_j(δ) ≤ (δ+√(jb)+(j²c)^(1/3)+(j³d)^(1/4))^j
           ≤ (1+√j+j^(2/3)+j^(3/4))^j q^(j/4).
For x=√n≥11 and j=n,n+1, log(1+√j+j^(2/3)+j^(3/4))≤2x/5. To verify it, bound j above by x²+1; at x=11 the sum is less than 1+12+25+37=75<e^(22/5) (use e>163/60 and e^(2/5)>1+2/5+2/25). The log derivative of this upper bound is at most 3x/[2(x²+1)]<2/5 thereafter. Further, m≤M≤(11/24)√n≤n/24, so j/4−m≥5n/24 and s(j/4−m)≥(5/11)n√n. Thus division by V_m=q^m m^n bounds each B_j(δ)/V_m by exp(−n√n/25), since 5/11−(2/5)(1+1/n)≥1/25 for n≥128. With the multiplying factor M+2≤n this is <1/100. The outward ratio bounds 1/6 from k=3 are unchanged. This establishes both edge signs by the same comparisons with the one or two largest summands.

## 4. Stitch and finite verification

The phase at zero is (n+2)π/2, because c=0 there and even powers of iπ are real. At S the error in φ(S)/π beyond the arctan and limiting shift terms is at most
    e^(−S)[1+S+(3S²+10)/6+(S²+10)^2/(24π)]<1/100
for S>24, by checking at 24 using e>2 and decreasing of the displayed bound. This gives the same |φ(S)/π−(M+1)|<1/8. Use the first/last hit argument in Section 4 of EVENTUAL_ALL_FIXED_K.md, which assumes no phase monotonicity, to count and strictly interlace the roots. This covers n≥128.

For 5≤n≤127 run the exact signed gamma-remainder certificate (123 pairs) in the standard-library command
    python -B check_interlacing_general.py 127 5
It constructs the rows by the original insertion recurrence and does not assume real-rootedness in these cases.

