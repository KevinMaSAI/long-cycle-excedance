"""Exact consecutive interlacing replay; Python 3.9+, stdlib only."""
from math import comb
import sys

def rows(limit):
    E=[[1],[0,0],[0,0,0]]
    for n in range(3,limit+1):
        row=[0]*(n+1)
        for j,c in enumerate(E[-1]):
            row[j]+=j*c
            row[j+1]+=(n-1-j)*c
        for j,c in enumerate(E[n-3]):
            row[j+1]+=comb(n-1,2)*c
            row[j+2]+=comb(n-1,2)*c
        assert row==row[::-1] and row[1]==row[-2]==1
        E.append(row)
    return E

def signed_remainder(f,g,scale):
    # Degree gap is exactly one, so the classical pseudo-remainder
    # uses exactly two multiplications by the divisor's positive lc.
    d=len(g)-1
    r=f.copy()
    b=g[-1]
    assert b>0 and len(r)==len(g)+1
    for i in (1,0):
        c=r[-1]
        r=[x*b for x in r]
        for j,x in enumerate(g): r[j+i]-=c*x
        assert r.pop()==0
    h=[]
    for x in r:
        q,rem=divmod(-x,scale)
        assert rem==0
        h.append(q)
    return h

def certify(f,g):
    scale=1
    while len(g)>1:
        assert len(f)==len(g)+1 and g[-1]>0 and f[-1]>0
        h=signed_remainder(f,g,scale)
        assert len(h)==len(g)-1 and h[-1]>0
        scale=g[-1]**2
        f,g=g,h
    assert len(g)==1 and g[0]>0 and len(f)==2 and f[-1]>0

if __name__=="__main__":
    if not __debug__: raise RuntimeError("Run without -O")
    nmax=int(sys.argv[1]) if len(sys.argv)>1 else 143
    e=rows(nmax+1)
    for n in range(3,nmax+1):
        certify(e[n+1][1:-1],e[n][1:-1])
    print(f"PASS: strict interlacing E_n/t with E_(n+1)/t for each n=3..{nmax}")

