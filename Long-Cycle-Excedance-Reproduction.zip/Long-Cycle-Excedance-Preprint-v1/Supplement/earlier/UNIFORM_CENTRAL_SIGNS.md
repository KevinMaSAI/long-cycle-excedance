# Exact central signs for every minimum cycle length

For all k≥2 and n≥k:
1. If n is even, E_(n,k)(−1) is nonzero with sign (−1)^(n/2).
2. If n is odd, E_(n,k)(−1)=0 and E′_(n,k)(−1) is nonzero with sign (−1)^((n−1)/2). Moreover E_(n+1,k)(−1)/E′_(n,k)(−1)<0.
No real-rootedness assumption is needed. In particular at the self-reciprocal root −1 the strict adjacent-row sign required for interlacing always holds in the odd row; that point cannot obstruct the conjecture.

Proof. Use the exact pole product from GROWING_K_REDUCTION.md. Let y_j=(2j+1)π, q=e^(−s), and write
    F_s(z)=sum_(n≥0) E_(n,k)(−e^(−s)) z^n/[n!(1+e^(−s))^n].
Then
    log F_s(z)=sum_(m≥k) z^m/m · sum_(j∈Z)(s+i y_j)^(−m) .
The sums and their s derivatives converge absolutely and normally on |z|≤r<π and real s near zero; for example, |s+i y_j|≥|y_j|, and one uses k≥2, a convergent sum of |y_j|^(-k), and geometric domination in m.

At s=0, z=i x, the logarithm becomes
    log F_0(i x)=sum_(m≥k, m even) x^m/m · sum_j y_j^(−m).
All displayed coefficients are positive; odd terms cancel in pairs. Its exponential has nonnegative coefficients and a strictly positive coefficient at every even n≥k, since the nth log term alone is positive. This proves the even claim after undoing multiplication by i^n and by a positive normalization. It also gives the odd zero.

Next differentiate before setting s=0. At z=i x, ∂_s log F_s(i x) at zero is
    i sum_(m≥k, m odd) x^m · sum_j y_j^(−m−1).
Indeed derivative of a pole term introduces minus and changes the exponent from −m to −m−1; multiplying by i^m gives i. Only odd m survive pairing. Therefore ∂_s F_s(i x) at zero has the form i times a series with nonnegative real coefficients and a strictly positive coefficient (after the i) for each odd n≥k, including its direct m=n term. Undoing multiplication by i^n, its sign is i^(1−n)=(−1)^((n−1)/2) in an odd row. At s=0 in an odd row, E_(n,k)(−1)=0, so the derivative of the positive normalizing denominator contributes zero. The derivative of t=−e^(−s) with respect to s is 1 at zero. Thus the coefficient sign is exactly that of E′_(n,k)(−1). Combining the two consecutive signs gives the stated negative ratio.

