# Eventual strict interlacing for every fixed minimum cycle length

This result proves an infinite range for every k≥4, but does not assert the conjecture for all pairs (n,k). Read PROOF.md for the enumeration and INTERLACING.md for the explicit k=3 sign argument.

**Theorem.** Put d=k−1≥3, S0=128d², C=d[4(d+7)]^d, and
    N(k)=max((100d)^4, 1000 S0²·3^(2C), 100+16C).
For every integer n≥N(k), E_(n,k) has n−1 distinct real roots, and E_(n,k)/t strictly interlaces E_(n+1,k)/t. This threshold is deliberately very conservative. Also, for any k≥4, E_(n,k) has simple real roots for k≤n<2k, with strict quotient interlacing when both rows are in that range: there is only one cycle, and the quotients equal the ordinary Eulerian polynomials A_(n−1). The latter interlace by the Eulerian derivative recurrence, which evaluates to t(1−t)A′_(n−1)(t) at each negative root of A_(n−1), and the outer endpoint signs then follow from positive leading and constant coefficients.

## 1. The scaled EGF and phase

At t=−q=−e^(−s), put a=1/(1+q), δ=1−a, and
    G_s(z) = sum_(j=2)^d q A_(j−1)(−q) z^j/[j!(1+q)^j],
    H(z) = exp(−az+G_s(z))/(exp(−z)+q).
Removing the short-cycle weights from the Eulerian EGF gives E_(n,k)(−q)=n!(1+q)^(n+1)h_n, h_n=[z^n]H. If G_s(z)=sum g_j z^j, then |g_j|≤q, because |A_(j−1)(−q)|≤A_(j−1)(1)=(j−1)!. As in PROOF.md, each row for n≥k has degree n−1, its zero at zero is simple, and E_(n,k)(t)=t^n E_(n,k)(1/t).

Let ρ=√(s²+π²), p=s+iπ, u=s/ρ², v=π/ρ², and
    φ_n(s)=(n+1)atan(π/s)+πa−Im G_s(p) .
Take atan(π/0)=π/2. At s=0 the phase equals (n+2)π/2. To see this, the cycle polynomial t A_(j−1)(t) is reciprocal of grade j by inversion on j-cycles. For odd j, evaluation at −1 is zero. Thus G_0(iπ) only uses even powers and is real. Its coefficients and φ_n(s) are continuous for s≥0.

## 2. Bulk estimates, s≤3√n

Put B=2|Res_p H|ρ^(−n−1). We prove
    |h_n/B+cos φ_n(s)|<1/3 ,
    |(h_(n+1)−u h_n)/(Bv)−sin φ_n(s)|<1/3 .       (A)
Use the square with sides at ±L as in Section 2 of INTERLACING.md. In particular L=2π ceil(ρ/π), and 2ρ≤L<2s+4π. Its poles have real part s and imaginary part odd multiples of π. The numerator exponential never vanishes. The denominator derivative at the poles is q. The closest pair contributes −B cos φ_n, or +Bv sin φ_n for the difference, by multiplying by 1/z−u. For a farther pair with imaginary part ±(2l+1)π the additional multiplier divided by v is at most 2l+1, as calculated there.

For every z in the square, including its poles, |z|≤4(s+7), so
    |G_s(z)| ≤ W(s):=d[4(s+7)]^d exp(−s) ≤ C .
For the last bound differentiate (s+7)^d exp(−s); its maximum is at s=max(0,d−7), where s+7≤d+7. In addition W(s)<1/100 for s≥S0. Indeed 4(s+7)≤8s there, and
    e^(s/2) ≥ (s/2)^(2d)/(2d)! ≥ (s/(4d))^(2d) ≥ (8s)^d
by s≥128d². It follows that W(s)≤d e^(−s/2)<1/100 for s≥S0, by e>2 and S0≥128d².

The denominator comparison and linear exponential bounds for the square give |H|/|Res_p H|≤2 e^(2C) on its boundary. Therefore the relative contour integral errors for (A), in respective units B and Bv, are at most 16 n e^(2C)2^(−n). Here ρ≤4√n, and the extra multiplier divided by v on the contour is at most 3ρ/(2π). Since n≥100+16C and e<3, this is at most 16n2^(−3n/4)<1/100, checked at 100 and decreasing beyond it.

By the same Bernoulli bound as in INTERLACING.md, the normalized sum of magnitudes of remaining contributing pairs is bounded, in both evaluations, by
    exp(2W(s)) sum_(l≥1) (2l+1)/(1+c l(l+1))^4,
    c=(n+1)π²/(2ρ²).
When S0≤s≤3√n, c>1/2, and the sum without the prefactor is below 1/4. The prefactor is at most e^(1/50)≤50/49. When s≤S0, c≥2n/S0², and the sum is at most 6/c^4: use 2l+1≤3l, l(l+1)≥l² and sum l^(−7)≤2. The prefactor is at most e^(2C)<3^(2C); the lower bound n≥1000 S0²·3^(2C) makes the resulting product <1/100. Only poles inside the square contribute; the extended sum of positive bounds is an upper estimate, not a summation of residues of G on the entire plane. Combining all errors proves (A).

## 3. Edge estimates, s≥S=n/M

Set M=ceil(√n/3); as before M≤(11/24)√n, M+1≤(7/12)√n, and (24/11)√n≤S≤3√n. Define for l≥0
    T_j(l)= j![z^j] exp((l+δ)z+G_s(z)).
The geometric series converges normally near zero since q<1 at the edge, giving
    j!h_j = sum_(l≥0) (−q)^l T_j(l).
The moment coefficients are real, but need not be nonnegative. We show that at l≥1, for 0≤j≤n+1,
    |T_j(l)/l^j−1|≤1/100,
    |T_(n+1)(l)/T_n(l)−l|≤1/100.               (B)

For the first bound, majorize absolute contributions to T_j(l) with at least one perturbation term, factoring out l^j. Expanding the exponential in δz and g_h z^h and using j!/(j−r)!≤(n+1)^r and l≥1 shows that their total is bounded by
    exp(δ(n+1)+sum_(h=2)^d |g_h|(n+1)^h)−1
    ≤ exp(d(n+1)^d e^(−2√n))−1.
Let x=n^(1/4)≥100d. We have log(n+1)≤x: at x=10, 10^4+1<e^10 (e>8/3 suffices), and the derivative of log(x^4+1) is at most 4/x<1 thereafter. Thus (n+1)^d e^(−2√n)≤exp(dx−2x²)≤e^(−x²), and d e^(−x²)<1/200. Hence the first bound, in particular T_j(l)>0 for these l. For the second, differentiate the generating function for the moments. It gives
    T_(n+1)(l)=(l+δ)T_n(l)+sum_(h=2)^d h g_h (n)_(h−1) T_(n+1−h)(l),
where (n)_r is the falling factorial. The first part of (B) implies |T_(n+1−h)(l)/T_n(l)|≤(101/99) l^(1−h). The combined excess over l in absolute value is at most 2d²(n+1)^d exp(−2√n)<1/100, since x≥100d.

For l=0 use Cauchy's estimate on |z|=exp(s/(2d)). The exponent δz+G_s(z) has absolute value ≤d e^(−s/2) on this circle, by δ,|g_h|≤q. For j=n,n+1 and V_m=q^m m^n, 1≤m≤M, this yields
    |T_j(0)|/V_m ≤ exp(d+j log j−s(j/(2d)−m)) ≤ e^(−n).
Indeed M≤n/(4d) since x≥100d, j log j≤2nx, s≥2√n, and s(j/(2d)−m)≥nx²/(2d)≥50nx. The factor M+2 multiplying the l=0 errors is harmless: n e^(−n)<1/100.

The unperturbed magnitudes V_l=q^l l^n have the same outward ratios bounded by 1/6 as in Section 3 of INTERLACING.md. At s=n/m the main term has magnitude at least (99/100)V_m, and the other terms have combined magnitude at most [(101/100)·2/5+1/100]V_m, smaller than the main term. At a zero between s=n/(m+1) and s=n/m, consider (n+1)!h_(n+1)−(m+1/2)n!h_n. From (B) the contributions from l=m,m+1 have the same sign, (−1)^(m+1), and combined magnitude at least (99/100)(49/100)(V_m+V_(m+1)). The error from l≠m,m+1 with l≥1 is at most
    (101/100) (sum_(j≥1)(j+51/100)6^(−j))(V_m+V_(m+1))
    < (7/20)(V_m+V_(m+1)).
Add <V_m/100 for l=0; the sign follows. The same subtraction at a root proves the sign of E_(n+1,k). In summary both edge signs used for k=3 remain valid.

## 4. Counting the roots without phase monotonicity

At S=n/M the offset from (M+1)π in units of π is at most 1/8 in absolute value. Indeed, bounding atan y between y−y³/3 and y bounds the unperturbed difference by the upper M/n≤11/(24√n) and lower −20(11/24)^3/(3√n)>−1/12. The linear δ factor contributes at most exp(−S) and |G_S(p)|≤W(S)<1/100, as S≥S0 follows from √n≥(100d)². Thus the additional difference is less than 1/50 in absolute value.

Start from s=S and move toward 0. Label the edge samples m=1,...,M by j=m+1. For the remaining indices j=M+2,...,floor((n+2)/2), choose the successive first hits of φ_n(s)=jπ. They exist by the endpoint values and continuity; at even n the final hit need not be at zero, and if it is earlier we may still use it. The sign at each sample j is (−1)^(j+1). This gives floor(n/2) samples and exactly one root between consecutive samples, as in the k=3 proof: reciprocal pairs, zero, and −1 for odd n already account for the whole degree. In particular, when n is odd no further root lies between the last sample and −1.

Before a first hit of (j+1)π in the bulk, take the last hit of jπ after or at the previous sample. The subinterval between these two hits still has opposite endpoint signs, so it contains the unique root in the original interval. The phase at the root belongs to (jπ,(j+1)π), by continuity and the choice of hits. For the first bulk bracket (the previous sample is S), the same argument works if there is a hit of jπ; if there is no such hit, φ_n(S)>jπ and φ_n stays within these two levels until the first next hit. The sign of sin φ_n therefore matches the k=3 comparison at every bulk root. This avoids requiring monotonicity of the perturbed phase. On the edge and at −1 the signs were already proved, and reciprocation transfers the comparison to (−∞,−1). At all nonzero roots E_(n+1,k)/E′_(n,k)<0. This is equivalent here to strict quotient interlacing by the derivative-sign and degree argument of INTERLACING.md.

**Remaining gap after the separate k=4 and k=5 theorems:** for k≥6, this package does not settle the remaining rows 2k≤n<N(k), or interlacing pairs 2k−1≤n<N(k). These ranges are finite for each particular k but not finite uniformly in k. This theorem plus single-cycle rows does not prove the full two-parameter conjecture.

