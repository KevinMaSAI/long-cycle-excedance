"""Exact consecutive interlacing replay; Python 3.9+, stdlib only."""
from functools import reduce
from math import gcd, comb
import sys

def rows(limit):
    E=[[1],[0,0],[0,0,0]]
    for n in range(3,limit+1):
        row=[0]*(n+1)
        for j,c in enumerate(E[-1]):
            row[j]+=j*c
            row[j+1]+=(n-1-j)*c
        for j,c in enumerate(E[n-3]):
            row[j+1]+=comb(n-1,2)*c
            row[j+2]+=comb(n-1,2)*c
        assert row==row[::-1] and row[1]==row[-2]==1
        E.append(row)
    return E

def primitive(p):
    while p and p[-1]==0: p.pop()
    if not p: return p
    g=abs(reduce(gcd,p))
    return [x//g for x in p]

def signed_remainder(f,g):
    r=f.copy()
    assert g[-1]>0
    while r and len(r)>=len(g):
        i=len(r)-len(g)
        c,b=r[-1],g[-1]
        r=[x*b for x in r]
        for j,x in enumerate(g): r[j+i]-=c*x
        r=primitive(r)
    return [-x for x in r]

def certify(f,g):
    while len(g)>1:
        assert len(f)==len(g)+1 and g[-1]>0 and f[-1]>0
        h=signed_remainder(f,g)
        assert len(h)==len(g)-1 and h[-1]>0
        f,g=g,h
    assert len(g)==1 and g[0]>0 and len(f)==2 and f[-1]>0

if __name__=="__main__":
    if not __debug__: raise RuntimeError("Run without -O")
    nmax=int(sys.argv[1]) if len(sys.argv)>1 else 143
    e=rows(nmax+1)
    for n in range(3,nmax+1):
        certify(e[n+1][1:-1],e[n][1:-1])
    print(f"PASS: strict interlacing E_n/t with E_(n+1)/t for each n=3..{nmax}")

