# Replay for the strict consecutive interlacing theorem

Read INTERLACING.md for the proof and PROOF.md for the preparatory enumeration, generating function, and prior real-rootedness argument. This work is an unreviewed research result for the minimum cycle length exactly k=3. Nothing was posted or submitted.

The preferred replay uses only Python 3.9+ and integer arithmetic:
    python -B check_interlacing_gamma.py 63
Do not use -O. The companion check_interlacing_fast.py works directly with E_n/t; it is slower.

The preferred replay uses E_n=t(1+t)^(n−2) G_n(x), x=t/(1+t)^2. It tests positivity of all coefficients of G_n and reconstructs the integer coefficients exactly. The map x(t) is strictly increasing from −∞ to 0 on (−1,0), so orders of negative roots of G_n agree with the orders of the corresponding roots of E_n in that interval. Each root lifts to a reciprocal pair. The odd row contributes a single additional root at −1 after lifting.

For odd n, G_(n+1) has degree one greater than G_n. The signed remainder certificate in Section 5 of INTERLACING.md gives strict alternating roots, beginning and ending with a root of G_(n+1). They are negative by coefficient positivity. Reflection by reciprocation and the center root −1 of F_n give strict interlacing in t.

For even n, f=G_(n+1) and g=G_n have the same degree d. The integer polynomial h=lc(f)g−lc(g)f is checked to have degree d−1 and positive leading coefficient, with roots strictly interlacing those of g. At each root r of g, f(r)=−h(r)/lc(g) has the opposite sign to g′(r). The d−1 disjoint intervals between g-roots and the interval between the largest g-root and 0 each contain a root of f (use f(0)=1 at the last endpoint). They exhaust the degree. Hence on (−1,0) the lifted roots are g_1<f_1<...<g_d<f_d, which reflects across the center root −1 of F_(n+1) to give strict interlacing in t.

Both scripts do their signed polynomial elimination using only positive leading coefficients and verified exact division by a positive scale. They never use a root approximation, floating point, or an unchecked sign heuristic.

The older standalone Sturm program in exact/verify.py in this archive has one defensive correction to ensure that its content normalization uses the absolute gcd even for degree zero. The corrected code passes the same exact replay; this does not change any theorem statement. The new signed-remainder certificate also independently proves reality and simplicity throughout its finite range.

