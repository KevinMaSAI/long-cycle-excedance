# Every bounded n/k regime for sufficiently large k

Let E_(n,k) be the long-cycle excedance polynomial. Write F_(n,k)=E_(n,k)/t.

**Theorem.** For every fixed integer L≥2 there exists an effective K(L) such that for every k≥K(L), all rows k≤n≤Lk have simple real roots and F_(n,k) strictly interlaces F_(n+1,k) for k≤n<Lk. In particular, the argument handles arbitrarily many cycle counts as long as n/k has a fixed bound. This does not give a single cutoff that works for unbounded L, and does not close the conjecture.

The proof is uniform in n∈[k,Lk−1] for each fixed L. Every error used below has an explicit bound or comes from a convergent series with an explicit positive tail majorant; Section 5 explains how to obtain a finite K(L).

## 1. Normalizations and the edge

Use the exact pole and occupancy formulas in GROWING_K_REDUCTION.md, OCCUPANCY_ALTERNATING_SERIES.md and THREE_CYCLE_BAND_AND_FOURTH_ONSET.md. For t=−e^(−s)=−q, s≥0, set
    p_i=s+(2i+1)πi_unit, i∈Z; S_a=∑_i p_i^(−a) (a≥2).
Here i_unit denotes the imaginary unit. Normalize the row by E_(N,k)(−q)=(N−1)!(1+q)^N P_N. Its contribution from m cycles is
    B_(N,m) = [1/(m−1)!] ∑_(a_j≥k, sum a_j=N) (∏ S_(a_j))/(∏_(j<m) a_j).
This is the exponential formula with ordered cycle sizes, using symmetry and N=∑a_j. In particular B_(N,1)=S_N and P_N=∑_(m=1)^L B_(N,m) for N≤Lk. Empty sums are zero.

For s>0, another formula is
    (N−1)! P_N = ∑_(r≥1)(−q)^r r^(N−1) A_N(r),
    A_N(r)=1+∑_(m≥2)c_(N,m,r),
    c_(N,m,r)=[r/m!]∑_(i_j≥1,sum i_j=r)(1/∏i_j) Pr(X_j≥k for each j),
where X is multinomial with N trials and probabilities p_j=i_j/r (these probabilities are unrelated to the pole notation). The single-cycle term is 1 since N≥k. This is the earlier occupancy identity multiplied by r. The bound
    1≤A_N(r)≤C_L:=1+∑_(m=2)^L L^m/[m!(m−1)!]
holds uniformly. Indeed the occupancy event is bounded by E(∏X_j)/k^m=(N)_m∏p_j/k^m. There are at most r^(m−1)/(m−1)! compositions in the sum.

We also use, uniformly for k≤n<n+1≤Lk,
    0≤r[A_(n+1)(r)−A_n(r)] ≤ [D_L/√k](1+2r/√k),
    D_L=2∑_(m=2)^L L^(m−1)/[(m−1)!(m−2)!].             (1)
Proof: conditional on cell probabilities, an added trial produces acceptance precisely when one cell count was k−1, all others were ≥k, and the new trial enters the deficient cell. By symmetry this gives
    r Δc_(m,r) = [r/(m−1)!]∑_(i_j≥1,sum i_j=r) [1/∏_(j>1)i_j] Pr(X_1=k−1, X_j≥k for j>1).
Bound the probability by E[1_(X_1=k−1)∏_(j>1)X_j]/k^(m−1)=(n)_(m−1) ∏_(j>1)p_j Pr(Bin(n−m+1,p_1)=k−1)/k^(m−1). This equals the count obtained by distinguishing one trial in each other cell. For fixed i_1 the number of remaining compositions is at most r^(m−2)/(m−2)!, so all powers of r in the prefactor cancel. If n+1<mk the difference is zero. Otherwise both binomial counts in the remaining mass are at least k−1 (the other count is n−m−k+2≥(m−1)(k−1)). As proved in GROWING_TWO_CYCLE_STRIP.md, summing such masses over the lattice p=i/r gives at most (2/√k)(1+2r/√k): Stirling bounds the peak by 2/√k, and the log likelihood decreases away from its maximizer by at least twice the number of trials times the squared distance, so the sum is bounded by the maximum plus the Gaussian integral. This proves (1), including the onset of a new cycle count.

Choose an integer T≥max(4,2√L) so that exp(−T²/8)≤η:=1/(100 C_L). Let D=n−1, M=ceil(√D/T) and S=D/M. When √D≥2T we have M+1≤2√D/T, M≤√k and S≤T√D. For V_r=q^r r^D, the outward successive ratios at witness s=D/m are at most η on both sides, and the same ratios hold outward from the pair m,m+1 for D/(m+1)≤s≤D/m, as in FIRST_TRANSITION_ALL_K.md; the exponent D/[2M(M+1)] is ≥T²/8. At witness m the sign is (−1)^m, because the sum outside m is at most 2C_L ηV_m/(1−η)<V_m.

At a zero of P_n in a pair bracket, subtract (m+1/2)(n−1)!P_n from n!P_(n+1); put b=m+1/2. The weights in the resulting series relative to (−1)^r V_r are
    (r−b)A_n(r)+r[A_(n+1)(r)−A_n(r)].
The first part has its two main terms of sign (−1)^(m+1), totaling at least half of V_m+V_(m+1); its opposing tails in those units are bounded by C_L[η/(1−η)^2+η/(2(1−η))]<1/10. The second part contributes in absolute value at most
    [D_L/√k][3+3η/(1−η)+2η/(1−η)^2]
by (1), since r≤M≤√k at the main points and on the left, and r≤√k+h on the right at outward distance h. The bracketed quantity is <4, so the error is <1/10 for k sufficiently large (for example √k>40D_L). Thus at each such root P_(n+1) has sign (−1)^(m+1).

## 2. Abel cancellation of all mixed pole terms

In the central domain 0≤s≤T√n put ρ=√(s²+π²), θ=atan(π/s) with θ=π/2 at zero, φ=nθ, u=s/ρ², v=π/ρ², and z_p=ρ/p. At conjugate level l≥0, |(1/p−u)/v|≤2l+1, as in FIRST_TRANSITION_ALL_K.md. For exponents a≥k,
    |z_p|^a ≤ b_l := (1+c_* l(l+1))^(−4), c_*=4/[(T²+10)L],
provided k≥8. This follows from |z_p|^a=[1+4π²l(l+1)/ρ²]^(−a/2), Bernoulli, and ρ²≤(T²+10)Lk. Put U=2∑ b_l and W=2∑(2l+1)b_l. For l≥1, b_l≤c_*^(−4)l^(−8), so both are finite, with effective tail bounds.

In B_(n,m), the all-identical pole tuples contribute L_(n,m)S_n with L_(n,m)≥0 the sum of the scalar weights. It obeys L_(n,m)≤L^(m−1)/(m−1)!, counting the m−1 free lengths and using each denominator≥k. Put A_n^*=∑ L_(n,m) with L_(n,1)=1. For the difference P_(n+1)−uP_n, decrement the last length of each next-row tuple with a_m≥k+1. This leaves exactly the same old scalar weights, with the last factor replaced by S_(a_m+1)−uS_(a_m). The identical-pole interior part is A_n^*(S_(n+1)−uS_n). The remaining boundary terms have a_m=k and are bounded below. This applies even if a new cycle count occurs only in the next row: its interior is empty.

For mixed tuples use a truncation to conjugate levels l<R. With U_tail and W_tail the omitted sums, for each m≥2 the absolute contributions of the omitted tuples to the value in units ρ^(−n) and to the difference in units vρ^(−n), respectively, are at most
    L^(m−1)/(m−1)! · m U_tail U^(m−1),
    L^(m−1)/(m−1)! · [(m−1)U_tail U^(m−2)W + U^(m−1) W_tail].
These follow from a union bound over the position of an omitted pole; summing over all m≤L lets us make both bounds arbitrarily small by choosing R.

For a retained mixed tuple choose two distinct coordinate poles p,p′ and fix the other m−2 lengths. The varying pair a,b lies on a consecutive integer interval with a+b fixed. Traverse the interval in the direction making the geometric ratio p′/p or p/p′ have modulus at most 1. Factor the initial normalized product (its modulus is ≤1). The remaining geometric partial sums are bounded by 2 max(|p|,|p′|)/|p−p′|. The varying scalar weight is monotone if one coordinate is the unweighted last coordinate, otherwise it is a constant times 1/[a(C−a)] with C fixed, which decreases then increases. Its total variation plus terminal value is therefore at most 3/k^(m−1). Abel summation bounds the retained pair, conditional on the other lengths, by 6 max(|p|,|p′|)/[k^(m−1)|p−p′|]. For retained poles |p|≤[T√L+2πR]√k and |p−p′|≥2π. Sum over at most (Lk)^(m−2) choices of other lengths and (2R)^m pole tuples. The additional multiplier in units v for the difference is at most 2R−1. Thus the retained errors are at most C(L,T,R)/√k, with the coefficient given by these displayed bounds.

The boundary a_m=k of the difference has scalar weight ≤L^(m−2)/[(m−1)!k] for m≥2; m=1 has no boundary for n≥k. Its absolute sum in units vρ^(−n) is at most this weight times U^m ρ/π. Since ρ≤√[(T²+10)Lk], this is another explicit O(L,T,U)(1/√k). Thus for any δ>0, for all sufficiently large k, uniformly in the central domain,
    |P_n−A_n^* S_n| < 2δ ρ^(−n),
    |P_(n+1)−uP_n−A_n^*(S_(n+1)−uS_n)| < 2δ vρ^(−n).            (2)
Here and below all thresholds depend only on L and the chosen tolerances, not on n in the allowed interval.

## 3. A uniform theta model for the single-cycle terms

For s≤n^(2/5), S_n/(2ρ^(−n)) is cosφ+o(1), and (S_(n+1)−uS_n)/(2vρ^(−n)) is −sinφ+o(1), uniformly as k→∞. The primary pair contributes exactly these quantities. The farther absolute errors are bounded by ∑_(l≥1)(2l+1)[1+c_n l(l+1)]^(−4), with c_n=nπ²/(2ρ²)≥ n^(1/5)/4 once n^(4/5)≥π². This sum is ≤3c_n^(−4)∑_(l≥1)l^(−7), which tends uniformly to zero.

For n^(2/5)≤s≤T√n let x=π/s and τ=exp(−2n x²), so 0<τ≤τ_*:=exp(−2π²/T²)<1. In that range the respective models for these same normalized quantities are
    C(φ,τ)=∑_(l≥0) τ^(l(l+1)) cos((2l+1)φ),
    ∂_φ C(φ,τ).
Both approximations have errors tending uniformly to zero. Here are explicit estimates for this assertion. For each fixed farther level with d=2l+1, its complex pole power has exact form
    z_p^n = exp{−(n/2)[log(1+d²x²)−log(1+x²)]} · exp{−i_unit n atan(d x)}.
The model term is exp[−n(d²−1)x²/2] exp[−i_unit dφ]. Their modulus factors differ by at most n(d^4+1)x^4/4, by |log(1+y)−y|≤y²/2 and the 1-Lipschitz property of exp on the negative real axis. Their phase factors differ by at most n(d³+d)x³/3, from |atan y−y|≤y³/3. Since x≤π n^(−2/5), these go uniformly to zero for finitely many levels. Note exp[−n(d²−1)x²/2]=τ^(l(l+1)). The extra complex multiplier in the difference in units v is
    (1/p−u)/v = x(1−d²)/(1+d²x²) − i_unit d(1+x²)/(1+d²x²),
which differs from −i_unit d by at most d²x+d³x². After taking the real part of each pair, multiplying its model by −i_unit d gives −d sin(dφ), exactly the derivative of the cosine term. The exact tails are bounded by the b_l majorant in Section 2, and the model tails by ∑_(l≥R)(2l+1)τ_*^(l(l+1)). The latter can be bounded by ∑_(l≥R)(2l+1)τ_*^l. These tails go uniformly to zero. Truncate first, then take n large; this proves the uniform approximations.

By Jacobi's theta product (NIST DLMF §§20.2, 20.5.2), C is
    cosφ · H(φ,τ),   H=∏_(j≥1)(1−τ^(2j)) (1+2τ^(2j)cos(2φ)+τ^(4j)).
Indeed C is the usual theta2 series divided by 2 τ^(1/4); this verifies its nome and normalization. Every factor is real positive and
    H≥∏_(j≥1)(1−τ_*^(2j))³≥h>0,
where for example h=exp(−3 τ_*²/(1−τ_*²)^2) follows from −log(1−y)≤y/(1−y). The lower bound is uniform. Also |∂²_φ C|≤J:=∑_(l≥0)(2l+1)²τ_*^(l(l+1)), finite (bound by the geometric series with τ_*^l times the square). At a half-integer phase φ0=(j+1/2)π, its derivative is −sinφ0 H(φ0,τ). For |φ−φ0|≤ε where ε=min(1/8,h/(4J)), its derivative has the same sign and magnitude at least 3h/4. Termwise differentiation and the product evaluation at the half-integer are valid by uniform convergence, or by the product and the difference quotient at cosφ=0.

## 4. The signs and root count

Take δ<h ε/16 and δ<1/16. Require each approximation error in Section 3 to be less than δ. Divide the relations (2) by A_n^*≥1 and by the natural primary units (2ρ^(−n), 2vρ^(−n)); the total deviations from the models in Section 3 are then each <2δ. Thus at φ=jπ the sign of P_n is (−1)^j in both central parts. At any central zero of P_n, in the theta part |cosφ|<2δ/h<ε/8. Its distance to a half-integer phase is at most 2|cosφ|<ε, by the inverse sine bound. The model derivative therefore has sign −sinφ and magnitude at least 3h/4. The error <2δ cannot change that sign. In the small-s part at zeros |cosφ|<2δ, so the single-cycle sine likewise fixes the sign. Consequently P_(n+1) has sign −sinφ at every central zero of P_n.

At S=D/M the phase offset |φ(S)/π−M|≤max(M/D,nπ²M³/(3D³)) is <1/8 for sufficiently large k, by the standard atan bounds and M≤2√D/T. Since S≤T√D there is overlap with the central estimates. Use the edge witnesses m=1,...,M, then central witnesses φ=jπ, j=M+1,...,floor(n/2); φ is continuous and strictly decreasing in s, with φ(0)=nπ/2, so all exist in order. For the first central bracket a possible extra interval with φ<Mπ contains no zeros because there |cosφ|≥cos(π/8) and the model is separated from zero by at least h|cosφ|. The signs alternate. Thus there are floor(n/2)−1 roots in (−1,0) in these brackets. Reciprocity yields their distinct reciprocals below −1; the simple zero at 0 and the odd-row root at −1 exhaust degree n−1. This proves simplicity without assuming the conjecture.

At each bracketed root the derivative in t has the sign of the witness on its right (t=−exp(−s) increases with s). The sign of the next row is opposite, by the edge subtraction or the central phase bracket. At −1 for odd n the last witness fixes the derivative sign, opposite to −sin(nπ/2), and reciprocation transfers this opposite-sign ratio to all roots below −1 (the transferred ratio is −r^(−3) times the original). Dividing out t preserves the ratio at any negative root. The opposite signs at the previous roots together with leading signs yield a root of the next quotient between every two preceding roots and on both sides, exhausting its degree. Both rows have linear coefficient 1 before division, since exactly one excedance is possible only for the single cycle with descending tail after the minimum. The theorem follows for every pair; the last row is covered by the last pair.

## 5. Effective choice and remaining gap

For a given L first compute C_L,D_L and choose T by Section 1. Define τ_*,h and any upper bound on J from the indicated geometric sum. Choose rational ε≤min(1/8,h/(4J)) and δ<min(h ε/16,1/16), using strict slack in numerical comparisons. Take R so the explicitly bounded far errors in (2) and the theta approximation are smaller than the desired tolerances (e.g. each <δ/4 after normalization). Now increase K until the edge inequalities, the stitch offset bound, the retained Abel and boundary estimates, 3 c_n^(−4)∑ l^(−7), and the finite theta error bounds all meet their respective tolerances for k≥K. In the last bounds replace n by k in all negative powers, and x by π n^(−2/5). Each is a decreasing explicit bound in k once k dominates the elementary stated cutoffs; hence this is a finite algorithm, with no root finding or unbounded case verification required. It is intentionally not optimized.

The result addresses every fixed upper ratio L, which is stronger than proving finitely many individual cycle-count bands. It is not uniform as L→∞. In particular the transition from this bounded-ratio theorem to the earlier polynomial-size cutoff in k has not been proved, nor have the gaps for all smaller k.

