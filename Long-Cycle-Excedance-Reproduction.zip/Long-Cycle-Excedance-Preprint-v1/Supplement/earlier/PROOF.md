# Real zeros for excedances on permutations with no cycles of length one or two

**Theorem.** For every integer n ≥ 3, the polynomial E_n(t) of the stated problem has n−1 distinct real zeros: one at zero, all others negative. This is a proof with a finite exact computation for 3 ≤ n ≤ 63. No consecutive interlacing, other k, or result on descents is asserted. Internal reverse audit only; no external peer review.

## 1. Exact model

A_m(t) = sum over permutations of [m] of t^des, with A_0 = 1. For an m-cycle, m ≥ 2, put its smallest entry first. The initial step is always an excedance; the closing step never is. Excedances along the remaining word are its ascents, whose distribution equals that of descents by reversing the word. The cycle weight is thus t A_(m−1)(t); the weight of a 1-cycle is 1, not t A_0(t).

Weights multiply over disjoint cycles. Expanding the exponential by cycle counts, the factor n!/(product of (m!)^c_m c_m!) counts the ways to select the unlabeled blocks with those sizes. Consequently, for k ≥ 2,
    sum E_(n,k)(t) z^n/n! = exp(sum_(m≥k) t A_(m−1)(t) z^m/m!).
Alternatively, take the cycle of the largest element directly:
    E_(n,k) = sum_(m=k)^n binom(n−1,m−1) t A_(m−1) E_(n−m,k).
For a separate insertion recurrence, if the cycle containing n has length greater than k, remove n and splice its two neighboring arrows. Conversely, insert n after any one of the n−1 elements. For a smaller permutation with j excedances, the insertion leaves the count at j in j places and raises it to j+1 in n−1−j places: the new outgoing arrow from n is never an excedance, and the arrow to n always is. If the cycle containing n has length exactly k, choose its other k−1 labels and use its cycle polynomial. Thus
    E_(n,k) = (n−1)t E_(n−1,k) + t(1−t) E'_(n−1,k)
              + binom(n−1,k−1) t A_(k−1) E_(n−k,k)   (n≥k).
The initial terms are 1 at n=0 and zero for 0<n<k. In k≤n<2k there is only one cycle. At n=6,k=3 the contribution of two cycles is 10t²(1+t)², in addition to the single-cycle t A_5(t).

For the unrestricted permutation sum, the same insertion argument has an additional fixed-point option rather than a new ≥2-cycle term. It gives
    A_n = [1+(n−1)t] A_(n−1) + t(1−t) A'_(n−1).
Here one can also obtain this recurrence by inserting in a descent word, so the ordinary excedance/descent counts agree. Its EGF is (1−t)/(exp((t−1)z)−t): this expression has constant term 1 and direct differentiation verifies (1−tz)F_z=F+t(1−t)F_t, which uniquely encodes the recurrence. Deleting the weights 1 and t of cycles of sizes 1 and 2 from the exponential model gives
    sum E_n(t) z^n/n! = exp(−z−tz²/2) (1−t)/(exp((t−1)z)−t).

For n≥3 no fixed points occur. An excedance of the inverse corresponds to a deficiency of the permutation, so E_n(t)=t^n E_n(1/t). A cyclic increasing traversal 1→2→...→n→1 has n−1 excedances. No permutation has n excedances. Thus deg E_n=n−1, and by reciprocal symmetry the root at zero is simple.

## 2. Alternating signs for n≥64: poles

Let s≥0, q=exp(−s), a=1/(1+q), b=q/[2(1+q)²], and
    H(z)=exp(−az+bz²)/(exp(−z)+q).
After scaling the EGF variable by 1+q, E_n(−q)=n!(1+q)^(n+1)[z^n]H. Write ρ=(s²+π²)^(1/2). Define the continuous phase
    φ(s) = (n+1) atan(π/s) + πa − 2πbs,
with atan(π/0)=π/2. I show that when s≤4√n and φ(s)=jπ, the sign of E_n(−q) is (−1)^(j+1).

The poles of H are simple, at p=s+(2d+1)πi for d∈Z, and Res_p H=exp(−ap+bp²)/q. Integrate H(z)/z^(n+1) on the counterclockwise square with sides Re z=±L and Im z=±L, where L=2π ceil(ρ/π). Then 2ρ≤L<2ρ+2π, no pole lies on the contour, and the closest pair p=s±πi is inside. The coefficient is the contour integral divided by 2πi minus the sum of the nonzero-pole residues of the integrand. The closest pair contributes the real number −2|Res_(s+πi) H| ρ^(−n−1) cos φ(s). Use B=2|Res_(s+πi) H| ρ^(−n−1) as the error unit.

On the horizontal sides |exp(−z)+q|=q(1+exp(s−Re z)); on the vertical sides it is at least half that, by the reverse triangle inequality and |s−Re z|≥π (so exp(|s−Re z|)>3). For real u and 0<a≤1, exp(au)≤1+exp(u). These facts imply
    max_contour |H|/|Res_(s+πi) H| ≤ 2 exp[b(L²+π²)] ≤ 2e^22.
Indeed, if 0≤s≤5, ρ≤2π and L≤4π, so b≤1/8 gives b(L²+π²)≤17π²/8<22. Otherwise L<2s+4π and b≤exp(−s)/2. The upper bound exp(−s)((2s+4π)²+π²)/2 decreases on s≥5 by differentiation. At 5 it is <22 using π<4 and e>2.

The normalized integral is bounded by (4/π)e^22 ρ (ρ/L)^n ≤ (4/π)e^22 (5√n)2^(−n)<1/6. The last inequality follows at 64 from π>3 and e<3 and decreases thereafter.

The remaining pole pairs, at p=s±(2d+1)πi for d≥1, each have normalized magnitude at most
    (1+4π² d(d+1)/(s²+π²))^(−(n+1)/2)
    ≤ (1+c d(d+1))^(−2),  c=(n+1)π²/(s²+π²)>1/2.
The Gaussian residue factor only reduces the magnitude. The inequality uses Bernoulli's inequality on the power (n+1)/4≥1, and c>1/2 follows from s²≤16n and 8<π²<16. It suffices to bound the sum by 1/4 + 4(1/16+integral_2^∞ x^(−4) dx)=2/3, using the separate d=1 term and d(d+1)≥d² thereafter. This bounds even the infinite sum of absolute errors, although only the enclosed poles are used. At cos φ=±1 the total normalized error is <1/6+2/3<1. This proves the sign.

## 3. Alternating signs near zero for n≥64

Let M=floor(√n/3). For each integer 1≤m≤M take s=n/m. I show the sign is (−1)^m. Put δ=1−a, and
    B_n(x)=n![z^n] exp(xz+bz²)
          = sum_(h=0)^floor(n/2) n! b^h x^(n−2h)/(h!(n−2h)!).
The geometric series in q exp(z) converges normally near z=0, because q<1. Therefore
    n![z^n]H = sum_(l≥0) (−q)^l B_n(l+δ).
For l≥1 the moment lies between l^n and 2l^n. The lower bound uses the h=0 term. For the upper bound factor out (l+δ)^n and use n!/(n−2h)!≤n^(2h):
    B_n(l+δ)/l^n ≤ exp(nδ+n²b) ≤ exp(n² exp(−3√n)) < 2.
Here δ≤q, b≤q/2, and n≥64; the last exponent decreases on that range, and at 64 it is at most 4096/2^24<1/2.

Let V_l=q^l l^n for l≥1. The outward successive ratios from index m decrease on both sides, because V_(l+1)/V_l=q(1+1/l)^n decreases with l. The first outward positive-side ratio is at most exp(−n/[2m(m+1)])≤exp(−9/4)<1/8. This follows from x−log(1+x)≥x²/[2(1+x)] at x=1/m, by integrating u/(1+u) between 0 and x. For m≥2 the first negative-side ratio is at most exp(−n/[2m²])≤exp(−9/2), by integrating u/(1−u), giving log(1−x)+x≤−x²/2. When m=1 that side is empty. The inequality exp(9/4)>8 follows, for example, from e>8/3 and exp(1/4)>5/4. Thus the sum of V_l for l≥1, l≠m is at most 2V_m/7; their total absolute moment contribution is at most 4V_m/7.

For l=0, use (2h)!/h!≤n^h term by term and the binomial theorem:
    B_n(δ) ≤ (δ+√(nb))^n ≤ (1+√n)^n q^(n/2).
Since m≤n/4, s≥3√n, m≥1, and log(1+√n)≤√n/2 (at √n=8 and by the derivative thereafter), division by V_m bounds this error by exp(−n√n/4)<1/4. The dominant term has magnitude at least V_m, and 4/7+1/4<1, so the sign claim follows.

## 4. Stitching and root count

Label each edge witness with j=m+1, giving j=2,...,M+1 in decreasing order of s and sign (−1)^(j+1). Set S=min(n/M,4√n). If S=n/M, then φ(S)/π≤(n+1)M/n+1<M+2; if S=4√n, then φ(S)/π≤(n+1)/(4√n)+1<√n/3+1<M+2. These bounds use atan u≤u and 0<a≤1, b≥0. At s=0 the value is φ(0)=(n+2)π/2, since a=1/2. By continuity choose witnesses for consecutive j=M+2,...,floor((n+2)/2) at strictly decreasing s from S toward 0; to choose the next one apply the intermediate value theorem on the interval from 0 to the previous witness. If n is even, use s=0 for the last witness, and if odd all witnesses have s>0. No assertion of phase monotonicity is required.

Consequently there are floor(n/2) alternating-sign witnesses in [−1,0), one for each j from 2 to floor((n+2)/2). The open intervals between them give floor(n/2)−1 distinct roots in (−1,0). Each yields a reciprocal root in (−∞,−1). In the odd case reciprocity forces E_n(−1)=0. Including zero gives n−1 distinct roots in both parities, equal to the degree. This proves the theorem for n≥64.

## 5. Exact finite range

Run from the archive root:
    python -B exact/verify.py 63
Use ordinary Python (do not enable -O, which removes assertions). No third-party dependency.
The code compares the two recurrences to 63, compares both against literal permutations to 8, and prints the requested small rows. It strips a factor t in gamma coordinates by writing
    E_n(t) = t(1+t)^(n−2) G_n(t/(1+t)²).
It constructs G_n triangularly in the integer basis t^i(1+t)^(n−2i) and verifies the reconstruction. For 3≤n≤63 it checks that G_n has the full degree floor(n/2)−1, constant coefficient 1, and exactly that many distinct negative roots by Sturm's theorem on its square-free part. Arithmetic is rational; clearing denominators and dividing by positive gcd preserves the signs of Sturm remainders. At −∞ the sign comes from the leading term; at 0 the constant term is used, with zeros in the sequence omitted. For each negative gamma root r the equation t/(1+t)²=r has two distinct real negative roots: its discriminant is 1−4r>0, product 1, and sum (1−2r)/r<0. Different r give disjoint pairs not involving −1 or 0. At maximal gamma degree the only remaining prefactor is t for even n, t(1+t) for odd n. This proves the theorem in the finite range. At n=3, G_3=1 and its Sturm negative-root count is zero; the formula still applies.

