# Strict consecutive interlacing for the fixed minimum cycle length three

Let E_n(t) count permutations of [n] with all cycle lengths at least three by excedances, and put F_n(t)=E_n(t)/t for n≥3.

**Theorem.** For each n≥3, the roots of F_n strictly interlace those of F_(n+1). In particular the two polynomials have no common root. Adding back the common zero proves the original (weak) consecutive interlacing assertion for E_n, for the fixed threshold k=3 only.

## 1. Conventions and setup

Use the insertion model and restricted Eulerian EGF derived in PROOF.md. Write q=e^(−s) for s≥0 and let
    H(z)=exp(−az+bz²)/(exp(−z)+q),
    a=1/(1+q), b=q/[2(1+q)²], δ=1−a, h_n=[z^n] H.
Then E_n(−q)=n!(1+q)^(n+1)h_n. The degree of E_n is n−1, its zero at zero is simple, and E_n(t)=t^n E_n(1/t). We prove the following inequality at each nonzero root r of E_n:
    E_(n+1)(r) / E_n'(r) < 0.                    (1)
This also holds with E replaced by F, since both numerator and denominator then divide by r. Since F_n has n−2 simple real roots, (1) places a root of F_(n+1) between each pair of adjacent roots of F_n and one outside at each end: at the root positions the derivative signs alternate, and the outer signs of F_(n+1) are fixed by its degree n−1 and positive leading coefficient. The number of these intervals equals the degree. We give a fresh proof for n≥64 and use exact computation for 3≤n≤63.

## 2. Two coefficient evaluations for the bulk

Assume n≥64 and 0≤s≤3√n. Define ρ=√(s²+π²), p=s+iπ, u=s/ρ², v=π/ρ² and the phase
    φ=(n+1)atan(π/s)+πa−2πbs ,
taking atan(π/0)=π/2. Write B=2|Res_p H|ρ^(−n−1)>0. We claim
    |h_n/B + cos φ| < 1/3 ,
    |(h_(n+1)−u h_n)/(Bv) − sin φ| < 1/3.     (2)

Integrate H(z)/z^(n+1) on the square in PROOF.md, with vertical and horizontal sides at ±L, L=2π ceil(ρ/π). Its side length is 2L; neither the simple poles s+(2d+1)πi nor zero lie on its sides. For the second bound multiply the integrand by (1/z−u). The coefficient is the integral divided by 2πi minus the nonzero-pole residues. The primary pair contributes −B cos φ in the first calculation. In the second, multiplying the upper-pole summand by 1/p−u=−iv and taking minus twice the real part gives +Bv sin φ.

On the contour the previously proved bound |H|/|Res_p H|≤2e^22 still holds. In units B the integral error is ≤(4/π)e^22 ρ2^(−n) for the first bound. For the second, the extra multiplier has absolute value after division by v at most (1/L+|u|)/v ≤3ρ/(2π). Both errors are <1/100: use ρ≤4√n, 3<π, e<3, and the decreasing bound proportional to n2^(−n), checked at 64.

For the other pair with imaginary parts ±jπ, j=2d+1,d≥1, the unweighted relative magnitude is at most (1+4π²d(d+1)/ρ²)^(−(n+1)/2). The new multiplier on a pole divided by v is at most j. In fact, putting x=s/π, its squared absolute value simplifies to (j²x²+1)/(x²+j²)≤j². Applying Bernoulli to the fourth root of the reciprocal magnitude gives the weighted sum bounded by
    sum_(d≥1) (2d+1)/(1+c d(d+1))^4 ,
    c=(n+1)π²/(2ρ²)>1/2
because π²>9 and ρ²≤9n+π². The same bound applies to the unweighted sum. Bound d=1 by 3/16, d=2 by 5/256, and the remaining terms by 40 sum_(d≥3)d^(−7)≤40(3^(−7)+3^(−6)/6), using d(d+1)≥d² and 2d+1≤(5/2)d. Their sum is less than 1/4. Combining the two errors proves (2).

Whenever h_n=0 in this range, (2) implies |cos φ|<1/3 and thus |sin φ|>1/3. The sign of E_(n+1)(−q) is then the sign of sin φ.

## 3. Two coefficient evaluations near t=0

Set M=ceil(√n/3), S=n/M. Thus M≤(11/24)√n and M+1≤(7/12)√n for n≥64, and (24/11)√n≤S≤3√n. For 1≤m≤M let the edge sample be s=n/m. We will use these two assertions:
- At the sample s=n/m, E_n(−q) has sign (−1)^m.
- For 1≤m<M, at a zero of E_n in n/(m+1)≤s≤n/m, the sign of E_(n+1) is (−1)^(m+1).

Write B_j(y)=j![z^j]exp(yz+bz²). Expansion of the geometric series near zero gives
    j!h_j = sum_(l≥0) (−q)^l B_j(l+δ).
For s≥S, l≥1, the following estimates hold:
    l^n≤B_n(l+δ)≤(101/100)l^n ,
    l≤B_(n+1)(l+δ)/B_n(l+δ)≤l+1/100.        (3)
The first uses the term (l+δ)^n and the upper bound exp(nδ+n²b)≤exp(n²e^(−(24/11)√n))<101/100. In the second, coefficient extraction gives B_(n+1)(y)=y B_n(y)+2bn B_(n−1)(y), and B_n(y)≥y B_(n−1)(y). Thus the excess over l is between 0 and (n+1)q<1/100. For the numerical inequalities, the bound n²e^(−(24/11)√n) decreases for n≥64 by differentiation and is <1/200 at 64 using e>8/3 and (8/3)^17>819200; also exp(1/200)≤1/(1−1/200)<101/100.

Put V_l=q^l l^n for l≥1. The ratios V_(l+1)/V_l=q(1+1/l)^n decrease with l. At s=n/m, the first outward upper ratio V_(m+1)/V_m is at most exp(−n/[2m(m+1)])≤exp(−144/77)<1/6, and (when m≥2) the first lower ratio V_(m−1)/V_m is at most exp(−n/[2m²])≤exp(−144/77)<1/6. These follow from x−log(1+x)≥x²/[2(1+x)], and log(1−x)+x≤−x²/2, by integration. Here n/[2M(M+1)]≥144/77, and exp(144/77)>exp(9/5)>6, by the partial series through order 6. In an interval n/(m+1)≤s≤n/m, the ratios outward from m on the left and from m+1 on the right still satisfy the same bounds: maximize the left ratio at s=n/m and the right ratio at s=n/(m+1). All further outward ratios are smaller by monotonicity.

We record one bound for the l=0 term in both applications. For j=n,n+1,
    B_j(δ)≤(δ+√(jb))^j≤(1+√j)^j q^(j/2)
by comparing the even terms in the binomial expansion, using (2h)!/h!≤j^h for 2h≤j. For s≥S, m≤M≤n/4 and m≥1, these bounds imply
    [B_(n+1)(δ)+(M+1)B_n(δ)]/V_m < 1/100 .
Indeed x=√n≥8 implies log(1+√(n+1))≤log(2+x)≤x/2 (at 8 and then by derivatives). Thus both ratios B_j(δ)/V_m are at most exp((n+1)√n/2−s(n/2−m))≤exp(−n√n/30); the last follows from s≥(24/11)√n and 1/22−1/(2n)≥1/30. The additional factor M+2≤n gives n exp(−n√n/30)<1/100, checked at 64 with e>2, and decreasing thereafter.

At s=n/m, the relative error from l≠m, l≥1, is at most (101/100)·2/5 and the l=0 error <1/100, in units V_m. This proves the sample sign. Now at a root in the interval corresponding to m,m+1 consider
    (n+1)!h_(n+1)−(m+1/2)n!h_n.
Its two contributions from l=m,m+1 have common sign (−1)^(m+1) and combined magnitude at least (49/100)(V_m+V_(m+1)), by (3). The absolute error from the other l≥1 terms is at most
    (101/100)(V_m+V_(m+1)) sum_(h≥1) (h+51/100)6^(−h).
The sum multiplied by 101/100 is less than 7/20, since the sum equals 6/25+51/500. The l=0 error is <V_m/100. Thus the sign is (−1)^(m+1); at a root this is the sign of h_(n+1) itself. No approximation of a root by an explicit t-value was needed.

## 4. Matching the signs and proving (1)

For this n, φ is strictly decreasing in s. Indeed a′=2b and b′=−b(1−q)/(1+q), so
    φ′/π=−(n+1)/(s²+π²)−2sb′ ≤−(n+1)/(s²+π²)+se^(−s)<0.
For the last inequality, (s³+π²s)e^(−s)≤27/e³+π²/e<9 by elementary maxima. Also
    |φ(S)/π−(M+1)|<1/8 .
For the upper bound, atan y≤y gives ≤M/n≤11/(24√n). For the lower bound atan y≥y−y³/3 gives a lower bound of −(n+1)π²M³/(3n³)−(1+S)e^(−S). The first absolute term is at most 20(11/24)^3/(3√n)<1/12 and the second is <1/100 since S≥17. The bounds place the transition in the phase interval of width π/4 centered at (M+1)π.

There are floor(n/2) alternating sign samples: first the edge values m=1,...,M (with label j=m+1), then the bulk values φ=jπ for j=M+2,...,floor((n+2)/2). For even n the last value is at s=0. For odd n the last one is before s=0 since φ(0)=(n+2)π/2. As in the root count in PROOF.md, these samples yield exactly one root between every successive pair, and, together with reciprocals, zero, and the odd root −1, account for all n−1 roots. They are simple.

On an edge interval the sign of E_n′ at its unique root is the sign at its right endpoint in t, namely (−1)^m. The second assertion of Section 3 now proves (1). Any bulk root in the bracket from sample j to sample j+1 has φ∈(jπ,(j+1)π), so (2) gives sign (−1)^j for E_(n+1); the sign at the right endpoint for E_n is (−1)^(j+1). This remains true for the first bulk interval, whose right endpoint is S: if the phase there is below (M+1)π, (2) excludes a root until the phase reaches (M+1)π, because |cos φ|≥cos(π/8)>1/3 in the intervening part. At the odd-n root −1, write n=2p+1. There φ=(p+3/2)π, so E_(n+1)(−1) has sign (−1)^(p+1); E_n′(−1) has sign (−1)^(p+2) from the last sample, j=p+1, to its right. This proves (1) at −1. For each root r∈(−1,0), differentiation of the reciprocal identity gives E_n′(1/r)=−r^(2−n) E_n′(r). The ratio at 1/r is the ratio at r multiplied by −r^(−3)>0, so (1) holds there too.

## 5. Exact finite range

Run python -B check_interlacing_fast.py 63 (standard library only); see INTERLACING_REPLAY.md for the quicker gamma-coordinate certificate. For each n=3,...,63 the code builds F_(n+1), F_n from the integer recurrence, then computes successive signed remainders (negative of the ordinary remainder up to positive scale). It checks each degree drops by exactly one, with positive leading coefficients down to the final positive constant. Using a positive multiplier (leading coefficient of the divisor) in every elimination and dividing only by an exact positive scale leaves the signs unchanged.

Here is why the certificate implies strict interlacing. The last linear polynomial and positive constant are the base case. If consecutive lower polynomials g,h, degrees d,d−1, already interlace with positive leading coefficients, h(r) has the sign of g′(r) at each root r of g, by counting factors to the right of r. At such a root the previous polynomial f has the sign of −h(r) by the signed remainder equation. Since f has degree d+1 and positive leading coefficient, the inner intervals and the two outer intervals each have an opposite-sign pair. They yield d+1 distinct roots, strictly alternating with those of g. Apply this argument backward up the chain. The initial E rows are E_0=1, E_1=E_2=0; the replay does not assume real-rootedness in the finite range.

## Scope and source check

The SymCat catalog and original author's issue 2590 and Davis's issue 81 still list the question or conditional work; the targeted search did not locate an existing complete k=3 result as of 2026-11-26. See SOURCES.md in the previous research package for links and caveats. This addendum does not resolve thresholds k≥4 or the descent conjecture and is not externally peer reviewed.

