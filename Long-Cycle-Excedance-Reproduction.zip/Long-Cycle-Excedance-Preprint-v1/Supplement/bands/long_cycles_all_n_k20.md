# Full n coverage for every k≥20

2026-11-27 06:30 UTC. For all integers k≥20, n≥k, genuine E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces E_(n+1,k)/t. The all-row threshold has dropped from 24 to 20. This does not claim the remaining k below 20 are all solved. No original polynomial rows were enumerated in this argument.

For 20≤k≤23, earlier note long_cycles_k20_through_3k.md proves all n≤3k with the next-row comparisons. The upper part of long_cycles_k16_upper_and_edge.md proves all n≥16k, and its half-sqrt edge proves the actual exterior signs for every n≥3k in this k bracket. Here we close the central part on 3≤n/k≤16. Larger k are already complete. Every result includes comparisons of both joining old rows.

## Quarter-degree mark refinement

The two-cycle normalized count peak .590/k follows for k≥20 from exp(.590−1/20)>1/.590 and the harmonic head induction. For j≥3k additionally d_j≥.555/k by the earlier lower envelope and head propagation. Hence T(2k)<.176/k, T(Lk)<.352/(k L!), ξ=.838, previous tilted bound J with .117 two-cycle variation. All retained count ratios are <1.81, and for residual degrees ≥2k use <1.064, since .590/.555<1.064. The relative symmetric cutoff errors at residual degrees ≥2k and ≥3k are <.153 and <.064 respectively. Larger integral cutoff L uses .704/L!.

Replace the earlier coarse delta marks by quarter-degree classes, in units k for degrees and 2/k for norms. Atom at 1 has mass 1/2. For r=1,1.25,1.50,1.75, the linear pre-2k degrees in (floor(rk),floor((r+.25)k)] have mass at most [1/(r−.05)−1/(r+.25)]/2, using denominator 1 instead of r−.05 at r=1; omit 2k itself. This is the telescoping d_j=1/j bound and the undershoot of at most 1 in the floor. For r≥2 each quarter class [rk,(r+.25)k) contains at most .30k integer shifts. For 2≤r<3 the count recurrence jΔ_j=d_(j−k)−d_(j−1) bounds the size numerator by max[1/(r−1)−.5,.590−1/(r−.75)]/k; d_(j−k)=1/(j−k) here. Divide by j≥rk and convert to the 2/k norm unit, giving factor .15/r. For 3≤r<4, the count numerator difference is at most .090/k (counts both in [.5,.590]/k). For r≥4 it is at most .035/k (both in [.555,.590]/k). Minimize each of these with the full tail bound .176/floor(r)! in the same norm units. These bounds are simultaneously valid per class, even when their sum overestimates the total norm; use the old global ξ bound separately where it is tighter.

Form the same positive convolution of lower and upper degree bounds for each product as in the earlier all-n K32 and K24 proofs. Sum over m factors with m! compensation; the distinct factors of the original product are enlarged to all possible ordered choices. Far envelope uses pure m-diagonal g plus all retained convolution classes with lower degree ≤(N−1+1/K)k, and radial exponent ≥max(k−1,(B−h/4)k). For old absolute primary amplitude use the same summation at scale p without far radial weights, with count ratio cap 1.064 at γ=B−h/4≥2, and min(1.81,max(1.064,1/[.555 max(1,γ)])) below. This caps the numerator for remaining one-cycle row m by 1/m, otherwise by .590/k. Optimize by taking min with the L=2 tilted absolute prefix bound based on baseline 1.064 plus excess .746; both bounds control the weighted absolute sum P, not merely the modulus of its final cancellation.

For a reference-relative error epsilon, sum the quarter-degree marks using only total upper degree h, including the shifts omitted from the exact finite C_n. As in the K24 method, bound each coefficient difference price by 1 if γ<1, by max(.153,1/(.555γ)−1) for γ in [1,2), by .153 and .064 for integral lower cutoffs 2 and 3, and by .704/floor(γ)! thereafter. Treat all type degrees beyond j=ceil(B)+1 as one high class with mass .176/j!, and merge all h beyond a high cap where they have error-price 1. Truncate only mark count at m=16, bounding the remaining contribution by exp(pA)(pA)^17/17!, where A is the total majorant type mass; the price beyond the cutoff is always ≤1. This gives the block epsilon and min with old tilted epsilon. At s≥4sqrt(k), compare the vertical log bound .41, real fraction .53, and the direct log bound .79p (segment factor .64 suffices since sin(theta)<.18). Use also the independent unweighted real floor 2−exp(ξp). The small-s core uses the unweighted reference lower only, with the same block error.

## Direct primary drift and refined mismatch

On the overlapping retained degrees, put m=n+1−b≥k+1. The exact coefficient recurrence and the one-cycle range give |Δ_m|/d_(m−1)≤1/(k+1). Also |d_n−d_(n+1)|/d_(n+1)<1/(n+1). Hence the difference of normalized adjacent count factors, divided by the old factor d_(m−1)/d_n, is at most (1+1/(n+1))/(k+1)+1/(n+1)≤1/k+1/(n+1). Its contribution is at most P/k+P/(Bk), using the weighted absolute P from above. This does not substitute a signed amplitude bound for an absolute coefficient sum.

The new boundary coefficient is at b=n+1−k. If it consists entirely of degree-k atoms, its number j satisfies B−1<j≤floor(N−1+1/K). Sum only these feasible terms (p/2)^j/j!, not the entire generic atom tail. Products with at least one nonatom can mark one such factor with coefficient supremum p/[2(k+1)], since |Δ_b|≤1/[k(k+1)] for b>k, and allow the remaining factors to use total plain coefficient norm ξp. Their number is at most floor(N−1+1/K)−1, giving the finite exponential partial sum of powers of ξp up to that order. Both boundary contributions receive the retained count ratio at most 1.81. The proof uses the exact total degree even in the sparse case where there is no pure-atom contribution at all. Take min of this direct adjacent bound and 2epsilon where a reference comparison has been made.

The true diagonal mismatch via the count difference recurrence can use relative-loss numerator factor .163 when n≥3k: d_n≥.555/k, d_(n+1−k)∈[.5,.590]/k, and d_(n+1)≥.555/k. Thus normalized difference costs at most .163/(n+1), before the angle normalization. Take min of .163 and .704/floor(B−1)! in the usual normalized mismatch R(1+g/3)/B units.

## Joins and completion

The exact ellipse tests use the smaller far envelope of the block and tilt bounds and the stronger real primary floor. In the low B≤4 rows the absolute amplitude is enough. At higher ratios the epsilon comparison supplies the sharper floor where needed; all small-s cores are checked. For each interval, only the witness index M is ranged over, not individual k or n: M≥floor(sqrt(ceil(KB)−1)/2), and D≤min(4(M+1)^2−1,floor(23N)−1) at K=20. Check min(D²/[M²K], ND²/[M²(D+1)])<a² at this maximum allowed D for each integer M. This monotonic bound is exact with both k endpoints. The oriented arctan phase for the .5-floor edge is strictly between Mπ and (M+1)π, so the exact degree and reciprocal/parity splice needs no separate exclusion window in these intervals. Old zero signs come from the centered ellipse. Replayed all intervals 3→16, including fractional overlap order and all small-s branches, with exact integer/rational checks. Together with the separate initial and upper rows this proves the all-n result k≥20, without asserting the remaining smaller k.

## Exact central replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=20,sk=q(447,100),xi=q(838,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[3.25,400,45,3,4],[4.25,400,45,3,4.5],[4.5,400,45,3,4.75],[4.75,400,45,3,5.25],[5.25,400,45,3,6],[6,400,45,3,6.5],[6.5,400,45,3,7],[7,400,45,3,8],[8,400,45,3,9],[9,400,45,3,10.75],[10.75,400,45,3,12.25],[12.25,400,45,3,14.25],[14.25,400,45,3,16],[3,470,45,2,3.25],[3.25,475,45,3,4],[4,503,45,2,4.25],[4.25,526,45,3,4.5],[4.5,540,45,3,4.75],[4.75,554,45,3,5.25],[5.25,572,45,3,6],[6,608,45,3,6.5],[6.5,631,45,3,7],[7,640,45,3,8],[8,697,45,3,9],[9,734,45,3,10.75],[10.75,797,45,3,12.25],[12.25,847,45,3,14.25],[14.25,898,45,3,16]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(41,100).sq().div(two));
ck(pu.div(q(36)).mul(ex(q(5,16)).sq()).lt(q(41,100).sq()),"vertical log");
ck(q(53,100).lt(q(59,100).mul(ca)),"vertical positive");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(41,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=9;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(min(q(163,1000),q(704,1000).div(fact(Math.floor(B-1)))).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4)));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(117,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(153,1000):L===3?q(64,1000):q(704,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1064,1000):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const core=a0===400;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 function typesOf(jlast){const types=[[4,4,q(1,2)]]; for(let j=4;j<8;j++){const den=j===4?q(1):q(j,4).sub(q(1,20));types.push([j,j+1,o.div(den).sub(q(4,j+1)).div(two)]);}
 for(let j=8;j<4*jlast;j++){const r=q(j,4);let v;if(j<12){v=max(o.div(r.sub(o)).sub(q(1,2)),q(590,1000).sub(o.div(r.sub(q(3,4))))).mul(q(15,100)).div(r);}else{v=q(j<16?9:35,j<16?100:1000).mul(q(15,100)).div(r);}
 v=min(v,q(176,1000).div(fact(Math.floor(j/4))));types.push([j,j+1,v]);}return types;}

 {
  const types=typesOf(Math.ceil(N));
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=q(0),wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const rem=q(Math.max(4,4*B-h),4); const factor=4*B-h>=8?q(1064,1000):min(U0,max(q(1064,1000),o.div(q(555,1000).mul(rem))));
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1064,1000).mul(abs).add(q(746,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let bw=q(0),t=o,pow=o, jmax=Math.floor(N-1+1/K);
  const pp=p.div(two),slot=xi.mul(p);
  for(let j=1;j<=jmax;j++){t=t.mul(pp).div(q(j));if(j>B-1)bw=bw.add(t);}
  let sum=o;for(let j=1;j<jmax;j++){pow=pow.mul(slot).div(q(j));sum=sum.add(pow);}
  drift=up(P.div(q(K)).add(P.div(q(B*K))).add(U0.mul(bw.add(pp.div(q(K+1)).mul(sum)))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const Qmax=Math.ceil(4*B)+4, Jlast=Math.ceil(B)+1, md=16, es=[[4,q(1,2)],[6,q(1,6)],[8,q(1,12)],[12,q(105,2000)]];
  for(let j=3;j<Jlast;j++)es.push([4*(j+1),q(176,1000).div(fact(j))]);
  es.push([Qmax,q(176,1000).div(fact(Jlast))]);
  const msum=es.reduce((s,[_,w])=>s.add(w),q(0)).mul(p);
  let epsDP=q(0),prod=o,dp=new Map([[0,o]]);
  const pref=new Map();
  function modLoss(h){
   if(pref.has(h))return pref.get(h);
   const r=Math.floor((4*B-h)/4);let v=q(1);
   if(r>=4)v=q(704,1000).div(fact(r));
   else if(r===3)v=q(64,1000);
   else if(r===2)v=q(153,1000);
   else if(r===1)v=max(q(153,1000),o.div(q(555,1000).mul(q(4*B-h,4))).sub(o));
   pref.set(h,v);return v;
  }
  for(let m=1;m<=md;m++){
   const tmp=new Map();
   prod=prod.mul(p).div(q(m));
   for(const [h,v] of dp)for(const [s,w] of es){let f=Math.min(Qmax,h+s);tmp.set(f,(tmp.get(f)??q(0)).add(v.mul(w)));}
   dp=tmp;
   for(const [h,v] of dp)epsDP=epsDP.add(prod.mul(v).mul(modLoss(h)));
  }
  let rem=o;for(let i=1;i<=md+1;i++)rem=rem.mul(msum).div(q(i));
  epsDP=up(epsDP.add(rem.mul(ex(msum))));
  const eps=min(epsDP,up(abs.mul(delta).add(ps)));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=core?o.sub(abs):max(q(53,60).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(79,100)); if(!core&&pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  c=max(c,ref.sub(eps));slice=q(87,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 
 if(!core){
  const minD=Math.ceil(B*K)-1,maxD=Math.floor(N*23)-1,Nq=q(Math.round(4*N),4);
  let M=Math.floor(Math.sqrt(minD)/2);
  ck(4*M*M<=minD&&minD<4*(M+1)*(M+1),"minimum M");
  for(;4*M*M<=maxD;M++){
    const d=Math.min(maxD,4*(M+1)*(M+1)-1);
    const s1=q(d*d,M*M*K),s2=Nq.mul(q(d*d,M*M*(d+1)));
    ck(min(s1,s2).lt(a.sq()),"finite M envelope");
  }
 }
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0];
ck(q(100,59).lt(lo(q(59,100).sub(q(1,20))))&&q(117,1000).mul(q(3,2)).lt(q(176,1000)),"count variation");
ck(o.add(q(694,1000)).add(q(1,78)).lt(q(59,100).mul(q(59,20))),"count upper head");
ck(q(59,100).sub(q(1,2)).div(q(555,1000)).lt(q(163,1000)),"direct mismatch");
ck(q(590,555).lt(q(1064,1000))&&o.div(q(555,1000)).lt(q(181,100))&&o.sub(q(500,590)).lt(q(153,1000))&&q(590,555).sub(o).lt(q(64,1000)),"count ratios");
ck(pu.div(q(4).mul(sk)).lt(q(18,100))&&q(64,100).sq().mul(q(236,100)).lt(o)&&o.div(q(2).mul(q(64,100))).lt(q(79,100)),"log improvement");
let end=q(3);
for(const [B,a,al,L,N] of rows)if(a!==400){const low=q(Math.round(4*B),4),hi=q(Math.round(4*N),4);ck(!end.lt(low)&&end.lt(hi),"overlap");end=hi}
ck(!end.lt(q(16)),"last interval");
```
