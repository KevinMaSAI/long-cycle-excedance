
# Edge comparison using exact balance at an old zero
2026-11-27 00:15 UTC. This is a structural edge lemma and explicit sufficient conditions, not yet a new complete parameter range for the mother conjecture.

Use the occupancy notation S_n(s)=E_(n,k)(−exp(−s))/(1+exp(−s))^n=sum_(r≥1)(−1)^r w_r, with w_r=exp(−rs) r^(n−1) A_n(r)>0. Write D=n−1 and D_r=r(A_(n+1)(r)−A_n(r))/A_n(r). Then S_(n+1)=sum (−1)^r (r+D_r)w_r. All series and their first derivatives converge absolutely for s>0. On a bracket s∈[D/(m+1),D/m] split into tails w^L_a=w_(m−a) and w^R_a=w_(m+1+a), a≥0, setting w_r=0 for r≤0. Let alpha_L=w^L_1/w^L_0, alpha_R=w^R_1/w^R_0. Assume each outward sequence has successive ratios ≤λ≤1/2. This bound may be checked separately on the two sides. In particular its alternating total S^L or S^R lies in [(1−alpha)w_0,w_0].

## Curvature bound from exact cancellation

At an old root the two alternating totals agree, say S^L=S^R=B>0. Thus beta=w_(m+1)/w_m belongs to [1−alpha_L,1/(1−alpha_R)]. The quantities
    P_L=alpha_L beta = [A_n(m−1) A_n(m+1)/A_n(m)^2] (1−1/m²)^D,
    P_R=alpha_R/beta = [A_n(m) A_n(m+2)/A_n(m+1)^2] (1−1/(m+1)²)^D
do not depend on s. At m=1 take P_L=alpha_L=0. Consequently alpha_L(1−alpha_L)≤P_L and alpha_R(1−alpha_R)≤P_R. Since alpha_{L,R}≤λ≤1/2, a bound P_i≤a_i(1−a_i), 0≤a_i≤1/2, proves alpha_i≤a_i at every root in the bracket. This is potentially much smaller than a pure tail ratio at either witness. No a priori estimate on the old root's location within the bracket was needed.

## Derivative and next-row comparison

For any f of the offset a, let a bar denote the mean against the corresponding alternating tail divided by B; it is a signed mean. Band signs are exact:
    (-1)^m S_n'(s)/B = 1 + bar a_L + bar a_R,
    (-1)^(m+1) S_(n+1)(s)/B = 1 + bar a_L + bar a_R + bar D_R − bar D_L.
Both follow by writing r=(m−a) or (m+1+a) and using equality of the two alternating masses. For a≥1 the numbers a w_a decrease because their successive ratio is at most 2λ. Leibniz and B≥(1−alpha)w_0 give bar a≥−alpha/(1−alpha). This suffices for old derivative positivity when the two lower bounds sum above −1.

For example, suppose D_r≥0 and D_(m−a),D_(m+1+a)≤d+gamma a on the actual indices, and both alpha≤α. In the adverse lag contribution, only even a for L, and only odd a for R, need be included. At a≥1 the bounds w_a/w_0≤α λ^(a−1) and B/w_0≥1−α apply. This gives the sufficient next-row margin
    1 − [2α + d + α(d/(1−λ)+gamma/(1−λ)^2)]/(1−α).
It may be tightened by tracking different α on each side or using D_(m+1)−D_m before bounding the tails. Positive derivative at all old zeros also gives uniqueness within the bracket when endpoint signs differ, by the opposite-orientation condition at consecutive simple zeros.

## Example constants for a future occupancy application

Suppose D≥1536, m+1≤M=floor(sqrt(D)/2), and all amplitude ratios A_n(r)/A_n(j) at the indices used in the tails lie in [1/C,C] for C=281/100. This is a sufficient assumption, not asserted globally for occupancy. For the pure weights exp(−rs)r^D, each outward ratio is at most eta=4/25: the first exponent loss is ≥D/(2M(M+1))≥78/41, with subsequent ratios improved by log-concavity, and exp(78/41)>25/4. Hence λ=C eta<.450. At any root P_{L,R}≤C² exp(−4)<C²/54<.18(.82), because (1−1/r²)^D≤exp(−D/r²), r≤M, and exp(4)>54. Thus use α=.180 although the unrestricted outward ratio bound is .450. At each witness, the opposing terms are the odd offsets; both sides together cost at most 2C eta/(1−eta²)<1 in main-term units, because each amplitude is at most C times the witness amplitude and pure ratios multiply. With d=.300,gamma=.005 the explicit next-row margin above is positive. The exponential bounds are verified by the first 16 positive series terms and the other checks by exact cross multiplication.

To apply this to actual occupancy tails one should use the load-dependent lower bounds only where they are valid and control the small-index left tail separately, rather than impose a global amplitude plateau. Their onset and the D_r bounds must be checked at all relevant indices. The lemma removes an artificial need to compare both root tails at the worst endpoint of the edge bracket, but the needed middle-region splice is still unproved.


## Application: complete uniform band through n=10k for k≥256 (00:30 UTC)

The adaptive edge curvature really applies to the original occupancy weights. For every k≥256 and k≤n≤10k, E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient (including the final pair). Use the previous stitched band through 7k, and below take 7k<n≤10k. The argument is uniform, not an enumeration. It does not cover all n.

Let D=n−1≥1792, M=floor(sqrt(D)/2), S=D/M, and H=n/k≤10. In addition to 1≤A_n(r)≤H, for r≥12 there is a load plateau A_n(r)>H/C with C=2.94. Indeed n/r≤5k/6, so use the deterministic cap L=ceil(5k/6) and the earlier truncated-occupancy estimate
    A_n(r) ≥ H (1−1/(2sqrt(L)))/(2+L/k−2/k).
Now sqrt(L)>14 and 2+L/k−2/k<17/6, so the reciprocal factor is below (17/6)(28/27)<2.94.

### Tail ratios and witnesses

For brackets with m≥12 and m+1≤M, each pure outward ratio on either side is ≤eta=.15: its first exponent loss is at least D/(2M(M+1))≥21/11 using sqrt(D)>42, and the pure ratios decrease outward. For any outward step whose denominator index is ≥12, the plateau and the upper bound on the numerator amplitude give actual ratio ≤C eta<.45. For leftward steps whose denominator index r satisfies 2≤r≤12, use s≤D/m≤D/r and log(1−1/r)≤−1/r−1/(2r²), giving pure ratio ≤exp(−D/(2r²))≤exp(−1792/288). Even an amplitude ratio of 10 then leaves the actual ratio below .45. Thus the monotonic alternating-tail requirement holds everywhere despite the low-index nonplateau. The two main curvature products obey P_L,P_R≤C² exp(−4)<C²/54<.201(1−.201), since both denominator indices are plateau indices and at most M. Hence at every old root alpha_L,alpha_R≤.201.

For brackets with m≤11 the pure ratio is below .004 from the loss D/(2·12·13). Bound all amplitude ratios by 10, giving actual ratio and first-neighbor alpha ≤.04. At a witness s=D/m, the same respective pure tail bounds apply (including the final witness m=M); terms of odd offset oppose the main sign, with normalized total at most 2 C eta/(1−eta²)<1 in the large-index case, or 2·10·.004/(1−.004²)<1 otherwise. In the large case the upper bound A_n(r)≤H against the plateau value at the witness suffices at all tail indices. Thus witnesses have the strict signs (−1)^m.

### D_r bounds and signs at old roots

For H/r≤2 use the earlier beta-lattice inequality 0≤D_r≤(H/A_n(r))(r/n+1/sqrt(k)). For H/r>2 and r≥2, r≤4, so the heavy-label bound gives D_r≤16r/n≤64/n; D_1=0. For large brackets (m≥12) the main left D_m is less than .224, and the right tail D_(m+1+a)<.224+.002a, since (m+1)/n<1/84 and the plateau gives H/A_n≤C. On the whole left tail D_r<.692: for r≥12 use the main bound, otherwise use max(64/n, H(12/n+1/sqrt(k))). For small brackets both tails obey D≤.692+.006a, including their main terms, by the same generic bound and H/n≤10/1793.

For large brackets use alpha=.201, lambda=.45. In the exact signed-mean lemma the old derivative cost is at most 2alpha/(1−alpha). The main unfavorable D term costs at most .224/(1−alpha); only even a≥2 on the left and odd a≥1 on the right can further hurt. Their numerators in units of their own main weights are at most
    L_e = alpha · lambda · .692/(1−lambda²),
    R_o = alpha [.224/(1−lambda²)+.002(1+lambda²)/(1−lambda²)²].
Thus 2alpha+.224+L_e+R_o<1−alpha. For small brackets alpha=lambda=.04, d=.692, gamma=.006 and use the prior sufficient margin; it is also strictly positive. The next-row sign at every old root is therefore (−1)^(m+1); the old derivative is strict there and the root unique within each edge bracket.

### Stitch to the previously certified complex-primary central estimate

The central part of the ratio-seven proof (in long_cycles_stitched_early_band.md) only uses the lower bound n≥6k in its error and drift estimates, not n≤7k. Hence for k≥256, n>7k it gives central witnesses and next-row signs through s≤(53/8)sqrt(k), plus exclusion of zeros within pi/40 of a cosine witness phase. Our edge splice is in this range: S≤2 sqrt(D)+4/(1−2/sqrt(D))<2 sqrt(n)+21/5, which is <(53/8)sqrt(k) by n≤10k, sqrt(k)≥16, and (53/8−21/80)^2>40. At S the phase n atan(pi/S) differs from M pi by <pi/40 in both directions, from the earlier cubic atan bounds, M≤sqrt(D)/2 and sqrt(D)>42. Keep edge witnesses for m≤M and central cosine witnesses with m>M up to floor(n/2). If the joining bracket extends left of M pi in phase, the exact exclusion just cited eliminates roots there, giving the correct original next-row sign throughout the joining bracket. Then use the previous degree exhaustion and reciprocal/parity argument verbatim: edge and central witness signs give all negative roots (including the forced −1 root for odd n), the one root at zero is simple, and full degree is exhausted; alternating next-row signs, reciprocity, and the first-root sign toward zero give strict quotient interlacing. No requirement on n+1≤10k appears in any estimate for the pair.

Exact replay passed. The critical exp comparisons were exp(21/11)>20/3, exp(1792/(2·12·13))>250, exp(1792/288)>200/9, and exp(4)>54, each by the first 20 positive terms. All further bounds above are direct rational inequalities after the replacements D≥1792, n≥1793, sqrt(D)>42, sqrt(k)≥16, with rational decimals. Checked edge low-index split explicitly rather than applying the amplitude plateau outside its validity.


### Independent verification of the coefficient-drift bound (all r in this band)

The n>7k application does not in fact need the heavy-label exception. On positive t use E_n(t)/(1−t)^n=sum_(r≥1) B_n(r)t^r with B_n(r)=r^(n−1) A_n(r). The exact insertion recurrence after normalization gives
    B_(n+1)(r)−r B_n(r)=binom(n,k−1) sum_(a=1)^(r−1) a^(k−1) B_m(r−a),  m=n+1−k,
since the normalized single k-cycle has coefficient a^(k−1). In particular D_r≥0 and
    D_r = (1/m) sum_(a=1)^(r−1) f(a/r) A_m(r−a)/A_n(r),
    f(x)=n binom(n−1,k−1) x^(k−1)(1−x)^(m−1).
Here f is a unimodal beta density with integral 1 (integrate the integer powers or the beta identity). For all r≥1 its lattice sum is at most r+max f. For a direct proof, pair samples to the left of the mode with the intervals to their right and to the right with intervals to their left, where monotonicity bounds the sample by the rectangle integral. On the one remaining interval straddling the mode the integral also bounds the smaller of the two boundary samples; only their maximum is charged separately.

Put p=(k−1)/(n−1), the mode. By Fourier coefficient extraction of the binomial polynomial, the peak binomial mass f(p)/n is at most (2pi)^(-1) integral_(−pi)^pi |1−p+p exp(iθ)|^(n−1) dθ. Square its integrand base to get 1−4p(1−p)sin²(θ/2), use sin(|θ|/2)≥|θ|/pi, and integrate the resulting Gaussian over the real line. This gives f(p)/n ≤sqrt(pi)/[2 sqrt(2(n−1)p(1−p))]<1/sqrt(k) for n>7k, k≥256, since (n−1)p(1−p)>(6/7)(k−1) and pi<22/7. As A_m≤m/k, it follows directly that D_r≤(H/A_n(r))(r/n+1/sqrt(k)) for every r, regardless of H/r, in this band. Thus the heavy-label estimate used above can be dropped from the proof and all .692 bounds still follow just from H≤10, r≤12 for nonplateau left indices. This independently verifies the main coefficient-drift input for the new range rather than extrapolating the previously used small-load case.


## Smaller-k bands with the adaptive edge (00:39 UTC audit)

Independently verified the earlier proof checkpoint, including the exact replay long_cycles_smaller_k_early_bands_replay.md. It establishes complete simple-real-rootedness and consecutive strict quotient interlacing for k≥80, n≤floor(64k/25), and for k≥96, n≤3k (always n≥k, last adjacent pair included). It also establishes the local uniqueness result for all n≥k on s≤4 sqrt(k) at k≥80 and s≤5 sqrt(k) at k≥300. The finite lag case uses cos(kθ)cos(mθ)=[cos((n+1)θ)+cos((k−m)θ)]/2 with |cos((n+1)θ)|≤V+sin θ at an old zero. Including both far errors adds 2h+h² before multiplication by 2 d_m/[d_(n+1)(n+1)sin θ]; the term containing sin θ costs at most 1/k. The large lag case uses d_m/d_(n+1)<6/5 and (n+1)sin θ>3L/2. Old-root derivative and next row then both follow by the ellipse inequality. Correction to a wording in the checkpoint: the signed ratio E_(n+1)(1/t)/E_n'(1/t) is −t^(-3) times E_(n+1)(t)/E_n'(t) at an old root; this factor is positive for negative t. All sign and interlacing conclusions are unchanged.

## Additional lower-k result: k≥52, n≤floor(5k/2) (00:40 UTC)

For the global stitch one does not need central uniqueness in advance: phase and edge witnesses plus degree exhaustion will prove it. Discarding the extra central derivative-error budget therefore reduces the k threshold. For every k≥52 and k≤n≤floor(5k/2) the original polynomial has n−1 simple real roots and its quotient strictly interlaces the next quotient. This includes the final adjacent pair.

When n<2k−1 both rows are one-cycle Eulerian rows. Otherwise on s≤4 sqrt(k) use the same six-term lattice geometry as above at K=52 and a=4, with
    R=.17771, f=.3302, h=.1087, g=.0312, j=.0104, L=11.25.
Here R>rho/(pi k), (n+1)sin θ≥2k sin θ>L; f,h bound weighted/unweighted half-lattices at exponent k−1, g,j the corresponding ones at 2k−2. Use b=4(157/50)^2/(16·52+10), powers 25 and 51, six finite terms and the integral from 6 exactly as before. The bounds P,Z have the same two anchor-distance formulas. Then
    V = P+Zh+j < 3/4,  W = P+Zf+g+(1+j)/L,  V²+W²<1.
For the mismatch use |d_(n+1)−d_n|/d_(n+1)<1/(n+1), since the exact first-difference recurrence compares two counts in [1/(2k−1),1/k]. Thus at a cosine witness the sign is correct, and at an old zero the next-row sign is −sin(nθ). No claim of central uniqueness from this bound alone. Exclude roots in the joining slice within pi/8 of a cosine witness since cos(pi/8)>3/4.

For the edge take D=n−1≥102, M=floor(sqrt(D)/2)≥5, and S=D/M. Amplitudes range in [1,C] for C=2.5. The right outward pure loss is at least 4 M²(1/M−log(1+1/M)) ≥ 2−4/15+1/25−4/625 by the alternating integral estimate at M=5; this extends to all further outward steps by discrete concavity. The left loss is at least 2. Thus eta=.175 bounds the pure ratios and lambda=C eta=.4375 the actual ratios. Witness errors from opposing odd offsets are ≤2 C eta/(1−eta²)<1. At an old root the curvature ratios are bounded by C² exp(−4)<.134(1−.134), so alpha=.134. The independently derived beta-lattice bound is valid again: (n−1)p(1−p)≥(k−1)/2 and pi·k<4(k−1) for k≥52, so max f<n/sqrt(k). Use D≤.472+.020a along either tail from its main index, since main indices are ≤M and r/n≤1/(2 sqrt(D))+a/n, sqrt(D)>10 and sqrt(k)>7.21. The exact signed-mean margin is strict:
    2alpha+.472+alpha[.472/(1−lambda)+.020/(1−lambda)^2]<1−alpha.
Therefore next-row signs match (−1)^(m+1) at old roots in every edge bracket.

Finally S≤2 sqrt(n)+5<4 sqrt(k) (sqrt(10)<3.3, .7 sqrt(k)>5), and the cubic atan deviation is bounded by 1/20+(103/102)(10/240)<1/8 in phase units of pi. Thus the same stitch, parity, and degree count apply. Real-rootedness and strict interlacing follow as in the 10k band. The claims in the audited checkpoint above about additional k and n ranges remain separate.

All constants were replayed with exact rational arithmetic: exponential upper/lower by 20 terms and geometric remainder, each six-term lattice and the stated tail integral, R²>(1+16·52/(157/50)^2)/52², LR<2, central V²+W²<1, the curvature and signed-mean margin, and the two stitch inequalities. In particular this does not test individual rows or imply a solution for arbitrary k,n.
