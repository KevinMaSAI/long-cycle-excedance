# Central and edge bridge for k≥24, 3k≤n≤24k

2026-11-27 06:15 UTC. For 24≤k≤31 and 3k≤n≤24k, genuine E_(n,k) has n−1 simple real roots and strict interlacing after removal of t with the next row. Larger k are already complete. This note is part of the merged all-n proof, not a finite row search.

## Two-state occupancy sandwich for the entire edge

Set D=n−1≥71,H=n/k,M=floor(sqrt(D)/2)≥4, S=D/M. Robbins modal peak <.51/sqrt(k) follows from n≥3k and variance ≥2(k−1)/3, for j=k−1 or k where needed. Use the exact binomial ratio geometric bounds and one marked size occupancy sandwich of long_cycles_k32_edge_two_marks.md. For any main or witness base 4≤r≤M, β=kr/n≤.5sqrt(31/3)<1.61. For r≥5 the hard derangement d_(r,2), d_(r−1,2), d_(r+1,2) are in [.36,.38], and d_(j,3)≥.20 for j≥3 (same prior short count proof). At r=4 use d_(4,2)=.375, d_(3,2)=1/3, d_(4,3)=.25 explicitly.

If β≤1.4, the no singleton and exactly one singleton events give P_r≥.32+.36p_1(r) at r≥5, or .335+(1/3)p_1(4) at r=4, since unconditional long error <.04 from initial mean ratio≥10/7 and the .51 mode geometric bound. The right upper P_(r+1)≤.38+.64p_1(r) uses decreasing p_1; left ≤1. Exact monotonicity of (linear numerator)/(linear denominator) and (linear numerator)/(linear denominator)^2 bounds normalized left/right ratios by 3.13,1.81 for r≥5 (2.26,1.91 at r=4), and their product by 3.72, including the r=4 factor (r²−1)/r². For 1.4<β<1.61, long b≥3 error <.003 using first mean≥300/161. At r≥5 the exact one-doubleton term (1/2)d_(r−2,3)p_2(r) yields P_r≥.273, since p_2(r)>.76 (marked lower tail ratio to mode j is >1.28). Left and right singleton means ≤25/28 and 5/7, with success bounds .845 and .115. Therefore P_(r−1)≤.9208, P_(r+1)≤.4536. These yield normalized left/right ratios <3.38,2 and product <5.61. For r=4 skip the marked doubleton, use P_4≥.247 and same right bound .4536 plus left ≤1; get normalized ratios <3.04,2.30 and product at most (15/16)·.4536/.247². All estimates use unconditional subtraction of the expected long-cycle failure count; no assumption that occupancy cells are independent.

At first outgoing left pure ratio use .136 via D/(2r²)≥2; at right use .172 at M≥5 from the quartic loss, and .158 for base r=4 from D≥71. At r≤3 use .047 either way. Combined with the actual occupancy ratios this yields λ=.47 for first steps. Later pure loss starting after the first is ≥4(4/5+4/15) on right and ≥6 on left (bound each using m+1≤M); even using global factor 1.5·27/8 the actual ratio is below .072. Curvature gives α=.075 in the first beta regime, .117 in the second (at r≥5 use product 5.61 times exp(−4), at r=4 use D/r²≥71/16), and .075 safely for r≤3 with crude min-amplitude ratios. Witness first opposition uses the separate left/right caps, and later odd offsets use global factor (27/8)(1+a/m) and the same first-step pure envelope; all pass. The first witness persists beyond s=D.

At r≥.75H, cap ceil(4k/3) gives H/A<3.66, and beta lattice drift ≤3.66(r/n+.51/sqrt(k)). Below this cap use x=D/r≥1.314k and the weighted binomial loss geometry, with spacing >8, to get d_r<.20. Hence for r≤M+a, d_r<.60+.051a; left uniform .60. In the second beta regime the main left d_m<.475 instead, since H/A=1/(βP_m)≤1/(1.4·.247); apply the same beta lattice with r/n≤.5/8.42. Use separate left α,d_m and common right α=.117 with d_(m+2)<.651 for the first odd-right adverse term. The even-left tail starts at α_L*.072 and later odd-right at α_R*.072²; replay verifies both margins with separately divided normalized masses (1−alpha_L),(1−alpha_R). This proves edge witnesses and old-root signs throughout n≥3k with this M, even though only 3k≤n≤24k is needed here.

## Block-resolved center and the new primary reference error

The d_j count invariants continue at k≥24: d_j≤.584/k for j≥2k because exp(.584−1/24)>1/.584 and the upper harmonic head propagates the bound; d_j≥.555/k for j≥3k by the prior lower linear and harmonic head induction. Thus two-cycle variation <.105/k, tail T(2k)<.158/k and T(Lk)<.316/(k L!), plain coefficient norm ξ=.829 in 2/k units, and tilted weight J with .105 in the previous formula. Mark masses as in K32: atom .5, pre halves 1/6 and 1/12, two-cycle variation .0525, remaining blocks .158/j! at j≥3. The far degree bracket convolution and M saturation splice are exactly as in long_cycles_all_n_k32.md, with K=24. Improve the old and next count ratio cap as a function of remaining size γ=B−h/4 (rounded up to 1 if smaller):
 use 1.053 for γ≥2; otherwise min(1.81,max(1.053,1/(.555γ))).
This is valid from d_m=1/m when k≤m<2k. The prefix absolute amplitude DP now starts at zero, not one (the K32 stored upper bound's start at one merely overestimated the amplitude and was harmless). Its minimum with the earlier hybrid bound stays valid. Direct adjacent drift unchanged. The resulting absolute ellipse covers from H=3 to 5.75 with exact fractional B,N endpoints.

For later intervals compute the primary reference error itself by a block convolution, not the single global tilted tail. This uses the same marked absolute weights but tracks only total upper degree h, for all reference degrees including shifts omitted from the finite C_n. Tail mark blocks beyond j=ceil(B)+1 are merged using total mass at most .158/j! and assigned to the high h cap, where every error costs 1. Accumulated high degree may also be saturated once B−h/4<1. All other h use the following relative loss price, uniformly for old and next row:
- If γ=B−h/4<1, use 1 (may be omitted, all actual ratios in [0,1.81]).
- If 1≤γ<2, use max(.145,1/(.555γ)−1), since remaining m≥k and could be in the single-cycle band; the smaller lower ratio .5/.584 gives loss <.145.
- If 2≤γ<3 use .145; if 3≤γ<4 use .053; beyond use .632/floor(γ)! from the telescoping count tail.
For each number of marks m≤16 multiply the convolution coefficients by p^m/m!, exactly as in the previous block argument. If A is the sum of type masses and m>16 the entire omitted contribution costs at most exp(pA)(pA)^17/17! by factorial factorization and uniform relative difference at most 1. This gives an explicit primary epsilon with no extrapolation from an old row. Take min with the earlier tilt bound. Then real part uses max of the absolute amplitude lower and reference lower minus epsilon; the next-row drift can take min of 2epsilon and the direct bound. This was the decisive improvement for intermediate ratios.

On s≥4sqrt(k) the vertical log difference is <.37, real fraction >.58, and |log P_*|≤.77p by the stronger segment bound with .65 (sin theta<.17). This gives reference floors from the real scalar, 2−exp(ξp), and exp(−.77p)(1−(.77p)^2/2) where positive. The small-s extra rows explicitly use only the unweighted real bound without vertical arguments. The central replay certifies all analytic intervals from H=3 to 24. No angular exclusion is needed on the floor splice: for D≥71, y=M/D, the same exact positive orientation as in the K32 proof applies. Lower arctan leaves y[1−(pi²/3)(n/D)(M²/D)]>0; upper using fifth order gives ≤y−3.2My²≤1/(12.8M)<1/40. Thus the central begins in the intended cosine phase interval. Exact radii, adjacent sign comparisons, degree exhaustion, parity and inversion then give the full row. Every overlap and upper pair is accounted for.

## Exact edge replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}


const lo=x=>eb(x)[0],eu=x=>eb(x)[1],C=q(27,8),K=q(24),sk=q(489,100),pl=q(157,50),p=q(51,100),n0=q(72),D=q(71),sv=q(842,100),A=q(1,2),F=q(3,5);
ck(sk.sq().lt(K)&&sv.sq().lt(D)&&q(31,12).lt(q(161,100).sq()),"scales and beta ceiling");
ck(K.mul(eu(q(1,6*71))).lt(p.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(23))),"Robbins peak");
function Phi(w,upper){const x=upper?o.sub(w):w.sub(o), cubic=x.sq().mul(x).div(q(3));return upper?x.sq().div(two).add(cubic):x.sq().div(two).sub(cubic);}
function lowerTail(w){return p.div(sk.mul(o.sub(o.div(w)))).mul(em(q(23).mul(Phi(w,false))));}
function upperTail(w){return p.div(sk.mul(o.sub(w))).mul(em(q(24).mul(Phi(w,true))));}
function bad(U,w){return lowerTail(w).div(q(U).mul(o.sub(em(q(23).mul(w.sub(o)).div(q(U))))));}
ck(bad(2,q(10,7)).lt(q(4,100))&&bad(3,q(300,161)).lt(q(3,1000)),"long cycle errors");
ck(q(128,100).lt(q(200,161).mul(q(31,30)))&&q(76,100).lt(o.sub(lowerTail(q(128,100)))),"doubleton success");
ck(upperTail(q(25,28)).lt(q(845,1000))&&upperTail(q(5,7)).lt(q(115,1000)),"singleton success");
const bp=q(32,100),qp=q(36,100),right=q(38,100),rp=q(64,100);
ck(rp.mul(bp).lt(two.mul(qp).mul(right))&&right.mul(qp).lt(rp.mul(bp)),"monotonic ratios A");
ck(o.div(bp).lt(q(313,100))&&q(6,5).mul(right.add(rp)).div(bp.add(qp)).lt(q(181,100))&&right.div(bp.sq()).lt(q(372,100)),"neighbors A");
ck(q(3,4).div(q(335,1000)).lt(q(313,100))&&q(5,4).mul(right.add(rp)).div(q(335,1000).add(q(1,3))).lt(q(191,100)),"A at 4");
ck(q(15,16).mul(right).div(q(335,1000).sq()).lt(q(372,100))&&rp.mul(q(335,1000)).lt(two.mul(q(1,3)).mul(right))&&rp.mul(q(335,1000)).lt(two.mul(q(1,3)).mul(right)),"A at 4 product");
const den=q(273,1000),Pleft=q(9208,10000),Pright=q(4536,10000);
ck(Pleft.div(den).lt(q(338,100))&&q(6,5).mul(Pright).div(den).lt(q(2))&&Pleft.mul(Pright).div(den.sq()).lt(q(561,100)),"neighbors B");
const dr4=q(247,1000);
ck(q(3,4).div(dr4).lt(q(304,100))&&q(5,4).mul(Pright).div(dr4).lt(q(230,100)),"B at 4");
const eta=q(172,1000),eta4=q(158,1000),eL=q(136,1000),lam=q(47,100),al=q(75,1000),ar=q(117,1000);
ck(o.div(eL).lt(lo(q(2)))&&o.div(eta).lt(lo(q(2).sub(q(4,15)).add(q(1,25)).sub(q(4,625))))&&o.div(eta4).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"pure first");
ck(q(338,100).mul(eL).lt(lam)&&q(2).mul(eta).lt(lam)&&q(230,100).mul(eta4).lt(lam)&&q(191,100).mul(eta4).lt(lam)&&q(304,100).mul(eL).lt(lam),"actual first");
const tiny=q(47,1000),lam2=q(72,1000);
ck(o.div(tiny).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&C.mul(q(3,2)).mul(tiny).lt(lam),"small base");
ck(C.mul(q(3,2)).div(lam2).lt(lo(q(4).mul(q(4,5).add(q(4,15)))))&&C.div(lam2).lt(lo(q(6))),"steep after first");
ck(q(372,100).div(al.mul(o.sub(al))).lt(lo(q(4)))&&q(561,100).div(ar.mul(o.sub(ar))).lt(lo(q(4)))&&q(15,16).mul(Pright).div(dr4.sq()).div(ar.mul(o.sub(ar))).lt(lo(D.div(q(16))))&&C.sq().mul(q(3,2)).div(al.mul(o.sub(al))).lt(lo(D.div(q(9)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R,E,m] of [[q(313,100),q(181,100),eta,5],[q(338,100),q(2),eta,5],[q(313,100),q(191,100),eta4,4],[q(304,100),q(230,100),eta4,4]])ck(L.mul(eL).add(R.mul(E)).add(cost(E,m,true)).lt(o),"witnesses");
ck(cost(tiny,1,false).lt(o),"low witness");
const cap=q(366,100),d=q(60,100),db=q(51,1000),xx=q(1314,1000),v=D.div(n0);
ck(q(10,3).div(o.sub(o.div(q(113,10)))).lt(cap)&&cap.mul(A.div(sv).add(p.div(sk))).lt(d)&&cap.div(n0).lt(db),"drift cap");
ck(xx.lt(q(4,3).mul(v))&&q(8).lt(q(314,1000).mul(K).add(o)),"drift spacing");
ck(C.div(v).mul(xx).mul(p).div(sk).mul(em(q(23).mul(Phi(xx,false)))).div(o.sub(em(q(8)))).lt(q(20,100)),"heavy drift");
const dR=d.add(db),dB=q(475,1000);
ck(o.div(q(14,10).mul(dr4)).mul(A.div(sv).add(p.div(sk))).lt(dB),"case B main drift");
function margin(a,dL){
 const z=o.sub(lam2.sq()),left=a.add(dL).add(a.mul(lam2).mul(d).div(z)).div(o.sub(a));
 const rem=d.add(q(3).mul(db)).div(z).add(two.mul(db).mul(lam2.sq()).div(z.sq()));
 const right=ar.add(ar.mul(dR)).add(ar.mul(lam2.sq()).mul(rem)).div(o.sub(ar));
 return left.add(right).lt(o);
}
ck(margin(al,d)&&margin(ar,dB),"signed comparison");
ck(q(10,3).mul(n0.div(D)).div(q(4)).lt(o),"phase positive");
ck(pl.sq().div(q(3)).mul(o.sub(q(6,4*71))).lt(q(16,5))===false,"phase upper");
```

## Exact central replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=24,sk=q(489,100),xi=q(829,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[5.75,400,50,3,6.75],[6.75,400,50,3,7.75],[7.75,400,50,3,8.75],[8.75,400,50,3,11.25],[11.25,400,50,3,14.25],[14.25,400,50,3,17.25],[17.25,400,50,3,20.25],[20.25,400,50,3,23.25],[23.25,400,50,3,24],[3,464,50,2,3.5],[3.5,480,50,2,3.75],[3.75,507,50,2,4.5],[4.5,533,50,2,5],[5,547,50,2,5.25],[5.25,559,50,2,5.5],[5.5,572,50,2,5.75],[5.75,604,50,3,6.75],[6.75,647,50,3,7.75],[7.75,674,50,3,8.75],[8.75,753,50,3,11.25],[11.25,837,50,3,14.25],[14.25,912,50,3,17.25],[17.25,988,50,3,20.25],[20.25,1051,50,3,23.25],[23.25,1068,50,3,24]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(37,100).sq().div(two));
ck(pu.div(q(44)).mul(ex(q(5,16)).sq()).lt(q(37,100).sq()),"vertical log");
ck(q(58,100).lt(q(63,100).mul(ca)),"vertical positive");
ck(q(88,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(37,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=11;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(632,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(105,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(145,1000):L===3?q(53,1000):q(632,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1053,1000):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const core=a0===400;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 {
  const types=[[4,4,q(1,2)],[4,6,q(1,6)],[6,8,q(1,12)],[8,12,q(105,2000)]];
  for(let j=3;j<=Math.ceil(N);j++)types.push([4*j,4*(j+1),q(158,1000).div(fact(j))]);
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=q(0),wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const rem=q(Math.max(4,4*B-h),4); const factor=4*B-h>=8?q(1053,1000):min(U0,max(q(1053,1000),o.div(q(555,1000).mul(rem))));
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1053,1000).mul(abs).add(q(757,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const Qmax=Math.ceil(4*B)+4, Jlast=Math.ceil(B)+1, md=16, es=[[4,q(1,2)],[6,q(1,6)],[8,q(1,12)],[12,q(105,2000)]];
  for(let j=3;j<Jlast;j++)es.push([4*(j+1),q(158,1000).div(fact(j))]);
  es.push([Qmax,q(158,1000).div(fact(Jlast))]);
  const msum=es.reduce((s,[_,w])=>s.add(w),q(0)).mul(p);
  let epsDP=q(0),prod=o,dp=new Map([[0,o]]);
  const pref=new Map();
  function modLoss(h){
   if(pref.has(h))return pref.get(h);
   const r=Math.floor((4*B-h)/4);let v=q(1);
   if(r>=4)v=q(632,1000).div(fact(r));
   else if(r===3)v=q(53,1000);
   else if(r===2)v=q(145,1000);
   else if(r===1)v=max(q(145,1000),o.div(q(555,1000).mul(q(4*B-h,4))).sub(o));
   pref.set(h,v);return v;
  }
  for(let m=1;m<=md;m++){
   const tmp=new Map();
   prod=prod.mul(p).div(q(m));
   for(const [h,v] of dp)for(const [s,w] of es){let f=Math.min(Qmax,h+s);tmp.set(f,(tmp.get(f)??q(0)).add(v.mul(w)));}
   dp=tmp;
   for(const [h,v] of dp)epsDP=epsDP.add(prod.mul(v).mul(modLoss(h)));
  }
  let rem=o;for(let i=1;i<=md+1;i++)rem=rem.mul(msum).div(q(i));
  epsDP=up(epsDP.add(rem.mul(ex(msum))));
  const eps=min(epsDP,up(abs.mul(delta).add(ps)));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=core?o.sub(abs):max(q(29,30).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(77,100)); if(!core&&pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  c=max(c,ref.sub(eps));slice=q(88,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 
 const mr=Math.floor(Math.sqrt(N*K-1)/2);
 ck(4*mr*mr<=N*K-1 && N*K-1<4*(mr+1)*(mr+1),"cut index");
 const wcut=q(4*mr*mr-1,mr-1).div(sk), w1=q(4*(mr+1)*(mr+1)-1,mr).div(sk), vm=q(Math.round(4*N),4).mul(q(4*(mr+1)*(mr+1)-1,2*mr*(mr+1)).sq()),v2=q(Math.round(4*N),4).mul(q(4*(mr+2)*(mr+2)-1,2*(mr+1)*(mr+2)).sq());
 if(!core)ck(wcut.lt(a)&&(w1.lt(a)||vm.lt(a.sq()))&&v2.lt(a.sq()),"floor splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0];
ck(q(1000,584).lt(lo(q(584,1000).sub(q(1,24))))&&q(105,1000).mul(q(3,2)).lt(q(158,1000)),"count bound");
ck(o.add(q(694,1000)).add(q(1,94)).lt(q(584,1000).mul(q(71,24))),"propagate upper counts");
ck(q(584,555).lt(q(1053,1000))&&o.div(q(555,1000)).lt(q(181,100))&&o.sub(q(500,584)).lt(q(145,1000))&&q(584,555).sub(o).lt(q(53,1000)),"relative count budgets");
ck(pu.div(q(4).mul(sk)).lt(q(17,100))&&q(65,100).sq().mul(q(234,100)).lt(o)&&o.div(q(2).mul(q(65,100))).lt(q(77,100)),"sharper log integral");
let high=q(3);for(const [B,a,al,L,N] of rows)if(a!==400){const low=q(Math.round(4*B),4),next=q(Math.round(4*N),4);ck(!high.lt(low)&&high.lt(next),"overlap");high=next;}
ck(!high.lt(q(24)),"end coverage");
```
