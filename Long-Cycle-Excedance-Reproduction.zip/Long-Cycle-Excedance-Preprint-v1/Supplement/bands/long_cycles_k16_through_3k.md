# Sparse interval for 16 ≤ k ≤ 19
For every old row 2k+1 ≤ n ≤ 3k the edge and central sign inequalities give simplicity and strict adjacent interlacing of E_(n,k)/t and its successor, using the same sign-to-root stitching as the k20 proof. The previously established universal onset covers n ≤ 2k.
 
Write D=n−1, H=n/k, and use M=3, S=D/3. The only interior edge brackets are m=1,2. For H in [2,2.25], [2.25,2.5], [2.5,2.75], [2.75,3], the central upper radii a√k are respectively a=3.17, 3.55, 3.92, 4.29, and complex radius ratios ρ/(πk) are bounded by .262, .291, .320, .349. Reuse the principal versus farther pole and next-row phase ellipse from long_cycles_all_n_k20.md. The first three slabs have only linear mixed terms because b≤n+1−k<2k. The pre-2k nonatom Δ variation is at most u/k, using u=1−1/(N−1+1/16), respectively 5/21, 9/25, 13/29. With normalized residual ratio at most 2, primary perturbation P=(1+u)p and farther envelope W=x j_(B−1)+u x f+g have powers (B−1)k, k−1 and Bk. Direct drift is P/k+P/(Bk)+p/(k+1), since the boundary degree exceeds k and supports only one factor. The diagonal mismatch is (1+j0)R/B times 1, .6, 1/3, respectively, from the count recurrence and 1/(B−1).
 
In the final slab d_n,d_(n+1)≥.555/k and d_j≤.591/k for j≥2k. Ratios for the atom, linear degrees through 1.5k, and all remaining retained terms are bounded by 1.065, 1.442 and 1.81. Their marker masses in units 2/k are .5, 1/6 and 1/12. The residual after the atom is at least 1.75k; the linear residual is at least 1.25k. Degree ≤2k+1 allows only a pair of pure atoms or an atom plus degree k+1. The remaining contribution is bounded by 1.81[p/(k+1)+p²(1/8+1/(4(k+1)))], also with p replaced by x and radial powers 1.75k, 1.25k, k−1. In fact the counts with index j in [k,2k) are exactly 1/j; the atom residual in this slab starts at 1.75k, so 1/(1.75·.555)<1.065, and the linear ratio is 1/(1.25·.555)<1.442. Relative diagonal drift bound is .17. Direct drift is P/k+P/(Bk)+1.81[p/(2(k+1))+p²/8]; the linear boundary has one degree ≥k+1, and the quadratic boundary has the pure pair or the single cross degree, not both. The overlap count variation ratio is ≤1/(k+1), with normalization cost (1+1/(n+1)) absorbed into 1/k. Each slab passes the ellipse and π/8 exclusion.
 
For 32≤D≤35, P_3≥1/3 by the 3-cycle and P_4≤.375+.625p<.407 from p<.05 (Robbins and a geometric upper tail with μ/k≤.5625). At r=3 the normalized neighbor ratios are ≤2 and 1.63, curvature .105; first outward .44 and later .071. The pure first ratios at r=3 are ≤.170 and .234; at r≤2 use .070. For 36≤D and H≤2.5 use .195 pure first, .5 actual first, .133 curvature, .052 later, .00013 for the third opposing pure term. For H>2.5 use .163, .5, .122, .062, .00005, respectively, from the same log expansion with D≥40. At r≤2, the beta drift is zero at r=1 and ≤H times the atom peak at r=2, giving .369 or .413 from the Robbins constants .59 or .55 over √k. The generic right drift caps are .597+.076a or .633+.074a for right offset a. Split first odd right from later odd, and even left against geometric tails. Signed margins, edge witnesses, splice radius and arctangent width pass exactly below.
 
## Exact constant replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(17)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}


const pl=q(157,50),pu=q(22,7),K=q(16),sk=q(4),lo=x=>eb(x)[0];
const rows=[[317,262,8,5,21,1,1],[355,291,9,9,25,3,5],[392,320,10,13,29,1,3],[429,349,11,0,1,17,100]];
for(const [a0,R0,B4,m1,m2,i1,i2] of rows){
 const a=q(a0,100),R=q(R0,1000),B=q(B4,4),b=q(4).mul(pl.sq()).div(a.sq().mul(K).add(q(10)));
 ck(o.add(a.sq().mul(K).div(pl.sq())).div(K.sq()).lt(R.sq())&&two.lt(b.mul(q(7*25**2-312))),"lattice");
 function lat(m,v){let s=q(0);for(let j=1;j<=12;j++){const u=b.mul(q(j*(j+1)));s=s.add(q(v?2*j+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return s.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(v?1:27)))));}
 const f=lat(7,true),h=lat(7,false),g=lat(2*B4,true),j0=lat(2*B4,false),j=lat(2*(B4-4),true);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 let P,W,d;
 if(B4<11){
  const r=q(m1,m2);P=o.add(r).mul(p);
  W=x.mul(j).add(r.mul(x).mul(f)).add(g);
  d=p.div(q(17)).add(P.div(K)).add(P.div(B.mul(K)));
 }else{
  const u=q(1065,1000),v=q(1442,1000),z=q(181,100);
  function mask(p){return z.mul(p.div(q(17)).add(p.sq().mul(q(1,8).add(q(1,68)))));}
  P=u.mul(p).div(two).add(v.mul(p).div(q(6))).add(z.mul(p).div(q(12))).add(mask(p));
  W=u.mul(x).mul(j).div(two).add(v.mul(x).mul(lat(10,true)).div(q(6))).add(z.mul(x).mul(f).div(q(12))).add(mask(x).mul(f)).add(g);
  const ne=two.mul(ex(q(84,100).mul(p)).sub(o));
  d=P.div(K).add(P.div(B.mul(K))).add(q(181,100).mul(p.div(q(34)).add(p.sq().div(q(8)))));
 }
 const V=W.div(q(3)),mis=q(i1,i2).mul(o.add(j0)).mul(R).div(B),c=o.sub(P),slice=c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))));
 text({a:a.val(),W:W.val(),d:d.val(),mis:mis.val(),c:c.val(),slice:slice.val()});
 ck(q(0).lt(c)&&V.sq().add(W.add(d).add(mis).sq()).lt(c.sq())&&V.lt(slice),"sparse ellipse");
}

const H0=q(9,4),H1=q(5,2),H2=q(3),e1=q(195,1000),e2=q(163,1000),e0=q(234,1000),u=q(59,100),v=q(55,100);
ck(K.mul(ex(q(1,6*32))).lt(u.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(15)))&&K.mul(ex(q(1,6*40))).lt(v.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(15))),"Robbins peaks");
const loss=q(1,18).sub(q(1,81)).add(q(1,324)).sub(q(1,1215));
ck(o.div(e0).lt(lo(loss.mul(q(32))))&&o.div(e1).lt(lo(loss.mul(q(36))))&&o.div(e2).lt(lo(loss.mul(q(40)))),"pure ratios");
const b=q(7,16),p4=u.div(q(4)).div(b).mul(em(q(16).mul(b.sq().div(two).add(b.sq().mul(b).div(q(3))))));
ck(p4.lt(q(1,20))&&q(3,8).add(q(5,8).mul(p4)).lt(q(407,1000)),"small-D r4 survival");
ck(q(4).mul(q(407,1000)).lt(q(163,100))&&o.div(q(17,100)).lt(lo(q(32,18))),"small-D ratio setup");
const le=q(17,100),l0=q(44,100),a0=q(105,1000);
ck(q(2).mul(le).lt(l0)&&q(163,100).mul(e0).lt(l0)&&q(8).mul(q(407,1000)).div(a0.mul(o.sub(a0))).lt(lo(q(32,9))),"small-D ratios and curvature");
const es=q(70,1000);
ck(o.div(es).lt(lo(q(8,3)))&&H0.mul(es).lt(l0),"small indices");
function wit(C,e){return two.mul(C).mul(e).div(o.sub(e.sq())).lt(o)}
ck(wit(H0,es)&&q(2).mul(le).add(q(163,100).mul(e0)).add(two.mul(H0).mul(e0.sq()).mul(e0).div(o.sub(e0.sq()))).lt(o),"small-D witnesses");
const al1=q(133,1000),al2=q(122,1000);
ck(H1.mul(e1).lt(q(1,2))&&H2.mul(e2).lt(q(1,2))&&H1.sq().div(al1.mul(o.sub(al1))).lt(lo(q(4)))&&H2.sq().div(al2.mul(o.sub(al2))).lt(lo(q(40,9))),"normal curvature");
function wit3(C,e,b,L){ck(o.div(b).lt(lo(L))&&two.mul(C).mul(e.add(b.div(o.sub(e.sq())))).lt(o),"quadratic witness")}
wit3(H1,e1,q(13,100000),q(9));wit3(H2,e2,q(5,100000),q(10));
const j0=q(71,1000),j1=q(52,1000),j2=q(62,1000);
ck(H0.div(j0).lt(lo(q(52,15)))&&H1.div(j1).lt(lo(q(39,10)))&&H2.div(j2).lt(lo(q(39,10))),"second outward");
const d1=q(369,1000),d2=q(413,1000),r1=q(597,1000),r2=q(633,1000),b1=q(76,1000),b2=q(74,1000);
ck(H1.mul(u.div(q(4))).lt(d1)&&H2.mul(v.div(q(4))).lt(d2),"left two-bin drift");
ck(H1.mul(q(3,33).add(u.div(q(4)))).lt(r1)&&H2.mul(q(3,41).add(v.div(q(4)))).lt(r2)&&H1.div(q(33)).lt(b1)&&H2.div(q(41)).lt(b2),"right drifts");
for(const [a,h,d,r,b] of [[a0,j0,d1,r1,b1],[al1,j1,d1,r1,b1],[al2,j2,d2,r2,b2]]){
 const z=o.sub(h.sq()),t=r.add(q(3).mul(b)).div(z).add(two.mul(b).mul(h.sq()).div(z.sq()));
 ck(two.mul(a).add(d).add(a.mul(h).mul(d).div(z)).add(a.mul(r.add(b))).add(a.mul(h.sq()).mul(t)).lt(o.sub(a)),"early signed margins");
}
for(const [N,D,a] of [[q(9,4),41,q(317,100)],[q(5,2),46,q(355,100)],[q(11,4),51,q(392,100)],[q(3),56,q(429,100)]])ck(N.mul(q(D*D,9*(D+1))).lt(a.sq()),"splice radius");
ck(q(3,32).lt(q(1,8))&&q(10,3).mul(q(33)).mul(q(3,32).sq()).mul(q(3,32)).lt(q(1,8)),"arctangent");

```
