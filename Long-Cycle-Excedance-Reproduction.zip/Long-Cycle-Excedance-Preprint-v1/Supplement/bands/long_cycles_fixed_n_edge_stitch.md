
# Fixed-n critical-cycle profile closes the complete band through floor(74k/5)
2026-11-27 01:30 UTC. For every k≥256 and k≤n≤floor(74k/5), the original E_(n,k) has n−1 simple real roots, and the quotients by t for rows n,n+1 strictly interlace. This includes the last pair. It is a uniform theorem over a band, not a proof for all n. For n≤10k use the earlier adaptive stitch; k≥1024 also has the existing all-n theorem. It remains to prove 256≤k≤1024 and 10k<n≤floor(74k/5).

## 1. Uniform fixed-n profile for neighboring occupancy indices

We prove a reusable lemma under 256≤k≤1024, 10k≤n≤16k. Let integer r0 satisfy .45 sqrt(n)≤r0≤.8 sqrt(n), set β0=kr0/n, L=ceil(.7β0), U=ceil(1.3β0), c_U=exp(−H_(U−1)), and let r range over r0−1,r0,r0+1. Define a smooth function on real [r0−1,r0+1] by
    F(r)=c_U sum_(m≤5) prod_(L≤b<U) [b^(−m_b)/(m_b!)] Q_n(r;b_1,...,b_m),
where m=sum m_b and Q is the exact multinomial probability that all listed critical cycle groups contain at least k balls, with cell masses b_i/r and the leftover cell. This is the finite critical-cycle model from long_cycles_occupancy_poisson_profile.md with its long-cycle coefficient replaced by c_U. We will show
    |P_r(n)−F(r)|<.045 c_U at each integer r, F(r)≥c_U,
    0≤−F'(r)<.46 c_U throughout the real interval.
It follows at r0 that
    A_n(r0−1)/A_n(r0)<1.58,    A_n(r0+1)/A_n(r0)<1.15.
For the first ratio use (r0−1)/r0≤1 and the error plus derivative bound to get 1+(.46+.09)/.955. For the second use decrease of F, r0≥23, and 24/23·1.045/.955.

### Control of the finite-profile approximation

We have 1.8≤β0<8.1, 2≤L≤6, 3≤U≤12, r0≥23, and r/U>5.5. For U=3 this follows from r≥22. For U≥4 it follows from r>10(U−1)/1.3−1. Thus m≤5 always gives B=sum b_i<r. The critical mass h_c=sum_(b=L)^(U−1)1/b is at most 5/6: for L=2,3,4 sum to floor(13L/7) directly, using U−1<(13/7)L; for L≥5 compare to 1/L+log(13/7)<.2+19/30.

Auxiliary exact hard-cycle count bounds used here:
    |d_(j,U)/c_U−1|<.08 if j≥2U;
    |d_(j,U)/c_U−1|<.002 if j≥3U;
    |d_(j,U)/c_U−1|<.00016 if j≥4U,
for 2≤U≤12. These concern only normalized ordinary cycle counts, not the original polynomials. Verify j<8U using the exact recurrence j d_j=sum_(b≤j−U) d_b and rational bounds on exp(H_(U−1)) from 32 terms and the geometric remainder. For j≥8U use the already proved factorial difference tail: relative error ≤6/8!<.00016, valid also for U=2 by the same recurrence proof. All exact comparisons passed; pseudocode at end.

In the exact critical-cycle model, for m≤2 the complement r−B exceeds 3U, for m=3 it exceeds 2U, and for 4≤m≤5 it is positive. For the latter cases the relative error from replacing d_(r−B,U) by c_U is at most 1, using 0≤d≤1/U and c_U>1/(2U). For omitted m≥6 the nonzero-complement mass divided by c_U is at most 2 sum_(m≥6)h_c^m/m!. A zero complement can require only m≥7, since r/(U−1)>5.5U/(U−1)≥6. It costs at most 24 sum_(m≥7)h_c^m/m!. The full relative replacement/truncation error is thus at most
    .002(1+h+h²/2)+.08 h³/6+h⁴/24+h⁵/120
       +2 sum_(m≥6)h^m/m!+24 sum_(m≥7)h^m/m! < .040,
where h=5/6. Bound both tails geometrically from their first term. Q≤1 was used throughout.

For b<L, μ/k=(nb/r)/k ≤(.7)/(22/23)<11/15, so a binomial success tail is at most exp[−k(8/225+64/10125)], using the first three terms of log(1−x). Multiply by sum_(b<L)1/b≤H_5 and normalize by c_U>1/24: cost <.002, since the exponent exceeds 10.5 and exp(10.5)>27500. For b≥U, μ/k≥(1.3)/(24/23)>31/25. The binomial failure Chernoff exponent at the boundary is below −6 (use log(1+x)≤x−x²/2+x³/3 at x=.24). Its derivative as a function of b is ≤−k(6/31)/β_r<−5 with β_r=kr/n<8.5. In the lower error from a bad long cycle use d_(r−b,L)≤1/L for b<r, while b=r contributes no probability. With 1/b≤1/U and c_U>1/(2U) this costs at most (2/L)e^(−6)/(1−e^(−5))<.003. The two exact model comparison inequalities in the previous note therefore give the asserted .045 relative-to-c_U error at all three neighbors.

### The derivative bound

Move mass into each critical cell from the leftover cell and apply the multinomial Bernstein derivative. A derivative can create success only when that critical cell has k−1 balls and all other cells already meet the thresholds. Hence
    0≤−Q_n'(r)≤ (n/r²) sum_i b_i Pr(Bin(n−1,b_i/r)=k−1).
This follows directly by differentiating the product over n labeled draws, distinguishing one draw and treating its three outcomes as unchanged/favorable/leftover. Summing over the critical composition weights, marking one cycle cancels its 1/b, and the rest has total weight ≤exp(h_c). Thus
    |F'|/c_U ≤ (n/r²) exp(h_c) sum_(b=L)^(U−1) Pr(Bin(n−1,b/r)=k−1).
Apply the unimodal beta lattice bound (integral 1/n in p) and sharpen the Fourier peak bound to .45/sqrt(k) as follows. At p=(k−1)/(n−1) the variance is ≥.9(k−1). In the Fourier formula use 1−cos θ≥11θ²/24 for |θ|≤1, and ≥11/24 outside. Gaussian integration plus the tail costs at most
    1/[2 sqrt(pi·(11/24)·.9(k−1))] + exp(−(11/24)·.9(k−1))
    < .449/sqrt(k)+.001/sqrt(k).
The exact first comparison uses pi>157/50 and (k−1)/k≥255/256; the second uses k≤1024 and exponent >11. Thus |F'|/c_U<2.31[1/22+(100/43)²(.45/16)]<.46, since r>.43 sqrt(n). This completes the lemma without a Poisson approximation.

## 2. Edge with the actual neighboring amplitudes

Let 10k<n≤floor(74k/5), D=n−1≥2560, M=floor(.6 sqrt(D)), S=D/M, H=n/k<15. Use the adaptive edge lemma from long_cycles_adaptive_edge_curvature.md. The cap L_cap=k proves A_n(r)>H/3.1 for r≥15 (reciprocal factor <96/31), and cap L_cap=3k proves A_n(r)>H/5.1 for r≥5 (factor <270/53). These follow from the deterministic weighted occupancy bound and binomial truncation, since n/r≤L_cap respectively. Always 1≤A_n(r)≤H. The beta lattice coefficient-drift inequality holds at all r because n>7k:
    D_r≤(H/A_n(r))(r/n+1/sqrt(k)).
For tiny indices 2≤r≤4 one may sharpen it to D_r<.01. In the exact beta formula the binomial mass is evaluated at p≥1/4 and k−1≤D/10. Markov on 2^(−Bin) bounds it by (63/64)^D. With A_m≤m/k and A_n≥1, the beta formula then gives D_r≤45(63/64)^D≤45 exp(−40)<.01. D_1=0.

For each bracket m+1≤M and each witness m≤M, divide the edge into three index regimes:

- High main index m≥.45 sqrt(n). The right pure outward loss is at least D[1/M−log(1+1/M)] ≥(25/9)(1/2−1/90), since M≥30, and the left loss is at least 25/18. Thus eta=.26 suffices. Where the denominator index remains in [.45 sqrt(n),.8 sqrt(n)] apply the profile ratios 1.58 (left) and 1.15 (right). Below that interval a left step with denominator r≥15 has pure loss ≥D/(2r²)≥(2560/2561)/(2·.45²), which absorbs factor 3.1 and leaves ratio <.42; for r≤14 use stronger loss D/(2·14²) and even factor 15. Above the interval a right step has loss at least (D/sqrt(n))(5/3−5/4), which absorbs factor 15. Consequently both outward sequences obey lambda=.42. At an old zero the two curvature products are at most (1.58)(1.15)e^(−25/9)<.132(1−.132), using the same profile with each main denominator, so alpha=.132. At a witness the first opposing neighbors cost at most (1.58+1.15)eta; the remaining odd offsets cost ≤2·3.1 eta³/(1−eta²), since the witness denominator is a plateau index and all pure ratios improve outward. Their total is <1.

- Medium 15≤m<.45 sqrt(n). Main indices ≤.47 sqrt(n) and the following index ≤.49 sqrt(n). Pure outward loss is at least (2560/2561)/(2·.47·.49), giving eta=.116. For denominators ≥15 the amplitude ratio costs ≤3.1; on the low left tail use D/(2·14²) with factor 15. This gives lambda=.36. Curvature products ≤3.1² exp[−(2560/2561)/.47²]<.125(1−.125), so alpha=.125. Witness error ≤2·3.1 eta/(1−eta²)<1.

- Low m≤14. Main indices are ≤15, so D/(2·15·16) bounds the pure outward loss and eta=.005 suffices. All amplitude ratios ≤15 give alpha=lambda=.075. Witness error ≤2·15 eta/(1−eta²)<1.

In either high/medium bracket the main left D_m<.231 and the right tail D_(m+1+a)<.231+.002a by the cap plateau and r/n≤.012+a/n. The whole left tail has D_r<1.03, using plateau when r≥15 and H(15/n+1/sqrt(k)) otherwise. With its regime alpha and lambda, the signed-mean lemma proves the adjacent sign because
    2alpha+.231 + alpha lambda·1.03/(1−lambda²)
       + alpha[.231/(1−lambda²)+.002(1+lambda²)/(1−lambda²)²] < 1−alpha.
In the low brackets both D tails are bounded by .350+.002a using cap 3k for r≥5 and the sharper tiny-index bound otherwise. The general margin with d=.350,gamma=.002 and alpha=lambda=.075 is strict. This supplies all old edge derivative and next-row signs, as well as the alternating witnesses; no approximate root calculation is used.

## 3. Central joining and exhaustion

Use the complex-primary central theorem in long_cycles_stitched_early_band.md for k≥256,n≥6k and s≤(53/8)sqrt(k), with its exclusion within pi/40 of any cosine witness. Here
    S ≤ (5/3)sqrt(n)+2.9 < (53/8)sqrt(k),
because the floor correction is at most (25/9)/(1−1/30)<2.9 and (53/8−29/160)²>(25/9)(74/5). At S the nθ phase differs from M pi by less than pi/40 in either direction, from M/D≤.6/sqrt(D) and n pi² M³/(3D³)≤(2561/2560)(10/3)(.6)³/50. Use the original degree-exhaustion argument with edge witnesses for m≤M and central witnesses thereafter, with no zero on any sliver below M pi at the join. Then inversion, the parity root at −1, and the simple zero at 0 exhaust the row degree, and the adverse-slope next signs at all nonzero old roots give strict quotient interlacing. All estimates concern the old index n, so the final pair is included.

## Exact checks

The hard-count finite replay used U=2,...,12 and j<8U via rational recurrence. For H=H_(U−1), set E=sum_(i=0)^32 H^i/i!, EU=E+[H^33/33!]/(1−H/34). Check (1−eps)<d_j E and d_j EU<(1+eps) for each of (j≥2U,eps=.08), (j≥3U,eps=.002), (j≥4U,eps=.00016). The factorial continuation proved above covers j≥8U. This is small auxiliary count arithmetic, not scans of E_(n,k). All edge and profile rational inequalities were independently compared by exact integer cross-multiplication, using 32 terms for exp lower bounds and its geometric remainder for upper bounds. In the profile estimation e>2.7 gives explicit lower bounds; e^10.5>2.7^10·1.5>27500, and (2.7)^11>32000. In the tiny-index beta tail, 45 exp(−40)<.01 follows even from e>2. The newly proved interval is complete; coverage above it for moderate k, and at smaller k, is still missing.


## Combining the sharper primary strip with the fixed-n profile (01:40 UTC)

The 01:28 checkpoint (replay long_cycles_ratio_16_replay.md) has three longer central strips for n>10k. I independently ran its BigInt replay and checked the proof dependencies. The higher minimum n improves powers of the diagonal/atom/middle terms to 10k/9k/8k, respectively. The first-difference tail T(9k) gives centered mismatch at most 6R(1+g/3)/(10·9!), and the newly included pure atom prefix needs at least nine factors; both are necessary to use the centered budget. The positive primary amplitude and exact slice exclusion follow with its constants. The central conclusions apply for s≤(27/4)sqrt(k) when k≥256, s≤(15/2)sqrt(k) when k≥512, and s≤8 sqrt(k) when k≥704. Its ceiling-index edge proof gives the recorded three bands through floor(729k/64), floor(225k/16), and 16k. The first two bands are already contained in the preceding fixed-n edge result at their stated thresholds.

Using the new central strips with the stronger fixed-n edge above proves two further complete bands:
    k≥512,  k≤n≤floor(39k/2);
    k≥704,  k≤n≤22k.
As usual this means simple real roots of the original polynomial and strict adjacent interlacing of the quotients by t, last pair included. It is enough to handle 512≤k≤1024, 10k<n≤22k, since earlier results give n≤10k and k≥1024.

### Extend the fixed-n neighbor profile without increasing its errors

The only use of n≤16k in the profile was to ensure β0=kr0/n≥1.8; it suffices that k/(n/k)≥16, because r0≥.45 sqrt(n). For k≥512 and n≤22k this holds strictly. The upper bound β0<8.1, the hard-count ranges, derivative, and all error constants depended only on k≤1024,n≥10k and the same β0 interval. Thus the left/right ratios remain 1.58 and 1.15 throughout the widened domain.

### Extend the edge constants to H≤22

Take D=n−1≥5120, M=floor(.6 sqrt(D)), S=D/M exactly as above. Use the same division by the high witness threshold .45 sqrt(n), but make the medium regime 22≤m<.45 sqrt(n) and the low regime m≤21. All amplitudes lie in [1,H] with H≤22. Cap k gives A_n(r)>H/3.1 for r≥22, and cap ceil(9k/2) gives A_n(r)>H/6.6 for r≥5. Indeed the reciprocal truncation factors are at most 3/(1−1/44) and (13/2)/(1−1/96), respectively, with sqrt(k)>22 and sqrt(ceil(9k/2))≥48. This cap dominates n/r since H/5≤4.4. Low r≤4 still have D_r<.01 by the same binomial Chernoff bound, now at most 66(63/64)^D≤66 exp(−80).

The high and medium constants eta, alpha, lambda are unchanged: (.26,.132,.42) and (.116,.125,.36). The only revisions in the proof are that nonplateau left denominators r≤21 have pure loss at least 5120/(2·21²), absorbing the factor 22 even at lambda=.36; the high far-right factor 22 is absorbed by loss >20; witness and curvature constants already use plateau denominators H/A≤3.1 or the local profile. In the small case the main denominator is at most 22, giving eta=.007 from loss 5120/(2·22·23), so alpha=lambda=.154 using H≤22. Its witness opposing-tail budget also passes.

Main-left D_m and right tails in high and medium cases are <.168+.001a with a=0 at the main, since 3.1(.6/71+1/22)<.168 and 3.1/5121<.001. On the whole left tail D_r<1.1, using 22(22/5121+1/22) for r<22. Substitute d=.168, gamma=.001 and left bound 1.1 into the even-left/odd-right margin above. It passes in both cases. For low brackets both tails obey D_r<.330+.0014a from the cap for r≥5 and the small-index estimate otherwise, since 6.6(22/5121+1/22)<.330 and 6.6/5121<.0014. The generic signed-mean margin with alpha=lambda=.154 also passes.

The same S≤(5/3)sqrt(n)+2.9 bound and pi/40 phase comparison apply. For k≥512 and n≤floor(39k/2), use sqrt(k)>22 and (15/2−29/220)^2 > (25/9)(39/2) to see that S fits the new 7.5 sqrt(k) strip. For k≥704 and n≤22k use sqrt(k)>26 and (8−29/260)^2>(25/9)22 to fit the 8 sqrt(k) strip. Then the splice and degree exhaustion again give the required root counts and signs. All modified rational inequalities, including exp decay for the low tail and the three signed margins, were replayed exactly. This goes beyond both the 16k checkpoint and the earlier 14.8k band without any search of individual original rows. The remainder of the conjecture is open here.

## Local neighbor profile without an upper n/k restriction (02:00 UTC)

For all 256≤k≤1024 and n≥14k, the actual occupancy amplitude satisfies
    A_n(r0−1)/A_n(r0)<1.58, A_n(r0+1)/A_n(r0)<1.15
for integer r0∈[.45 sqrt(n),.8 sqrt(n)]. This extends the local lemma, not yet a global edge or central sign theorem for these n. If β0=kr0/n>1.5 use the same critical interval [ceil(.7β0),ceil(1.3β0)); for U=3 the required complement bound follows from r/U≥(14·1.5−1)/3>5.5, and for U≥4 from n/k≥10 as before. There is no remaining need to bound n/k in that part of the argument. The upper β0<8.1 follows from n≥14k and k≤1024.

For β0≤1.5, only the length-1 cycles are critical: use L=1,U=2, truncate m≤7, and replace d_(r−m,2) by c_2=e^(−1). Since r0≥27, r≥26 and r−m≥19, the relative hard-count error is ≤6/9! by the factorial tail, and the omitted all-degree critical mass relative to c_2 is at most 3 sum_(m≥8)1/m! (works also at zero complement since d≤1). These costs together are <.0002. There are no forbidden-short errors. For b≥2 the mean-to-threshold ratio is at least 9/7 because β_r≤(28/27)·1.5=14/9. Chernoff failure exponent at the lowest mean is below −8 using the cubic log bound at 2/7 and k≥256. The exponent decreases by at least k/7>36 per additional b, as its derivative is k(1/b−1/β_r). The long-cycle error, relative to c_2, is at most (3/2)exp(−8)/(1−exp(−36))<.001. Therefore the genuine probability is within .002 c_2 of the fixed-n critical profile at the three integer neighbors.

The same signed Bernstein derivative bound now costs at most (n/r²) e (.45/sqrt(k)), because the critical set contains only b=1 and the binomial point-mass estimate is uniform for n≥14k. Since r≥(26/27).45 sqrt(n)=(13/30)sqrt(n), this is <3(30/13)^2(.45/16)<.45 in units of c_2. The profile is decreasing in r and ≥c_2. Hence in this small-β regime the ratios even improve to 1.46 on the left and 1.05 on the right, by 1+(.45+.004)/.998 and (28/27)(1.002/.998). This resolves the prior restriction n/k≤k/16 in the local amplitude lemma only. To go further, the global plateau and drift for the whole edge still need a different bound when r is smaller than H, and the central tilted norm may grow once s/k is no longer small.
