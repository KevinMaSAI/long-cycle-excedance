# A tiered, uniform extension of the inner pole lemma

For any row n >= k, put t = -exp(-s) and phi = n atan(pi/s), with the usual limit at s=0. For each pair (K,a) in (10,2), (24,3), (64,4), (256,5), the two signs from INNERMOST_POLE_ALL_K.md hold for all k >= K and 0 <= s <= a sqrt(k): at a witness |cos phi|=1 the sign of E_(n,k)(t) equals cos phi; at an old zero in that interval E_(n+1,k)(t) has sign -sin phi. There is no finite row enumeration. This is a local result, not a new all-row cutoff.

Use the same h_N, q_i, u, v, d_N, B_i and exact two prefix identities as in the innermost lemma; in particular ||delta||_1 < 2/k and 1/(2k−1) <= d_N <= 1/k. Normalize value by 2d_n and centered h_(n+1)−u h_n by 2v d_(n+1) when n >= 2k−1.

For upper-half far level l >= 1, |q_l|² = [1 + 4 pi² l(l+1)/(s²+pi²)]^(-1). Replacing s² by a²k, each (k−1)-st power is decreasing in k by differentiating (k−1) log(1+A/(a²k+pi²)) and using log(1+x)>x/(1+x). The same holds for power 2k−2. Set b=4(157/50)²/(a²K+10). For the two powers the weighted upper-half sum is thus bounded by L(floor((K−1)/2)) and L(K−1), respectively, where
L(m)=3/(1+2b)^m + (5+(1+6b)/(b(m−1)))/(1+6b)^m.
This includes l=1 and 2 explicitly, and integrates the weighted tail (2x+1)/(1+bx(x+1))^m from 2 to infinity. It is decreasing there since numerator of the derivative is 2+2b x(x+1)−mb(2x+1)^2 < 0, implied by (26m−12)b>2. Call strict rational bounds for these sums f and g. The unweighted sums have bounds f/3 and g/3. Also use R > rho/(pi k) and D > a/(pi sqrt(k)), bounding both at K and pi>157/50.

At the primary anchor the total factor norm in the product bound for 1+||B_i||_1 is at most R(1+2f/3), retaining the opposite primary anchor alone. At a far anchor l, the two primary denominators contribute at most 1/l+1/(l+1) <= 3/2 instead of 2. Consequently 2||B_i||_1 is bounded by P=2(exp(R(1+2f/3))−1) at primary and Z=2(exp(R(3/2+2f/3))−1) at farther levels. The factor 2 absorbs dtilde/d_N. The error due to other anchors uses shifted exponent k−1 only for the mixed terms. For n >= 2k−1 the diagonal terms use the stronger exponent 2k−2. Thus the far errors are at most (Zf+g)/3 in value and Zf+g centered, recalling |q_l−u|/v <= 2l+1. The diagonal mismatch costs at most D(1+g/3) in centered units since (2k−1)/(k(n+1)) <= 1/k. This yields the comparison pair
V=P+(Zf+g)/3, W=P+Zf+g+D(1+g/3).
In the single-cycle range n<2k−1 normalize both rows by their individual d_N before subtracting. No mixed or diagonal mismatch terms remain and the errors are at most f/3 and f. The squared sum is less than 1 in each case. Thus at an old zero the centered error is smaller than |sin phi|, and the witness and next-row signs follow.

Rational table columns are (K,a,1000R,1000f,1000g,1000D,1000 upper V,1000 upper W):
(10,2,225,75,1,202,555,800)
(24,3,200,114,4,196,520,780)
(64,4,161,318,30,160,515,835)
(256,5,100,699,134,100,473,870).
Exact rational replay of all bounds passed. The outer edge has not yet been joined to this central region in general. Windows was marked unavailable during the wake, so this checkpoint and the replay are saved in shared notes for later project sync.

Separately verified the Dreamer logarithmic derivative identity for the infinite scalar reference. It is useful farther out, but was not required in this proof. It cannot by itself control finite prefix or far anchor errors.

## Exact replay (JavaScript)
```javascript
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
for(const [K,a,r,F,G,d,V,W] of [
[10,2,225,75,1,202,555,800],
[24,3,200,114,4,196,520,780],
[64,4,161,318,30,160,515,835],
[256,5,100,699,134,100,473,870]
]){
 const b=q(4).mul(pi.pow(2)).div(q(a*a*K+10));
 function lattice(m){return three.div(one.add(two.mul(b)).pow(m)).add(q(5).add(one.add(q(6).mul(b)).div(b.mul(q(m-1)))).div(one.add(q(6).mul(b)).pow(m)))}
 assert(q(2).lt(b.mul(q(26*Math.floor((K-1)/2)-12))));
 const R=q(r,1000), f=q(F,1000), g=q(G,1000), D=q(d,1000);
 assert(one.add(q(a*a*K).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)));
 assert(lattice(Math.floor((K-1)/2)).lt(f));
 assert(lattice(K-1).lt(g));
 assert(q(a*a).div(pi.pow(2).mul(q(K))).lt(D.pow(2)));
 const s=two.mul(f).div(three);
 const p=two.mul(expUp(R.mul(one.add(s))).sub(one));
 const z=two.mul(expUp(R.mul(q(3,2).add(s))).sub(one));
 const uf=z.mul(f).add(g);
 const v=p.add(uf.div(three)), w=p.add(uf).add(D.mul(one.add(g.div(three))));
 assert(v.lt(q(V,1000)));assert(w.lt(q(W,1000)));
 assert(q(V,1000).pow(2).add(q(W,1000).pow(2)).lt(one));
 assert(f.pow(2).add(f.div(three).pow(2)).lt(one));
 text({K,a,V,W,ok:true});
}
```
