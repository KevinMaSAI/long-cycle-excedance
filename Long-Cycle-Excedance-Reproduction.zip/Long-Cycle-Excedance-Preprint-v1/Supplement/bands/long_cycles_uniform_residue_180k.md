# Uniform eventual improvement: k≥12 and n≥180k

2026-11-27 05:00 UTC. For all k≥12, n≥180k, original E_(n,k) has n−1 simple real zeros and E_(n,k)/t strictly interlaces the next quotient. This strengthens the earlier n≥400k by a narrower, farther-out contour and a two-group dense-edge verification. It suffices to prove 12≤k≤63 by the independent all-n result at k≥64. The unresolved lower/middle ranges have not been eliminated.

## Sharper contour and far poles

Use the exact normalized H,h_n,u,v,B,theta,beta,psi and G_s from long_cycles_uniform_residue_400k.md. Its Fourier-kernel bound in |z|≤rho(1+1/d) is in fact <72.7, because 2pi·2.1[1+log(10d/7)]<2(22/7)·2.1·5.5<72.7, uniformly d=k−1∈[11,62]. Choose a radius R in [rho(1+.95/d),rho(1+1/d)] separated by δ=1/(30d) from all pole moduli. The number of distinct moduli needing exclusion is <rho/2 (positive imaginary odd levels; use (R_max+δ)/(2pi)+1<rho/2). Hence their total excluded length <rho/(30d), less than the available .05rho/d. The same denominator argument gives |H|≤90d exp(4+72.7) on the circle. With rho²≤1.66n proved below, the contour error in either h_n/B or (h_(n+1)−u h_n)/(Bv) is ≤3000dn exp(145.4−.95n/k), since log(R/rho)≥.95/(d+.95)>.95/k. For each fixed k this decreases once n≥180k, and at n=180k is bounded by 3000·62·11340 exp(−25.6)<.02.

Keep the far pole weights 2l+1 and radial estimate exp[−(121/288)n·4pi²l(l+1)/rho²]. Split at s=6sqrt(d). Below it, n/rho²≥5 from n≥180k, so radial loss greater than 80l(l+1). The crude residue ratio exp(145.4) still safely gives weighted far sum <.001, using l(l+1)≥2l. Above s=6sqrt(d) use the same exact G_* identity and correction as before; now s>19, |p_l|<1.11s, and correction <.001. For included poles d y²/(2s²)≤10/72+(1+1/22)(1+10/(36·11))<1.22; multiplying exp(1.22)<3.4 by 1/s+1/sqrt(2pi d) gives <.59. Therefore vertical differences in G_* cost .59|y|, and the ratio of residue moduli at level l costs at most exp[3.75(l+1)]. Radial loss is >9.9l(l+1) from rho²≤1.66n, so the weighted remainder is bounded by sum_(l≥1)(2l+1)exp(−6l(l+1))<.001. Both normalized h and centered-next models differ from (−cos psi,+sin psi) by <.021. All sign properties of the previous theorem follow.

## Dense edge now split by k

Set D=n−1, H=n/k, M=floor(.8sqrt(D))≥37 and S=D/M. For 12≤k≤31 use the dense occupancy window r≤.9sqrt(n), where r/H<3/8 and the same good-label Chernoff proof gives .999r<A≤r. For 32≤k≤63 use r≤.84sqrt(n), where r/H<.5 and exp(−.3k)<.001 since k≥32; the same occupancy conclusion holds. Everywhere A≤r. First pure ratio eta=.465 from M≥37, third witness pure ratio .0016 by the exact quadratic loss 9D/[2M(M+3)], and m≤15 uses eta=.020 by D/(2·16·17). With these, actual lambda=.496, curvature alpha=.31. Inside the dense window use the same factors 1/.999 and (17/16)/.999 for high m, or 1.5/.999 for low m. Outside the window the outgoing right pure loss is at least (D/sqrt(n))(5/4−1/c) with c=.9 or .84 and amplitude ratio at most 81/16; both losses suffice. Quadratic third-offset plus geometric continuation gives the high witness signs; the low geometric witnesses use .020. The first dominance persists beyond s=D.

The beta-lattice peak <.45/sqrt(k) still holds from variance ≥.99(k−1). In the small-k dense window the x=D/r≥2.66k weighted binomial estimate of the n≥400k proof still gives d_r<.001 with n≥2160. In the large-k dense window r<H/2, so the geometric Markov estimate gives d_r<7exp(−.299k)<.001. For all r≤M+b, the cap-2k drift from r≥H/2 is ≤.67+.0021b for the small group and .39+.00075b for the large group, via cap ratios 4.46 and 4.27, respectively. Other indices below H/2 already satisfy each crude bound by the same Markov estimate. Thus use drift <.001 on the whole left and on right offsets b<5 for the small group or b<4 for the large group. Check the resulting signed-mean margin, with each remaining right tail conservatively including all offsets, not just odd ones; the corresponding first powers are αλ^4 or αλ^3. Replay proves both margins and the correct signs at all old edge roots. Floor correction S≤(5/4)sqrt(n)+1.62 gives rho²≤1.66n.

## Splice and endpoints

At s=S, we still have |p_0|≤1.02s. With t=s/d (this t is only a positive ratio in the following bound), t≥2.1 uniformly, and t≥3.4 whenever d≤24: use S≥1.25sqrt(180k−1), and evaluate the decreasing ratio sqrt(180k−1)/(k−1) at k=63 or 25. The sharper factorial bound is
 |F_d(rp_0)|≤exp[d(1+log(r|p_0|/d))−rs]
because |rp_0|≥d and each term in the truncated exponential is bounded by (r|p_0|/d)^d d^j/j!. At r=1 its exponent is below −.33d when d≥25, using t≥2.1, and below −1.15d if d≤24, using t≥3.4; the function 1+log(1.02t)−t decreases for t>1. The exponent decreases by at least 11 per increment of r, since d/r−s≤d−s≤−1.1d. Summing the geometric bound and adding the logistic correction gives |G_s(p_0)|<.002 and hence |beta−pi|<.003. The (n+1)theta/pi difference from M is below 1/25 on both sides by the linear and cubic arctangent estimates. It follows psi(S) is within pi/20 of (M+1)pi, while psi(0)=(n+2)pi/2 identically as before. Using the phase first/last-hit construction and degree, inversion and parity gives the desired full row and adjacent comparison. No monotonicity of the phase is required.

## Exact constant replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}

const lo=x=>eb(x)[0],eu=x=>eb(x)[1],pl=q(157,50),pu=q(22,7),d=q(11),n0=q(2160),D=q(2159),s0=q(46),v=D.div(n0),A=q(4,5),C=q(27,8);
ck(q(620,7).lt(lo(q(9,2)))&&q(12,11).sq().add(q(12,11).mul(eu(o))).lt(q(21,5)),"geometric Fourier bound");
ck(q(2).mul(pu).mul(q(21,10)).mul(q(11,2)).lt(q(727,10)),"Taylor norm");
ck(q(12,11).add(q(1,330).div(pl)).div(two.mul(pl)).add(o.div(pl)).lt(q(1,2)),"excluded radii count");
ck(q(90).mul(q(55)).mul(q(166,100)).div(pl).lt(q(3000))&&eu(q(4)).lt(q(55)),"contour prefactor");
ck(q(3000*62*11340*50).lt(lo(q(128,5))),"contour error at 180k");
ck(q(5,4).add(q(81,50).div(s0)).sq().add(q(10,2160)).lt(q(166,100)),"rho square");
ck(q(80).lt(q(121,288).mul(q(5)).mul(q(4)).mul(pl.sq()))&&q(99,10).lt(q(121,288).mul(q(4)).mul(pl.sq()).div(q(166,100))),"radial exponents");
ck(q(10,72).add(q(23,22).mul(o.add(q(10,36*11)))).lt(q(122,100))&&eu(q(122,100)).lt(q(34,10)),"vertical exponential");
ck(q(34,10).mul(q(17,30)).div(q(331,100)).lt(q(59,100))&&q(331,100).sq().lt(d)&&o.lt(q(4,10).sq().mul(two).mul(pl)),"vertical derivative");
ck(q(59,100).mul(two).mul(pu).add(q(2,1000)).lt(q(375,100))&&q(10000).lt(lo(q(12)))&&q(10000).lt(lo(q(146,10))),"far sums");
ck(q(19).lt(q(6).mul(q(331,100)))&&q(12,11).sq().mul(o.add(q(10,36*11))).lt(q(111,100).sq())&&q(1000).mul(o.add(q(111,100).mul(q(19)))).lt(lo(q(19)).sub(o)),"pole correction");
ck(q(21,10).sq().mul(q(62).sq()).lt(q(25,16).mul(q(180*63-1)))&&q(34,10).sq().mul(q(24).sq()).lt(q(25,16).mul(q(180*25-1))),"splice load");
ck(o.add(q(10).div(q(57).sq())).lt(q(102,100).sq()),"primary modulus");
ck(q(102,100).mul(q(21,10)).lt(lo(q(77,100)))&&q(102,100).mul(q(34,10)).lt(lo(q(125,100))),"incomplete gamma exponents");
ck(q(3000).lt(lo(q(33,100).mul(q(25))))&&q(4000).lt(lo(q(115,100).mul(q(11))))&&q(3).lt(lo(q(11))),"primary tiny");

const F=q(999,1000),eta=q(465,1000),lambda=q(496,1000),alpha=q(31,100),x3=q(16,10000),pk=q(45,100),sk=q(346,100);
ck(q(9,10).sq().mul(q(31,180)).lt(q(3,8).sq())&&q(84,100).sq().mul(q(63,180)).lt(q(1,4)),"heavy windows");
ck(q(8,3).lt(lo(o))&&q(1000).lt(lo(q(8)))&&q(1000).lt(lo(q(96,10))),"good-label Cherokee");
ck(sk.sq().lt(q(12))&&q(12).mul(eu(q(1,6*2159))).lt(pk.sq().mul(two).mul(pl).mul(q(99,100)).mul(q(11))),"binomial peak");
ck(o.div(eta).lt(lo(o.div(A.sq()).mul(q(1,2).sub(q(1,111))))),"initial pure");
ck(o.div(x3).lt(lo(q(9).div(two.mul(A.sq())).mul(q(37,40)))),"third pure");
ck(q(50).lt(lo(D.div(q(2*16*17))))&&eta.mul(q(17,16)).div(F).lt(lambda)&&q(81,16).div(lambda).lt(lo(v.mul(s0).mul(q(5,4).sub(q(100,89)))))&&q(81,16).div(lambda).lt(lo(q(5759,5760).mul(q(75)).mul(q(5,4).sub(q(25,21))))),"outward ratios");
ck(o.div(F.sq().mul(alpha).mul(o.sub(alpha))).lt(lo(o.div(A.sq()))),"curvature");
const z=o.sub(eta.sq()),w=o.sub(lambda.sq()),u=o.sub(lambda),h=q(1,1000);
ck(two.div(F).mul(eta.add(x3.mul(q(19,16).div(z).add(eta.sq().div(q(8).mul(z.sq())))))).lt(o),"witness");
const el=q(2,100), zl=o.sub(el.sq());
ck(two.div(F).mul(el.div(zl).add(el.mul(o.add(el.sq())).div(zl.sq()))).lt(o),"low witness");
const x=q(266,100);
ck(x.lt(q(8,3).mul(v))&&q(20).lt(q(166,100).mul(q(12)).add(o)),"small beta spacing");
ck(C.div(v).mul(x).mul(pk).div(sk).mul(em(q(66,100).mul(q(11)))).div(o.sub(em(q(20)))).lt(h),"small beta drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(32))))&&q(7000,670).lt(lo(q(299,1000).mul(q(12)))),"other heavy drift");
for(const [s,K,n,cap,dd,db,gap,cut] of [[s0,sk,n0,q(446,100),q(67,100),q(21,10000),q(9,10).sub(A),5],[q(758,10),q(565,100),q(5760),q(427,100),q(39,100),q(75,100000),q(84,100).sub(A),4]]){
 ck(cap.mul(A.div(s).add(pk.div(K))).lt(dd)&&cap.div(n).lt(db)&&q(cut-1).lt(gap.mul(s)),"drift and late onset");
 let p=o;for(let j=1;j<cut;j++)p=p.mul(lambda);
 const far=alpha.mul(p).mul(dd.add(q(cut).mul(db)).div(u).add(db.mul(lambda).div(u.sq())));
 ck(two.mul(alpha).add(h).add(alpha.mul(lambda).mul(h).div(w)).add(alpha.mul(h).div(w)).add(far).lt(o.sub(alpha)),"signed mean");
}
ck(o.div(A.sq()).div(o.sub(o.div(A.mul(s0)))).lt(q(81,50)),"floor loss");
ck(two.mul(A).div(s0).lt(q(1,25))&&q(10,3).mul(A.sq()).mul(A).mul(q(2161,2159)).div(s0).lt(q(1,25)),"splice phase");
```
