# Variance transported exactly to the critical points of the old row

This gives a new all-n identity and a compact computation of the variance from the insertion coefficients. It does not establish the uniform variance upper bound or solve the conjecture.

Work with the Cayley polynomials F=F_n, L=binom(n,k−1) F_k F_(n+1−k), as in long_cycles_resultant_variance.md. Assume the induction hypothesis that F has d=n−2 distinct real roots r_i in (−1,1). Define rho_i=L(r_i)/F'(r_i), s=sum rho_i=lc(L)/lc(F), and V=sum(rho_i−s/d)^2 (set s=0 when the lag is absent). Let a_j, j=1,..,d−1, be the critical points of F. Rolle and the degree of F' give one simple critical point in each gap and none elsewhere. Define S_j=sum_i (a_j−r_i)^(-2)>0. The exact identity is
    V = sum_j [L(a_j)/F(a_j)]²/S_j
      = -sum_j L(a_j)²/[F(a_j) F''(a_j)].

Proof 1 (orthogonal transport). The d−1 vectors with entries (a_j−r_i)^(-1)/sqrt(S_j) are unit vectors and orthogonal to the constant vector, since sum_i(a_j−r_i)^(-1)=F'(a_j)/F(a_j)=0. Distinct vectors are mutually orthogonal by subtracting these last two zero sums and dividing by their critical-point difference. They are therefore an orthonormal basis of the complement of the constant vector. Partial fractions of L/F say that the projection of rho onto each vector is L(a_j)/(F(a_j)sqrt(S_j)). Parseval gives the first equality. Differentiating F'/F at a_j gives F''(a_j)/F(a_j)=−S_j. This gives the second.

Proof 2 (residue cross-check). The rational function L²/(F F') has simple residues rho_i² at r_i and L(a_j)²/(F(a_j)F''(a_j)) at a_j (coincident zeros are excluded by the hypothesis; zero numerator just gives zero residue). Its x^(-1) coefficient at infinity is s²/d by the leading coefficients. Adding all finite residues proves the same formula, including V=0 when d=1.

## Root-free formula from insertion coefficients

Since F and F' are coprime, calculate the rational polynomial U=(L² * F^(-1)) mod F' by polynomial Euclid and modular division. Then, directly from Lagrange interpolation on the roots a_j of F',
    V = −[x^(d−2)] U / lc(F').
To see this, the leading interpolation coefficient of U is lc(F') times sum U(a_j)/F''(a_j). The positive/negative signs are therefore fixed without computing individual algebraic roots. The same calculation with F and F' interchanged gives the raw squared energy from an interpolation leading coefficient, and subtracting s²/d agrees exactly. The replay checks both formulas on k,n = (3,5), (6,11), (11,21); it is not finite testing offered as a proof.

## A sharper geometric mass identity

Use the same orthogonal transport with input vector rho_i=r_i. Since sum_i r_i/(a−r_i)=a sum_i 1/(a−r_i)−d=−d at each critical point, it yields
    sum_j 1/S_j = (sum_i r_i² − (sum_i r_i)^2/d)/d².
By parity sum r_i=0 and by the interior root bound the right side is <1/d. In particular the critical-point measure is normalized on the scale 1/d, not a fixed constant. Thus a uniform bound |L(a_j)/F(a_j)| <= C sqrt(d) would imply V<C². More flexibly, the critical formula only needs a weighted average square bound, allowing large local ratios near endpoints. A gap estimate also follows: if a_j is in (r_j,r_(j+1)) then S_j>=8/(r_(j+1)−r_j)^2 by convexity of inverse square. This weights tight endpoint gaps correctly. No bound of the needed magnitude for the actual L/F on all critical points has been proved here.

Possible next step: exploit the insertion recurrence in the modular inverse modulo F' or derive a direct critical-point estimate with the weights above. Nothing in this note assumes positivity of the next row or changes the target to finite-range checking.

## Exact replay
```javascript
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}


const zeros=n=>Array(n).fill(0n);
const abs=x=>x<0n?-x:x;
function choose(n,k){let a=1n;for(let j=1;j<=k;j++)a=a*BigInt(n+1-j)/BigInt(j);return a}
function rows(k,N){const F=[];let p=[1n];
 for(let j=3;j<=k;j++){const r=zeros(p.length+1);for(let i=0;i<p.length;i++){r[i+1]+=BigInt(2+i)*p[i];if(i)r[i-1]-=BigInt(i)*p[i]}p=r}F[k]=p;
 for(let n=k;n<N;n++){const r=zeros(p.length+1);for(let i=0;i<p.length;i++){r[i+1]+=BigInt(2+i)*p[i];if(i)r[i-1]-=BigInt(i)*p[i]}
 const b=lag(F,k,n);if(b)for(let j=0;j<b.length;j++){r[j+2]+=b[j];r[j]-=b[j]}F[n+1]=p=r;}
 return F}
function lag(F,k,n){const f=F[k],g=F[n+1-k];if(!g)return null;const r=zeros(f.length+g.length-1),c=choose(n,k-1);
 for(let i=0;i<f.length;i++)for(let j=0;j<g.length;j++)r[i+j]+=c*f[i]*g[j];return r}
const Z=q(0),I=q(1),qd=(p)=>p.slice(1).map((b,i)=>b.mul(q(i+1)));
function trim(p){let r=p.slice();while(r.length&&r.at(-1).a===0n)r.pop();return r}
function add(p,g,s=I){return trim(Array.from({length:Math.max(p.length,g.length)},(_,i)=>(p[i]??Z).add((g[i]??Z).mul(s))))}
function mul(p,g){if(!p.length||!g.length)return[];const r=Array(p.length+g.length-1).fill(Z);for(let i=0;i<p.length;i++)for(let j=0;j<g.length;j++)r[i+j]=r[i+j].add(p[i].mul(g[j]));return trim(r)}
function divrem(p,g){let r=trim(p),s=Array(Math.max(0,r.length-g.length+1)).fill(Z);while(r.length>=g.length){let i=r.length-g.length,t=r.at(-1).div(g.at(-1));s[i]=t;r=add(r,[...Array(i).fill(Z),...g],Z.sub(t))}return [trim(s),r]}
function inv(p,g){let r=g,s=p,x=[],y=[I];while(s.length){const [d,t]=divrem(r,s),u=add(x,mul(y,d),q(-1));[r,s,x,y]=[s,t,y,u]}if(r.length!==1)throw Error("not invertible");return divrem(x.map(t=>t.div(r[0])),g)[1]}
function coeff(k,n){
 const F=rows(k,n),f=F[n],l=lag(F,k,n),par=n%2;
 const root=f.filter((_,j)=>j%2===par).map(v=>q(v));
 const fd=f.slice(1).map((v,i)=>q(v*BigInt(i+1))).filter((_,i)=>i%2===1-par);
 const lagp=l.map(v=>q(v)).filter((_,i)=>i%2===1-par);
 const w=add([I],divrem(mul(inv(fd,root),lagp),root)[1]);
 const d=w.length-1,b=w.map((_,i)=>w.slice(0,i+1).reduce((z,t,j)=>z.add(t.mul(q(choose(i,j),choose(d,j)))),Z));
 return [root,w,b];
}

function bern(p,l,r){const d=p.length-1,du=r.sub(l);
 const v=Array.from({length:p.length},(_,i)=>p.slice(i).reduce((z,t,j)=>z.add(t.mul(q(choose(i+j,i))).mul(l.pow(j)).mul(du.pow(i))),Z));
 return v.map((_,i)=>v.slice(0,i+1).reduce((z,t,j)=>z.add(t.mul(q(choose(i,j),choose(d,j)))),Z));}


function ev(p,x){return p.reduceRight((a,t)=>a.mul(x).add(t),Z)}

function varianceCritical(k,n){
 const F=rows(k,n),p=F[n].map(i=>q(i)),q1=qd(p),L=lag(F,k,n).map(v=>q(v)),m=q1.length-1;
 const rem=divrem(mul(divrem(mul(L,L),q1)[1],inv(p,q1)),q1)[1];
 const crit=Z.sub(rem[m-1]??Z).div(q1.at(-1));
 const orig=divrem(mul(divrem(mul(L,L),p)[1],inv(q1,p)),p)[1],raw=(orig[m]??Z).div(p.at(-1));
 const s=L.at(-1).div(p.at(-1)),mean=s.div(q(m+1));
 assert(crit.sub(raw.sub(s.mul(mean))).a===0n);
 assert(Z.lt(crit)); return [crit,s];
}
for(const [k,n,cap] of [[3,5,q(1,2)],[6,11,q(1,2)],[11,21,q(3,5)]]){
 const [v,s]=varianceCritical(k,n);assert(v.lt(cap)&&s.lt(q(2)));
 text("PASS: k="+k+", n="+n+" critical residue and exact variance agree, variance < "+cap.val());
}
```

## Reduced-degree high-mode numerator and transported orthogonality (14:00 UTC)
Under the same old-row hypothesis, set m=floor((k−1)/2), and let p(x)=s/d+q(x) be the orthogonal projection of the uncentered residue vector rho to old-root evaluations of polynomials of degree <=m (odd projection is zero by parity; q is in low_degree_quadrature). Define the explicit polynomial
    C_p(x)=sum_i (p(x)−p(r_i))/(x−r_i),
    M(x)=L(x)−p(x)F'(x)+F(x)C_p(x).
C_p is computable in rationals from p and old power sums of order at most m−1; no algebraic roots needed. Partial fractions give M/F = sum_i (rho_i−p(r_i))/(x−r_i), also proving that M is the remainder of L−pF' modulo F. Projection gives the zero moments sum_i (rho_i−p(r_i))r_i^j=0 for every 0<=j<=m. Consequently M/F=O(x^(−m−2)), i.e. deg M <= d−m−2, rather than d−1 for the original numerator. No sign or bound concerning the new row is used.
At a critical point a_j, write g_j=L(a_j)/F(a_j)+C_p(a_j). This equals M(a_j)/F(a_j) and an exact identity is
    V−W = sum_j g_j^2/S_j,
where W is the known low-mode centered energy. Moreover the weighted critical values have zero moments sum_j a_j^b g_j/S_j=0 for every 0<=b<m: g_j/S_j=−M(a_j)/F''(a_j), and deg(x^b M)<=d−3, so Lagrange interpolation at the d−1 roots of F' gives zero leading coefficient. Thus the orthogonal transport preserves the low-degree cancellation with a one-degree shift on the critical side. As a check m=0 gives p=s/d, C_p=0, M=L−(s/d)F', recovering the basic identity and no extra critical moments. If m>=2, choosing just the degree-two subspace gives p=alpha+beta*x² and C_p=beta*d*x; then sum g_j/S_j=sum a_j*g_j/S_j=0 by the same argument. This isolates the high-mode burden in a lower-degree numerator and removes any polynomial of degree <m from a critical-pairing test, but does not yet bound its norm. Next use the degree gap to look for an explicit contour bound or a majorizing kernel for the specific M, rather than more n,k enumeration.

## Endpoint completion improves the numerator gap from ~k/2 to k (14:15 UTC)
Keep the simple interior old-row hypothesis. Put G(x)=(x²−1)F(x), of degree n, with the two extra distinct nodes ±1, and define
    N(x)=(x²−1)L(x)−(s/n)G'(x).
Do not estimate the first term and the derivative separately: their leading coefficients cancel for k consecutive degrees. Indeed N/G=L/F−(s/n)G'/G has partial fraction residues eta_i=rho_i−s/n at old roots and eta_±=−s/n at ±1. The exact low-degree quadrature from the separate note now says sum eta_i r_i^j=0 for every 0<=j<k on the extended node set. Thus N/G=O(x^(−k−1)) and deg N<=n−k−1 (similarly parity may cause the next term to vanish). This construction uses no projection inverse, and cancels twice as many leading degrees as the earlier projection up to floor((k−1)/2).
Insertion is exactly F_(n+1)=(1+s/n)G'+N because G'=2xF+(x²−1)F'. Given the distinct nodes of G, F_(n+1) strictly interlaces G iff 1+s/n+eta_i>0 at every extended node: the endpoint factors are identically 1, and at old roots this is precisely 1+rho_i. This directly preserves the full induction goal: n−1 distinct roots in the n−1 gaps of G, with the old n−2 roots between them. Inactive lag gives s=N=0, a pure derivative and strict interlacing.
The same critical Parseval identity on all n extended roots and their n−1 critical points c_j gives
    sum_j (N(c_j)/G(c_j))² / T_j = sum_i eta_i² = V + 2s²/[n(n−2)],
where T_j=sum_(G(r)=0)(c_j−r)^(-2). The equality at right uses sum rho=s and subtracting s/n at all n nodes. In this setup the critical weighted moments vanish through degree k−2: if g_j=N(c_j)/G(c_j), then g_j/T_j=−N(c_j)/G''(c_j) and deg(x^b N)<=n−3 for b<=k−2, so Lagrange leading coefficients give zero. Exact normalization check: sum_j 1/T_j = sum_(G(r)=0) r²/n² = 2/(3n) by the old second root moment and the added endpoints. This is a strictly larger analytic cancellation gap, not a bound by itself. Next see if the explicit EGF expansion of N, after these exact cancellations, gives a uniform upper bound in this new critical norm. Do not report it as a completed induction.

## Exact first surviving coefficient after endpoint completion (14:30 UTC)
Write z=1/x, A(z)=z/atanh(z), D(z)=A(z)/(1−z²), and define R_j(z) by G_j(x)/(lc(G_j)x^j)=A(z)^j R_j(z), where G_j=(x²−1)F_j. For active lag let m=n+1−k and s=lc(L)/lc(F). The normalization and differentiation give respectively L/F=s z D R_kR_m/R_n and G'/G=z[nD−z R_n'/R_n]. Thus the endpoint-completed residual has the exact formal identity
    N/G=s z [D(R_k R_m/R_n−1)+(z/n)R_n'/R_n].
This identity, unlike separately estimating L/F and G'/G, retains the entire low-mode cancellation. Let ell=2 ceil(k/2), and use the already proved expansion R_j=1+κ C_j z^ell+O(z^(ell+2)) from first_high_lag_moment. Then the first possible surviving moment of the extended residues equals
    [z^(ell+1)](N/G)=s κ [C_k+C_m−(1−ell/n)C_n].
It is always nonzero for active lag. Indeed 0<=1−ell/n<1 by n>=2k−1. For even k, C_k=1, C_m>=0 and 0<=C_n<2/k. For odd k, C_k=k, C_m>=−1, C_n<2, so the bracket is >k−3 (strictly positive also for k=3). The upper bracket is <=2 for even k and <2k+2/(k+1) for odd k. Consequently deg N=n−ell−1 exactly; its leading coefficient divided by lc(G) has the explicit sign of κ and absolute size at most s*2*zeta(ell)/pi^ell times the bracket bound. Independent sign check: for k=3,n=5, F=24x³−16x, L=40x² and s=5/3. G'=120x⁴−120x²+16, so N=−16/3; normalized leading coefficient −2/9 agrees with s κ(C_k+C_m−(1−4/5)C_n) where C_k=C_m=3, C_n=0, κ=−1/45. This identifies exactly the start of the remaining high modes without a test range. A single leading coefficient cannot bound the critical norm; still need control across all coefficients/critical points.

## Closing the exact Jacobi normalization from short-cycle counts (after the 14:28 research)
The separate Jacobi stripping reduces N/G to a shorter tail and multiplies the variance by n*b_1²⋯b_ell². The whole product, not just the coefficients below k/2, is explicitly computable from short-cycle probabilities; no high-degree full F is required for this normalization. In detail write u=2 atanh z, gamma_(a,b)=(-1)^(a−1) binom(b−1,a−1)c_b for even b>=a (zero otherwise) using the single-cycle expansion in first_high_lag_moment. Then R_n(z)=E product over cycles of (1+sum_b gamma_(a,b)u^b). Put e_a=d_(n−a)/(a d_n), e_(a,b)^ord=d_(n−a−b)/(ab d_n); the latter counts ordered pairs of distinct cycles even when a=b, by marking and choosing two disjoint labeled cycles. Use d_j=0 for j<0 or 0<j<k, d_0=1. Define v_j=sum_a e_a gamma_(a,j). Up to order 2ell inclusive the only product of two cycle corrections uses ell from each, since all corrections start at ell; no triple can enter. The formal logarithm is therefore
    log R_n(z) = sum_(j even, ell<=j<=2ell) v_j u^j
                 + (u^(2ell)/2) * (sum_(a,b) e_(a,b)^ord gamma_(a,ell) gamma_(b,ell) − v_ell²)
                 + O(u^(2ell+2)).
For the extended uniform measure, its moments through 2ell are the coefficients of D(z)−(z/n)(log R_n)'(z); this is exactly (1/(n z))G'/G. In the Jacobi representation b_1²⋯b_ell² equals the squared norm of the monic degree-ell orthogonal polynomial, hence det(M_ell)/det(M_(ell−1)) where M_j=(moment_(a+b))_(0<=a,b<=j). Positivity and the determinant ratio require ell<n; this holds for the active lag n>=2k−1, k>=3. Multiplying the standard monic recurrence norms proves the product identity, and Schur complement of the last row/column proves the determinant identity. This yields a finite-moment formula for exactly the full scale in the stripped norm, with n dependent only through counting probabilities and 1/n. For an immediate check at k=3,n=5 there is a single 5-cycle, v_4=0 and no pairs, and hence the first correction is at order 6, consistent with the known coefficient. This does not bound the high-degree spectral tail or solve the conjecture.

## Using the endpoint values and the first surviving moment jointly (14:45 UTC)
This strengthens the earlier pointwise threshold by using the entire gap including the first known nonzero moment, not just the moments of half the degree. Work on the n extended nodes of G, and use the unweighted Euclidean inner product on their value vectors. Let U be the even polynomial evaluations through degree ell=2 ceil(k/2), P its orthogonal projector, Q=I−P, and K(x,y) its evaluation kernel (inverse of the unweighted Gram). The known projection of eta is c*u, where u is the normalized monic-degree-ell orthogonal polynomial, normalized to unit norm for the unweighted sum, and c=M_ell/sqrt(n h_ell). Here M_ell=sum eta_i r_i^ell is the first surviving moment explicitly known above and h_ell is the monic norm for the probability measure, computed by the determinant formula. All lower even inner products vanish by the moment gap. Odd components vanish identically by parity. Write E=sum eta_i², now known to equal V+2s²/[n(n−2)].
For a nonzero old node r let e_r=(delta_r+delta_−r)/2, and e_*=e_1 the endpoint-pair probe. Put h_r=1/2−K(r,r), h_*=1/2−K(1,1), and B_r=<Q e_r,Q e_*>=−K(r,1), since their supports are disjoint. Q eta must have endpoint value a_* = −s/n−c*u(1). If h_*>0, its minimum-norm component consistent with the endpoint is (a_*/h_*)Q e_*. Subtracting this component gives the exact sharp (for these moment and energy constraints) lower bound
    eta(r) >= c*u(r) + a_* B_r/h_* − sqrt((E−c²−a_*²/h_*) (h_r−B_r²/h_*)).
Both factors under the square root are nonnegative: they are squared norms of, respectively, the residual eta and the residual probe after orthogonal projection against Q e_*. Cauchy–Schwarz proves the bound, with equality by anti-alignment whenever the residual probe is nonzero. If h_*=0, a_*=0 necessarily and the corresponding formula omits the a_* and B_r terms. When U is the entire even subspace the residual vanishes and the weights are determined exactly. All kernels in this statement require moments only through 2ell, available from the one/two-cycle count formula; no approximations to roots enter the proof. The target is still eta(r)>−1−s/n (the zero root handled separately). This new bound is a way to use an eventual energy upper estimate better, but is not such an upper estimate.

## Exactly what endpoint / moment data can and cannot prove; Euclidean division using the actual long lag factor (14:57 UTC)
Let active lag have m=n+1−k, ell=2 ceil(k/2), and G=(x²−1)F_n as above. Fix G, s, the endpoint values of N, all zero moments of eta through ell−1, and its exact first surviving moment M_ell. Those data alone cannot yield any finite energy upper bound in general. If n is odd and n>=ell+5, let H=x²−1; if n is even and n>=ell+6, let H=x(x²−1). Replacing N by N+λH preserves the required parity n−1, its degree and leading coefficient, both endpoints, and all specified moments because deg H<n−ell−1, so H/G=O(x^(−ell−2)) at infinity. At any fixed nonzero old interior node r, H(r)/G'(r) is nonzero. Hence arbitrary λ forces eta(r) arbitrarily negative and its norm arbitrarily large, still with every fixed datum intact. These deformations are not permitted by the actual insertion lag; they show why merely refining the moment/endpoint Cauchy–Schwarz information cannot prove the global upper bound.
Useful exact structural alternative: let f_j=F_j/lc(F_j), g=G/lc(G), and D=(x²−1)f_m. Because L=s lc(G) f_k f_m, the exact equation is
    g'/n = D f_k + R,     R=−N/(s lc(G)).
This is literally the monic Euclidean division of g'/n by D. The remainder satisfies deg R=n−ell−1<deg D=n−k+1. It follows directly by substituting N and using the degree gap, not by assuming any relative root geometry. In particular the quotient and remainder are uniquely determined by the old row and the actual long-lag factor D; no arbitrary deformation maintaining divisibility by D is possible. Equivalently, valid even over complex numbers and independent of simplicity, f_k is the polynomial part at infinity of g'/(nD). Under the earlier-row induction hypotheses, D has simple real nodes (including ±1), so R is also their unique Lagrange interpolant to g'/n. The higher cancellation manifests as the top ell−k+1 potential coefficients of that interpolant vanishing. This offers a concrete next analytical target: control this specific remainder measured on the nodes of g, by a root-spacing/weighted interpolation estimate coupling g and f_m, rather than bounding arbitrary polynomials with the same moments. The estimate remains open.

## Root displacement criterion for the exact remainder (15:00 UTC)
Under the preceding-row induction hypotheses, compare the two degree n−1 monic real-rooted polynomials T=g'/n and P=D f_k. Let b_1<…<b_(n−1) be the critical points of g (one in each extended-node gap), and let a_1,…,a_(n−1) be the roots of P, with multiplicity, paired with the b's in any way. The latter roots are exactly the endpoints and the roots of f_m,f_k. At an old root r, g'(r) is nonzero and rho(r)=(s/n)P(r)/T(r), directly by evaluating the insertion and cancelling x²−1. If P(r)=0 the sign is automatic; if P(r)/T(r)>0, likewise. At any r with P(r)/T(r)<0, strict induction is therefore equivalent to the exact logarithmic comparison
    sum_j log(|r−a_j|/|r−b_j|) < log(n/s).
A sufficient comparison for such r is sum_j (|r−a_j|−|r−b_j|)_+ / |r−b_j| < log(n/s), from log u<=u−1 for u>0 and dropping the nonpositive terms. Matching the sorted roots is not required; for a given r this last sufficient comparison is minimized by pairing the increasing absolute distances |r−a_j| with the increasing absolute distances |r−b_j|. To see this set the cost c(u,v)=(u/v−1)_+, then for v<w the difference c(u,v)−c(u,w) is nondecreasing in u (slopes 0, 1/v, 1/v−1/w, all nonnegative), and repeated swaps remove crossings. The exact log comparison itself depends only on two unordered multisets. Also R=T−P having degree n−ell−1 implies these two multisets have identical power sums through order ell−1 (indeed through ell−1, with first possible difference at ell) by Newton identities. This is a possible non-variance route using actual factor root geometry. Moment agreement still does not bound small-denominator displacement near r; need a true estimate for these particular rows, not generic interlacing alone.

## Local-distance isolation via complex smoothing (15:15 UTC)
Use monic P and T and their matched power sums up to ell−1 from the displacement note. For an old root r and a>0 put z=r+i a. Choose w such that z=(w+w^(-1))/2 and |w|<1; such a unique branch exists since z is off [-1,1]. For x=cos theta the identity z−x=(1−w exp(i theta))(1−w exp(−i theta))/(2w) gives the absolutely convergent expansion log|z−x|=−log(2|w|)−2 sum_(j>=1) Re(w^j)T_j(x)/j (T_j here Chebyshev). Subtracting the summed expansion over the two degree n−1 root multisets cancels all degrees <ell by matched moments, with |T_j(x)|<=1 at all real nodes. Hence
    |log|P(z)/T(z)|| <= 4(n−1)|w|^ell/[ell(1−|w|)],   |w|<=exp(−asinh(a)).
The latter follows by writing w=exp(−v+i theta), since a<=sinh v. This handles the smooth far-field contribution without assuming root spacing. The exact local correction, for r not a zero of P or T, is
    log|P(r)/T(r)| = log|P(z)/T(z)| + (1/2) sum_j [log(1+a²/|r−b_j|²)−log(1+a²/|r−a_j|²)].
This follows from the factorization of both polynomials; if r is a P-zero the sign test is already automatic. The sum can also be written as an integral against the difference of their interval counting functions about r, using d/dy log(1+a²/y²)=−2a²/[y(y²+a²)]. The exact threshold for the entire right side remains log(n/s) at the roots with negative correction. It is tempting to discard the P contribution, but this costs control on the n/k scale; even quite regular T-nodes can accumulate smoothing cost proportional to n*a (nodes spaced about 1/n within distance a). Thus simple universal far-field cancellation plus a one-sided local bound is not a viable uniform proof; an estimate needs the signed local discrepancy or the true P and T geometry. This gives a precise division between the known cancellation and the remaining local task.

## Positive spline: a localized bound on actual lag residues (after 15:28 research)
See the earlier proof checkpoint for the generalized Stieltjes law nu of the long-factor ratio f_m/f_n and its concentration. Use p=k−1 and a_i=f_m(r_i)/f_n'(r_i). For any δ>0 at most the minimum distance from r_i to another old root, define the C^(p−1) bump φ(x)=(1−((x−r_i)/δ)^2)_+^p. At old roots, φ(r_j) is 1 if i=j and zero otherwise, including equality at the support edge. The law's derivative identity gives
    |rho_i| <= s |f_k(r_i)| δ^(−(p−1)) C_p Pr(|Y−r_i|<=δ),
where C_p may be taken as (1+2R²)^p/R^(p−1) for any R>0. Indeed on |u|<=1 and |w|=R, |1−(u+w)^2|<=1−u²+2|u|R+R²<=1+2R². The Cauchy derivative estimate for the polynomial (1−u²)^p gives this C_p; derivatives through order p−1 join to zero at the support boundary. For example R=1/sqrt(2) yields C_p=2^((3p−1)/2). The probability is at most 3^(−floor(k(max(0,|r_i|−δ))²/2)) by concentration where |r_i|−δ>0, and trivially at most 1 otherwise. This makes an explicit sufficient sign test with only the actual old-row gaps and f_k in addition to universal constants. It does not presently give enough uniform control: δ^(−(p−1)) can dominate the mass bound. It must not be mistaken for a proof, and sharpening now needs local mass rather than only global tails.
A separate tail bound usable with no finite-moment cutoff: constituent X_j is symmetric with exact E[X_j²]=1/3 (adjacent quotient atanh(w)/w through degree 2). The 2/3 value is the second moment of the extended-node empirical measure, not the adjacent residue law. For 0<w<1, E[(1−w X_j)^(-1)]<=1+(1/3)w²/(1−w²), since |X_j|<=1. Markov on either side with w=a gives Pr(|Y|>=a)<=min(1,2(1−2a²/3)^p) for 0<a<1: the multiplier (1−a²)^p cancels the transform denominator. This sharper bound still does not overcome the local gap factor.

## Determinantal spline supported on subsets of the actual old knots (15:30 UTC)
There is a second positive representation of the same spline law that uses only the old roots as knots, not independent roots from different rows. Under the earlier adjacent interlacings, let A be diagonal with the d=n−2 old roots. Build a nested sequence of Hermitian compressions down to dimension d−p (p=k−1) with characteristic rows f_(n−1),...,f_m. To realize each step, choose a normal unit vector with coordinates sqrt of the positive residues of f_(j−1)/f_j in the current eigenbasis. The ratio of the characteristic polynomials of the hyperplane compression and current matrix is that vector's scalar resolvent, by the cofactor identity in an orthonormal basis extending the vector. The desired characteristic polynomial follows, so the construction iterates. At the end write U for a d-by-p orthonormal matrix spanning the orthogonal complement of the remaining subspace. Then the complementary minor identity (or block inverse + Schur complement at large z) gives
    f_m(z)/f_n(z) = det[U^T (zI−A)^(-1) U]
                 = sum_(S subset [d], |S|=p) det(U_S)^2 product_(i in S) (z−r_i)^(-1).
The second equality is Cauchy–Binet; all coefficients are nonnegative and sum to one by U^T U=I. Thus choose S from this fixed-size determinant law and take the uniform-simplex average over its distinct old knots. It has the same moments and hence the same unique compactly supported law as in the 15:28 result. This identifies the derivative jumps with signed sums over actual knot subsets rather than other-row knots; at r_i,
    a_i = sum_(S containing i) det(U_S)^2 / product_(j in S minus i)(r_i−r_j).
In fact with u_j equal to row j of U, viewed as a column, and B_i=sum_(j≠i) u_j u_j^T/(r_i−r_j), this same value is u_i^T adj(B_i) u_i, by expanding det(B_i+u_i u_i^T/(z−r_i)) to first order in the rank-one pole, valid also for singular B_i. The subset inclusion probability is ||u_i||² (differentiate det[U^T diag(t) U] at all t=1), and the expected inclusion sum is p. This representation carefully keeps local sign cancellations and may allow an operator bound instead of the inverse-smallest-gap bound of the bump test; no such uniform operator bound yet. The current user update covers the positive spline route generally; do not announce the determinant identity as a solution.

## Local determinant inertia and one-sided gap bounds (15:45 UTC)
Use the compression construction, d=n−2, p=k−1, V the final subspace (row f_m), U=V^perp. For old node r_i with nonzero leverage l_i=||Proj_U e_i||², let W_i=U ∩ e_i^perp, dimension p−1. In e_i^perp let B be diagonal with entries 1/(r_i−r_j), j≠i, and C_i its compression to W_i. The rank-one pole (or rotate U so its first basis vector is Proj_U e_i/sqrt(l_i)) gives a_i=l_i det C_i. If l_i=0 then a_i=0. If f_m(r_i)=0 then likewise a_i=0; otherwise C_i is nonsingular. Its number q_i of negative eigenvalues is exact:
    q_i = #{j:r_j>r_i} − #{r: f_m(r)=0, r>r_i}.
To prove this, write D=B^(-1)=(r_i I−A)|_(e_i^perp). The complement W_i^perp within e_i^perp is the orthogonal projection of V onto e_i^perp, because projection preserves orthogonality to W_i, is injective as e_i is not in V, and the dimensions agree. The D compression to that projected V is congruent to the compression of r_i I−A to V (the removed e_i component was in its kernel), so it is nonsingular and has exactly the f_m root count in the second term as negative inertia. Block elimination of D shows its remaining Schur complement has inverse C_i, so its negative inertia is precisely the difference above. Thus the sign matches the direct polynomial sign, but the formula also constrains the magnitude. With lambda_i=p−1−q_i, let L_1,... be the old-root distances to the left of r_i in increasing order, and R_1,... the distances to its right. Separate positive and negative eigenvalues and apply the min–max theorem to B compressed on W_i, to obtain
    |rho_i| <= s |f_k(r_i)| l_i /[(product_(j=1)^lambda_i L_j) (product_(j=1)^q_i R_j)].
Positive and negative eigenvalues are bounded by the corresponding ordered eigenvalues of B and −B, respectively. This keeps the required numbers on each side and is sharper than replacing every gap by the smallest one. It still requires a true quantitative estimate from the special compression/rows (leverage and gaps), and does not show this bound <1 at the negative-rho nodes. Do not start another finite sweep as a substitute.

## Folded positive transform with an exact binomial decomposition (16:00 UTC)
Exploit symmetry before trying to control a single-root residue. Write f_j(x)=x^(j mod 2) H_j(x²) with H_j monic, and y=x². Under prior strict interlacings, an even j gives H_(j−1)/H_j=C_j(y), the Stieltjes transform of a probability on (0,1) (its denominator degree is one higher, and the positive squared roots alternate in the standard order). For odd j the folded degrees coincide: the positive roots b of row j−1 and a of row j have 0<b_1<a_1<b_2<a_2<…; the ratio has positive residues at each a_i, as numerator and derivative have the same number of negative factors there. Its constant term at infinity is 1, and the sum of its residues equals sum a_i−sum b_i =1/3 by the exact old second-root moments sum (roots of f_j)^2=2j/3−2. Thus H_(j−1)/H_j=1+C_j(y)/3 for odd j, with C_j again a probability Stieltjes transform. No root of H_j is at zero under the simple old-row/parity assumptions.
Let a,b be the counts of even and odd j in m+1,...,n. The product telescopes to H_m/H_n=(product over even C_j) (product over odd (1+C_j/3)). Expand over subsets I of the odd rows: term I is 3^(−|I|) times a generalized transform of order a+|I| on [0,1], by the same simplex identity. Consequently the positive mixture at order a+h has total coefficient binom(b,h)3^(−h), exactly and independent of n. This is a squared-coordinate analogue of the spline route, avoiding separate distances to mirrored ± roots; individual real-axis residues still require cancellation or knot estimates.
The constituent probability moment sequences are also known before the first defect. For w=1/x the consecutive monic quotient is w*(atanh(w)/w)[1+O(w^ell)]. If j is even divide by x to get H_(j−1)/H_j = y^(−1)[sum_h y^(−h)/(2h+1)+O(y^(−ell/2))]. If j is odd multiply by x, subtract 1, and normalize by 3; then C_j(y)=y^(−1)[sum_h 3 y^(−h)/(2h+3)+O(y^(−ell/2+1))]. Here each sum is interpreted through the last unambiguous coefficient. The two model probability measures on [0,1] have densities 1/(2 sqrt(y)) and 3 sqrt(y)/2 respectively. This exact decomposition uses only earlier interlacings plus actual row moments. It exposes more structure to estimate local poles but does not yet give the uniform residue bound.

## Concentration for each folded spline component (16:15 UTC)
In any term of order q=a+h in the folded positive decomposition, let X_j be the constituent variables on [0,1], mu_j=E X_j, bar_mu their average, and Y the uniform-simplex average. Then E Y=bar_mu and
    Var(Y)=[2 sum_j Var(X_j)+sum_j (mu_j−bar_mu)^2]/[q(q+1)] <= 1/[2(q+1)].
The equality follows from E W_i²=2/[q(q+1)], E W_i W_j=1/[q(q+1)] for i≠j; for the upper bound the uniform mixture of the X_j laws is supported on [0,1] and has variance <=1/4. For k>=5 the exact short moments give bar_mu=(a/3+3h/5)/(a+h), including all n. The component also satisfies Pr(|Y−bar_mu|>=b)<=min(1,2 exp(−7q b²/48)) for 0<b<=1. To verify this, write W_j=G_j/sum G_j with independent standard exponentials, so the one-sided event is sum G_j (X_j−bar_mu−b)>=0. Chernoff bounds it by the product E[1/(1−t D_j)] with D_j=X_j−bar_mu−b and t=b/4. Here D_j<=1 and E[1/(1−t D_j)] <= 1+t E D_j + t² E D_j²/(1−t), by exact expansion of 1/(1−tD). Log and sum: sum E D_j=−q b, sum E D_j²<=q(1/4+b²), and 1/(1−t)<=4/3. Thus log bound <=−q b²/4+5q b²/48, as claimed. The other side follows by replacing X_j by 1−X_j. These bounds need no interior root spacings. They give an exact description of where the folded kernels concentrate, but the residue still depends on local jumps, not just mass or variance; no uniform sign follows.

## Determinantal baseline and an exact measure of its mismatch (16:30 UTC)
In the nested compression representation, let S have determinantal weights, D_S(x)=prod_(j in S)(x−r_j), and use the derivative baseline Q_S=D_S'/p. Its residue at each selected root is exactly 1/p. At any old node r_i,
    rho_i = (s/p) Pr(i in S) + s E[1_(i in S) (f_k(r_i)−Q_S(r_i))/D_S'(r_i)].
This is a positive baseline with a signed error; all knots in S are distinct. Let B=U^T A U (complement compression), C=V^T A V (old lag row), and X=U^T A V in orthonormal bases. Cauchy–Binet gives E D_S(x)=det(xI−B), and hence E Q_S its normalized derivative. This averaged derivative cannot generally be replaced by f_k. In fact trace B=trace A−trace C=0 (all rows symmetric), and the exact second moments of rows give
    trace B² = trace A²−trace C²−2||X||_F² = 2p/3−2||X||_F².
The sum of squared roots of E Q_S is (p−2)/p times trace B², by comparing the second coefficients of the monic characteristic polynomial and of its normalized derivative. The corresponding sum for f_k is exactly 2(p−2)/3. Therefore their exact difference is 2(p−2)||X||_F²/p, nonnegative. For p>2 and strict old adjacent interlacings, merely treating f_k as that mean derivative requires ||X||_F=0; that would make V invariant, i.e. the spectrum of C a subset of the old nodes, which is not guaranteed and must not be assumed. The identity does not itself prove X nonzero for every n, since lags of more than one level can share roots. In the nested normal-vector basis, the diagonal at each eliminated step is zero by symmetry and the squared coupling to all remaining vectors at that step is 1/3 by the second moment of the positive consecutive resolvent. Thus any quantitative baseline comparison needs control on how much of this coupling lands in V versus other removed directions, and also an estimate conditional on i in S, not merely the unconditional mean. No bound at every node has been found.

## Audited chain leverage and an adjacent-atom bound (after 16:28 research)
The 16:28 Dreamer note gives the explicit overlap matrices P_j and mean lost leverage L=1−P_n⋯P_(m+1)1. Their convex comparison yields p/3<=sum_i L_i r_i²<=2p/3. In the determinant baseline, for each nested compression trace(U^T A² U)=trace B²+||X||²=2p/3−||X||². Thus the mean cross energy is exactly 2p/3−sum_i L_i r_i², and lies in [0,p/3]. In fact the same upper bound (p/3) holds before averaging: each of the p removed normals in the ordered nested basis has squared coupling exactly 1/3 to all later basis directions, by the consecutive resolvent. Summing counts each off-diagonal pair within B once and each cross pair once, thus ||B||²/2+||X||²=p/3.
For every individual adjacent-removal atom a_i, there is a uniform Christoffel bound using the exact uniform moments, with no small-gap loss. Put h=floor((ell−1)/2) and K_h(x,x)=sum_(j=0)^h (2j+1)P_j^Leg(x)^2, where P_j^Leg(1)=1 are Legendre polynomials for uniform probability on [−1,1]. Then a_i<=1/K_h(r_i,r_i). Indeed for every degree <=h polynomial q with q(r_i)=1, positivity gives a_i<=sum_j a_j q(r_j)^2=∫ q² dx/2; the minimum over q is 1/K_h by the reproducing kernel or Cauchy–Schwarz with equality at q(x)=K_h(x,r_i)/K_h(r_i,r_i). This applies to the immediate a^(j) in every summand of the exact leverage product; it does not yet bound its propagated distribution sharply enough at the bad nodes. In particular, when one uses the averaged L in the previous sign-sensitive gap bound, the counts of required left and right gaps are fixed by f_n and f_m and are not affected by the random signs. The moment comparisons and the one-step bound are rigorously available; the actual chain gap estimate remains open.

## Exact obstruction: the sign-sensitive nearest-gap upper bound is insufficient (16:45 UTC)
At k=10,n=19 (first active lag, m=10, s=19/10), let r be the 14th old root of f_19 in ascending order. Exact isolation gives 9361969129385549023388/10^22<r<9361969129385549023389/10^22. All these old rows are single-cycle rows; strict earlier interlacing follows from the lag-free derivative recurrence. At r the derivative of f_19 is negative and f_10(r) is nonzero, so the actual lag residue is negative (the numerator is s f_10²). The inertia criterion gives two right and six left distances. The proposed one-sided min–max estimate has upper-bound value greater than 4, even if the full mean leverage L is replaced with its smaller first term f_18(r)/f_19'(r)>0. The exact arithmetic compares lower and upper rational bounds for individual polynomial/gap factors. Hence this specific sufficient estimate cannot prove all signs; the determinant correlations or alternating subset cancellations cannot be discarded. This is a failure of the estimate, not a counterexample to the mother conjecture or the variance inequality.

### Exact replay, JavaScript BigInt
```javascript

const D=10n**22n;
function sg(x){return x>0n?1:x<0n?-1:0}
const rows={2:[1n]};for(let n=3;n<=19;n++){
 const p=rows[n-1],r=Array(p.length+1).fill(0n);p.forEach((a,i)=>{r[i+1]+=BigInt(i+2)*a;if(i)r[i-1]-=BigInt(i)*a});rows[n]=r;
}
function ev(p,x){let A=0n,M=1n;for(let j=p.length-1;j>=0;j--){A=A*x+p[j]*M;M*=D}return A}
const rt={2:[]};
for(let n=3;n<=19;n++){
 const h=rt[n-1].map(([a,b])=>(a+b)/2n);
 const t=[-D,...h,D], l=[];
 for(let i=0;i<t.length-1;i++){
  let a=t[i],b=t[i+1],c0=sg(ev(rows[n],a)),c1=sg(ev(rows[n],b)); if(c0*c1!==-1)throw Error('sign');
  while(b-a>1n){let q=(a+b)/2n,v=sg(ev(rows[n],q));if(!v){a=q;b=q;break}if(v===c0)a=q;else b=q;}
  l.push([a,b]);
 }
 if(l.some(([a,b],i)=>i>0 && a<=l[i-1][1]))throw Error('not disjoint');rt[n]=l;
}
const [A,B]=rt[19][13], i=13, d=rt[19].length;
const count=m=>rt[m].filter(([a,b])=>{if(a>B)return true;if(b<A)return false;throw Error('overlap')}).length;
const q=d-1-i-count(10);
if(q!==2||d!==17)throw Error('inertia');
if(!(rt[18][12][1]<A&&rt[18][13][0]>B))throw Error('not interlacing');
function floor(a,b){if(b<0n)return floor(-a,-b);let q=a/b;return a<0n&&a%b?q-1n:q}
function ceil(a,b){return -floor(-a,b)}
function prod([a,b],[c,d]){let h=[a*c,a*d,b*c,b*d].sort((x,y)=>x===y?0:x>y?1:-1);return [floor(h[0],D),ceil(h[3],D)]}
function value(p){let lo=0n,hi=0n;for(let j=p.length-1;j>=0;j--){[lo,hi]=prod([lo,hi],[A,B]);lo+=p[j]*D;hi+=p[j]*D;}return [lo,hi];}
function abs([a,b]){if(b<0n)return [-b,-a];if(a>0n)return [a,b];throw Error('overlap with zero');}
const f10=rows[10],g18=rows[18],g19=rows[19],gp=g19.slice(1).map((x,j)=>x*BigInt(j+1));
if(value(gp)[1]>=0n)throw Error('rho negative check');
const [u]=abs(value(f10)),[v]=abs(value(g18)),[,w]=abs(value(gp));
let gapU=1n;for(let j=1;j<=6;j++)gapU*=B-rt[19][13-j][0];
for(let j=1;j<=2;j++)gapU*=rt[19][13+j][1]-A;
const num=19n*u*v*g19.at(-1)*D**7n,den=10n*f10.at(-1)*w*g18.at(-1)*gapU;
if(num<=4n*den)throw Error('failure not certified');
text({pair:[10,19],i:14,r:[String(A),String(B)],scale:String(D),left:6,right:2,lowerBoundGreaterThan:4});

```

The same isolating interval certifies the actual rho in (-1/20,0), not merely negativity: after the replay assign `const [, uHi]=abs(value(f10)), [wLo]=abs(value(gp)); let choose=1n;for(let j=1n;j<=9n;j++)choose=choose*(20n-j)/j; if(20n*choose*uHi*uHi>=D*wLo)throw Error('rho magnitude check');` This bounds binom(19,9) times the squared raw single-cycle F_10 divided by the absolute raw F_19 derivative, using the original insertion normalization. The local gap estimate misses substantial determinant cancellation even in the first-lag row.

## A cancellation-sensitive determinant factor, in place of the failed separate-gap bound (17:00 UTC)
At an old node r_i in the determinantal representation let Q be an orthonormal basis matrix for W_i, dimension h=p−1, expressed in the remaining old eigenvectors. Set B=diag(1/(r_i−r_j)), j!=i, and split B=B_+−B_- into its two nonnegative sides. Write M=Q^T |B| Q, strictly positive definite because all r_i−r_j are nonzero, and K=M^(−1/2) Q^T B_- Q M^(−1/2), so 0<=K<=I. Then the exact cofactor identity refines to
    rho_i = s f_k(r_i) l_i det(M) det(I−2K).
Cauchy–Binet supplies a probabilistic meaning that makes the lost cancellations explicit. Weight subsets S of h remaining nodes proportionally to det(Q_S)^2 prod_(j in S)|r_i−r_j|^(-1). Its generating polynomial for the count of selected nodes to the right of r_i is det(I−K+zK)=prod_j(1−lambda_j+z lambda_j), where lambda_j are eigenvalues of K. This follows by multiplying each negative-side diagonal by z before applying Cauchy–Binet and dividing by det M; the count is exactly a sum of independent Bernoulli variables in distribution. The required signed sum is its parity bias, not the sum of magnitudes that caused the previous obstruction. In particular |det(I−2K)|<=exp(−2 tr(K(I−K))) by squaring each factor and using 1−4lambda(1−lambda)<=exp(−4lambda(1−lambda)); if one eigenvalue is 1/2 the residue vanishes. Thus a candidate bound needs the *overlap of the two sides* in the weighted subspace, e.g. enough eigenvalues near 1/2, rather than small individual gaps alone. This identity is exact for the actual compression; no uniform overlap estimate or solution is claimed.

## What the cancellation factor really requires (17:15 UTC)
In the parity-bias formula, let Z=|B|^(1/2) Q M^(−1/2), so Z^T Z=I, and let Π=ZZ^T. If S is the coordinate projector onto the right-side nodes, K=Z^T S Z. Exact expansion of tr K−tr K² using Π²=Π gives
    tr(K(I−K)) = sum_(a on right, b on left) |Π_ab|².
Proof: tr K=sum_(a right)Π_aa, tr K²=sum_(a,b right)|Π_ab|², and Π_aa=sum_b|Π_ab|². Therefore the bias contraction is controlled by cross-side overlap in the gap-tilted projection, not by a marginal leverage profile. There can be no positive universal lower bound based only on that profile: with coordinates L1,L2,R1,R2, consider the two-dimensional subspaces spanned by (L1+L2,R1+R2) or by (L1+R1,L2+R2), normalizing each of these vectors. Both projections have all four diagonal entries 1/2. The first has K eigenvalues 0,1 and parity bias of magnitude 1; the second has K eigenvalues 1/2,1/2 and bias 0. These illustrative subspaces need not be from the actual polynomial chain and are not conjecture counterexamples. They show that even exact marginal leverage cannot by itself close the proof. What must now come from the consecutive-root chain are off-diagonal correlations of the conditional tilted complement, or a different way of controlling the signed determinant directly. The previous analytic large-k route remains complementary but still leaves its uncovered region.

## A positive subset transport for exact averaged determinant correlations (17:30 UTC)
The sign averaging that gave marginal overlap P_j extends to all minors, without retaining a choice of basis. Let d_0=m−2 be the final dimension and let O_j be the rectangular isometry from the f_(j−1) eigenbasis to the f_j eigenbasis, with entries sqrt(a_i)/[(r_i−t_l)sqrt(S_l)] in a canonical sign choice. At each stage multiply its rows by independent signs as before. For sets I,J of d_0 indices in rows j and j−1 define T_j(I,J)=det(O_j[I,J])². Cauchy–Binet and O_j^T O_j=I give sum_I T_j(I,J)=1. If V is the final d_0-dimensional isometry in the original eigenbasis, its averaged law of subsets I of size d_0 with weights E det(V_I)² is exactly obtained by starting with all indices of row m and successively applying T_(m+1),...,T_n. At each intermediate basis the independent diagonal row signs multiply the summands of the Cauchy–Binet expansion by characters indexed by J. Distinct J give orthogonal sign characters, so they vanish in the average of the square. Iterating gives the claimed product. Complements of I have the averaged removed-subset law by the identity of complementary minors in an orthogonal completion of V. Finally each T_j entry is explicit via the Cauchy determinant:
    T_j(I,J)= (prod_(i in I) a_i)(prod_(l in J) S_l^(-1))
               * [prod_(i<i' in I) (r_i−r_i')² prod_(l<l' in J) (t_l−t_l')²]
                 / prod_(i in I,l in J) (r_i−t_l)².
Distinct real nodes and strict interlacing ensure none of the denominators vanish. This retains all rather than only first-order correlations and gives an exact signed sum test by conditioning on a removed subset containing the target root and weighting its successive left/right gaps as in the previous formula. The averaged law is a mixture of determinant laws, not automatically itself a single projection law. To turn this into a proof would require a quantitative bound on the locally gap-weighted parity bias; no such bound is derived here.

## Stable squared-minor transfers and a two-positive-evaluations test (after 17:28 research)
The averaged subset transport is strongly Rayleigh, as proved in the 17:28 checkpoint. For precise theorem verification, the sufficient direction is Borcea–Brändén (2009), Theorem 1.1(b), https://arxiv.org/pdf/0809.0401. Pad the multi-affine input to the same dim as the output by evaluating dummy inputs at 0. The algebraic symbol is the determinant stated in the checkpoint times the dummy w monomial, stable because the imaginary part of diag(w)+O^T diag(x) O is positive definite. Nonnegative coefficient/mass preservation means neither composition nor later positive specializations give the zero polynomial on actual supported events. Complementation uses conjugation, then conditioning, scaling and the specialization of unmarked variables to one use the elementary stability closures (Borcea–Brändén–Liggett 2009, Prop. 3.1, https://arxiv.org/pdf/0707.2340). All the squared Cauchy minors are strictly positive, so all subset events of the required size occur. At a nonextreme old node both parities are possible: the h=p−1 conditional sample has 1<=h<=d−2 among d−1 positions with both sides nonempty, so attainable consecutive counts exist. This proves strict but not uniform cancellation.
Let H(z) be the normalized probability generating polynomial of the tilted right count, with H(1)=1. It is Poisson–binomial by the stable specialization. A useful evaluation-only alternative to variance differentiation: for any t>0, t!=1, put v=t+t^(−1)−2>0. For a Bernoulli parameter lambda the product of its factors at t and 1/t equals 1+v lambda(1−lambda). Therefore log[H(t)H(1/t)] <= v Var(C), and
    |rho_i| <= s |f_k(r_i)| Z_i [H(t)H(1/t)]^(−2/v).
This follows from the parity bound exp(−2 Var(C)), and its right-hand exponent tends to that bound as t→1. Unlike a bound on individual overlaps, this uses only two *positive* partition evaluations of the full averaged subset process. The inequality can evaluate a proposed positive-mass comparison without computing roots of H, but no such comparison is known to yield <1 everywhere. Mother conjecture not solved.

For the 17:45 UTC continuation of stable subset transport, see long_cycles_tilted_subset_exchange.md (exact cancellation of the target-root pole in positive single-row exchanges).