# Full n coverage for every k≥24

2026-11-27 06:15 UTC block. For all integers k≥24 and n≥k genuine E_(n,k) has n−1 simple real roots, and E_(n,k)/t strictly interlaces E_(n+1,k)/t. This lowers the full all-row threshold from 32 to 24. The remaining k<24 cases are not claimed solved. No original polynomial row sweep was run.

The already verified all-n theorem covers k≥32. For 24≤k≤31, long_cycles_k24_through_3k.md covers all early rows n≤3k, and long_cycles_k24_middle.md covers all 3k≤n≤24k. That middle proof introduced a block calculation for the relative reference error, not merely the earlier bound on the far coefficient error. Below is the independent upper bridge starting at 23.25k and reaching past the previous uniform eventual n≥180k theorem. Every one of these range statements includes the next-row comparison for all old rows under its own bounds.

## Larger edge at n≥16k

For 24≤k≤31,n≥16k write D=n−1≥383, M=floor(.55sqrt(D)), S=D/M, and H=n/k. When r≤.59sqrt(n) the mean of Bin(n,1/r) relative to k−1 exceeds 1.258, since β=kr/n≤.59sqrt(31/16) and k/(k−1)≥31/30. Robbins peak .46/sqrt(k) is valid by variance ≥(15/16)(k−1). Geometric lower-tail upper bound gives Pr(X<k)<.25 via the cubic Φ lower and prefactor 1/(1−1/1.258); exact replay. The occupancy good-label argument then gives A_n(r)>.75r in this window, and A_n(r)≤r everywhere. Thus no central sigmoid or independent cycle approximations are needed here.

First pure outward ratio η=.215 using M≥10 and pure right loss ≥1/.55²·(1/2−1/30). All left ratios inside the window have amplitude factor ≤1/.75, right factor ≤1.5/.75; beyond it the right outgoing loss ≥(D/sqrt(n))(20/11−100/59) absorbs global amplitude ratio 81/16. Hence λ=.49. Curvature products ≤exp(−1/.55²)/.75² give α=.071. Witness opposing ratios are bounded by pure η and amplitude (1+a/m)/.75 for m≥8. For m≤7 use pure .03 and factor (1+a)/.75, giving strict bounds. First dominance stays true past s>D.

At r≥.75H, cap ceil(4k/3) gives H/A<3.66, and the exact beta lattice bounds drift ≤3.66(r/n+.46/sqrt(k)). At smaller r, use x=D/r≥1.329k, step loss >8 and weighted binomial monotonicity for drift <.20. Thus the standard signed-mean budgets .45+.0096a and left .45 pass. The cubic and floor estimates give S≤(20/11)sqrt(n)+3.7 and phase deviation <π/16. The signed comparison involves the original adjacent row, not a limiting score. The bound proves every edge n≥16k, whether or not the upper central intervals below are the ones used.

## Central and complete coverage

Use the K24 two-cycle count tail T(Lk)<.316/(k L!), ξ=.829 and tilt with .105 variation as established in long_cycles_k24_middle.md. Counts at old n≥3k are at least .555/k, so the far shift ratio can use baseline 1+δ with excess .81−δ, where δ=.632/L! on short retained shifts with residual length at least Lk. The primary relative short error uses .632/L!, and the diagonal mismatch uses the same .632 constant scaled by floor(B−1)!, always rounding the lower degree cutoff in the safe direction when B is fractional. Use the real reference on s≥4sqrt(k), vertical log bound .37, scalar (29/30)/(a/4.89+2); improve it with exp(−.77p)(1−(.77p)^2/2) as appropriate. The π/16 angular fraction >.88 suffices. For the small central core, use a=4 and primary real reference lower bound 2−exp(ξp) without vertical decomposition. Every ellipse and splice condition was checked exactly.

Analytic ratio intervals start at 23.25, reach 184.25 and overlap n≥180k, already proven uniformly for all k≥12. They also overlap the 3≤n/k≤24 center. Strict comparisons at each old root, together with the degree-count and parity splices, yield each entire row, not merely part of its zeros. Combining all these proves the displayed k≥24 theorem; k<24 remains a separate open range in this work.

## Exact upper-band replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(44)).mul(ex(q(5,16)).sq()).lt(q(37,100).sq()),"vertical log bound");
ck(q(58,100).lt(q(63,100).mul(o.sub(q(37,100).sq().div(two)))),"vertical real fraction");
ck(q(88,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(37,100).div(o.sub(q(37,100).sq().div(two))).mul(pu.div(q(16))))),"splice angle fraction");
const rows=[[24,23.25,40,550,5,23.25,1],[24,23.25,108,450,5,30.25],[24,30.25,125,375,7,41.25],[24,41.25,144,300,7,56.25],[24,56.25,164,250,7,73.25],[24,73.25,183,200,7,92.25],[24,92.25,202,150,10,113.25],[24,113.25,215,125,10,129.25],[24,129.25,227,125,10,145.25],[24,145.25,235,125,10,156.25],[24,156.25,243,100,10,167.25],[24,167.25,251,100,10,178.25],[24,178.25,255,100,10,184.25]];
const covered={24:23.25};
for(const [K,B,a2,at,L,N,core] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(489,100);
 ck(!q(K).lt(sk.sq())&&(core||B<=covered[K])&&B>L&&(core||N>covered[K]),"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(105,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(829,1000).mul(p)).sub(o).mul(q(632,1000)).div(fact(L)).add(em(alpha.mul(q(Math.round(4*(B-L)),4))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(632,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(q(181,100).mul(em(alpha.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(q(81,100).sub(delta).mul(em(alpha.mul(q(Math.round(4*(B-L)),4)))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(632,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 const ref=core?two.sub(ex(q(829,1000).mul(p))):q(29,30).div(a.div(sk).add(two)); const rp=p.mul(q(77,100));const ref2=!core&&rp.lt(o)?dn(o.div(ex(rp)).mul(o.sub(rp.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 if(!core)ck(V.lt(q(88,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(37,10).div(sk));
 if(!core)ck(q(0).lt(rad)&&q(Math.round(4*N)*100,121).lt(rad.sq()),"splice location");
 if(!core)covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=x=>eb(x)[0],K0=q(24),D=q(383),n=q(384),sk0=q(489,100),sd=q(195,10),u=q(55,100),reach=q(59,100),pk=q(46,100),C=q(27,8),v=D.div(n);
ck(covered[24]>180,"eventual overlap");
ck(K0.mul(ex(q(1,6*383))).lt(pk.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(23))),"Robbins peak");
const w=q(1258,1000),z0=w.sub(o),F=q(3,4);
ck(w.sq().mul(reach.sq()).mul(q(31,16)).lt(q(31,30).sq()),"density mean");
function loss(x){return q(23).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))))}
ck(pk.div(sk0.mul(o.sub(o.div(w)))).mul(em(loss(z0))).lt(o.sub(F)),"density good-label probability");
const e=q(215,1000),l=q(49,100),a=q(71,1000);
ck(o.div(e).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,30)))))&&q(3,2).div(F).mul(e).lt(l),"high ratios");
ck(q(81,16).div(l).lt(lo(v.mul(sd).mul(o.div(u).sub(o.div(reach))))),"right exit");
ck(o.div(F.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(u.sq()))),"curvature");
function witness(e,m){
 const z=o.sub(e.sq());return two.div(F).mul(e.div(z).add(e.mul(o.add(e.sq())).div(q(m).mul(z.sq())))).lt(o);
}
ck(witness(e,8)&&q(100,3).lt(lo(D.div(q(49)).mul(q(1,2).sub(q(1,21)))))&&witness(q(3,100),1),"witnesses");
const cap=q(366,100),d=q(45,100),b=q(96,10000),x=q(1329,1000);
ck(q(10,3).div(o.sub(o.div(q(113,10)))).lt(cap)&&cap.mul(u.div(sd).add(pk.div(sk0))).lt(d)&&cap.div(n).lt(b),"cap drift");
ck(x.lt(q(4,3).mul(v))&&q(8).lt(q(329,1000).mul(K0).add(o)),"drift spacing");
ck(C.div(v).mul(x).mul(pk).div(sk0).mul(em(loss(q(329,1000)))).div(o.sub(em(q(8)))).lt(q(2,10)),"heavy drift");
const zz=o.sub(l.sq());
ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(zz)).add(a.mul(d.div(zz).add(b.mul(o.add(l.sq())).div(zz.sq())))).lt(o.sub(a)),"sign budget");
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sd)))).lt(q(37,10))&&u.div(sd).lt(q(1,16))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sd)).lt(q(1,16)),"splice");
```
