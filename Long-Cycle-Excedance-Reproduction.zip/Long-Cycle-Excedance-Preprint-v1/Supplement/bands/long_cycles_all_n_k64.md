# Full n coverage for every k≥64

2026-11-27 04:28 UTC Computational proof checkpoint; the estimates and exact replay are given below. Original excedance polynomial only. All rows n≥k at every k≥64 now covered. The complete mother conjecture below this remains open.

### Every n≥k is now covered for k≥64

For all k≥64 and n≥k, E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient. The new proof covers 6k≤n≤16k for 64≤k≤79 and includes the final pair. The preceding lower and upper bands already cover n≤6k and n≥16k, and k≥80 already has all rows. This fills the exact gap described to the user at 04:20 UTC. It does not settle the general k<64 case. [Earlier lower range](long_cycles_k64_through_6k.md) · [Earlier upper range](long_cycles_k64_from_16k.md) · [Central replay](long_cycles_all_n_k64_central_replay.md) · [Edge replay](long_cycles_all_n_k64_edge_replay.md).

**Near-edge drift directly on the occupancy lattice.** Put D=n−1 and H=n/k. Throughout the new range the beta-lattice peak is <.45/√k: at p0=(k−1)/D the binomial variance is ≥5(k−1)/6, and the Stirling numerator contributes at most exp(1/(12D)). For fixed j=k−1, the binomial mass at p=a/r relative to that at p0 is ≤exp(−j Φ(a/β)), where β=p0r and Φ(w)=w−1−log w. This is immediate by applying log(1−u)≤−u to the second factor in the probability ratio. For 0<β≤2.2,
    sum_(a≥1) exp(−j Φ(a/β)) < 1.05.
For β≤1.3 keep a=1 at cost 1 and bound a≥2 from w≥20/13, with successive exponent loss ≥j(10/13−1/2). For 1.3≤β≤1.7 use w≤10/13 for a=1, w≥20/17 for a=2, and w≥30/17 for a≥3 plus loss ≥j(10/17−1/3). For 1.7≤β≤2.2 keep a=2 at cost 1, then use w≤10/17 for a=1 and w≥15/11 for a≥3 plus loss ≥j(5/11−1/3). The rational replay uses Φ(1−u)≥u²/2+u³/3 and Φ(1+u)≥u²/2−u³/3 at those endpoints. In the first edge range below, r≤M+1 implies β<.552√(79/6)<2.2. Thus the main and first outward right drift in the cap-k plateau are <3.18·1.05·.45/8<.189. [Exact beta-lattice identity](long_cycles_adaptive_edge_curvature.md) · [Robbins](https://dornsife.usc.edu/sergey-lototsky/wp-content/uploads/sites/211/2024/02/Stirling-Robbins.pdf).

**Shared plateau and nonplateau estimates.** Use H/A_n(r)<3.18 when r≥ceil H by cap k, <3.45 when r≥ceil(4H/5) by cap ceil(5k/4), and <4.19 when r≥H/2 by cap 2k. Always A_n(r)∈[1,H]. Below H/2 the geometric binomial bound gives D_r<7exp(−.297k)<.001 because D/r≥1.994k. Otherwise D_r≤(H/A_n(r))(r/n+.45/√k). At all three edges classify m below the high threshold as medium if m≥H/2, low otherwise. For medium m<ceil(ZH), both main indices are ≤ZH+1. The pure loss is ≥(64H−1)/(2(ZH+1)(ZH+2)), decreasing for H≥6. Medium denominators use amplitude factor 4.19. Below H/2 the loss ≥2D/H² absorbs H. At old roots use curvature bound 4.19² exp(−D/(ZH+1)²) for the medium main indices. For low m both main indices are ≤H/2+1. Use the corresponding pure and curvature losses with Z=1/2 and factor H. Low pure η<.0035 throughout. These bounds give medium and low λ,α respectively at most (.311,.060), (.374,.101), (.345,.093) in the three H ranges 6–9, 9–10, 10–16. Their drift is ≤.320+.011b at offset b, and the generic signed-mean and odd witness bounds pass. Use Z=1 in the first two ranges and 4/5 in the last.

**High brackets in 6≤H≤9.** Take M=floor(√D/2)≥9 and high m≥ceil H. The first pure ratio is <.156 by the quartic logarithm bound at M=9. With cap-k factor 3.18 take actual λ=.497 and old-root α=.248 from curvature ≤3.18² e^(−4). For left steps dropping below the plateau use loss ≥575/162 and amplitude ≤9. Every ratio beyond the first is <.060 even charging amplitude factor 9. On the right the second loss is at least
    D/[r(r+1)]+D/[2(r+1)(r+2)] ≥4(9/10+81/220),
where r=m+1≤M. The left second loss is ≥6 and subsequent losses improve. At a witness the combined first opposing offset costs at most 2·3.18·.156. The pure third offset costs <.0000015 by the quadratic loss 9D/[2M(M+3)]≥13.5. After it use geometric ratios .156, so the odd witness sum is <1.

The main left and first right drift are <d=.189 by the peaked lattice bound. The whole left uses .344, and all right offsets b can use .262+.0083b. Write ℓ=.060, u=1−ℓ². The adverse even-left and odd-right costs in the old-root numerator are at most
    L_e=αℓ·.344/u,
    R_o=αd+αℓ²[(.262+3·.0083)/u+2·.0083ℓ²/u²].
With 2α+d they total less than 1−α. This retains the much steeper drop after the first offset and avoids charging the full lattice integral on the first opposing neighbor.

**High brackets in 9≤H≤16.** Use M=ceil(.44√D). On 9–10 use r≥ceil H and cap k, and on 10–16 use r≥ceil(4H/5) and cap ceil(5k/4). Then M/√D≤.482,.480 and M≥11,12. The first right log loss is at least (D/M²)(1/2−1/(3M)), giving (η,λ,α)=(.133,.424,.166) and (.130,.450,.195) after the cap and root curvature. Left below either plateau uses cap 2k until H/2 and the full factor H below H/2, with corresponding larger pure losses. The whole left drift uses .322,.317. The main left and right use .244+.0056b or .261+.0055b. The standard even-left/odd-right margin and witness margin pass. These three edge ranges give next-row sign (−1)^(m+1) at all old roots and alternate at all witnesses.

### Central and endpoint checks

Reuse the k≥64 count tail T(2k)<.125/k, T(Lk)<.25/(k L!), absolute norm ξ=13/16 in old 2/k units and the sharper tilted rate from the lower and upper source proofs. For 6≤H≤8, use the hybrid absolute-primary method of the k≥80 proof at K=64. For H≥8 use the harmonic tilted endpoint estimate and δ=.5/L!. Bound the reference's real part by the maximum of the established scalar lower bound (19/15)/(a/8+2), 2−exp(ξp) from the unweighted anchor norm, and exp(−p)(1−p²/2) for p<1. All obey the same splice angular margin .97 via the established .22 vertical argument bound when s≥4√k. For s≤4√k use the earlier inner strip. [Hybrid proof](long_cycles_all_n_k80.md) · [Harmonic endpoint formula](long_cycles_harmonic_anchor_bridge.md).

The central replay uses consecutive intervals B≤H≤B+1 with B=6,…,15. Their strip factors a are 5.88, 6.18, 6.55, 7.19, 7.55, 7.88, 8.20, 8.51, 8.81, 9.10. The hybrid tilt is (.65,2), (.70,2) for B=6,7. The tilted proof uses α=.70 with L=3 for B=8,9, L=4 for B=10,…,13 and L=5 afterward. All ellipses and phase exclusion margins pass. When M=floor(√D/2), use S/√k<2√(B+1)(1+1/M). For B=7 only, handle M=10 with S/√k≤483/80, and use the general bound with M≥11 otherwise. When M=ceil(.44√D), use S≤√D/.44. The cubic atan bound puts the left phase within π/40 of Mπ. In the floor case use M=9 for D<400 on the positive side. Thus the joining sliver has no roots. The established witness, inversion, parity and degree argument yields simplicity and strict next-row interlacing, with all endpoint pairs.


## Reverse audit and supporting derivations

The sharp binomial lattice bound does not suppose independence of multinomial cell counts. It is applied to the exact marked beta-lattice formula for the adjacent drift. Its geometric bounds use j=k−1≥63; for w=a/β>1 the derivative with respect to continuous a is j(1/β−1/a) and is increasing. Thus the stated endpoint sums dominate all corresponding β ranges. The upper bounds on beta use r≤M+1 for both the left main term r=m and the first outward right offset r=m+2 (since m+1≤M). The point mass <.45/sqrt(k) is from positive factorial arguments in Robbins and variance Dp_0(1−p_0)≥(5/6)(k−1), valid at n≥6k. The separate integral bound is only used after this first offset or for other brackets.

For the high floor bracket, r=m+1 and s≥D/r. The second right loss has exactly the bound
  D[1/r−log(1+1/(r+1))] ≥ D/[r(r+1)]+D/[2(r+1)(r+2)].
With r≤M and D≥4M² this is ≥4[9/10+81/220]. The second left loss for m−1 positive is ≥D/[m(m−1)]+D/[2(m−1)²]≥6. Both only grow afterwards. The amplitude factor ≤H≤9 also applies on a nonplateau step; thus .060 controls every ratio after the first on both sides. The witness at a=3 uses separate quadratic pure decay, while the drift at a≥3 uses the actual tail ratio .060 after the first. The old-root signed-mean correction denominators all use B≥(1−α)w_0 separately on the respective side. The factor α times .060 squared at the first odd later offset is essential, and is justified by the two successive ratio bounds after offset 1.

In the medium and low edge cases, the outgoing bases below H/2 appear only on the left of a medium bracket. For the right of a low bracket both main indices are at most H/2+1; the stronger exponent is used for the first step, then pure ratios decrease and amplitude factors are globally ≤H. When checking medium or low drift, a main index is at most ZH+1, so its ratio to n is at most (1+1/6)/k. This validates the common .320+.011a budget without assuming plateau below its onset. The high floor phase upper correction uses M=9 for D<400; for D≥400 use M/D≤.5/sqrt(D)≤.025 and strict subtraction by the atan cubic. A floor splice at B=7, M=10 satisfies D≤483, giving S/sqrt(k)≤483/80; the general bound applies for M≥11. The ceiling splice at B≥9 satisfies S≤sqrt(D)/.44 directly. Both switch values n=9k and 10k are covered from either applicable side.

The extra primary lower bound 2−exp(ξp) for the tilted intervals holds because P_*=1+B_i(1/q_i) on the primary, and the absolute coefficient norm of B_i is at most exp(ξp)−1. It is a bound for Re P_*(s+iπ) itself, hence the same angular exclusion applies to the maximum of this bound and the scalar and direct-log bounds. For the hybrid case taking the smaller amplitude bound is legitimate from the short/long coefficient split; all adjacent drift terms still use the old larger norm. The relative count tail .5/L! and improved main/lag estimates are those previously proved for k≥64. For small s the tilted intervals have n≥8k, so the earlier k≥64,n≥4k central signs apply.

The parent re-executed both exact replays with every check passing. Earlier occupancy-profile replays in the inherited k≥80/k≥96 bands were also rerun with conservative revised hard-count omission bounds, and all margins still passed. No original-polynomial finite sweep was used. The remaining research should target general k<64; all ranges here concern the fixed minimum cycle length and the stated exceeded-position statistic.

## Exact central replay
# Central rational checks for the k≥64 bridge

All decisions use rational bounds. The central radius proposal is checked by exact squaring. Run with a text(value) output function or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=64,sk=q(8),xi=q(13,16),o44=q(11,25);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[6,588,65,2],[7,618,70,2],[8,655,70,3],[9,719,70,3],[10,755,70,4],[11,788,70,4],[12,820,70,4],[13,851,70,4],[14,881,70,5],[15,910,70,5]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(22,100).sq().div(two));
ck(pu.div(q(124)).mul(ex(q(5,16)).sq()).lt(q(22,100).sq()),"vertical log");
ck(q(76,100).lt(q(78,100).mul(ca)),"vertical positive");
ck(q(97,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(22,100).div(ca).mul(pu.div(q(40))))),"splice rotation");
for(const [B,a0,tilt0,L] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=31;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(1,2).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(83,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=q(1,2).div(fact(L)),abs=ex(xi.mul(p)).sub(o);
 const ps=em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 if(B<8){
  const P=min(two.mul(abs),o.add(delta).mul(abs).add(ps)), xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=two.mul(ex(xc).sub(o).sub(xc)).add(q(125,1000).mul(x));
  W=up(high.mul(f).add(x.mul(j)).add(x.mul(ell).div(two)).add(g));
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(40)).sq().div(two))).sub(P.mul(pu.div(q(40))));
 }else{
  const eps=up(abs.mul(delta).add(ps));
  const far=o.add(delta).mul(em(al)).mul(j).add(two.add(delta).mul(em(al.mul(q(B-1)))).mul(f)).add(em(al.mul(q(B-L))).mul(fl));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));drift=two.mul(eps);
  let ref=max(q(19,15).div(a.div(sk).add(two)),o.sub(abs));
  if(p.lt(o))ref=max(ref,dn(o.sub(p.sq().div(two)).div(ex(p))));
  c=ref.sub(eps);slice=q(97,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 if(B===6)ck(q(4*7*100,81).lt(a.sq()),"floor M9");
 if(B===7)ck(q(483,80).lt(a)&&q(4*8*144,121).lt(a.sq()),"floor M10 or 11");
 if(B===8)ck(q(4*9*144,121).lt(a.sq()),"floor M11");
 if(B>=9)ck(q(B+1).div(o44.sq()).lt(a.sq()),"ceiling splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
```


## Exact edge replay
# Edge rational checks for the k≥64 bridge

All decisions use rational bounds. The central radius proposal is checked by exact squaring. Run with a text(value) output function or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const lo=x=>eb(x)[0], pi=q(157,50),C=q(318,100),C2=q(419,100),CU=q(345,100),pk=q(45,100),sk=q(8);
const D=q(383), sd=q(195,10), qa=q(1,40);
ck(q(3).sub(q(2,79)).div(o.sub(q(1,16))).lt(C),"cap k");
ck(q(4).div(o.sub(q(5,113))).lt(C2),"cap 2k");
ck(q(13,4).div(o.sub(q(5,89))).lt(CU),"cap 5k/4");
ck(sd.sq().lt(D)&&q(89,10).sq().lt(q(80))&&q(113,10).sq().lt(q(128)),"square roots");
ck(q(64).mul(ex(q(1,6*383))).lt(pk.sq().mul(two).mul(pi).mul(q(5,6)).mul(q(63))),"binomial peak");
ck(q(7000).lt(lo(q(297,1000).mul(q(64)))),"tiny drift");
const a55=q(552,1000);
ck(q(1,2).add(o.div(sd)).lt(a55)&&a55.sq().mul(q(79,6)).lt(q(11,5).sq()),"near saddle beta");
function minus(u){return u.sq().div(two).add(u.sq().mul(u).div(q(3)))}
function plus(u){return u.sq().div(two).sub(u.sq().mul(u).div(q(3)))}
const j=q(63),geom=(x,step)=>em(j.mul(x)).div(o.sub(em(j.mul(step))));
ck(o.add(geom(plus(q(7,13)),q(10,13).sub(q(1,2)))).lt(q(105,100)),"lattice b<=1.3");
ck(em(j.mul(minus(q(3,13)))).add(em(j.mul(plus(q(3,17))))).add(geom(plus(q(13,17)),q(10,17).sub(q(1,3)))).lt(q(105,100)),"lattice b<=1.7");
ck(o.add(em(j.mul(minus(q(7,17))))).add(geom(plus(q(4,11)),q(5,11).sub(q(1,3)))).lt(q(105,100)),"lattice b<=2.2");
function witness(C,e){return two.mul(C).mul(e).div(o.sub(e.sq())).lt(o)}
function curv(C,e,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(e))}
function generic(a,l,d,b){const u=o.sub(l);return two.mul(a).add(d).add(a.mul(d.div(u).add(b.div(u.sq())))).lt(o.sub(a))}
function signed(a,l,d,b,dL){const u=o.sub(l.sq());return two.mul(a).add(d).add(a.mul(l).mul(dL).div(u)).add(a.mul(d.div(u).add(b.mul(o.add(l.sq())).div(u.sq())))).lt(o.sub(a))}
const grad=(C,A,sd)=>C.mul(A.div(sd).add(pk.div(sk)));
const driftSmall=q(32,100), slopeSmall=q(11,1000),el=q(156,1000),ll=q(497,1000),al=q(248,1000),l2=q(6,100),tight=q(189,1000),left=q(344,1000),dR=q(262,1000),bR=q(83,10000);
const lowerLog=q(2).sub(q(4,27)).add(q(1,81)).sub(q(4,3645));
ck(o.div(el).lt(lo(lowerLog))&&C.mul(el).lt(ll),"early high first ratios");
ck(q(9).div(ll).lt(lo(q(575,162)))&&q(9).div(l2).lt(lo(q(4).mul(q(9,10).add(q(81,220))))),"early nonplateau and second ratios");
ck(curv(C,q(4),al),"early high curvature");
const t3=q(15,10000000),wHi=two.mul(C).mul(el).add(two.mul(C).mul(t3).div(o.sub(el.sq())));
ck(o.div(t3).lt(lo(q(27,2)))&&wHi.lt(o),"early high witnesses");
ck(C.mul(pk).mul(q(105,100)).div(sk).lt(tight),"sharp near-neighbor drift");
ck(grad(C2,q(1,2),sd).lt(left)&&grad(C,q(1,2),sd).lt(dR)&&C.div(q(384)).lt(bR),"early drift tails");
let u=o.sub(l2.sq());
const Lcost=al.mul(l2).mul(left).div(u);
const farRight=dR.add(q(3).mul(bR)).div(u).add(two.mul(bR).mul(l2.sq()).div(u.sq()));
const Rcost=al.mul(tight).add(al.mul(l2.sq()).mul(farRight));
ck(two.mul(al).add(tight).add(Lcost).add(Rcost).lt(o.sub(al)),"early high signed margin");
ck(q(9,383).lt(qa)&&!qa.lt(q(1,2).div(q(20))),"early phase upper");
ck(q(10,3).mul(q(1,8)).mul(q(384,383)).div(sd).lt(qa),"early phase lower");
for(const [H,Z,lambda,alpha,eta] of [[9,o,q(311,1000),q(60,1000),q(74,1000)],[10,o,q(374,1000),q(101,1000),q(89,1000)],[16,q(4,5),q(345,1000),q(93,1000),q(82,1000)]]){
 const h=q(H),d=h.mul(q(64)).sub(o),r=Z.mul(h).add(o),rL=h.div(two).add(o);
 ck(o.div(eta).lt(lo(d.div(two.mul(r).mul(r.add(o)))))&&C2.mul(eta).lt(lambda),"medium outward");
 ck(h.div(lambda).lt(lo(two.mul(d).div(h.sq()))),"below cap");
 ck(curv(C2,d.div(r.sq()),alpha)&&witness(C2,eta),"medium curvature and witness");
 const e0=q(35,10000);
 ck(o.div(e0).lt(lo(d.div(two.mul(rL).mul(rL.add(o)))))&&h.mul(e0).lt(lambda)&&curv(h,d.div(rL.sq()),alpha)&&witness(h,e0),"small index");
 ck(C2.mul(q(7,6*64).add(pk.div(sk))).lt(driftSmall)&&C2.div(q(384)).lt(slopeSmall),"low drift");
 ck(generic(alpha,lambda,driftSmall,slopeSmall),"nonplateau margin");
}
for(const [H,Z,A,sd,M0,cap,eta,l,a,dL,d,b] of [
 [10,o,q(482,1000),q(239,10),11,C,q(133,1000),q(424,1000),q(166,1000),q(322,1000),q(244,1000),q(56,10000)],
 [16,q(4,5),q(48,100),q(252,10),12,CU,q(130,1000),q(450,1000),q(195,1000),q(317,1000),q(261,1000),q(55,10000)],
]){
 const h=q(H),minD=q(H===10?575:639),minN=minD.add(o),DmaxH=q(64*H-1);
 ck(sd.sq().lt(minD)&&q(11,25).add(o.div(sd)).lt(A)&&q(M0-1).lt(q(11,25).mul(sd)),"ceiling bounds");
 const loss=q(1,2).sub(q(1,3*M0)).div(A.sq());
 ck(o.div(eta).lt(lo(loss))&&cap.mul(eta).lt(l),"late high ratios");
 ck(C2.div(l).lt(lo(DmaxH.div(two.mul(Z.mul(h).sq()))))&&h.div(l).lt(lo(two.mul(DmaxH).div(h.sq()))),"late high exit");
 ck(curv(cap,o.div(A.sq()),a)&&witness(cap,eta),"late high curvature and witness");
 ck(grad(cap,A,sd).lt(d)&&cap.div(minN).lt(b)&&grad(C2,A,sd).lt(dL),"late high drifts");
 ck(signed(a,l,d,b,dL),"late high sign");
 ck(A.div(sd).lt(qa)&&q(10,3).mul(A.sq()).mul(A).mul(minN.div(minD)).div(sd).lt(qa),"late phase");
}
text("All edge inequalities passed.");
```

