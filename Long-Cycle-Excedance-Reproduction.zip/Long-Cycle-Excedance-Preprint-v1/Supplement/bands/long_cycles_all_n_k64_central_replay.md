# Central rational checks for the k≥64 bridge

All decisions use rational bounds. The central radius proposal is checked by exact squaring. Run with a text(value) output function or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=64,sk=q(8),xi=q(13,16),o44=q(11,25);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[6,588,65,2],[7,618,70,2],[8,655,70,3],[9,719,70,3],[10,755,70,4],[11,788,70,4],[12,820,70,4],[13,851,70,4],[14,881,70,5],[15,910,70,5]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(22,100).sq().div(two));
ck(pu.div(q(124)).mul(ex(q(5,16)).sq()).lt(q(22,100).sq()),"vertical log");
ck(q(76,100).lt(q(78,100).mul(ca)),"vertical positive");
ck(q(97,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(22,100).div(ca).mul(pu.div(q(40))))),"splice rotation");
for(const [B,a0,tilt0,L] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=31;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(1,2).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(83,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=q(1,2).div(fact(L)),abs=ex(xi.mul(p)).sub(o);
 const ps=em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 if(B<8){
  const P=min(two.mul(abs),o.add(delta).mul(abs).add(ps)), xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=two.mul(ex(xc).sub(o).sub(xc)).add(q(125,1000).mul(x));
  W=up(high.mul(f).add(x.mul(j)).add(x.mul(ell).div(two)).add(g));
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(40)).sq().div(two))).sub(P.mul(pu.div(q(40))));
 }else{
  const eps=up(abs.mul(delta).add(ps));
  const far=o.add(delta).mul(em(al)).mul(j).add(two.add(delta).mul(em(al.mul(q(B-1)))).mul(f)).add(em(al.mul(q(B-L))).mul(fl));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));drift=two.mul(eps);
  let ref=max(q(19,15).div(a.div(sk).add(two)),o.sub(abs));
  if(p.lt(o))ref=max(ref,dn(o.sub(p.sq().div(two)).div(ex(p))));
  c=ref.sub(eps);slice=q(97,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 if(B===6)ck(q(4*7*100,81).lt(a.sq()),"floor M9");
 if(B===7)ck(q(483,80).lt(a)&&q(4*8*144,121).lt(a.sq()),"floor M10 or 11");
 if(B===8)ck(q(4*9*144,121).lt(a.sq()),"floor M11");
 if(B>=9)ck(q(B+1).div(o44.sq()).lt(a.sq()),"ceiling splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
```
