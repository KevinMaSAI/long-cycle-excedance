
# Tilted endpoint control and three complete long-cycle bands

2026-11-27 01:45 UTC. For every k≥256, the original E_(n,k) has simple real roots and E_(n,k)/t strictly interlaces the next quotient for k≤n≤19k. For k≥512 the same holds through 32k, and for k≥704 through 40k. Each statement includes the last adjacent pair. This is uniform in k and n, not a finite search or the complete mother conjecture. It suffices to handle k≤1024 because the prior all-row theorem handles k≥1024. The finite threshold checks are saved as runnable JavaScript in long_cycles_tilted_anchor_band_replay.md.

## 1. Central control by an exact near-primary reference

Use the full normalized pole notation θ=atan(pi/s), v=sin θ, u=cos θ, p_i=s+(2i+1)pi i, ρ=|p_0|, q_i=ρ/p_i, g(z)=exp(sum_(a≥k)z^a/a)=sum d_a z^a. Let Δ_a=d_a−d_(a−1) and δ(z)=sum_(a≥k) Δ_a z^a=(1−z)(g(z)−1). The exact anchor prefix uses B_i(z)=prod_(j≠i)(1+δ(q_jz)/(1−q_j/q_i))−1. In h_n the mixed anchor term is q_i^n sum_(b≤n−k) d_(n−b) [z^b]B_i(z)/q_i^b. In h_(n+1)−u h_n the same expression uses q_i^n(q_i−u), n+1 in the coefficient d, and prefix b≤n+1−k. These identities follow by expanding δ-products and partial fractions of the distinct simple denominators. The total-shift term of degree n+1 contributes no old-row part because its homogeneous coefficient at degree −1 is zero in the partial-fraction sum. Thus one can include this boundary in the centered sum before regrouping; do not estimate a spurious mixed-prefix drift divided by v. Each single-anchor diagonal term uses d_n, d_(n+1) respectively and leaves the separately bounded true diagonal mismatch u(d_(n+1)−d_n) sum q_i^n. Absolute convergence at each fixed s follows as before from powers k−1≥2 and the finite prefixes.

At a primary, |q_i|=1 and the mixed plus main amplitude for row N is
    C_N=1+sum_(b≤N−k)[d_(N−b)/d_N] [z^b]B_i(z/q_i).
Its infinite reference is exactly
    P_*(w)=1+B_i(1/q_i)=prod_(j≠0) g(w/(w+2pi i j)), w=s+pi i.
This is a nonvanishing product because each g factor has no zero and the sum of logarithms converges absolutely. For each ξ=w/(w+2pi i j) with |ξ|≤1, ξ≠1, use
    log g(ξ)=ξ^k integral_0^1 t^(k−1)/(1−ξ t) dt.
The formula follows by radial integration of the derivative of −log(1−ξ)−sum_(a<k)ξ^a/a, so the logarithm is fixed from zero. Since |1−ξ t|≥|1−ξ|/2 via the triangle inequality and |1−ξt|≥1−t, this bounds |log g(ξ)|≤2|ξ|^k/[k|1−ξ|]. Using inverse distances, if R>ρ/(pi k), h bounds the unweighted farther half-lattice at power k−1, and
    p=R(1+3h/2), x=R(3/2+4h/3),
then |log P_*|≤p. The nearest partner contributes 1 in p; a far conjugate pair has inverse distance sum at most 3/2. For the common coefficient norms the same geometry gives ||B_i||_1≤exp(p)−1 at primary, exp(x)−1 farther, from ||δ||_1<2/k. In particular the old crude |C_N−1|≤2(exp(p)−1) remains valid, useful for the splice.

Put R_t=exp(2/(5k)). The tilted norm satisfies
    ||δ||_(R_t) ≤ [exp(.4)+exp(.8)/(2−exp(.4))]/k < 6/k.
Proof: beyond 2k the recurrence aΔ_a=−sum_(j=a−k+1)^(a−1)Δ_j has induced sum norm factor ≤exp(.4)/2 and never uses Δ_k. The sum from k+1 to 2k−1 is <1/(2k) before tilting, and the atom Δ_k=1/k is separate. The estimate holds first on finite sums, then by monotone convergence. Thus ||B_i||_(R_t) ≤exp(3p)−1 or exp(3x)−1 in the two cases.

For N≥B k with integer B≥14, split the primary prefix at b=N−6k. For the shorter shifts |d_(N−b)/d_N−1|≤2k T(6k)≤6/6!=1/120, using the factorial block-tail bound and a single telescoping tail, not two. For longer shifts this difference is ≤1, including missing terms (coefficient zero). Therefore for both consecutive primary amplitudes
    |C_N−P_*|≤eps=(exp(p)−1)/120+exp[−.4(B−6)](exp(3p)−1).
Their drift is at most 2eps, and Re C_N≥c=(1−p)(1−p²/2)−eps by exp(−p)≥1−p and cos p≥1−p²/2 (all p<1).

The sharper farther budget uses a tilted endpoint estimate rather than a fixed shift split. For b∈[k,n+1−k] and a=|q_i|, the function a^(n−b) R_t^(−b) is log-affine in b, hence its maximum is at an endpoint and at most a^(n−k) exp(−.4)+a^(k−1) exp[−.4(B−1)]. Thus for weighted far half-lattice bounds f,j,g at powers k−1,(B−1)k,B k, the total far centered error before mismatch is at most
    W=2(exp(3x)−1)[exp(−.4)j+exp(−.4(B−1))f]+g.
The d-ratio costs at most 2 and the centered multiplier |q_i−u|/v is at most the level weight 2l+1. The value error is at most V=W/3 because each far level has weight at least 3. The diagonal mismatch in centered units is at most 6R(1+g/3)/[B(B−1)!] by the factorial tail and (n+1)v>B/R. This estimate also holds at s=0 by continuity.

The exact replay checks the following tables (lattice bounds take six terms plus the decreasing integral at K, then monotonicity in k):
    K   B   a      R        f      h      j       g
    256 14  7.5    .14934   2.259  .645   .00035  .00018
    512 19  9.75   .13725   4.209  1.057  .00174  .00115
    704 22  11     .13205   5.523  1.293  .00322  .00233
For s≤a sqrt(k), k≥K and n≥B k, the checks give V²+(W+mismatch+2eps)²<c² and c(1−pi²/3200)−2(exp(p)−1)pi/40>V. The exact complex-primary ellipse argument gives the central witness signs, the next-row sign −sin(nθ) at every old zero, and exclusion within pi/40 of a cosine witness. This step replaces the poorest earlier far bound by a geometrically tilted endpoint weight; in these ranges W is below .05.

## 2. Adaptive occupancy edge when H=n/k grows

Handle group A with k≥256, n≥14k, H≤19; group B with k≥512, n≥19k, H≤40 but H≤k/16. All use k≤1024 for the neighbor profile. The earlier fixed-n profile for r0∈[.45 sqrt(n),.8 sqrt(n)] still gives left/right ratios 1.58 and 1.15: in group B β0≥1.8 as before; in group A β0>1.5, enough for L≥2 and U≥3, and if U=3 use r/U≥(14·1.5−1)/3>5.5. For U≥4, n≥10k still gives the earlier r/U>5.5. All remaining approximation and derivative estimates only used β0<8.1, r0≥23, and these integer and scale bounds, so unchanged.

Put D=n−1, M=floor(.6 sqrt(D)), and S=D/M. Use an adaptive plateau onset r_on=ceil H. At r≥r_on, binomial truncation with cap k gives A_n(r)>H/3.1. The high regime m≥.45 sqrt(n) is automatically above r_on, since .45²k>H+2+1/H in both groups. The high/medium constants from the fixed-n proof, (eta,alpha,lambda)=(.26,.132,.42) and (.116,.125,.36), therefore still hold, with medium now r_on≤m<.45 sqrt(n). A nonplateau left denominator r<r_on has pure loss at least D/(2r²)≥(k−1/B)/(2H), using r≤H and n≥B k. This absorbs the worst factor H even for lambda=.36. Far-right tails outside the profile lose >20 in the pure exponent, absorbing the enlarged H. All witness checks for high/medium are unchanged.

For low m<r_on both main indices are ≤H+1, so every pure ratio is at most exp(−(k−1/B)/[2(H+3+2/B)]). Use eta=.005 in group A and .003 in group B, with alpha=lambda=19 eta or 40 eta respectively. Opposing witnesses and the old-root margin hold with the following drift bounds; for r≥5 use binomial cap 4k in A (factor <6.1) or 8k in B (factor <10.1), again since n/r≤cap. Tiny r≤4 are handled by the same beta-binomial Markov argument and have D_r<.01. For low tails the drift is ≤d_s+gamma_s a, as r/n≤(1+1/B)/k+a/n. Main left and outward right in the other regimes use d+gamma a with the cap-k plateau; the whole left tail is bounded by d_L, using the generic drift for r<r_on. The checked constants are:
    group   d_s   gamma_s   d     gamma   d_L
    A       .408  .0018     .226  .001    1.27
    B       .480  .0011     .160  .001    1.90
The two asymmetric even-left/odd-right margins and the generic small-bracket margin pass strictly exactly as in the prior fixed-n edge proof. Thus all edge witnesses alternate and each old root has the required adjacent sign.

## 3. Splice and coverage

The old pure phase estimates |nθ(S)/pi−M|<1/40 and S≤(5/3)sqrt(n)+2.9 still apply (D≥3583). With the displayed a values, the three checked inequalities are
    (25/9)19 < (7.5−2.9/16)²;
    (25/9)32 < (9.75−2.9/22)²;
    (25/9)40 < (11−2.9/26)².
They put the splice in the appropriate central strip. For 32k use H≤k/16 because k≥512; for 40k it follows from k≥704. Use the already certified lower bands to cover n<14k, n<19k and n<22k respectively. Combining the edge witnesses with the cosine ones, the no-zero sliver near M pi, and reflection/exhaustion gives simple real roots and strict consecutive quotient interlacing exactly as before. No result is claimed here for the remaining n above each band or for the full mother conjecture.


## A common positive scalar profile on the real and complex sides (02:02 UTC)

The occupancy Poisson profile c(s)=exp(−sum_(b≥1) Pr(Pois(bs)<k)/b) in long_cycles_occupancy_poisson_profile.md and the infinite pole prefix reference P_*(w)=prod_(j≠0)g(w/(w+2pi i j)) are exactly related on positive real s:
    P_*(s)=exp(H_(k−1)) c(s)/s.
This was present in earlier large-k proof assets in different notation. Here is a direct derivation plus a sharper bound for vertical translation to the primary pole.

On Re w>0 the product logarithm is analytic, with positive real reference on the real axis and
    (log P_*)'(w)=(1/w) sum_(j≠0) (w/(w+2pi i j))^k.
For each factor the identity follows by differentiating log g(ξ), whose derivative is ξ^(k−1)/(1−ξ), then differentiating ξ=w/(w+2pi i j). On compact subsets the series converges normally. On real s>0 the gamma density f_k(x)=x^(k−1) exp(−x)/(k−1)! for x≥0 has Fourier transform (1+iω)^(-k), by its gamma integral. Its periodization with spacing s is continuous and has absolutely summable Fourier coefficients for k≥3, so evaluating its Fourier series at zero gives
    s sum_(b≥1) f_k(bs) = sum_(j in Z) (1+2pi i j/s)^(-k).
This is also derivable without a distributional Poisson formula by ordinary Fourier coefficients of the periodization. The b=0 term is zero. As c'/c=sum_(b≥1) f_k(bs), the logarithmic derivative of c(s)/s equals that of P_*(s).

To fix the constant, P_*(s)→1 as s↓0 by the power series of log g. With G Gamma(k,1), B=ceil(G/s) one has −log c(s)=E H_(B−1). The identity H_(B−1)−log B→γ and dominated convergence, plus 0≤log B−log(G/s)≤s/G and E(1/G)=1/(k−1), give c(s)/s→exp(−γ−E log G). The gamma recurrence gives E log G=Γ'(1)+H_(k−1). For completeness Γ'(1)=−γ follows by differentiating at x=1 the beta representation n^x integral_0^1 t^(x−1)(1−t)^n dt=n^x n!/[x(x+1)...(x+n)], and taking n→∞. After u=nt the integrands and derivatives are dominated near x=1 by integrable powers and logs times exp(−u), and the logarithmic derivative on the right is log n−H_(n+1)→−γ. This gives the stated constant. In particular P_*(s)≥k/(s+2k) by c(s)≥s/(s+2k) and exp(H_(k−1))≥k.

For w=s+iy and |y|≤pi, the nonzero shifted pole distances in pairs are bounded below by the positive lattice distances pi,2pi,3pi,... (one half is at least (2j−1)pi and the other at least 2j pi, j≥1). Hence
    sum_(j≠0) |w/(w+2pi i j)|^k
      ≤ exp(k y²/(2s²)) (s/pi) integral_0^∞ (1+t²)^(-k/2) dt
      ≤ exp(k y²/(2s²)) s/sqrt(2pi(k−2)).
For the first use the decreasing positive lattice sum bounded by its integral; for the last substitute t=tan θ and use log cos θ≤−θ²/2 on [0,pi/2). This omits the j=0 term rather than charging the maximal lattice term. Integrating the vertical logarithmic derivative and using |w|≥s yields
    |log P_*(s+pi i)−log P_*(s)| ≤ sqrt(pi/[2(k−2)]) exp(pi²k/(2s²)).
For k≥256 and s≥4 sqrt(k) the right side is <.11 (pi<22/7, pi²<10, exp(5/16)<1.37). In particular Re P_*(s+pi i)>.88 P_*(s), via exp(−.11)≥.89 and cos(.11)≥1−.11²/2. This replaces a lower bound that collapsed once the absolute anchor norm p exceeded 1. For a general vertical range |y|≤Y the same reasoning with the full shifted lattice uses one maximal term plus the integral, giving
    |log P_*(s+iy)−log P_*(s)| ≤ (|y|/s) exp(kY²/(2s²))[1+s/sqrt(2pi(k−2))].
It might help retain only a bounded number of coherent far poles. The remaining issue is quantitative finite-prefix control, including the shifted norm for the farther anchors, at larger s/k. No new global sign region is claimed from the reference comparison alone.
