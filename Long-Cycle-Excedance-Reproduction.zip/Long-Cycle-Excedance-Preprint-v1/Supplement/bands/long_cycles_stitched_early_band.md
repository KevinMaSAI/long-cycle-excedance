# A complete early band for k >= 256

For every integer k >= 256 and k <= n <= floor(25k/9), the row E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces E_(n+1,k)/t. The last pair includes the transition to the first row beyond this band. No row enumeration is needed. This proves a complete band, not the mother conjecture.

For n<2k−1 both rows use only one cycle and are t times successive ordinary Eulerian polynomials, which strictly interlace by their derivative recurrence. Otherwise set D=n−1>=510, M=ceil(sqrt(D)/3), S=D/M. Then S<=3sqrt(D)<5sqrt(k). The local sign theorem in TIERED_INNER_POLE.md (k>=256, s<=5sqrt(k)) is therefore applicable throughout [0,S]. It yields a value error <.473 relative to cos(phi) after normalization and sign of the next row at old roots = sign(−sin(phi)); here phi=n atan(pi/s).

## Outer witness and old-root signs
Use the exact series from OCCUPANCY_ALTERNATING_SERIES.md:
 E_(n,k)(−exp(−s))/(1+exp(−s))^n = sum_(r>=1)(−1)^r exp(−rs) r^D A_n(r).
The weighted upper bound and full cycle give 1<=A_n(r)<=H=n/k<=25/9. Let D_r=r(A_(n+1)(r)−A_n(r))/A_n(r). It is zero at r=1. For r>=2 use the marked deficient-cycle and beta lattice bounds from GROWING_RATIO_LOG_BAND.md, noting mu=H/r<2, to get 0<=D_r<=H(r/n+1/sqrt(k)). Both main indices are <=M, and at distance a>=0 from one of them, r/n<=.018+a/n. This follows from M<=sqrt(D)/3+1 and sqrt(D)>22. Hence D_r<.225+.006a.

At witness s=D/m, 1<=m<=M, and outward from either main index m,m+1 for D/(m+1)<=s<=D/m, successive outward pure ratios of exp(−rs)r^D are at most eta=1/20. By integrating log increments, the first exponent loss is at least D/[2M(M+1)], and discrete concavity improves it thereafter. This loss is >=1/[2(1/3+1/22)(1/3+2/22)], whose exponential exceeds 20. A witness tail in units of the main weight from both directions costs at most 2H eta/(1−eta)<1, so the sign is (−1)^m.

At an old zero in a two-index edge bracket subtract (m+3/5) times the old normalized row from the next normalized row. The terms gain multiplier r−m−3/5+D_r. Both main contributions have sign (−1)^(m+1) and individual margins at least .375. At distance a>=1 on the left, the multiplier stays negative and its modulus is at most a+.6; on the right it is positive and at most 1.006a+.625. Each tail is therefore bounded relative to its own main weight by H sum_(a>=1)(1.006a+.625) eta^a<.375. In units of the sum of both weights the combined tail is bounded by the same constant, not twice it. The next-row sign at the old zero is strict.

## Stitch and degree argument
At S, phi/pi=n atan(pi M/D)/pi differs from M by <1/40: its upper deviation is <=M/D, and the negative deviation is bounded by n pi² M³/(3D³). Use M< (1/3+1/22)sqrt(D), D>=510, pi²<10, and x−x³/3<=atan(x)<=x. The exact inequalities are in the companion script. For s<=S the phase increases as s decreases. Choose witnesses indexed m=1,...,floor(n/2) in decreasing s: for m<=M use the edge witnesses (last at S); for m>M use phi=m pi. These latter witnesses exist in [0,S), and M<floor(n/2). Their signs are (−1)^m. At a root between S and the next witness, the small slice phi in (M pi−pi/40,M pi] has no roots because |cos phi|>=1−pi²/(2*40²)>.473. Thus sin phi has sign (−1)^M in the rest of this joining bracket. For all later central brackets the sign of sin phi is (−1)^m. It follows for every bracket that the next-row sign at an old root is (−1)^(m+1).

Because there are no fixed points, inversion gives E_(n,k)(t)=t^n E_(n,k)(1/t). The degree is n−1 and the linear coefficient is one: exactly one excedance forces one cycle, in which the word following its minimum is decreasing. Divide by t, leaving degree n−2. For n=2h, the h witnesses, the last at −1, give h−1 distinct roots between −1 and 0; reciprocation gives the other h−1. For n=2h+1 the h witnesses again give h−1 such roots, and odd reciprocal grade forces −1 as well. This exhausts degree in both cases, with each root simple.

Consecutive old roots between −1 and 0 carry opposite signs of E_(n+1,k). When n is even, reciprocation in odd grade n+1 flips the signs across −1, filling the middle interval as well. When n=2h+1, the old root −1 has next-row sign (−1)^(h+1) by the central lemma, opposite the right-nearest sign (−1)^h and, by even reciprocity, also opposite the left-nearest sign. In all cases the next row therefore has a root between every pair of nonzero old roots. It has one between the largest old root and 0 because its sign at that root is positive (m=1), while near 0 it is negative by its linear term. Reflect to get the left extreme. After factoring t the degree of the next row is one higher, so these roots exhaust its degree and show strict interlacing.

Checked by rational replay, and by separately auditing the joining bracket, the −1 parity cases and the final pair. This covers the early band simultaneously in k and n, not just local signs. The interval beyond n=25k/9 is not claimed here unless a different theorem covers it.

## Exact replay
```javascript
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const C=q(25,9),eta=q(1,20),x=q(1).div(two.mul(q(1,3).add(q(1,22))).mul(q(1,3).add(q(2,22))));
let term=one, sum=one;for(let j=1;j<=12;j++){term=term.mul(x).div(q(j));sum=sum.add(term)}
assert(q(20).lt(sum));
assert(q(1,66).add(q(1,511)).lt(q(18,1000)));
assert(C.mul(q(18,1000).add(q(1,16))).lt(q(225,1000)));
assert(C.div(q(511)).lt(q(6,1000)));
assert(C.mul(two).mul(eta).div(one.sub(eta)).lt(one));
const cost=C.mul(q(1006,1000).mul(eta).div(one.sub(eta).pow(2)).add(q(625,1000).mul(eta).div(one.sub(eta))));
assert(cost.lt(q(375,1000)));
// Phase at S: upper deviation M/D and lower deviation <= n*pi^2*M^3/(3D^3).
const A=q(1,3).add(q(1,22));
assert(A.div(q(22)).lt(q(1,40)));
assert(q(511,510).mul(q(10,3)).mul(A.pow(3)).div(q(22)).lt(q(1,40)));
assert(q(473,1000).lt(one.sub(q(10,2*40**2))));
text("PASS: all edge and stitch constants for 256 <= k, n <= 25 k / 9");
```

# Improvement to the stitched early band: crossing the three-cycle onset

For all integers k >= 256 and k <= n <= floor(2500 k/729), E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces E_(n+1,k)/t. This strengthens floor(25k/9) and crosses n=3k. There is no per-row enumeration.

Use the full earlier stitch argument with M=ceil((10/27)sqrt(n−1)), S=(n−1)/M <= (27/10)sqrt(n−1) < 5sqrt(k). All witnesses, phase signs and root counts follow exactly as before once the following new edge constants are substituted. For the nontrivial rows n>=2k−1, split n<=3k and n>3k:
    case         n lower   sqrt(n−1)>   A_n(r) upper C   eta      D_r upper at distance a from main index
    n<=3k        511       22           3                .074     .244 + .006a
    n>3k         769       27           2500/729         .0633    .266 + .0045a
Indeed 1<=A_n(r)<=H=n/k<=C. For r=1, D_r=0. Otherwise mu=H/r<2, so D_r<=H(r/n+1/sqrt(k)). Bound main r/n by J/u+1/N where J=10/27, N is the row lower bound and u the square root lower bound. The pure exponential ratio estimate is exp(−1/[2(J+1/u)(J+2/u)])<eta. Witness tails cost at most 2C eta/(1−eta)<1.

For adjacent signs choose the subtraction center m+.63. The two main margins are .63−D0 and .37. At any distance a>=1 the outward multiplier has the same orientation as at its main index, with absolute value <=a+.63 on the left and <=(1+D1)a+.37+D0 on the right. Thus **only odd offsets oppose** the main sign. Apply sum_odd eta^a=eta/(1−eta²) and sum_odd a eta^a=eta(1+eta²)/(1−eta²)². The two costs are separately smaller than the respective main margins in both cases; even offsets reinforce. The same phase-deviation check at S is <1/40 in both cases; use A=J+1/u, upper M/(n−1)<=A/u and lower deviation <= (N/(N−1))(10/3) A³/u. Hence the prior joining-bracket and degree-exhaustion proof carries through, including the last row's pair even when n+1 is outside the range. These inequalities are replayed exactly in the companion code.

## Improved exact replay
```javascript
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const J=q(10,27),lam=q(63,100);
for(const [C,N,u,eta,D0,D1] of [[q(3),511,22,q(74,1000),q(244,1000),q(6,1000)],[q(2500,729),769,27,q(633,10000),q(266,1000),q(45,10000)]]){
 const A=J.add(q(1,u));
 const expo=one.div(two.mul(A).mul(A.add(q(1,u))));
 let t=one,z=one;for(let j=1;j<=14;j++){t=t.mul(expo).div(q(j));z=z.add(t)}
 assert(one.div(eta).lt(z));
 assert(C.mul(J.div(q(u)).add(q(1,N)).add(q(1,16))).lt(D0));
 assert(C.div(q(N)).lt(D1));
 assert(two.mul(C).mul(eta).div(one.sub(eta)).lt(one));
 const f=eta.div(one.sub(eta.pow(2))),g=eta.mul(one.add(eta.pow(2))).div(one.sub(eta.pow(2)).pow(2));
 assert(C.mul(g.add(lam.mul(f))).lt(lam.sub(D0)));
 assert(C.mul(one.add(D1).mul(g).add(one.sub(lam).add(D0).mul(f))).lt(one.sub(lam)));
 assert(A.div(q(u)).lt(q(1,40)));
 assert(q(N,N-1).mul(q(10,3)).mul(A.pow(3)).div(q(u)).lt(q(1,40)));
}
assert(q(473,1000).lt(one.sub(q(10,2*40**2))));
text("PASS: odd-tail edge and stitch constants through n=floor(2500 k/729)");
```

# Uniform early band through four times the minimum cycle length

For all integers k >= 256 and k <= n <= 4k, the long-cycle excedance polynomial E_(n,k) has n−1 simple real roots and the quotients of rows n and n+1 by t strictly interlace. The last pair is included. This is a full band, not the whole mother conjecture. No enumeration by n or k is used.

The preceding odd-tail proof covers n <= floor(2500k/729). In the remaining part it suffices to prove (17/5)k <= n <= 4k; these bands overlap. Use M=ceil(2 sqrt(n−1)/5), S=(n−1)/M <= (5/2)sqrt(n−1) < 5sqrt(k), and the tiered inner-pole sign theorem. The same witness stitch and degree argument apply after the following edge bounds.

## A load-dependent occupancy bound
Let H=n/k and set L=ceil(k/2). For any r>=8 the binomial per-label count has mean n/r<=L. The deterministic legal-cut argument in DETERMINISTIC_OCCUPANCY_EDGE.md says that after truncation of the nonnegative integer label weights to L the success probability times r is at least the new total divided by 2k+L−2, provided the new total is >=k. Success for the truncated weights implies success originally. If the new total is <k, the same bound is valid for original weights because the original one-cycle contribution gives A>=1. Thus A_n(r) >= r E[min(Bin(n,1/r),L)]/(2k+L−2). Concavity of the binomial capped expectation as a function of p, and the mean/variance bound at p=L/n, give E[min(Bin(n,1/r),L)] >= (n/r)(1−1/(2sqrt(L))). With k>=256 and L>=128>11², 2k+L−2<=5k/2 yields A_n(r)>H/2.62. The general upper bound A_n(r)<=H still applies for all r. Thus relative to a main r>=8, any tail amplitude ratio is <2.62. This combined with the smaller first difference is the gain that allows the 2.5 sqrt(n) stitch.

## Edge constants
Here n>=871, sqrt(n−1)>29 and 1<=A_n(r)<=H<=4. At r=1 the first difference D_r=0. At r>=2, mu=H/r<=2, hence D_r <= (H/A_n(r))(r/n+1/sqrt(k)). At a main index and at distance a from it on a tail we have r/n <= (2/5)/29+1/871+a/n. In particular the generic D_r<.31+.005a everywhere relevant. For main r>=8 and on its outward right side the stronger bound is .204+.0031a. For main r<=8 or on its outward right side the bound .29+.005a follows from r<=8+a. At witness m<=7 and pair with m<=7 use pure outward eta=.003 by D/[2*8*9] >= 870/144; amplitude ratios <=4. At witness or pair with m>=8 use eta=.087 by exponent >=1/[2(2/5+1/29)(2/5+2/29)]; amplitude ratio <2.62. The exact arithmetic replay checks the witness margins.

For old-root signs center the subtraction at m+.6. The left outward multipliers are negative throughout, using the generic D_r<.31+.005a even if r drops below 8, and have modulus at most a+.6. The right outward multipliers are positive and at most (1+m1)a+.4+d0 where (d0,m1)=(.204,.0031) for the stronger regime and (.29,.005) for the small-index regime. Only odd offsets oppose the sign. The corresponding left/right tail bounds are below the main margins .6−d0 and .4 in each regime. This follows from the same exact odd-geometric sums as in the previous proof. The phase deviation at S is <1/40 using J=2/5, u=29 and N=871. The prior central/edge stitch applies and all required pairwise signs, including at −1 when present, follow by the same degree and reciprocity argument.

Exact companion replay passed. Initial Windows synchronization attempts of earlier files met approval-review timeouts; the tiered and stitched proofs and their replay sources are preserved in the research checkpoints. Nothing has been published.

## Ratio-four exact replay
```javascript
const gcd=(a,b)=>b===0n?(a<0n?-a:a):gcd(b,a%b);
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const lam=q(3,5), J=q(2,5), N=871,u=29,A=J.add(q(1,u));
function eLower(x){let t=one,s=one;for(let i=1;i<=18;i++){t=t.mul(x).div(q(i));s=s.add(t)}return s}
assert(one.div(q(87,1000)).lt(eLower(one.div(two.mul(A).mul(A.add(q(1,u)))))));
assert(one.div(q(3,1000)).lt(eLower(q(N-1,2*8*9))));
assert(q(5,2).div(one.sub(q(1,22))).lt(q(262,100)));
assert(q(262,100).mul(J.div(q(u)).add(q(1,N)).add(q(1,16))).lt(q(204,1000)));
assert(q(262,100).div(q(N)).lt(q(31,10000)));
assert(q(4).mul(q(8,N).add(q(1,16))).lt(q(29,100)));
assert(q(4).div(q(N)).lt(q(5,1000)));
assert(q(4).mul(J.div(q(u)).add(q(1,N)).add(q(1,16))).lt(q(31,100)));
for (const [C,e,d,m] of [[q(262,100),q(87,1000),q(204,1000),q(31,10000)],[q(4),q(3,1000),q(29,100),q(5,1000)]]){
 const f=e.div(one.sub(e.pow(2))),g=e.mul(one.add(e.pow(2))).div(one.sub(e.pow(2)).pow(2));
 assert(two.mul(C).mul(e).div(one.sub(e)).lt(one));
 assert(C.mul(g.add(lam.mul(f))).lt(lam.sub(d)));
 assert(C.mul(one.add(m).mul(g).add(one.sub(lam).add(d).mul(f))).lt(one.sub(lam)));
}
assert(A.div(q(u)).lt(q(1,40)));
assert(q(N,N-1).mul(q(10,3)).mul(A.pow(3)).div(q(u)).lt(q(1,40)));
text("PASS: truncated occupancy and ratio-four stitch margins");
```

# Uniform early band through five times the minimum cycle length

For all integers k>=256 and k<=n<=5k the polynomial E_(n,k) has n−1 distinct real zeros and, after dividing by t, the consecutive rows n and n+1 strictly interlace. Includes the final pair. The earlier ratio-four proof gives n<=4k. Below prove the remainder 4k<n<=5k, without verifying any individual polynomial.

## Central signs for n>=4k and s<=5.6 sqrt(k)

Use the exact two prefix identities of INNERMOST_POLE_ALL_K.md and TIERED_INNER_POLE.md. Same normalization: value by 2d_n; centered by 2v d_(n+1), subtracting u h_n. Keep the same primary norm bound P=2(exp(R(1+2f/3))−1), where R>rho/(pi k) and f bounds the upper-half weighted far lattice at exponent k−1. For farther anchors x=R(3/2+2f/3) bounds the sum of factor norms, retaining the distances to both primaries. The improvement is to separate the leading degree k in delta from the rest.

The coefficient norm of the degree-k contribution in the linear expansion of B_i is at most x/2, since delta_k=1/k. The remainder of the linear part also has norm at most x/2, using ||delta||_1<2/k. All nonlinear terms have total norm at most exp(x)−1−x: expand in products of distinct factors, and bound degree in the number of factors m by x^m/m!. It follows that the norm after removing the degree-k term is at most exp(x)−1−x/2. In both prefix identities the leading degree k has anchor power n−k>=3k, whereas the remaining prefix can be bounded by power k−1. The factor dtilde/d_N<2 still applies separately. The far diagonal has exponent n>=4k. Thus the normalized weighted farther contribution is bounded by
    W=(2(exp(x)−1)−x)f + x j + g,
where j and g bound the weighted far powers 3k and 4k, and the value contribution is at most W/3. This keeps three different radial discounts instead of imposing k−1 on all of them. Multipliers for the centered sum satisfy |q_i−u|/v<=2l+1 as before. The centered diagonal mismatch is bounded by (5.6/(2pi sqrt(k)))(1+g/3), since |d_(n+1)−d_n|/d_(n+1)<1/(2k).

Set a=28/5, K=256, b=4(157/50)^2/(a²K+10). Each lattice decreases as k grows, before replacing the half integer exponent by its floor at K. Using the explicit two terms plus integral L(m) from TIERED_INNER_POLE.md, use L(127)<1.036=f, L(384)<.0707=j, L(512)<.0203=g, R=.1116 and mismatch bound .0562. The exact replay certifies the value error <.536 and centered error <.831, with .536²+.831²<1. This proves the same cosine witness and −sin(phi) sign at any zero, with phi=n atan(pi/s).

## Edge signs and stitching

For 4k<n<=5k use D=n−1>=1024, M=ceil(2sqrt(D)/5) and S=D/M<(28/5)sqrt(k). The truncated occupancy bound of the ratio-four proof applies with L=ceil(k/2) for every r>=10, since n/r<=k/2. Thus A_n(r)>H/2.62 there, H=n/k<=5. All r have 1<=A_n(r)<=H. At r=1 the difference D_r vanishes; if r=2 and mu=H/r>2, use the heavy-label estimate D_r<16r/n from DETERMINISTIC_OCCUPANCY_EDGE.md. In all other cases D_r<=(H/A_n(r))(r/n+1/sqrt(k)). Put N=1025. At main indices r/n<=(2/5)/32+1/N and at outward distance a add at most a/n. Thus for all tails the generic bound is <.38+.005a, also valid in the heavy-label case since 32/N<.362. For main r>=10 and their outward right tails use .2+.0026a. For main r<=10 and their outward right tails use .362+.005a, from r<=10+a.

At witness m<=9 or pair with m<=9 the pure ratio is <.01, from exponent >=1024/(2*10*11). Otherwise it is <.082, from exponent >=1/[2(2/5+1/32)(2/5+2/32)]. The amplitude ratios relative to their own main indices are bounded by 5 and 2.62 respectively. The standard witness tails are <1 in main units. At a zero center the subtraction at m+.6. The main margins are .6−d0 and .4, where d0=.362 or .2. Left outward multipliers are negative everywhere by the generic difference bound and have modulus <=a+.6. Right outward multipliers are positive and have modulus <=(1+d1)a+.4+d0, where d1=.005 or .0026. Costs of odd offsets using the geometric sums from the previous proof are separately below the two respective main margins. At S, |phi/pi−M|<1/40 by the earlier atan calculation with J=2/5, sqrt(D)>=32 and n/D<=1025/1024. The value error .536 excludes zeros in the short slice where phi has not crossed M pi. The previous stitched witness, parity, reciprocity and degree argument therefore proves the stated full range, including the next row's signs at all old nonzero roots and hence strict interlacing at n=5k.

Exact arithmetic replay passed using integer fractions. There is no new result in this note for n>5k. The scalar-reference route for the larger n/k range is separate.

## Ratio-five exact replay
```javascript
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const a=q(28,5),K=256, b=q(4).mul(pi.pow(2)).div(a.pow(2).mul(q(K)).add(q(10)));
const R=q(1116,10000), f=q(1036,1000),j=q(707,10000),g=q(203,10000),D=q(562,10000);
function lat(m){return three.div(one.add(two.mul(b)).pow(m)).add(q(5).add(one.add(q(6).mul(b)).div(b.mul(q(m-1)))).div(one.add(q(6).mul(b)).pow(m)))}
assert(q(2).lt(b.mul(q(26*127-12))));
assert(one.add(a.pow(2).mul(q(K)).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)));
assert(lat(127).lt(f)&&lat(384).lt(j)&&lat(512).lt(g));
assert(a.pow(2).mul(one.add(g.div(three)).pow(2)).div(q(4*K).mul(pi.pow(2))).lt(D.pow(2)));
const x=R.mul(q(3,2).add(two.mul(f).div(three)));
const P=two.mul(expUp(R.mul(one.add(two.mul(f).div(three)))).sub(one));
const W=two.mul(expUp(x).sub(one)).sub(x).mul(f).add(x.mul(j)).add(g);
const y=P.add(W.div(three)), z=P.add(W).add(D);
assert(y.lt(q(536,1000))&&z.lt(q(831,1000)));
assert(q(536,1000).pow(2).add(q(831,1000).pow(2)).lt(one));
const J=q(2,5), A=J.add(q(1,32)), H=q(5), L=q(262,100), l=q(3,5);
function eLower(x){let t=one,s=one;for(let i=1;i<=18;i++){t=t.mul(x).div(q(i));s=s.add(t)}return s}
assert(one.div(q(82,1000)).lt(eLower(one.div(two.mul(A).mul(A.add(q(1,32)))))));
assert(q(100).lt(eLower(q(1024,220))));
assert(L.mul(J.div(q(32)).add(q(1,1025)).add(q(1,16))).lt(q(1,5)));
assert(L.div(q(1025)).lt(q(26,10000)));
assert(H.mul(q(10,1025).add(q(1,16))).lt(q(362,1000)));
assert(H.div(q(1025)).lt(q(5,1000)));
assert(q(32,1025).lt(q(362,1000)));
assert(H.mul(J.div(q(32)).add(q(1,1025)).add(q(1,16))).lt(q(38,100)));
assert(q(5,2).div(one.sub(q(1,22))).lt(L));
for(const [C,e,d,m] of [[L,q(82,1000),q(1,5),q(26,10000)],[H,q(1,100),q(362,1000),q(5,1000)]]){
 const u=e.div(one.sub(e.pow(2))),v=e.mul(one.add(e.pow(2))).div(one.sub(e.pow(2)).pow(2));
 assert(two.mul(C).mul(e).div(one.sub(e)).lt(one));
 assert(C.mul(v.add(l.mul(u))).lt(l.sub(d)));
 assert(C.mul(one.add(m).mul(v).add(one.sub(l).add(d).mul(u))).lt(one.sub(l)));
}
assert(q(25,4).mul(H).lt(a.pow(2)));
assert(A.div(q(32)).lt(q(1,40)));
assert(q(1025,1024).mul(q(10,3)).mul(A.pow(3)).div(q(32)).lt(q(1,40)));
assert(q(536,1000).lt(one.sub(q(10,2*40**2))));
text("PASS: ratio-five central, outer and phase-stitch exact measurements");
```

# Uniform real-rootedness and strict interlacing through n=6k

For every integer k>=256 and k<=n<=6k, E_(n,k) has simple real roots, and dividing by t gives strict interlacing with row n+1. In particular the pair 6k,6k+1 interlaces. This builds on the existing early band n<=5k. No polynomial enumeration.

## Preserve the finite primary amplitude

For n>=5k and s<=a sqrt(k), a=49/8, use the existing exact coefficient prefix identities. For i=0,0's conjugate, after pulling out q_i^n define
    C_N=1+sum_c dtilde_(N-c) b_c/d_N  (N=n,n+1),
where b_c=[z^c] B_i(z/q_i). This rephasing preserves the coefficient norms since |q_i|=1. In old units 2d_n the primary is Re(q_0^n C_n); in centered units 2v d_(n+1) the primary is Im(q_0^n C_(n+1)), using q_0−u=−iv. The diagonal denominator mismatch is charged separately. As previously p=R(1+2f/3) bounds the sum of primary factor norms, where f is the weighted far lattice at power k−1 and R>rho/(pi k). Thus |C_N−1|<=P=2(exp(p)−1), and Re C_n>.47.

For the drift, in the common prefix each coefficient index j=n+1−c>k changes by |delta_j|<=1/(kj) and d_(n+1)>=1/(2k−1). Its total cost is <=P/k. Changing the denominator costs <=2P/(5k). The only newly admitted term at c=n+1−k has multiplier d_k/d_(n+1)<2. To control that coefficient, separate each factor into its degree-k atom and tail. Across all factors the sum of the suprema of tail coefficient magnitudes is <=p/[2(k+1)], because |delta_j|<=1/(kj) for j>k. For terms involving at least one tail, mark a contributing tail factor and bound the convolution by its coefficient supremum times the coefficient 1-norms of all other factors. This bounds any coefficient in the tail-containing product sum by p exp(p)/[2(k+1)], even if marking counts a term more than once. For products of atoms only, degree c=n+1−k>=4k requires at least four factors, and the bound is (p/2)^4 exp(p/2)/4!, by the elementary symmetric product norm estimate. Consequently drift |C_(n+1)−C_n|<.005.

For a far anchor use x=R(3/2+2f/3) for the sum of factor norms. Split the linear part into the degree-k atom (norm <=x/2), degrees k+1 to 2k−1 (norm <=x/4), and degrees >=2k (norm <=x/4). The middle delta mass is 1/k−1/(2k−1)<1/(2k). The last mass is no larger than the middle mass by the contraction recurrence for delta: every j>=k+1 occurs at most k−1 times in the sum over m>=2k, with coefficient <=1/(2k). Nonlinear products have norm <=exp(x)−1−x. The atom gets radial exponent n−k>=4k, the middle band at least 3k, and the rest at least k−1. The diagonal exponent is >=5k. Thus
    W=[2(exp(x)−1)−1.5x] f+x j+(.5x) l+g
bounds the centered far terms, and W/3 the far value terms. The lattice bounds l,j,g correspond to powers 3k,4k,5k respectively. In addition the centered diagonal mismatch is at most (2a/(5pi sqrt(k)))(1+g/3).

At K=256 use the decreasing-in-k lattices and the two terms plus integral estimate of TIERED_INNER_POLE.md, with b=4(157/50)^2/(a²K+10). The exact constants are R<.1220 (use .1220 as upper bound), f=1.382, l=.1307, j=.0458, g=.0161 as upper bounds, and discrepancy <.0491. The far value v0 is <.130, the far centered plus diagonal w0 <.437. Exact replay gives v0²+(w0+.005)²<.47². At an old zero put Z=q_0^n C_n. Then |Re Z|<=v0 and Re C_n=cos(phi)Re Z−sin(phi)Im Z>.47 imply sign Im Z=sign(−sin(phi)) and |Im Z|>=sqrt(.47²−v0²)>w0+.005. The next-row sign follows. At cosine witnesses the value sign holds since Re C_n>.47>v0. In the stitch slice |phi−M pi|<pi/40 the same sign persists: the lower signed real primary is at least .47(1−pi²/(2*40²))−P pi/40>v0. This replaces the simple absolute cosine-error test in the prior stitch.

## Edge and full degree count

For 5k<n<=6k use D=n−1>=1280, M=ceil(.4 sqrt(D)), S=D/M. Then S<6.125 sqrt(k) since 6*(2.5)²=37.5<(49/8)². The ratio-four load-dependent lower bound applies for r>=12 (mean n/r<=k/2), giving A_n(r)>H/2.62 for H=n/k<=6. For all r have 1<=A_n(r)<=H. For r=1 the difference D_r is zero, for r=2 with H/r>2 use D_r<16r/n, otherwise use the beta-lattice bound D_r<=(H/A_n(r))(r/n+1/sqrt(k)).
With sqrt(D)>35 and n>=1281 these imply the universal difference bound .45+.005a at outward distance a from a main index. For main r>=12 and outward right tails the sharper cap is .196+.0021a, and for main r<=12 or its outward right tails use .432+.005a. At witness or pair with m<=11 use eta=.017 from pure exponent D/[2*12*13] and amplitude ratio <=6. Otherwise eta=.080 from exponent >=1/[2(.4+1/35)(.4+2/35)] and amplitude ratio <=2.62. The same witness and odd-offset tail formulas with subtraction center m+.6 show that all witness signs and old-root next-row signs hold. Left outward orientation is ensured by the universal difference cap; right orientation by D_r>=0. Exact replay rechecks the individual left and right margins. The phase deviation at S is <1/40 in units pi. Using the central sign slice proved above, the join, parity, reciprocal reflection and degree count of the earlier early-band proof apply including the final pair.

The exact rational replay passed. The mother conjecture, in particular the general region of n>6k below the earlier uniform asymptotic tail, remains unproved here.

## Ratio-six exact replay
```javascript
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const a=q(49,8),K=256,b=q(4).mul(pi.pow(2)).div(a.pow(2).mul(q(K)).add(q(10)));
const R=q(1220,10000),f=q(1382,1000),l=q(1307,10000),j=q(458,10000),g=q(161,10000);
function lat(m){return three.div(one.add(two.mul(b)).pow(m)).add(q(5).add(one.add(q(6).mul(b)).div(b.mul(q(m-1)))).div(one.add(q(6).mul(b)).pow(m)))}
assert(q(2).lt(b.mul(q(26*127-12))));
assert(one.add(a.pow(2).mul(q(K)).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)));
assert(lat(127).lt(f)&&lat(384).lt(l)&&lat(512).lt(j)&&lat(640).lt(g));
const x=R.mul(q(3,2).add(two.mul(f).div(three))),p=R.mul(one.add(two.mul(f).div(three)));
const P=two.mul(expUp(p).sub(one)), c=q(47,100);
assert(c.lt(one.sub(P)));
const W=two.mul(expUp(x).sub(one)).sub(q(3,2).mul(x)).mul(f).add(x.mul(j)).add(x.mul(l).div(two)).add(g);
const V=q(130,1000),w=q(437,1000),D=q(491,10000);
assert(two.mul(a).mul(one.add(g.div(three))).div(q(5*16).mul(pi)).lt(D));
assert(W.div(three).lt(V)&&W.add(D).lt(w));
const d=q(5,1000),head=p.div(two);
const coeff=head.div(q(K+1)).mul(expUp(p)).add(head.pow(4).div(q(24)).mul(expUp(head)));
const drift=two.mul(coeff).add(P.div(q(K))).add(two.mul(P).div(q(5*K)));
assert(drift.lt(d));
assert(V.pow(2).add(w.add(d).pow(2)).lt(c.pow(2)));
const J=q(2,5),A=J.add(q(1,35)),H=q(6),L=q(262,100),lam=q(3,5),N=1281;
function eLower(x){let t=one,s=one;for(let i=1;i<=18;i++){t=t.mul(x).div(q(i));s=s.add(t)}return s}
assert(one.div(q(80,1000)).lt(eLower(one.div(two.mul(A).mul(A.add(q(1,35)))))));
assert(q(1000,17).lt(eLower(q(N-1,2*12*13))));
assert(L.mul(J.div(q(35)).add(q(1,N)).add(q(1,16))).lt(q(196,1000)));
assert(L.div(q(N)).lt(q(21,10000)));
assert(H.mul(q(12,N).add(q(1,16))).lt(q(432,1000)));
assert(H.div(q(N)).lt(q(5,1000)));
assert(q(32,N).lt(q(432,1000)));
assert(H.mul(J.div(q(35)).add(q(1,N)).add(q(1,16))).lt(q(45,100)));
assert(q(5,2).div(one.sub(q(1,22))).lt(L));
for(const [C,e,d,m] of [[L,q(80,1000),q(196,1000),q(21,10000)],[H,q(17,1000),q(432,1000),q(5,1000)]]){
 const u=e.div(one.sub(e.pow(2))),v=e.mul(one.add(e.pow(2))).div(one.sub(e.pow(2)).pow(2));
 assert(two.mul(C).mul(e).div(one.sub(e)).lt(one));
 assert(C.mul(v.add(lam.mul(u))).lt(lam.sub(d)));
 assert(C.mul(one.add(m).mul(v).add(one.sub(lam).add(d).mul(u))).lt(one.sub(lam)));
}
assert(q(25,4).mul(H).lt(a.pow(2)));
assert(A.div(q(35)).lt(q(1,40)));
assert(q(N,N-1).mul(q(10,3)).mul(A.pow(3)).div(q(35)).lt(q(1,40)));
assert(V.lt(c.mul(one.sub(q(10,3200))).sub(P.mul(q(22,280)))));
text("PASS: ratio-six coefficient drift, central sign, edge and stitch");
```

# Uniform early band through n = 7k
For every integer k>=256 and k<=n<=7k, E_(n,k) has n−1 distinct real zeros, with strict adjacent interlacing after removing the zero root. This includes the pair 7k and 7k+1. The ratio-six band already covers n<=6k. This section proves 6k<n<=7k without finite root enumeration.

## Central with the actual distances to the primary pair
Use the ratio-six finite primary amplitudes, with a=53/8 and s<=a sqrt(k). At upper far level l, the paired upper and lower poles have distances l,l+1 from a primary anchor. The inverse sum <=3/2. At an upper far anchor l, the primary distances contribute at most 3/2; other upper far distances are >=1 and all opposite-half far distances are >=3. Thus if f,h are weighted/unweighted far lattice upper bounds at power k−1 and R>rho/(pi k), use primary p=R(1+1.5h) and far x=R(1.5+4h/3). Lower anchors follow by conjugation. These sharpen the total factor-norm bounds without modifying their expansions.

For m>=2 the lattice comparison at K=256 is to (1+b l(l+1))^(-m), b=4(157/50)^2/(a^2 K+10), after monotonicity in k and rounding down half-exponents at K. Sum levels 1..6 explicitly, and use the decreasing weighted integral from 6, equal to 1/[b(m−1)(1+42b)^(m−1)]. Divide that integral by 13 for unweighted tail. The derivative condition (26m−12)b>2 implies decrease from x=2, hence on the tail. With (m=127,512,640,768) get f=1.630, h=.489, and bounds l=.084, j=.0343, g=.014 on the weighted far lattices at powers 4k,5k,6k. Also R=.132 suffices.

Keep the leading degree k, linear degrees k+1..2k−1, and all remaining terms separate as in the ratio-six proof. Their minimum anchor powers are 5k,4k,k−1. The centered far bound is W=[2(exp(x)−1)−1.5x]f+x j+x l/2+g, and the old value far bound is W/3. The additional centered diagonal mismatch is <=(2a/(6pi sqrt(k)))(1+g/3)<.0442, since |d_(n+1)−d_n|/d_(n+1)<=2/(6k). Thus total far v<.138 and w<.457. Primary magnitude error <=P=2(exp(p)−1), so Re C_n>.485. The same ratio-six drift proof applies: the newly admitted coefficient requires degree >=4k for the pure atom product, and use p exp(p)/[2(k+1)] on tail-marked coefficients. The two common-prefix and denominator costs are P/k and 2P/(6k). Altogether drift <.004. Exact replay gives .138^2+(.457+.004)^2<.485^2. By the complex-primary lemma, each cosine witness has its prescribed sign and at any old zero the next row has sign −sin(phi). The short stitch slice |phi−M pi|<=pi/40 has no zeros because .485(1−pi²/(2*40²))−P pi/40>.138.

## Edge and stitch
For 6k<n<=7k use D=n−1>=1536, M=ceil(.4 sqrt(D)), S=D/M<=2.5 sqrt(D)<(53/8)sqrt(k). Put H=n/k<=7. For r>=10 use the deterministic occupancy truncation with cap L=ceil(7k/10), since n/r<=.7k and L>13². Then 2k+L−2<=2.7k and A_n(r)>=H(1−1/26)/2.7>H/2.81. The argument is the same as the ratio-four load bound, including truncated totals less than k. All amplitudes still satisfy 1<=A_n(r)<=H. For r=1 the difference is zero. Cases with r>=2 and H/r>2 have r=2 or 3, so use the heavy-label bound D_r<16r/n<=48/n. Otherwise the standard beta-lattice bound applies. With n>=1537 and sqrt(D)>39, the generic difference is <.52+.005a for an outward distance a. For main r>=10 and right tails it is <.207+.0019a. For main r<=10 and their right tails it is <.484+.005a.

For m<=9 use pure ratio eta=.001 from exponent >=1536/(2*10*11), and amplitude ratio <=7. Otherwise use eta=.075 from exponent >=1/[2(.4+1/39)(.4+2/39)], and amplitude ratio <=2.81. Witness tails cost less than 1. Center old-root subtraction at m+.6; left outward terms remain negative by the generic bound and right outward terms positive. Only odd offsets oppose, and the two separate bounds are below .6−d0 and .4 in both regimes. The phase deviation at S is less than pi/40 by the earlier atan comparison with sqrt(D)>39. The central slice exclusion, witnesses, parity, reciprocal reflection and degree count then apply, including the last adjacent pair. All numerical margins were checked with exact rational arithmetic, rounding individual lattice contributions upward to a rational grid to keep denominators small.

This is an extension of the proven band, not a solution of the mother conjecture. No claim for n>7k beyond previously proven ranges.

## Ratio-seven exact replay
```javascript
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}
const a=q(53,8),K=256,b=q(4).mul(pi.pow(2)).div(a.pow(2).mul(q(K)).add(q(10)));
const R=q(132,1000),f=q(1630,1000),h=q(489,1000),l=q(84,1000),j=q(343,10000),g=q(14,1000);
function up(num,den){const QN=1000000000n;return q((num*QN+den-1n)/den,QN)}
function lat(m,w=true){let s=q(0);const mm=BigInt(m),bp=b.b**mm;
for(let j=1;j<=6;j++)s=s.add(up(BigInt(w?2*j+1:1)*bp,(b.b+b.a*BigInt(j*(j+1)))**mm));
return s.add(up(bp,b.a*(mm-1n)*(b.b+42n*b.a)**(mm-1n)*(w?1n:13n)));}
assert(q(2).lt(b.mul(q(26*127-12))));
assert(one.add(a.pow(2).mul(q(K)).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)));
assert(lat(127).lt(f)&&lat(127,false).lt(h)&&lat(512).lt(l)&&lat(640).lt(j)&&lat(768).lt(g));
const x=R.mul(q(3,2).add(q(4,3).mul(h))),p=R.mul(one.add(q(3,2).mul(h)));
const P=two.mul(expUp(p).sub(one)),c=q(485,1000);assert(c.lt(one.sub(P)));
const W=two.mul(expUp(x).sub(one)).sub(q(3,2).mul(x)).mul(f).add(x.mul(j)).add(x.mul(l).div(two)).add(g);
const V=q(138,1000),w=q(457,1000),D=q(442,10000);
assert(two.mul(a).mul(one.add(g.div(three))).div(q(6*16).mul(pi)).lt(D));
assert(W.div(three).lt(V)&&W.add(D).lt(w));
const d=q(4,1000),head=p.div(two);
const coeff=head.div(q(K+1)).mul(expUp(p)).add(head.pow(4).div(q(24)).mul(expUp(head)));
assert(two.mul(coeff).add(P.div(q(K))).add(two.mul(P).div(q(6*K))).lt(d));
assert(V.pow(2).add(w.add(d).pow(2)).lt(c.pow(2)));
const J=q(2,5),A=J.add(q(1,39)),H=q(7),L=q(281,100),lam=q(3,5),N=1537;
function eLower(x){let t=one,s=one;for(let i=1;i<=18;i++){t=t.mul(x).div(q(i));s=s.add(t)}return s}
assert(one.div(q(75,1000)).lt(eLower(one.div(two.mul(A).mul(A.add(q(1,39)))))));
assert(q(1000).lt(eLower(q(N-1,2*10*11))));
assert(L.mul(J.div(q(39)).add(q(1,N)).add(q(1,16))).lt(q(207,1000)));
assert(L.div(q(N)).lt(q(19,10000)));
assert(H.mul(q(10,N).add(q(1,16))).lt(q(484,1000)));
assert(H.div(q(N)).lt(q(5,1000)));
assert(q(48,N).lt(q(484,1000)));
assert(H.mul(J.div(q(39)).add(q(1,N)).add(q(1,16))).lt(q(52,100)));
assert(q(27,10).div(one.sub(q(1,26))).lt(L));
for(const [C,e,d,m] of [[L,q(75,1000),q(207,1000),q(19,10000)],[H,q(1,1000),q(484,1000),q(5,1000)]]){
 const u=e.div(one.sub(e.pow(2))),v=e.mul(one.add(e.pow(2))).div(one.sub(e.pow(2)).pow(2));
 assert(two.mul(C).mul(e).div(one.sub(e)).lt(one));
 assert(C.mul(v.add(lam.mul(u))).lt(lam.sub(d)));
 assert(C.mul(one.add(m).mul(v).add(one.sub(lam).add(d).mul(u))).lt(one.sub(lam)));
}
assert(q(25,4).mul(H).lt(a.pow(2)));
assert(A.div(q(39)).lt(q(1,40)));
assert(q(N,N-1).mul(q(10,3)).mul(A.pow(3)).div(q(39)).lt(q(1,40)));
assert(V.lt(c.mul(one.sub(q(10,3200))).sub(P.mul(q(22,280)))));
text("PASS: ratio-seven central geometry, amplitude drift, edge and stitch");
```
