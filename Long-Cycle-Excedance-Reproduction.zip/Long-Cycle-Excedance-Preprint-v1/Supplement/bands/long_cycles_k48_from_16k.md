# Uniform upper band for k≥48, starting at n=16k

2026-11-27 05:00 UTC. For every k≥48 and n≥16k original E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient, with no upper n limit. It suffices to add 48≤k≤63 and 16k≤n≤180k, by the new uniform eventual theorem and all-row coverage above k=64. No implication for smaller rows is asserted here.

Use D≥767 and the single-critical-size profile of long_cycles_k64_from_16k.md, with r0∈[.43,.62]sqrt(n), β0=kr0/n≤.62sqrt(63/16)<1.5, r0≥12, r≥11. Retain m≤7 critical singleton cycles. Hard-count relative errors are .00016 for m≤3 (complement≥8), .002 for m=4,5 (≥6), and .08 for m=6,7 (≥4). Adding 3 sum_(m≥8)1/m! gives weighted cost <.0008. At first long cycle b=2 the mean ratio ≥2/[.62sqrt(63/16)(13/12)]>1.49, so the geometric-binomial prefactor is <.20 using peak .45/sqrt(k), exponent loss ≥47(.49²/2−.49³/3), and successive exponent loss >11 per b. Multiplying by the relative marked union factor 3/2 gives total model error <.009. Peak .45/sqrt(k) follows from Robbins and variance ≥(15/16)(k−1). The marked multinomial derivative in c units is ≤exp(1)·.45/[sqrt(k)(.43·11/12)²]<1.15. This gives common neighboring amplitude ratios 2.19 left and 1.11 right.

With M=floor(.55sqrt(D))≥15 use the familiar three adaptive bands. High m≥.43sqrt(n) has (eta,lambda,alpha)=(.207,.46,.10); the first right pure loss is ≥(.55)^(-2)(1/2−1/45). Outside local profile the left loss is ≥D/(2r²) at r<.43sqrt(n), and the right loss ≥(D/sqrt(n))(20/11−50/31) at r>.62sqrt(n), absorbing C and C·18/17, C=27/8. The curvature product uses 2.19·1.11 exp(−1/.55²). High witnesses use both local ratios for first opposing offsets, then C(1+a/12). Medium 10≤m<.43sqrt(n) uses (.120,.445,.155), from m+1<.467sqrt(n) and m+2<.503sqrt(n), and curvature for r≥10 uses C²·11/10 while r≤9 uses C²·1.5 exp(−767/81). Low m≤9 uses (.031,.157,.157). All geometric opposition bounds pass. At r≥.75H the cap ceil(4k/3) gives H/A<3.57, so beta lattice gives d_r≤3.57(r/n+.45/sqrt(k)). Otherwise the earlier weighted binomial progression at x=D/r≥1.331k gives d_r<.10, using gap exponent >16. The uniform signed budgets .305+.0047a on the right and .305 on the left give both derivative and next-row signs. The floor and cubic phase bounds give S≤(20/11)sqrt(n)+3.6 and phase deviation <π/40. No endpoint approximations of polynomial roots are used.

The two-cycle peak .575/k (minimum at x=1/.575 in the inequality used earlier) holds for k≥48; with old endpoints it gives T(2k)<.131/k and ξ=.816, J with .087, δ=.524/L!. Use positive scalar reference plus direct lower bound exp(−p)(1−p²/2) when appropriate; vertical log difference <.26 for k≥48,s≥4sqrt(k), giving Re P_*(s+iπ)>.71P_*(s), so use (71/60)/(a/6.9+2) and angular margin .97. For s≤4sqrt(k) the familiar absolute center uses R=.186 and the k−1 and 2k−2 half-lattices; improve ξ in both P,Z absolute norm exponents and bound the relative diagonal mismatch by (1+j)R/16 (n≥16k). The exact V²+W²<1 passes. Five analytic intervals validated by harmonic tilt join n=16k through 188k. This overlaps the new n≥180k theorem strictly. Last adjacent pairs are included. No claim for n<16k.

## BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(92)).mul(ex(q(5,16)).sq()).lt(q(26,100).sq()),"vertical log bound");
ck(q(71,100).lt(q(74,100).mul(o.sub(q(26,100).sq().div(two)))),"vertical real fraction");
ck(q(97,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(26,100).div(o.sub(q(26,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[48,16,102,550,5,28],[48,28,137,375,7,52],[48,52,179,250,7,91],[48,91,222,150,10,142],[48,142,255,100,10,188]];
const covered={48:16};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(69,10);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(87,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(816,1000).mul(p)).sub(o).mul(q(524,1000)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(524,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(524,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(71,60).div(a.div(sk).add(two)); const ref2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(97,100).mul(ref).sub(eps)),"splice phase");
 const dense=B>=300; const rad=a.sub((dense?q(8,5):q(18,5)).div(sk));
 ck(q(0).lt(rad)&&(dense?q(25*N,16):q(400*N,121)).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1],C=q(27,8), sk=q(69,10),A=q(43,100),mt=q(45,100),sp=q(276,10),n0=q(768),D=q(767),v=D.div(n0),u=q(55,100);
ck(covered[48]>180,"eventual overlap");
ck(q(1000,575).lt(lo(q(575,1000).sub(q(1,48))))&&q(87,1000).mul(q(3,2)).lt(q(131,1000)),"cycle tail");
ck(q(48).mul(eu(q(1,6*767))).lt(mt.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(47))),"Stirling peak");
function g(x,y){return x.div(o.sub(y))}
function low(x){return q(47).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))));}
const eps=q(9,1000),rf=A.mul(q(11,12)),hh=q(115,100),L=q(219,100),R=q(111,100);
ck(q(62,100).sq().mul(q(63,16)).lt(q(3,2).sq())&&q(62,100).sq().mul(q(63,16)).mul(q(13,12).sq()).lt(q(2).div(q(149,100)).sq()),"single critical");
ck(mt.div(sk.mul(o.sub(o.div(q(149,100))))).lt(q(20,100))&&q(11).lt(q(47).mul(q(149,200).sub(q(1,2)))),"long tail");
ck(q(8,10000).add(q(3,10).mul(g(em(low(q(49,100))),em(q(11))))).lt(eps),"profile error");
ck(eu(o).mul(mt).div(sk.mul(rf.sq())).lt(hh)&&o.add(hh.add(two.mul(eps)).div(o.sub(eps))).lt(L)&&q(13,12).mul(o.add(eps)).div(o.sub(eps)).lt(R),"neighbor profile");
const eH=q(207,1000),lH=q(46,100),aH=q(10,100),eM=q(120,1000),lM=q(445,1000),aM=q(155,1000),eL=q(31,1000),lL=q(157,1000);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,45))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(467,1000)).mul(q(503,1000))))),"medium pure");
ck(o.div(eL).lt(lo(D.div(q(220)))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&C.mul(q(18,17)).div(lH).lt(lo(v.mul(sp).mul(o.div(u).sub(q(50,31))))),"outside");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM)&&C.mul(q(3,2)).mul(eL).lt(lL),"actual");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(o.div(u.sq()))),"high curvature");
ck(C.sq().mul(q(11,10)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(467,1000).sq())))&&C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(D.div(q(81)))),"medium curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,12,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witnesses");
const d=q(305,1000),b=q(47,10000),C3=q(357,100);
ck(q(10,3).div(o.sub(o.div(q(16)))).lt(C3)&&C3.mul(u.div(sp).add(mt.div(sk))).lt(d)&&C3.div(n0).lt(b),"upper drift");
ck(q(1331,1000).lt(q(4,3).mul(v))&&q(16).lt(q(331,1000).mul(q(48)).add(o)),"lower drift spacing");
ck(C.div(v).mul(q(1331,1000)).mul(mt).div(sk).mul(g(em(low(q(331,1000))),em(q(16)))).lt(q(1,10)),"lower drift");
for(const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){const z=o.sub(l.sq());ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");}
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sp)))).lt(q(18,5))&&u.div(sp).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sp)).lt(q(1,40)),"splice");

const rr=q(186,1000),bs=q(4).mul(pl.sq()).div(q(16*48+10));
ck(o.add(q(16*48).div(pl.sq())).div(q(48*48)).lt(rr.sq())&&two.lt(bs.mul(q(23*25**2-312))),"small s radius");
function latSmall(m,w){
 let z=q(0);
 for(let j=1;j<=12;j++){const y=bs.mul(q(j*(j+1))); z=z.add(q(w?2*j+1:1).mul(em(q(2*m).mul(y).div(two.add(y)))));}
 const y=bs.mul(q(156));
 return z.add(em(q(2*(m-1)).mul(y).div(two.add(y))).div(bs.mul(q((m-1)*(w?1:27)))));
}
const f=latSmall(23,true),h0=latSmall(23,false),g0=latSmall(47,true),j0=latSmall(47,false);
const P=two.mul(eu(q(816,1000).mul(rr).mul(o.add(q(3,2).mul(h0)))).sub(o));
const Z=two.mul(eu(q(816,1000).mul(rr).mul(q(3,2).add(q(4,3).mul(h0)))).sub(o));
const V=P.add(Z.mul(h0)).add(j0),W=P.add(Z.mul(f)).add(g0).add(o.add(j0).mul(rr).div(q(16)));
ck(V.sq().add(W.sq()).lt(o),"small s sign");
```
