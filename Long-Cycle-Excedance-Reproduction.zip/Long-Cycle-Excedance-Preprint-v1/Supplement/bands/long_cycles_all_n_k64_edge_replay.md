# Edge rational checks for the k≥64 bridge

All decisions use rational bounds. The central radius proposal is checked by exact squaring. Run with a text(value) output function or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const lo=x=>eb(x)[0], pi=q(157,50),C=q(318,100),C2=q(419,100),CU=q(345,100),pk=q(45,100),sk=q(8);
const D=q(383), sd=q(195,10), qa=q(1,40);
ck(q(3).sub(q(2,79)).div(o.sub(q(1,16))).lt(C),"cap k");
ck(q(4).div(o.sub(q(5,113))).lt(C2),"cap 2k");
ck(q(13,4).div(o.sub(q(5,89))).lt(CU),"cap 5k/4");
ck(sd.sq().lt(D)&&q(89,10).sq().lt(q(80))&&q(113,10).sq().lt(q(128)),"square roots");
ck(q(64).mul(ex(q(1,6*383))).lt(pk.sq().mul(two).mul(pi).mul(q(5,6)).mul(q(63))),"binomial peak");
ck(q(7000).lt(lo(q(297,1000).mul(q(64)))),"tiny drift");
const a55=q(552,1000);
ck(q(1,2).add(o.div(sd)).lt(a55)&&a55.sq().mul(q(79,6)).lt(q(11,5).sq()),"near saddle beta");
function minus(u){return u.sq().div(two).add(u.sq().mul(u).div(q(3)))}
function plus(u){return u.sq().div(two).sub(u.sq().mul(u).div(q(3)))}
const j=q(63),geom=(x,step)=>em(j.mul(x)).div(o.sub(em(j.mul(step))));
ck(o.add(geom(plus(q(7,13)),q(10,13).sub(q(1,2)))).lt(q(105,100)),"lattice b<=1.3");
ck(em(j.mul(minus(q(3,13)))).add(em(j.mul(plus(q(3,17))))).add(geom(plus(q(13,17)),q(10,17).sub(q(1,3)))).lt(q(105,100)),"lattice b<=1.7");
ck(o.add(em(j.mul(minus(q(7,17))))).add(geom(plus(q(4,11)),q(5,11).sub(q(1,3)))).lt(q(105,100)),"lattice b<=2.2");
function witness(C,e){return two.mul(C).mul(e).div(o.sub(e.sq())).lt(o)}
function curv(C,e,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(e))}
function generic(a,l,d,b){const u=o.sub(l);return two.mul(a).add(d).add(a.mul(d.div(u).add(b.div(u.sq())))).lt(o.sub(a))}
function signed(a,l,d,b,dL){const u=o.sub(l.sq());return two.mul(a).add(d).add(a.mul(l).mul(dL).div(u)).add(a.mul(d.div(u).add(b.mul(o.add(l.sq())).div(u.sq())))).lt(o.sub(a))}
const grad=(C,A,sd)=>C.mul(A.div(sd).add(pk.div(sk)));
const driftSmall=q(32,100), slopeSmall=q(11,1000),el=q(156,1000),ll=q(497,1000),al=q(248,1000),l2=q(6,100),tight=q(189,1000),left=q(344,1000),dR=q(262,1000),bR=q(83,10000);
const lowerLog=q(2).sub(q(4,27)).add(q(1,81)).sub(q(4,3645));
ck(o.div(el).lt(lo(lowerLog))&&C.mul(el).lt(ll),"early high first ratios");
ck(q(9).div(ll).lt(lo(q(575,162)))&&q(9).div(l2).lt(lo(q(4).mul(q(9,10).add(q(81,220))))),"early nonplateau and second ratios");
ck(curv(C,q(4),al),"early high curvature");
const t3=q(15,10000000),wHi=two.mul(C).mul(el).add(two.mul(C).mul(t3).div(o.sub(el.sq())));
ck(o.div(t3).lt(lo(q(27,2)))&&wHi.lt(o),"early high witnesses");
ck(C.mul(pk).mul(q(105,100)).div(sk).lt(tight),"sharp near-neighbor drift");
ck(grad(C2,q(1,2),sd).lt(left)&&grad(C,q(1,2),sd).lt(dR)&&C.div(q(384)).lt(bR),"early drift tails");
let u=o.sub(l2.sq());
const Lcost=al.mul(l2).mul(left).div(u);
const farRight=dR.add(q(3).mul(bR)).div(u).add(two.mul(bR).mul(l2.sq()).div(u.sq()));
const Rcost=al.mul(tight).add(al.mul(l2.sq()).mul(farRight));
ck(two.mul(al).add(tight).add(Lcost).add(Rcost).lt(o.sub(al)),"early high signed margin");
ck(q(9,383).lt(qa)&&!qa.lt(q(1,2).div(q(20))),"early phase upper");
ck(q(10,3).mul(q(1,8)).mul(q(384,383)).div(sd).lt(qa),"early phase lower");
for(const [H,Z,lambda,alpha,eta] of [[9,o,q(311,1000),q(60,1000),q(74,1000)],[10,o,q(374,1000),q(101,1000),q(89,1000)],[16,q(4,5),q(345,1000),q(93,1000),q(82,1000)]]){
 const h=q(H),d=h.mul(q(64)).sub(o),r=Z.mul(h).add(o),rL=h.div(two).add(o);
 ck(o.div(eta).lt(lo(d.div(two.mul(r).mul(r.add(o)))))&&C2.mul(eta).lt(lambda),"medium outward");
 ck(h.div(lambda).lt(lo(two.mul(d).div(h.sq()))),"below cap");
 ck(curv(C2,d.div(r.sq()),alpha)&&witness(C2,eta),"medium curvature and witness");
 const e0=q(35,10000);
 ck(o.div(e0).lt(lo(d.div(two.mul(rL).mul(rL.add(o)))))&&h.mul(e0).lt(lambda)&&curv(h,d.div(rL.sq()),alpha)&&witness(h,e0),"small index");
 ck(C2.mul(q(7,6*64).add(pk.div(sk))).lt(driftSmall)&&C2.div(q(384)).lt(slopeSmall),"low drift");
 ck(generic(alpha,lambda,driftSmall,slopeSmall),"nonplateau margin");
}
for(const [H,Z,A,sd,M0,cap,eta,l,a,dL,d,b] of [
 [10,o,q(482,1000),q(239,10),11,C,q(133,1000),q(424,1000),q(166,1000),q(322,1000),q(244,1000),q(56,10000)],
 [16,q(4,5),q(48,100),q(252,10),12,CU,q(130,1000),q(450,1000),q(195,1000),q(317,1000),q(261,1000),q(55,10000)],
]){
 const h=q(H),minD=q(H===10?575:639),minN=minD.add(o),DmaxH=q(64*H-1);
 ck(sd.sq().lt(minD)&&q(11,25).add(o.div(sd)).lt(A)&&q(M0-1).lt(q(11,25).mul(sd)),"ceiling bounds");
 const loss=q(1,2).sub(q(1,3*M0)).div(A.sq());
 ck(o.div(eta).lt(lo(loss))&&cap.mul(eta).lt(l),"late high ratios");
 ck(C2.div(l).lt(lo(DmaxH.div(two.mul(Z.mul(h).sq()))))&&h.div(l).lt(lo(two.mul(DmaxH).div(h.sq()))),"late high exit");
 ck(curv(cap,o.div(A.sq()),a)&&witness(cap,eta),"late high curvature and witness");
 ck(grad(cap,A,sd).lt(d)&&cap.div(minN).lt(b)&&grad(C2,A,sd).lt(dL),"late high drifts");
 ck(signed(a,l,d,b,dL),"late high sign");
 ck(A.div(sd).lt(qa)&&q(10,3).mul(A.sq()).mul(A).mul(minN.div(minD)).div(sd).lt(qa),"late phase");
}
text("All edge inequalities passed.");
```
