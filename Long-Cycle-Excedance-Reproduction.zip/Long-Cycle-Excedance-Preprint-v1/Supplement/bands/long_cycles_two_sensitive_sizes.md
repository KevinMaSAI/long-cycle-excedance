# Two sensitive cycle sizes reach n≥14k for k≥128

2026-11-27 03:15 UTC. For every k≥128 and n≥14k, E_(n,k) has n−1 simple real roots and the quotient by t strictly interlaces the next quotient. No upper bound on n; k≥256 still has all n≥k. This is an analytic coverage theorem, not a finite search.

## The model switch
Handle 128≤k≤255 and n≥14k. For r0∈[.45,.62] sqrt(n) put β0=kr0/n and examine the integer triple r0−1,r0,r0+1. In each case F(r) is the finite critical-cycle profile using exact joint multinomial success, with a hard-cycle constant c=e^(−H_(U−1)). It decreases, F≥c, and a profile error εc and derivative bound hc give ratios ≤1+(h+2ε)/(1−ε) to the left and ≤(1+1/r0)(1+ε)/(1−ε) to the right.

1. β0≤1.5: U=2, sole critical size 1, retain at most seven cycles. r0≥20, r−m≥12, so the hard-count relative error is <.00016 by the checked j≥4U bound. Omitting m≥8 costs at most 3 sum_(m≥8)1/m!, and a useful tighter bound comes from the early m: r−m≥16 for m≤3, hence 6/8! there, and for m≥4 use .00016; upper bound `(6/8!)sum_(m≤3)1/m!+.00016 sum_(4≤m≤7)1/m!+3 sum_(m≥8)1/m!<.0005`. Use this safe .0005 in the final error (still ε=.038). For long b≥2, μ/k≥80/63>1.269 at the first b, and the Chernoff exponent decreases at least 17 per unit b. Bound its relative contribution by (3/2) exp[−128(.269²/2−.269³/3)]/(1−exp(−17)). The derivative is ≤exp(1)·.45/(sqrt(k)·[(19/20).45]²)<.60.
2. 1.5<β0≤2.15: U=3, forbid size 1, critical size 2, retain at most five. r0≥22, r−2m≥11≥3U. Use the .002 hard-count relative bound times exp(.5), plus omitted cost 5 sum_(m≥6)(.5)^m/m!: the combined conservative cost <.0035. A singleton succeeds with μ/k≤44/63<.70, so its relative error cost is ≤5 exp[−128(.30²/2+.30³/3)]. Long b≥3 has mean-to-threshold ≥1.33 and exponent decrease at least 14 per b, giving cost (5/6) exp[−128(.33²/2−.33³/3)]/(1−exp(−14)). The sum is <.0135; use ε=.014 in the final ratio. The derivative uses exp(.5) and r≥(21/22).45 sqrt(n), giving <.37.
3. β0>2.15: U=4, forbid size 1, both 2 and 3 critical, retain at most six. r0≥31, so r−B≥12=3U; for m≤4 it is ≥18≥4U. The critical weight sum uses h_mass=5/6. Hard-count replacement costs at most .00016 sum_(m≤4)(5/6)^m/m!+.002 sum_(5≤m≤6)(5/6)^m/m!, and omissions at most 7 sum_(m≥7)(5/6)^m/m!; together <.001. A short singleton has μ/k<.5. A long b≥4 has μ/k≥1.46 and exponent drop ≥14 per b. The long complement (when positive) has hard minimum 2 and count ≤1/2, giving factor 7/8 after dividing by c. The total error is <.003.

In all cases use the Fourier peak bound .45/sqrt(k), with binomial mode p0=(k−1)/(n−1) and variance ≥.92(k−1). The Gaussian cost on |θ|≤1 is <.44/sqrt(k), the rest <.01/sqrt(k). In case 3 **the two sensitive binomial masses do not peak together**. Since the mean ratios p/p0 at p=2/r and 3/r differ by a factor 1.5, one is ≤.8 or the other ≥1.2. The exact ratio of the point mass to its modal value is at most exp[−(k−1)(p/p0−1−log(p/p0))], by log(1−u)≤−u on the second binomial factor (u may be negative). At .8 the exponent loss is greater than at 1.2; at 1.2 use the alternating logarithm through degree five. The smaller loss is >log(100/11), so the sum of both masses is <.45(1+.11)/sqrt(k)<.50/sqrt(k). The marked multinomial derivative therefore costs ≤exp(5/6)·.50/(sqrt(k)·[(30/31).45]²)<.55, rather than charging two independent peaks. Inserting all three error/derivative budgets gives the common neighbor ratios 1.71 left, 1.14 right. Binomial Chernoff and cycle-union normalizations are as in long_cycles_two_critical_switch.md.

## Adaptive edge and center
With D≥1791 and M=floor(.6sqrt(D)), use the old three-regime edge lemma. For m≥.45sqrt(n), (eta,lambda,alpha)=(.26,.45,.15), since the profile covers [.45,.62]sqrt(n); on leaving it to the right the actual base r≥26, so its factor is ≤(27/8)(27/26) and its log loss ≥(D/sqrt(n))(5/3−50/31). To the left use factor 27/8 and prior loss. High opposing witnesses use both new ratios for first offsets, and for odd a≥3 use 2C sum .26^a(1+a/20). In the medium band 10≤m<.45sqrt(n) use (.121,.45,.17), m+1<.474sqrt(n) and m+2<.498sqrt(n). For curvature refine m+1<.47365sqrt(n), which follows from 1/sqrt(1792)<.02365; split at r=16, using 17C²/16 for r≥16 and 1.5C² times exp(−1791/225) otherwise. Low m≤9 uses (.001,.006,.006) as before. The drift bound is .367+.0038a at r≤M+a. Here n≥1792 means x=(n−1)/r≥1.998k for r<H/2; the geometric Markov proof still gives 7exp(−.299k)<.001 (replace 1.999 by 1.998 throughout). For r≥H/2 the beta-lattice bound uses the .45 peak above. The signed-mean and geometric witness inequalities pass in every band. The splice still uses S≤(5/3)sqrt(n)+2.9 because M≥25, and phase error <π/40 because both linear and cubic corrections are below 1/40 when sqrt(D)>42.

For the center take the minimum of the original crude pole-distance exponents and the newer harmonic weighted bounds, separately for primary and far anchors. The same tilted endpoint proof, L=6, applies: .18 vertical log bound at k≥128, and earlier small-s signs. The three exact central intervals [14,18], [18,27], [27,58] in n/k join the previously proved range n≥20k. All endpoints give the next-row comparison. No claims below n=14k from this proof.

## Exact replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[128,14,15,450,6,18],[128,18,18,450,6,27],[128,27,26,350,6,58]];
const covered={128:14};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(29,10).div(sk));
 ck(q(0).lt(rad)&&q(25*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1],C=q(27,8), v=q(1791,1792), sk=q(113,10), n0=q(1792), eM=q(121,1000), eH=q(26,100), eL=q(1,1000);
ck(covered[128]>=20,"overlap");
ck(o.lt(q(4).mul(q(44,100).sq()).mul(pl).mul(q(11,24)).mul(q(92,100)).mul(q(127,128))),"Fourier main");
ck(q(1600).lt(lo(q(40))),"Fourier tail");
function geo(first,ratio){return first.div(o.sub(ratio));}
function bad(x){return em(q(128).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3)))));}
function short(x){return em(q(128).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3)))));}
const e1=q(38,1000),e2=q(14,1000),e3=q(3,1000), L=q(171,100), R=q(114,100);
ck(q(1269,1000).lt(q(80,63))&&q(17).lt(q(128).mul(q(40,63).sub(q(1,2)))),"long b2 one");
ck(q(5,10000).add(q(3,2).mul(geo(bad(q(269,1000)),em(q(17))))).lt(e1),"error one");
ck(q(133,100).lt(q(3).div(q(215,100).mul(q(23,22))))&&q(14).lt(q(128).mul(o.div(q(215,100).mul(q(23,22))).sub(q(1,3)))),"long b3 two");
ck(q(35,10000).add(q(5).mul(short(q(3,10)))).add(q(5,6).mul(geo(bad(q(33,100)),em(q(14))))).lt(e2),"error two");
const mb4=q(62,100).sq().mul(q(255,14)).mul(q(32,31).sq());
ck(mb4.lt(q(4).div(q(146,100)).sq())&&q(14).lt(q(128).mul(q(146,400).sub(q(1,4)))),"long b4 multi");
ck(q(1,1000).add(q(7).mul(short(q(1,2)))).add(q(7,8).mul(geo(bad(q(46,100)),em(q(14))))).lt(e3),"error multi");
const A=q(45,100),r1=A.mul(q(19,20)),r2=A.mul(q(21,22)),r3=A.mul(q(30,31));
ck(eu(o).mul(A).div(sk.mul(r1.sq())).lt(q(60,100)),"derivative one");
ck(eu(q(1,2)).mul(A).div(sk.mul(r2.sq())).lt(q(37,100)),"derivative two");
const z=q(1,5), bd=q(127).mul(z.sq().div(two).sub(z.sq().mul(z).div(q(3))).add(z.sq().sq().div(q(4))).sub(z.sq().sq().mul(z).div(q(5))));
ck(q(100,11).lt(lo(bd)),"separated peak");
ck(eu(q(5,6)).mul(q(1,2)).div(sk.mul(r3.sq())).lt(q(55,100)),"derivative multi");
for(const [h,eps,b] of [[q(60,100),e1,q(21,20)],[q(37,100),e2,q(23,22)],[q(55,100),e3,q(32,31)]]){
ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L) && b.mul(o.add(eps)).div(o.sub(eps)).lt(R),"profile ratios");
}
const lH=q(45,100),lM=q(45,100),lL=q(6,1000),aH=q(15,100),aM=q(17,100);
ck(o.div(eH).lt(lo(q(25,9).mul(q(1,2).sub(q(1,75))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(474,1000)).mul(q(498,1000))))),"middle pure");
ck(q(1000).lt(lo(q(1791,220))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq())))) && C.mul(q(27,26)).div(lH).lt(lo(v.mul(q(42)).mul(q(5,3).sub(q(50,31))))),"profile exit");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(q(25,9))),"high curvature");
ck(C.sq().mul(q(17,16)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(47365,100000).sq()))) && C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(q(1791,225))),"middle curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,20,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witness");
const d=q(367,1000),b=q(38,10000),C2=two.mul(C);
ck(C2.mul(q(6,10).div(q(42)).add(A.div(sk))).lt(d)&&C2.div(n0).lt(b),"drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(128)))),"heavy drift");
for (const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){
const z=o.sub(l.sq());
ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");
}
```
