
# Exact unit-circle theorem for the two-principal-pole surrogate

2026-11-26 22:30 UTC. This concerns an intermediate polynomial, not the original mother conjecture. It avoids numerical roots and works uniformly for k≤n<4k.

Let g(v)=exp(sum_(a≥k) v^a/a)=sum_j d_j v^j, where d_j=E_(j,k)(1)/j!. The complex pole formula from the previous work expresses the normalized E as [v^n] product over poles g(q_i v). Write the two conjugate principal weights as q_0 and its conjugate. Their contribution when all other poles are omitted is q_0^n H_n(conj(q_0)/q_0), where
    H_n(z)=[v^n]g(v)g(zv)=sum_(a=0)^n d_a d_(n−a) z^a.
The same formula applies directly to the normalized moment construction on the cut, with q_0 viewed as either chosen primary pole. No approximation error is being claimed here.

## General reduction to the expected number of cycle colorings

For n≥k, let C be the cycle count of a uniform admissible permutation. The cycle index gives H_n(1)/d_n = E[2^C], since the two factors give every cycle one of two colors consistently with the labeled model. Write H_n(z)=A_n(z)+z^n A_n(1/z), where A_n takes the lower half coefficients and half of the central coefficient if n is even. Then A_n(0)=d_n and the sum of its remaining (nonnegative) coefficients equals d_n(E[2^C]−2)/2. If E[2^C]<4, constant-term dominance makes A_n nonzero on the closed unit disk.

For completeness this implies exactly n simple roots of H_n on the unit circle. If A_n has degree m≤n/2, its zeros α_j all satisfy |α_j|>1. The analytic quotient B(z)=z^n A_n(1/z)/A_n(z) is a finite Blaschke product up to a unit factor: factor z^(n−m) and pair each exterior root of A_n with the interior reciprocal-conjugate root of its reversed polynomial (the coefficients are real). For |z|=1, the argument of each single factor (z−β)/(1−conj(β)z), |β|<1, has derivative (1−|β|²)/|z−β|²>0, by logarithmic differentiation. Including z^(n−m), the full argument increases strictly by 2 pi n on one turn. The equation B(z)=−1 has n distinct simple solutions; A_n is nonzero there, so these exhaust the degree of H_n. Moreover the argument derivative is at least n−m≥n/2, an exact phase bound independent of localization.

## A checkable uniform margin for every k≤n<4k

Let d_(n,c) count normalized permutations with exactly c allowed cycles. Its value is (1/c!) times the sum of 1/prod_i a_i over ordered lengths a_i≥k of total n. For n<4k only c=1,2,3 can occur, and d_(n,1)=1/n. Also n d_(n,2)=sum_(a=k)^(n−k)1/a≤2, with an empty sum taken as zero. For c=3 and n≥3k, use
    d_(n,3) ≤ binom(n−3k+2,2)/(6k³) ≤ k(k+1)/(12k³).
It follows for k≥3 and n<4k that n d_(n,3)< (k+1)/(3k) ≤ 4/9; it also holds with zero when n<3k. Thus n d_n≤31/9 and
    4−E[2^C]=(2 d_(n,1)−4 d_(n,3))/d_n ≥ 2/31.
Consequently the nonconstant coefficient mass of A_n is at most (30/31)d_n. Both lower nonvanishing margin |A_n(z)|≥d_n/31 on the closed disk and the upper bound |A_n(z)|≤(61/31)d_n follow.

## What this does and does not prove

This gives an exact moving phase with a nonvanishing analytic factor through the entire pre-four-cycle band instead of approximating it by n times the primary angle. It is not the full pole sum, and the phase derivative bound in one row does not prove interlacing across rows. For a genuine next step compare arg A_(n+1)−arg A_n, preserve the nonvanishing margins when restoring all other poles, or find a disk-nonvanishing factorization that works when E[2^C]≥4 instead of using coefficient dominance. The positive square estimates in the preceding note are an independent partial route.


## A second uniform regime via coefficient differences: n ≥ 40 k log(2k)

The constant-coefficient argument is necessarily insufficient at large n. Instead the anti-reciprocal polynomial (1−z)H_n(z) has a lower-half analytic factor that is uniformly close to a zero-free exponential. This also provides an exact all-n tail regime for the surrogate, not for the original full pole sum.

Put P(v)=sum_(a=1)^(k−1) v^a/a, c=exp(−P(1)), and r=1+1/k. Write g(v)=c/(1−v)+f(v), f(v)=(exp(−P(v))−c)/(1−v) entire, with coefficients eps_j=d_j−c. On |v|=r the bound
    |f(v)| ≤ M = [exp(sum_(a<k) r^a/a)+c]/(r−1) ≤ 28 k^4
follows from r^a < e < 3, P(1)≤1+log k, c≤1, and e³<27. Thus |eps_j|≤M r^(−j). Also c>1/(3k).

Let m=floor(n/2), put d_(−1)=0, and define T_n(z)=sum_(a=0)^m b_a z^a, b_a=d_a d_(n−a)−d_(a−1)d_(n−a+1), with b_0=d_n. Anti-reciprocity and possible zero central coefficient give exactly
    (1−z)H_n(z)=T_n(z)−z^(n+1) T_n(1/z).
The candidate zero-free factor is T_*(z)=c exp(−P(z))=c(1−z)g(z), whose coefficient at a is c(d_a−d_(a−1)). On |z|≤1, |T_*(z)|≥c²>1/(9k²). For a≤m the coefficient error is at most 2M r^(−(n−a)), since 0≤d_j≤1. For a>m the omitted coefficients have absolute value at most cM(r^(−a)+r^(−(a−1))). Sum the two geometric bounds: the total is at most
    M [2(k+1) r^(−(n−m))+(2k+1) r^(−m)]
    ≤ 5 k M r^(−(n−1)/2) < 280 k^5 exp(−n/(4k)).
Here log r≥1/(2k) and sqrt(r)<2. For n≥40 k log(2k), this is at most 280 k^5/(2k)^10 < 1/(9k²) by 2520<1024 k³ for k≥3. Hence T_n is zero-free on |z|≤1. The exact Blaschke reasoning above, now taking degree n+1 and B(z)=1, gives n+1 simple unit-circle roots of (1−z)H_n(z); deleting the simple root 1 gives n simple unit-circle roots of H_n(z). This does not prove an interlacing assertion. A tail interlacing check could next bound the derivative of the difference of arguments of consecutive T_n; the present sup bound alone does not control that difference relative to the angular gap near 1.


## Strict adjacent angular interlacing of the surrogate for n ≥ 96 k log(2k)

Use the same notation and increase the comparison radius to R=1+1/(2k), so R/r=1−1/[2(k+1)]. On |z|≤R the lower-half coefficient errors sum to at most 2M (k+1)(R/r)^m, bounding the geometric ratio rR/(rR−1) by k+1 and using n−m≥m. The omitted tail costs at most M(r+1)·2(k+1)(R/r)^m. Together these are less than 10 k M (R/r)^m. Since m≥(n−1)/2, k≥3 gives the upper bound E=600 k^5 exp(−3n/(16k)) on that disk (use M≤28k^4 and absorb the n−1 factor by 2). For n≥96 k log(2k) this is at most 600 k^5/(2k)^18, including for row n+1 using the same E. Cauchy's derivative estimate on every unit-circle point gives |T_n'−T_*'|≤2kE. For Δ_n=(T_n−T_*)/T_*, use |T_*|>1/(9k²) and |T_*'/T_*|=|P'|≤k on the unit circle to obtain |Δ_n|<1/2 and |Δ_n'|≤27 k³ E. Hence the difference of angular derivatives of arg T_(n+1) and arg T_n is at most 108 k³ E < 1/4: each phase contribution of 1+Δ is at most 54 k³ E and the T_* phases cancel. The final inequality reduces to 259200<2^18 k^10. The branches start at zero since T_n(1) and T_(n+1)(1) are real positive; no winding occurs for either since each analytic factor is zero-free on the disk.

If φ_n(θ)=(n+1)θ−2 arg T_n(exp(iθ)), then each phase is strictly increasing as proved above. The phase difference φ_(n+1)−φ_n starts at 0, ends at 2 pi, and has derivative ≥1/2. At θ_(n,j) where φ_n=2 pi j, j=1,...,n, we have consequently 2 pi j<φ_(n+1)<2 pi (j+1). This gives strict alternating order of the two surrogate root arguments after cutting the unit circle at 1. The genuine polynomials have other pole contributions, so this order is not yet an implication for them.


## Closing a much earlier tail of the surrogate uniformly: n ≥ 10k (23:00 UTC)

The unit-circle theorem for H_n holds for every n≥10k and k≥3, superseding its earlier n≥40k log(2k) tail. This does not yet touch the missing [4k,10k) surrogate wedge or the actual farther poles.

Write Delta_j=d_j−d_(j−1), with d_(−1)=0. For j≥2k, subtraction of the two count recurrences gives
    j Delta_j = d_(j−k)−d_(j−1) = −sum_(a=j−k+1)^(j−1) Delta_a.
For T(N)=sum_(j≥N)|Delta_j| this implies T(N)≤(k−1) T(N−k+1)/N for N≥2k, because each old index occurs at most k−1 times. Absolute convergence follows already from the entire f(v) representation above; one could also use finite cutoffs first. The known prefix mass T(k)−T(2k)=2/k−1/(2k−1)<3/(2k), plus T(2k)≤T(k)/2, gives T(k)<3/k. Successively T(lk) ≤ T((l−1)k)/l, so for integer l≥1
    T(lk)<3/(l! k).
The limit c of d_j is as above, hence |eps_j|≤T(j+1). Sharpen c to 1/(2k)<c≤1/k: the lower harmonic bound follows by the integral from 1 to k, and the upper harmonic bound follows from 1/j≤integral_(j−1/2)^(j+1/2) dx/x by convexity, giving P(1)≤log(2k−1).

There is a disk-uniform bound
    |1−z|/|exp(−P(z))| < 9   for |z|≤1.
For |1−z|≤1/k this follows from |exp(P)|≤1/c<2k. Otherwise the bound by summation by parts on the series sum_(a≥k) z^a/a is 2/(k|1−z|)≤2, since each starting geometric partial sum is bounded by 2/|1−z|. Use (1−z)exp(P(z))=exp(−sum_(a≥k) z^a/a) on the open disk and continuity at the boundary. Thus the modulus is ≤e²<9, including z=1 by direct evaluation.

For n≥2Lk, L≥1 an integer and m=floor(n/2), compare T_n from the previous section with T_*=c exp(−P). Their coefficient-error sum at a=0,1 combines exactly to eps_n(1−z); coefficients 2≤a<k vanish in both. For k≤a≤m the error is
    Delta_a eps_(n−a) − d_(a−1) Delta_(n−a+1).
The total absolute value of these errors is at most [T(k)+1/k] T(Lk) < (4/k) T(Lk), because m≤n−Lk, the second index moves injectively, and d_(a−1)≤1/k in this range. The remaining omitted coefficients c Delta_a for a>m have total ≤(1/k) T(Lk). Use the disk-uniform bound to compare eps_n(1−z) to T_* and the minimum |T_*|≥c²>1/(4k²) for the rest. This yields
    sup_(|z|≤1) |(T_n−T_*)/T_*| < 54/(2L)! + 60/L!.
At L=5 this is strictly <1 (indeed very close to 1/2). Therefore T_n has no disk zero for n≥10k, and the earlier anti-reciprocal Blaschke argument gives the n simple unit-circle roots of H_n. This proof does not claim angular interlacing in the newly added interval; for that one would need a derivative estimate for the difference of neighboring analytic factors, with cancellation of the eps_n terms.


## Strict adjacent angular interlacing in the linear tail n ≥ 16k (23:02 UTC)

This replaces the older 96k log(2k) bound for angular interlacing of H, still not a result on the omitted poles. Let m=floor(n/2), L=floor(m/k)≥8, and B=T((L−1)k)<3/((L−1)! k). Write A_n=T_n/T_*=1+eta_n, so |A_n|,|A_(n+1)|≥1/2 on the unit disk from the preceding bounds (at L≥8 the relative error is far below 1/2). Absolute convergence of all coefficient series on the circle below follows from the entire remainder or the weighted tails.

Two direct recurrence bounds are useful:
    max_(j≥m)|Delta_j| ≤ B/m,
    sum_(j≥m)|Delta_(j+1)−Delta_j| ≤ 3B/m.
The first uses the recurrence at j. For the second, subtract two such recurrences to get (j+1)(Delta_(j+1)−Delta_j)=Delta_(j+1−k)−2Delta_j, and sum with the denominator ≥m. Also sum_(j>m) j|Delta_j|≤kB, by the recurrence and the same multiplicity count as for T.

Put D_n=(T_(n+1)−T_n)/T_*. Its numerator starts with Delta_(n+1)(1−z) and vanishes in degrees 2 through k−1. For degrees a=k,...,m the remaining coefficient is
    Delta_a Delta_(n+1−a) − d_(a−1)(Delta_(n+2−a)−Delta_(n+1−a)).
If m advances for row n+1 there is one extra coefficient at s=m+1=(n+1)/2, equal to d_s Delta_s−d_(s−1)Delta_(s+1). Thus the remainder coefficient norm is bounded by 8B/(km), from T(k)<3/k, the two tail bounds, and the central cost 2B/(km). Its derivative norm is at most (m+1) times this, hence at most 9B/k. For |z|=1 use |1/T_*|<4k² and |T_*'/T_*|=|P'|≤k. The remainder contributes to |D_n| at most 32 k B/m and to |D_n'| at most (36+32/L) k B≤40 k B.

The early term after division is Delta_(n+1)(1−z)exp(P(z))/c. The factor (1−z)exp(P) has modulus below 9 and derivative bounded by 2k+9k=11k on the unit circle. Since |Delta_(n+1)|≤T((2L−1)k)/(2Lk)<3/((2L)! k²), the early term adds at most 54/((2L)! k) to |D_n|, and 66/(2L)! to |D_n'|. Together,
    |D_n| < (96/L!+54/(2L)!)/k,
    |D_n'| < 120/(L−1)!+66/(2L)!.

For comparison, |A_n'|<k on |z|=1. To see this, use the numerator of eta_n decomposed in the preceding section. The early term derivative is at most 66 k/(2L)!. The middle coefficient norm is at most (4/k)T(Lk), its derivative norm at most m times that, and the omitted tail has derivative norm ≤c kB≤B. Dividing by T_* and bounding the derivative of 1/T_* for the non-early terms gives (16km+20k²)T(Lk)+4k² B. Using m<(L+1)k, the full bound divided by k is at most [48(L+1)+60]/L!+12/(L−1)!+66/(2L)!, which is below 1 at L=8 and decreases afterward.

Therefore |(log A_(n+1)−log A_n)'| ≤2|D_n'|+4|D_n| |A_n'| < 240/(L−1)!+384/L!+348/(2L)! < 1/4. The last inequality at L=8 is an exact factorial comparison, decreasing afterward. This bounds the angular derivative of arg T_(n+1)−arg T_n as well, because the reference factor T_* cancels and |z|=1. The phase derivative argument of the earlier angular proof now yields θ_(n+1,j)<θ_(n,j)<θ_(n+1,j+1) for all j=1,...,n after cutting at z=1. The reopened numerical regimes for the actual excedance polynomials are not settled by this isolated pole pair.


## Transfer back to the genuine polynomial on the central strip (23:15 UTC)

For every k≥16 and n≥16k, the full original row on the central interval t=−exp(−s), 0≤s≤pi, has a strictly controlled sign and phase comparison. Every complete phase bracket constructed below contains exactly one simple zero, and at every genuine old zero in the interval the next row has the sign of the old row's derivative in the increasing phase parameter. This covers only the central strip, not all t or the whole conjecture.

### Exact full pole normalization and error

Put θ=atan(pi/s) with endpoint pi/2, so pi/4≤θ≤pi/2, and q_l(θ)=1/(cos θ+i(2l+1)sin θ) for l in the integers. The two principal conjugate weights are exp(−iθ), exp(iθ), with z=exp(2iθ). The normalized genuine row is the real coefficient h_n=[v^n] product_l g(q_l v) using the earlier exact pole identity; the positive scalar connecting this with E_(n,k)(−exp(−s)) never changes signs. Let C(v) be the product over all remaining poles. Its absolute-coefficient majorant C_hat is formed by replacing each q by |q| in that product. For l≥1 and its conjugate, |q|≤sqrt(2)/(2l+1), and
    sum_far |q|^a ≤ 2 (sqrt(2)/3)^a [1+3/(2(a−1))] < 4 (1/2)^a for a≥3,
by bounding the tail of (2l+1)^(-a) by its integral starting at l=1. Let δ=1/2. In coefficient norm with radius 1 the logarithm of C_hat has norm at most S=8 δ^k/k, and C_hat−1 has norm at most 2S. At radius 3/2 the corresponding log norm is at most 16 (3/4)^k/k≤1/2, so its nth coefficient is bounded by 32(3/4)^k(2/3)^n/k ≤ δ^k/k² for k≥16, n≥16k. The latter reduces to 32k(2/3)^(15k)≤1, following from (2/3)^5<1/4.

For j≥k, the coefficient variation of (1−z)H_j(z) is bounded by 2 sum_(a=0)^j |Delta_a| d_(j−a) ≤ 10/k; indeed the first two terms cost at most 2/k and the rest at most T(k)<3/k. For 0<j<k, H_j=0. Since |1−z|≥sqrt(2), |H_j(z)|<8/k for j>0. The full error e_n=h_n−exp(−inθ)H_n(z) comes from multiplying by C−1, so the nonzero principal rows cost at most (8/k)2S and the special principal coefficient j=0 costs at most δ^k/k². Thus |e_n|≤129 δ^k/k².

For derivatives with respect to θ, |q_l'/q_l|≤1, because on this interval |−sin θ+i(2l+1)cos θ|≤|cos θ+i(2l+1)sin θ|. It follows term by term that |C_b'|≤b C_hat_b. This is legitimate through the absolutely convergent pole sums and coefficient convolutions, also for the derivatives by the same majorants. For j≥k, differentiate the principal row from its (1−z)H_j numerator of degree j+1 and l1 norm ≤10/k: since |z'|=2 and |1−z|≥1, the derivative of exp(−ijθ)H_j(z) is bounded by (30j+40)/k ≤ 50j/k. Combining the derivative bounds gives |e_n'|≤801 n δ^k/k² (for j+b=n use 50j+8b≤50n).

### Phase brackets and sign transfer

The exact principal row equals A_n^*(θ) sin p_n(θ), where
    p_n(θ) = (n+1)θ−arg T_n(exp(2iθ)),  A_n^* = |T_n(exp(2iθ))|/sin θ.
This is direct from (1−z)H_n=T_n−z^(n+1)T_n(1/z). The prior phase proof gives p_n'>n/2 and p_(n+1)−p_n with derivative in (1/2,3/2) on [0,pi], starting at zero. Thus on our central interval this phase increment is in [pi/8,3pi/4]. Also A_n^*≥c²/2>1/(8k²). The estimates |A_n|≥1/2 and |A_n'|<k for A_n=T_n/T_* in the previous section, with |P'|≤k, yield |(log A_n^*)'|≤6k+1 (factor 2 from the circle angle and cot θ≤1). The full normalized errors are therefore |e_n|/A_n^* <1/32 and |e_n'|/A_n^*<n/8, from 8·129·2^(-k)<1/32 and 8·801·2^(-k)<1/8 at k≥16.

Every genuine root must lie in a strip |p_n−j pi|<pi/64 for an integer j: distance to the nearest multiple of pi is at most (pi/2)|sin p_n|. At the two boundaries of a complete strip the principal row's sine has modulus at least 1/32, so the signs alternate despite the error. On any such strip, |cos p_n|>3/4 and |sin p_n|<1/16. The derivative of h_n then has sign (−1)^j throughout the strip, since the main derivative has magnitude above 3n A_n^*/8, while the two remaining terms together cost at most ((6k+1)/16+n/8) A_n^* < (n/32+n/8) A_n^*. Hence there is exactly one simple root in each complete strip, and at most one in a strip partially crossing the fixed central boundaries. At a genuine old root, p_(n+1) is between j pi+7pi/64 and j pi+49pi/64; its sine has sign (−1)^j and magnitude at least 7/32. Including the next-row error gives the same sign for h_(n+1), matching the derivative sign in θ. Multiplication by the positive normalization and use of the strictly monotone θ coordinate preserve these stated signs (d t/dθ is negative). This is a direct transfer from the two-pole phase for the genuine polynomial on a strict subinterval. It is silent for s>pi and for the early/mid n/k wedge.


## Genuine-polynomial transfer on a growing central strip (23:30 UTC)

For k≥32 and n≥16k, set y0=sqrt(6 log(k)/k) in (0,1). The previous genuine-polynomial phase and next-row sign result extends to θ in [arcsin(y0),pi/2], equivalently
    0≤s≤pi sqrt((1−y0²)/y0²),   t=−exp(−s).
This is of order sqrt(k/log k) in s and strictly expands the earlier s≤pi result for large k. It is still not the cutoff of order sqrt(n) needed to join the edge analysis, even when n/k is bounded. No more finite cases of the mother conjecture are asserted.

Write y=sin θ and δ=(1+8y²)^(-1/2). For every nonprincipal pole |q_l|=(1+4l(l+1)y²)^(-1/2)≤δ when indexed by l≥1 and its conjugate. For a≥k,
    sum_far |q_l|^a ≤ 2 δ^(a−2) sum_(l≥1) 1/(1+4 l² y²)
                    ≤ δ^(a−2) pi/(2y) < 15 δ^a/y.
Use the integral from l=0 and δ^(-2)≤9. Since 1−δ≥(2/3)y² and log(1+8y²)≥y² log 9>2y² by concavity, the logarithm norm of C_hat at radius 1 is at most S=(45/2) δ^k/(k y³), and δ^k≤e^(−k y²)≤k^(−6). At radius δ^(-1/2) its log norm is at most 45 δ^(k/2)/(k y³), using 1−sqrt(δ)≥(1−δ)/2. This is <1/2 from y≥k^(-1/2) and k≥32; the unweighted bound is then also <1/2. The corresponding C_hat−1 has norm at most twice the logarithm bound. The coefficient of degree n at radius 1 is bounded by 90 δ^((n+k)/2)/(k y³) ≤ δ^k/(k² y⁴), since it suffices that 90 k δ^((n−k)/2) ≤1, which follows from n≥16k and δ^k≤k^(-6).

For |z|=1 and z=exp(2iθ), the earlier variation bound gives |H_j(z)|≤5/(k y) for all j>0. Its normalized principal row derivative in θ is at most (15j+10)/(k y)+5/(k y²)≤20j/(k y²) when j≥k, by differentiating the degree-(j+1) numerator and the denominator 1−z of modulus 2y. For j between 1 and k−1 the row vanishes. Every pole now has |q_l'/q_l|≤1/y using |2l+1| y≤|cos θ+i(2l+1)sin θ|, so |C_b'|≤ b C_hat_b/y. Convolution with the principal rows then gives
    |e_n| ≤ 226 δ^k/(k² y⁴),
    |e_n'| ≤ 901 n δ^k/(k² y⁵).
The b=n exceptional term uses the tilted coefficient estimate; the other terms use the untitled norm and 20j+5b≤20n. Divide by the principal amplitude A_n^*≥1/(8k² y). Uniformly on this interval, noise satisfies |e_n|/A_n^*<y0/64 and |e_n'|/A_n^*<n/8: bound the decreasing-in-y expressions at y0 and use δ(y0)^k≤k^(-6), y0≥k^(-1/2), and 1808*64<32^4, 7208*8<32^4. Also |(log A_n^*)'|≤6k+1/y≤7k.

Use strips |p_n−j pi|≤y0/32. Every zero is strictly inside one by the sine error. On the boundaries of each complete strip the sine has magnitude ≥y0/(16pi)>y0/64. Inside a strip its cosine has magnitude >3/4 and its sine <1/16, so the full derivative keeps sign (−1)^j by p_n'>n/2 and n≥16k. Thus each complete strip has one simple root and each partial strip at most one. At an old root the next phase is in
    j pi + [15y0/32, 3pi/4+y0/32],
since the phase increment is between θ/2 and 3θ/2. The distance of either end of this interval from the nearest boundary j pi or (j+1) pi is ≥15y0/32 (use y0≤1 and pi>3 at the upper end). Hence the sine dominates the next-row error, giving the required adjacent sign at every genuine old root there. The next unresolved transfer would need cancellation among farther poles when δ^k is not small, or a different uniform argument between this strip and the edge.


## Audited sharper localization and an exact splice count (23:32 UTC)

Independently audited the earlier proof checkpoint. For k≥128, n≥16k its adaptive summation proves full-polynomial uniqueness and the adjacent sign for 0≤s≤pi sqrt(k/log k−1). This improves the factor 6 in the preceding strip by using l(l+1)−2≥3(l−1) rather than a bound requiring an extra 1/sin θ. In the checkpoint notation y0=log k/k and θ0=arcsin sqrt(y0), δ=(1+8y0)^(-1/2), the normalized value error is at most 82/k² and the derivative error less than n/8. The key convex bounds 1−δ≥y0 and log(1+8y0)>6y0 follow on y0≤1/16 from the derivative of (1+8y)^(-1/2) and log(3/2)>3/8. At k=128 the two decreasing comparisons follow, for example, from 656²<128³ and 8(400·11+82·128)<128²·11 (use sqrt(128)>11). Both exact comparisons passed. The checkpoint has the full pole convolution and derivative argument. The root is within 328/(n k²) of the principal-pair root in θ by the phase derivative >n/2 and |sin p_n|≤82/k². A principal root associated to a partial bracket may be outside the strip; its phase is well defined globally. Reciprocity can be applied to all verified noncentral roots without double-counting t=−1.

For eventual joining to an edge count, the reasonably sharp generic lower count can be replaced by the following exact per-splice count. At any left splice θL≥θ0 with dist(p_n(θL),pi·Z)>h=θ0/8, write a=p_n(θL), b=(n+1)pi/2. The number of complete strips is exactly
    max(0, floor((b−h)/pi) − ceil((a+h)/pi) + 1).
There is no partial strip at the left splice. The disk logarithm normalized at z=1 has real values on [−1,1], since T_n is real and zero-free there and T_n(1)>0, so p_n(pi/2)=b exactly. If n is even, b is a half-integer phase and there is no partial strip at the right end either. If n is odd, b is an integer phase and the only partial strip at the right contains exactly the forced root at t=−1, since E(t)=t^n E(1/t); the derivative bound gives its simplicity. These counts are thus exact for the genuine polynomial in the narrower strip, before adding reciprocal roots.

A guaranteed splice with the distance hypothesis is obtained at the first half-integer phase at or after θ0: its θ-coordinate is between θ0 and θ0+2pi/n by monotonicity p_n'>n/2 (we have θ0<pi/6 and n≥2048, so it exists before the right endpoint). Moreover at any θ∈[θ0,pi/2], p_n(θ)=nθ+pi/2−eta with |eta|≤1/(k sin θ)+argbound, where argbound=2[54/(2L)!+60/L!] and L=floor(floor(n/2)/k). Use arg(1−exp(2iθ))=θ−pi/2, the Abel bound 1/(k sin θ) on the omitted tail of −P, and log(T_n/T_*) near 1. The branch identity extends from θ=pi/2, where the tail is real. This names an exact, readily evaluable central root count to compare against an edge count. No edge validity at this splice is yet proved.


## Uniqueness out to s=4 sqrt(k) using the exact derivative recurrence (23:45 UTC)

This extends localization by phase intervals (but not the small displacement estimate). Suppose k≥64, n≥16k, and (n+1)sin θ≥160. On 0≤s≤4 sqrt(k), every complete interval j pi≤nθ≤(j+1)pi within those restrictions contains exactly one simple zero of the genuine E_n, and a truncated interval has at most one. At every genuine old zero, h_(n+1) and h_n' in θ have the same sign (−1)^(j+1). In particular all of the strip is eligible when k≥64,n≥27k, or k≥180,n≥16k. This extends the tiered sign theorem to uniqueness for the stated subrange without differentiating its anchor-error series.

For the exact full coefficient h_n, put Q_k(θ)=sum_i q_i(θ)^k. From q_i' = −cot θ q_i+q_i²/sin θ, and j d_j=(j−1)d_(j−1)+d_(j−k) for j≥1 (use zero at negative indices), one gets
    sin θ h_n' = (n+1)h_(n+1) − n cos θ h_n − Q_k(θ) h_(n+1−k).
To check this directly, distinguish one pole in each product coefficient. A term with exponent a in row n contributes a d_a q_i^(a+1) after adding n cos θ h_n. At exponent b=a+1 in row n+1, the discrepancy between b d_b and (b−1)d_(b−1) is d_(b−k). Summing discrepancies gives Q_k h_(n+1−k). This remains valid at b=k when a=k−1 is forbidden. Absolute convergence and termwise derivative on every fixed θ>0 follow from the inverse-power tails (k≥3). At an old root the middle term vanishes.

Use the (K,a)=(64,4) estimates in long_cycles_tiered_inner_pole.md. In its notation V<.515, W<.835, f<.318. Thus at an old zero, h_(n+1)/(2 sin θ d_(n+1)) has the sign of −sin(nθ) and modulus >1/46: indeed (.835+1/46)^2+.515^2<1. The same tier gives |h_(n+1−k)| ≤ 2 d_(n+1−k)(1+.515) since this is also an active row. Its unweighted far sum gives |Q_k| ≤ 2(1+.318/3), using the stronger exponent k instead of k−1. For n≥16k, both count indices n+1−k and n+1 are at least 15k. The factorial tail above and c>1/(2k) give |d_j/c−1|<6/15! for j≥15k, so their ratio is <101/100. The magnitude of the lag divided by (n+1)·2 sin θ d_(n+1) is therefore less than
    2(1+.318/3)(1+.515)(101/100) / ((n+1)sin θ)
    < (17/5)/160 < 1/46.
All last numerical inequalities were checked by exact integer cross multiplication. Thus h_n' has the strict sign of h_(n+1) at every old zero in the strip, not just at surrogate witnesses. On a single phase interval all old zero derivatives have the same sign since −sin(nθ) does not change sign there. There are finitely many such zeros and they are simple, so two consecutive ones in the interval would require opposite derivative signs (otherwise continuity would force another intervening zero). This gives at most one. On a complete interval the tier's witness signs give existence by continuity.

Finally sin θ=pi/sqrt(s²+pi²)>3/(4sqrt(k)) throughout 0≤s≤4sqrt(k), since pi²(1−9/(16k))>9 for k≥64. At n≥27k the product exceeds (81/4)sqrt(k)≥162. At k≥180,n≥16k it exceeds 12sqrt(k)>160. These prove the two uniform versions. The main open gap is still between this enlarged central range and the edge sign sequence for n≫k or in uncovered moderate rows; this estimate does not bridge it by itself.


## Same s≤4 sqrt(k) uniqueness already for n≥4k, k≥64 (00:00 UTC)

The preceding direct derivative argument originally used n≥27k (or k≥180,n≥16k). All genuine simple-root uniqueness and strict next-row signs there in fact hold for every k≥64, n≥4k. This is uniform in both parameters, not global root coverage. Three estimates suffice.

1. Sharper absolute anchor bounds. Use the exact geometry from the ratio-seven early-band proof: for a primary anchor the inverse denominator distances to a far conjugate pair sum to at most 3/2 in the common rescaling; for a far anchor the two primary distances also contribute at most 3/2, and the other far anchors contribute an upper-half total ≤4h/3, separating same-half distances ≥1 from opposite-half distances ≥3. For s≤4 sqrt(k), at K=64 use R=16001/100000 > rho/(pi k), and bounds f=.316 and h=.105 for the weighted and unweighted far sums at power k−1, while g=.030 and j=.010 bound those sums at power 2k−2. For each m=31,63 compute b=4(157/50)^2/1034; sum the first six terms of (1+b l(l+1))^(−m), with weight 2l+1 if weighted. Remaining weighted tail is at most 1/[b(m−1)(1+42b)^(m−1)] by its decreasing integral from 6, and the unweighted tail is bounded by this divided by 13. The same monotonicity in k as in the tiered bound applies. Set P=2(exp(R(1+3h/2))−1), Z=2(exp(R(3/2+4h/3))−1). The value and centered bounds prior to the diagonal mismatch are respectively V≤P+Zh+j<.481 and W0≤P+Zf+g<.627, by the same anchor norm decomposition as the tiered proof.

2. The diagonal term is much smaller once n≥4k. From the exact Delta recurrence, |d_(n+1)−d_n|≤T(3k)/(n+1)<1/[2k(n+1)], and d_(n+1)≥1/(2k−1). As v=sin θ>3/(4 sqrt(k)), (n+1)v>24 for k≥64 and n≥4k. Its centered contribution is <(1+j)/24, so the complete centered error is <.670. Since (.670+.200)^2+.481²<1, at any old zero the next-row magnitude in centered units is >.200 and its sign is −sin(nθ). The same old-value error bound is available for the lag row n+1−k, which is ≥3k+1: use the identical absolute anchor bound and note that its farther diagonal exponent is at least 2k−2. No centered bound is needed for that row.

3. A tighter elementary bound d_a<3/(5k) for k≥64, a≥2k reduces the lag factor. For 2k≤a<3k, write x=(a−k)/k. From the recurrence,
    a d_a ≤ 1+1/k+log x.
The difference of this bound and 3a/(5k) has maximum 1/k+log(5/3)−3/5 over x≥1, which is negative by log(5/3)≤44/81 (the cubic alternating truncation). For a≥3k the fixed prefix mass 1+sum_(b=k)^(2k−1)1/b is at most 1+1/k+log 2 < 3(3k−1)/(5k) using log 2<.7; the rest has a−3k+1 terms to which induction applies. Thus d_(n+1−k)/d_(n+1)<6/5. With |Q_k|≤2(1+h), the lag magnitude in the derivative comparison is less than
    2(1+.105)(1+.481)(6/5)/24 < .164 < .200.
The exact derivative identity therefore forces the same next-row and old derivative signs. The existence, at-most-once, parity and negative t orientation arguments are unchanged.

Exact rational replay passed. To reproduce constants, use the tiered-inner replay's rational class and expUp; substitute K=64,a=4, the six-term lattice plus integral above, and check:
    R² > (1+1024/(157/50)²)/64²;
    lat(31,weighted)<.316, lat(31,unweighted)<.105;
    lat(63,weighted)<.030, lat(63,unweighted)<.010;
    P+Z*.105+.010<.481;
    P+Z*.316+.030+(1+.010)/24<.670;
    (.670+.200)²+.481²<1;
    2(1+.105)(1+.481)(6/5)/24<.200.
None of these checks samples a polynomial row or uses floating point for a sign. The remaining gap to the edge grows once n/k grows; this provides a stronger central ingredient but still no complete mother-conjecture proof.
