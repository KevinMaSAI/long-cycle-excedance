# Early band through 3k for every k≥20

06:28 UTC Reviewed analytic derivation with exact replay. The proven all-row threshold is still k≥24 at this checkpoint.

### The first complete band now reaches 3k at k≥20

For every k≥20 and k≤n≤3k, the genuine E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient, including old n=3k. New coverage is for 20≤k≤23, because the parent has all n at k≥24. The proof uses ordinary Eulerian interlacing for n<2k−1 and proves the onset directly. It enumerates no original polynomial rows. [Earlier k≥24 proof](long_cycles_k24_through_3k.md) · [First three interval checks](long_cycles_k20_early_11over4_replay.md) · [Final interval checks](long_cycles_k20_early_3k_replay.md).

**Sparse center through 11k/4.** Use the normalized anchor identities, K=20, and the old primary/far norm scales p,x. For Bk≤n≤Nk with (B,N)=(2,9/4),(9/4,5/2),(5/2,11/4), mixed shifts b≤n+1−k<2k are linear only. The atom gets normalized ratio d_(n−k)/d_n<2/(B−1), since d_(n−k)=1/(n−k) and d_n>.5/k. Other shifts use ratio 2 and their telescoped mass is ≤u/k with u=1−1/(N−1+1/K). Hence P=p[1/(B−1)+u] bounds the old primary perturbation. Far centered error is W=x[j_atom/(B−1)+u f]+g, where j_atom, f and g have powers (B−1)k, k−1 and Bk. The old value error is W/3. Primary drift is bounded by P₀/K+P₀/(BK)+p/(K+1), P₀=(1+u)p, by the established overlap and denominator bounds and the nonatom new degree. Diagonal mismatch is at most (1+j)R/B with j the unweighted far diagonal. The ellipse and π/8 splice exclusion pass at a=3.94,4.16,4.36 for s≤a√k. At old n=2k−1 the old mixed part vanishes. The new boundary b=k costs at most p on primary and x f farther out. Add far diagonal g and mismatch (1+j)R/2, using floor half-exponent K−1 for diagonal. The direct ellipse at 3.94√k passes.

**Sparse center to 3k.** At 11k/4≤n≤3k, both rows have counts ≥.555/k. On the two-cycle band use kd_j≥(2+3y)/(2+y)²≥5/9 for y∈[.75,1], and at 3k or 3k+1 use 1+log 2 and the extra .5/k terms in the recurrence. Counts at j≥2k are ≤.590/k by the tangent minimum and the short head bound 1+log 2+1/(4k−2) in the same recurrence. The atom ratio is ≤1.064 and the linear prefix b≤1.5k has ratio ≤1.442. Their unweighted coefficient norms in units p or x are 1/2 and 1/6, and radial powers are 1.75k and 1.25k. Later pre-2k linear mass is at most 1/(6k), hence cost y/12 for scale y=p or x. Linear degrees 2k and 2k+1 cost y/(K+1). Pairs can only use k,k or k,k+1, costing Q(y)=y²[1/8+1/(4(K+1))]. Apply ratio 1.81 to all three late terms and radial power k−1 to them farther out. The usual far diagonal uses B=2.75. The old and new prefixes have unweighted norm at most P₀/2, with P₀=1.5p+2[p/(K+1)+Q(p)]. Then primary drift is P₀/K+P₀/(BK)+p/(K+1)+2Q(p), the last terms charging the exact new boundary. The diagonal mismatch gains an extra factor .17 since d old and new ≥.555/k and the lag count lies in [.5,.590]/k. This verifies the ellipse through s≤4.55√k.

**Edges and join.** Use D=n−1, M=floor(√D/2), H=n/k. Through 2.5k use A∈[1,H]. Every first pure ratio is <.195 by the fifth-order logarithm bound at M≥3. Actual ratios after the first are <.052 because the right second loss is at least 3.9 and the left at least 6. The pure third witness offset is <.00013 by the quadratic loss, so the witnesses keep their signs. Curvature gives α=.105 or .132 for H≤2.25 or H≤2.5. Robbins peak .59/√k gives drift .482+.058b in the first range and .517+.055b in the second, with the constant on the left. Here b is outward offset. The signed mean passes after separating right offset one from the geometric tail of later odd offsets. In 2.5<H≤2.75 and 20≤k≤23, M=3, first pure η=.105, λ≤2.75η, α=.031 via D≥50. Use drift .526+.055b. In 2.75≤H≤3 with M=3 use η=.087, α=.024 via D≥54, with drift .562+.055b.

When M=4, D∈[64,68]. For old m≤2 and witnesses m≤3 use η=.055 and factor 3. For the last bracket m=3, the r=4 base has a sharper amplitude from the exact cycle types. The full cycle contributes 1/4. Two 2-cycles contribute at least (1−2q₂)/8, and the singleton plus triple contributes at least (p₁−q₃)/3, where q_b is bad-cycle probability and p₁ is singleton success at r=4. The modal peak .54/√k and geometric binomial tails give q₂<.085 and q₃<.002, because the mean ratios to k−1 are ≥65/44 and 195/88. Thus P₄=A_n(4)/4≥.353+p₁/3. Since P₃≤1 and P₅≤.38+.64p₁, the neighbor product at 4 is ≤(15/16)·.38/.353². Hence curvature choices α_L=.008 and α_R=.056 suffice. The actual ratio ≤.34 and drift .562+.055b pass the unequal-alpha signed margin. The last witness uses the same first-neighbor amplitude ratios then factor 3 on later tails. The usual cubic atan gives phase error <π/8. At M=3 use D≤63 to bound S/√k by (63/24)√N, and at M≥4 the relevant bounds in the replay give the smaller required strips. The half-line witness count, reciprocal pairing, parity at −1, and the simple zero at zero exhaust the degree and prove strict interlacing. [Robbins's Stirling bounds](https://dornsife.usc.edu/sergey-lototsky/wp-content/uploads/sites/211/2024/02/Stirling-Robbins.pdf).



## Reverse audit

For n=2k−1, the old mixed prefix is empty, so the extra n+1 coefficient is the degree-k atom alone; the count ratio d_k/d_(2k) is <2 and its contribution fits the displayed p and x lattice bounds without invoking general nonlinear truncation. In the single-factor intervals b>k for the new boundary once n≥2k; d_(n−b)/d_n ratios and overlap are treated independently of the atom refinement. At the last two-mark interval, exact allowed shifts are ≤2k+1 and the only pairs are (k,k),(k,k+1); both row counts are ≥.555/k. The refined mismatch uses the range of the actual lag count (at least .5/k), not an incorrectly extrapolated equilibrium. The first ratio at M=3 derives from the fifth-order logarithm lower loss, while the pure tail as a whole decays quadratically or by the separately verified second-step loss. At r=4, the one 4-cycle weight is 1/4, two 2-cycles have weight 1/8, and singleton plus triple weight 1/3. A union bound within the chosen two-cycle shape gives success ≥1−2q_2, and intersecting the singleton success with triple success gives ≥p_1−q_3; no independence was used. These yield .353+p_1/3 after subtraction. The pure and actual margins compare different left/right curvature at m=3 explicitly. The 2.5k and 2.75k switches leave every actual integer row covered. Both exact replays below passed independently.

# Early proof at k≥20 through n≤11k/4

Exact BigInt rational checks with directed exponential rounding. Use text(value) or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=20,sk=q(447,100),lo=x=>eb(x)[0];
ck(sk.sq().lt(q(K)),"sqrt k");
for(const [N,H,D,n,sd,alpha,d,slope] of [
 [q(9,4),q(9,4),q(38),q(39),q(616,100),q(105,1000),q(482,1000),q(58,1000)],
 [q(5,2),q(5,2),q(45),q(46),q(67,10),q(132,1000),q(517,1000),q(55,1000)],
]){
 ck(sd.sq().lt(D)&&q(36).lt(D),"floor scale");
 const eta=q(195,1000),l2=q(52,1000),eta3=q(13,100000);
 const loss=q(2).sub(q(4,9)).add(q(1,9)).sub(q(4,135));
 ck(o.div(eta).lt(lo(loss))&&H.mul(eta).lt(q(1,2)),"first ratio");
 ck(H.div(l2).lt(lo(q(39,10)))&&H.div(l2).lt(lo(q(6))),"second ratio");
 ck(H.sq().div(alpha.mul(o.sub(alpha))).lt(lo(q(4))),"curvature");
 ck(o.div(eta3).lt(lo(q(9)))&&two.mul(H).mul(eta.add(eta3.div(o.sub(eta.sq())))).lt(o),"witness");
 const peak=q(59,100);
 ck(q(K).mul(ex(o.div(q(6).mul(D)))).lt(peak.sq().mul(pl).mul(q(K-1))),"modal mass");
 ck(H.mul(q(1,2).div(sd).add(peak.div(sk))).lt(d)&&H.div(n).lt(slope),"drift");
 const z=o.sub(l2.sq());
 const lc=alpha.mul(l2).mul(d).div(z);
 const rc=alpha.mul(d.add(slope)).add(alpha.mul(l2.sq()).mul(d.add(q(3).mul(slope)).div(z).add(two.mul(slope).mul(l2.sq()).div(z.sq()))));
 ck(two.mul(alpha).add(d).add(lc).add(rc).lt(o.sub(alpha)),"signed margin");
 ck(q(1,2).div(sd).lt(q(1,8))&&q(10,3).mul(q(1,8)).mul(n.div(D)).div(sd).lt(q(1,8)),"phase splice");
}
for(const [B,N,av] of [[q(2),q(9,4),q(394,100)],[q(9,4),q(5,2),q(416,100)],[q(5,2),q(11,4),q(436,100)]]){
 const m0=Math.floor((K-1)/2),b=q(4).mul(pl.sq()).div(av.sq().mul(q(K)).add(q(10)));
 ck(q(2).lt(b.mul(q(m0*25**2-312))),"lattice decreasing");
 const rr=o.add(av.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"radius");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,w){
  let z=q(0);
  for(let l=1;l<=12;l++)z=z.add(w(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const f=lat(m0,l=>q(2*l+1)),h=lat(m0,l=>o),g=lat(Math.floor(B.val()*K/2),l=>q(2*l+1)),j=lat(Math.floor(B.val()*K/2),l=>o);
 const fj=lat(Math.floor((B.val()-1)*K/2),l=>q(2*l+1));
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h))),u=o.sub(o.div(N.sub(o).add(q(1,K))));
 const P=p.mul(o.div(B.sub(o)).add(u)),W=x.mul(fj.div(B.sub(o)).add(u.mul(f))).add(g),V=W.div(q(3));
 const P0=p.mul(o.add(u)),e=P0.div(q(K)).add(P0.div(B.mul(q(K)))).add(p.div(q(K+1)));
 const c=o.sub(P),dc=R.mul(o.add(j)).div(B);
 ck(q(0).lt(c)&&V.sq().add(W.add(dc).add(e).sq()).lt(c.sq()),"central ellipse");
 ck(V.lt(c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))))),"central slice");
 if(B.val()===2){
  const go=lat(K-1,l=>q(2*l+1)),jo=lat(K-1,l=>o);
  const wo=go.add(x.mul(f)).add(p).add(R.mul(o.add(jo)).div(two));
  ck(go.div(q(3)).sq().add(wo.sq()).lt(o)&&go.div(q(3)).lt(o.sub(pu.div(q(8)).sq().div(two))),"direct two-cycle onset");
 }
 ck(N.mul(q(63,24).sq()).lt(av.sq())&&q(25,4).mul(N).lt(av.sq()),"floor strip");
 text({B:B.val(),N:N.val(),V:V.val(),W:W.val(),P:P.val()});
}
const e=q(105,1000),a=q(31,1000),H=q(11,4),D=q(50),nn=q(51),m=q(3),d=q(526,1000),b=q(55,1000);
const loss=q(1,18).sub(q(1,81)).add(q(1,324)).sub(q(1,1215)); // x=1/3
ck(q(1).div(e).lt(lo(D.mul(loss))),"third band pure ratio");
const l=H.mul(e);
ck(l.lt(q(1,2))&&H.sq().div(a.mul(o.sub(a))).lt(lo(q(50,9))),"third band curvature");
ck(two.mul(H).mul(e).div(o.sub(e.sq())).lt(o),"third band witness");
ck(H.mul(m.div(nn).add(q(59,100).div(sk))).lt(d)&&H.div(nn).lt(b),"third band drift");
const u=o.sub(l.sq());
const t=two.mul(a).add(d).add(a.mul(l).mul(d).div(u)).add(a.mul(d.div(u).add(b.mul(o.add(l.sq())).div(u.sq()))));
ck(t.lt(o.sub(a)),"third band signed margin");

text("All first three intervals passed.");
```


# Last early interval at 20≤k≤23 through n≤3k

Exact BigInt rational checks with directed exponential rounding. Use text(value) or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=20,sk=q(447,100),lo=x=>eb(x)[0];
// Last quarter of the early band, using sparse degrees through 2k+1.
{
const B=q(11,4),av=q(455,100),H=q(3);
ck(q(100,59).lt(lo(q(59,100).sub(q(1,K)))),"upper count one-turn");
ck(o.add(q(694,1000)).add(q(1,4*K-2)).lt(q(59,100).mul(q(3).sub(q(1,K)))),"upper count recurrence");
ck(q(2).lt(lo(q(694,1000)))&&q(693,1000).lt(two.mul(q(1,3).add(q(1,81)).add(q(1,1215)).add(q(1,15309)))),"log two");
ck(q(555,1000).lt(q(5,9))&&q(3).mul(q(555,1000)).lt(q(1693,1000)),"row count lower");
ck(q(59,100).div(q(555,1000)).lt(q(1064,1000))&&q(8,10).div(q(555,1000)).lt(q(1442,1000))&&o.div(q(555,1000)).lt(q(181,100)),"count ratios");
ck(q(9,100).div(q(555,1000)).lt(q(17,100)),"count drift ratio");
{
 const b=q(4).mul(pl.sq()).div(av.sq().mul(q(K)).add(q(10))),m0=9;
 ck(q(2).lt(b.mul(q(m0*25**2-312))),"last lattice");
 const rr=o.add(av.sq().mul(q(K)).div(pl.sq())).div(q(K*K)),R=q(330,1000);
 ck(rr.lt(R.sq()),"last radius");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,w){
  let z=q(0);for(let l=1;l<=12;l++)z=z.add(w(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const wf=l=>q(2*l+1), f=lat(m0,wf),h=lat(m0,l=>o),g=lat(27,wf),j=lat(27,l=>o);
 const fj=lat(17,wf),fl=lat(12,wf);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 const twoMark=y=>y.sq().mul(q(1,8).add(q(1,4*(K+1))));
 const late=y=>q(181,100).mul(y.div(q(12)).add(y.div(q(K+1))).add(twoMark(y)));
 const P=q(1064,2000).mul(p).add(q(1442,6000).mul(p)).add(late(p));
 const W=q(1064,2000).mul(x).mul(fj).add(q(1442,6000).mul(x).mul(fl)).add(late(x).mul(f)).add(g);
 const P0=q(3,2).mul(p).add(two.mul(p.div(q(K+1)).add(twoMark(p))));
 const drift=P0.div(q(K)).add(P0.div(B.mul(q(K)))).add(p.div(q(K+1))).add(two.mul(twoMark(p)));
 const mismatch=q(17,100).mul(R).mul(o.add(j)).div(B);
 const c=o.sub(P),V=W.div(q(3));
 ck(q(0).lt(c)&&V.sq().add(W.add(drift).add(mismatch).sq()).lt(c.sq()),"last central ellipse");
 ck(V.lt(c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))))),"last central splice");
 ck(q(3).mul(q(63,24).sq()).lt(av.sq())&&q(3).mul(q(68,4).sq()).div(q(69)).lt(av.sq()),"M3 or M4 radius");
 text({lastV:V.val(),lastW:W.val(),lastP:P.val(),lastDrift:drift.val()});
}
{
 const d=q(562,1000),b=q(55,1000),e=q(87,1000),l=H.mul(e),a=q(24,1000);
 const l0=q(1,18).sub(q(1,81)).add(q(1,324)).sub(q(1,1215));
 ck(o.div(e).lt(lo(q(54).mul(l0)))&&H.sq().div(a.mul(o.sub(a))).lt(lo(q(6))),"last M3 ratio");
 ck(H.mul(q(3,55).add(q(59,100).div(sk))).lt(d)&&H.div(q(55)).lt(b),"last M3 drift");
 ck(two.mul(H).mul(e).div(o.sub(e.sq())).lt(o),"last M3 witness");
 function ms(aL,aR,l,d0,b0){
  const z=o.sub(l.sq());
  const le=aL.add(d0).add(aL.mul(l).mul(d0).div(z)).div(o.sub(aL));
  const ro=aR.add(aR.mul(d0.div(z).add(b0.mul(o.add(l.sq())).div(z.sq())))).div(o.sub(aR));
  return le.add(ro).lt(o);
 }
 ck(ms(a,a,l,d,b),"last M3 signs");
 const e0=q(55,1000),lf=q(34,100),aL=q(8,1000),aR=q(56,1000);
 ck(o.div(e0).lt(lo(q(64).mul(l0)))&&H.sq().div(aL.mul(o.sub(aL))).lt(lo(q(64,9))),"M4 left");
 ck(q(20).mul(ex(q(1,6*64))).lt(q(54,100).sq().mul(two).mul(pl).mul(q(3,5)).mul(q(19))),"M4 modal peak");
 const pk=q(54,447),bin=w=>{
  const u=w.sub(o),loss=u.sq().div(two).sub(u.sq().mul(u).div(q(3))).add(u.sq().sq().div(q(4))).sub(u.sq().sq().mul(u).div(q(5)));
  return pk.mul(w.div(w.sub(o))).mul(em(q(19).mul(loss)));
 };
 ck(bin(q(65,44)).lt(q(85,1000)),"M4 pair failure");
 const v3=q(195,88);ck(v3.lt(lo(q(8,10)))&&pk.mul(v3.div(v3.sub(o))).mul(em(q(19).mul(v3.sub(q(18,10))))).lt(q(2,1000)),"M4 triple failure");
 const d4=q(353,1000);
 ck(q(1,4).add(q(1,8).mul(o.sub(q(17,100)))).sub(q(2,3000)).lt(d4)===false,"M4 success lower");
 ck(q(64,100).mul(d4).lt(two.mul(q(1,3)).mul(q(38,100))),"neighbor product monotone");
 ck(q(15,16).mul(q(38,100)).div(d4.sq()).div(aR.mul(o.sub(aR))).lt(lo(q(4))),"M4 right curvature");
 const lL=q(3,4).div(d4),lR=q(5,4).mul(q(102,100)).div(d4.add(q(1,3))),eta=q(181,1000);
 ck(q(136,1000).mul(lL).add(eta.mul(lR)).add(two.mul(H).mul(eta.sq().mul(eta)).div(o.sub(eta.sq()))).lt(o),"M4 witness");
 ck(lR.mul(eta).lt(lf)&&H.div(lf).lt(lo(q(64,20))),"M4 actual ratios");
 ck(H.mul(q(4,65).add(pk)).lt(d)&&H.div(q(65)).lt(b),"M4 drift");
 ck(ms(aL,aR,lf,d,b)&&ms(aL,aL,H.mul(e0),d,b),"M4 signed margins");
}
}
text("All exact early bounds passed.");

```
