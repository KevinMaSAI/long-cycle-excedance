# Uniform upper range starting at n=16k for k≥32

2026-11-27 05:45 UTC. For every k≥32 and n≥16k, the genuine E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient. This covers all n above its lower bound, not all n≥k. It suffices to prove 32≤k≤47 and 16k≤n≤180k by the k≥48 all-row theorem and common eventual n≥180k. Last adjacent pairs are included. No original polynomial-row checks.

## 1. Edge occupancy and signs

Write H=n/k, D=n−1≥511, M=floor(.53sqrt(D))≥11, S=D/M. In the neighboring amplitude window r0∈[.42,.62]sqrt(n), β0=kr0/n≤.62sqrt(47/16)<1.5. Thus only singleton cycles are critical. Keep at most seven; r0≥10 and integer neighbors r≥9. The relative hard-count errors for the eight non-omitted critical counts are .00016,.00016,.002,.002,.08,.08,1,1 by residual count thresholds 4U,3U,2U for U=2. The weighted costs, plus omitted exponential tail factor 3, total <.008. For b≥2 the initial long-cycle mean-to-threshold ratio >1.70, including neighbor factor 11/10. Use geometric prefactor <.19 and exponent loss ≥31(.70²/2−.70³/3), increasing >10 per extra b, with relative marked-union factor 3/2. This gives error epsilon .014. The binomial point peak .44/sqrt(k) follows from Robbins and variance ≥(15/16)(k−1). The marked multinomial derivative bound is exp(1)·.44/[sqrt(k)(.42·9/10)²]<1.49. The common amplitude ratios are <2.54 left and <1.14 right.

For m≥.42sqrt(n), use pure eta=.189, actual λ=.49 and curvature α=.092, by log loss ≥1/.53²(1/2−1/33) at M≥11 and the two ratios just proved. Outside the profile on left or right use the same pure exponent D/(2r²) or (D/sqrt(n))(100/53−50/31), absorbing C=27/8 and 81/16, respectively. Curvature product ≤2.54·1.14 exp(−1/.53²); first witness opposition uses the profile, then global C(1+a/10) for later odd a. All pass.

For m below the threshold let r=m+1 for the first right step, giving D≥(r−1)^2/.42²−1. If r≤9 use D/r²≥511/81; if r=10 use ≥511/100; if r≥11 use (10/11)^2/.42²−1/121. The pure first ratio from (D/r²)(1/2−1/(3r)) is below .055,.093,.112, respectively. Corresponding amplitude factors ≤1.5C,1.1C,(12/11)C give λ=.42; later ratios improve in each direction. Left step uses the stricter D/(2m²). Apply the same D/r² bounds to either main curvature center, with C²(1+1/r), giving α=.14. At a low witness m≥8 the first pure ratio is .077 from the cutoff m<.42sqrt(n); otherwise it is .010, by D≥511. The opposing witness sums pass. First witness dominance persists for all s>D.

For r≥.75H the cap ceil(4k/3) gives H/A<3.62; then d_r≤3.62(r/n+.44/sqrt(k)) by beta lattice. Below .75H use the marked loss profile x=D/r≥1.330k, exactly as in the preceding K48 proof, giving d_r<.11 with step loss >11. The uniform right budget .37+.0071a and left .37 yield strict signed-mean margins for both regimes. The floor and phase bounds give S≤(100/53)sqrt(n)+4 and phase error <π/40, using sqrt(D)>22.6. No central counting argument is needed on this occupancy edge.

## 2. Uniform coefficient counts and harmonic center

At k≥32 the .58/k two-cycle maximum follows from exp(.58−1/32)>1/.58. With earlier endpoints .5 and .563 this gives variation <.097/k on the two-cycle band, T(2k)<.146/k and T(Lk)<.292/(kL!). The tilted bound J=[e^α+e^(2α)/2+.097 e^(3α)/(1−e^α/3)]/2 and plain norm ξ=.823 in 2/k units follow by the same tail recurrence. The upper .58/k propagates to d_j for j≥3k by the harmonic head ≤1+log2+1/(4k−2). The lower .555/k at j≥3k follows from the same linear lower envelope on 2k≤j≤3k−1 as in the K48 theorem. For induction at j≥4k, the harmonic head lower is 1.693+.5+(k−1)/(36k)≥(4−1/k)·.555, as seen by comparing constants and coefficients of 1/k. Thus every retained count ratio at n≥3k is ≤1.81. For the short part L≥5 the symmetric difference from one is ≤δ=.584/L! by telescoping. In the weighted far bound use baseline 1+δ and excess .81−δ. Primary epsilon uses δ in its short segment (not the former .5/L!), plus the tilted long tail. Adjacent drift in these intervals is ≤2 epsilon.

On s≥4sqrt(k), the scalar log argument gives .32 vertical drift, so Re P_*≥.64 times the positive real reference and angular margin >.95 on π/40. Use (16/15)/(a/5.65+2) as the uniform real-part floor. The improved segment estimate in the K48 theorem applies with .66 in place of 2/3: sin(theta)<.14 and sqrt(2+2·.14)·.66<1. Thus |log P_*|≤.76p, permitting the improved direct real floor exp(−.76p)(1−(.76p)²/2) when appropriate. The center replay has eleven exact analytic intervals joining n=16k to 187k, strictly overlapping the independent 180k region. For s≤4sqrt(k) the first extra replay row verifies the same tilted harmonic ellipse with B=16,a=4 and reference floor 2−exp(ξp), directly from the unweighted norm of P_*−1. No comparison with vertical positive real reference is needed at small s, and the splice occurs in the larger-s strip. Every ellipse and endpoint comparison passes. The usual floor, phase window, witnesses, parity and inversion exhaust the degree and give strict adjacent signs.

## Exact BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(60)).mul(ex(q(5,16)).sq()).lt(q(32,100).sq()),"vertical log bound");
ck(q(64,100).lt(q(68,100).mul(o.sub(q(32,100).sq().div(two)))),"vertical real fraction");
ck(q(95,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(32,100).div(o.sub(q(32,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[32,16,40,550,5,16,1],[32,16,92,600,5,20],[32,20,107,500,5,28],[32,28,128,375,7,41],[32,41,151,280,7,58],[32,58,175,200,7,79],[32,79,198,150,10,102],[32,102,217,150,10,123],[32,123,234,125,10,144],[32,144,246,100,10,160],[32,160,258,100,10,176],[32,176,266,100,10,187]];
const covered={32:16};
for(const [K,B,a2,at,L,N,core] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(565,100);
 ck(!q(K).lt(sk.sq())&&(core||B<=covered[K])&&B>L&&(core||N>covered[K]),"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(97,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(823,1000).mul(p)).sub(o).mul(q(584,1000)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(584,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(q(181,100).mul(em(alpha.mul(q(B-1)))).mul(f)).add(q(81,100).sub(delta).mul(em(alpha.mul(q(B-L)))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(584,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=core?two.sub(ex(q(823,1000).mul(p))):q(16,15).div(a.div(sk).add(two)); const rp=p.mul(q(76,100));const ref2=!core&&rp.lt(o)?dn(o.div(ex(rp)).mul(o.sub(rp.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 if(!core)ck(V.lt(q(95,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(4).div(sk));
 if(!core)ck(q(0).lt(rad)&&q(10000*N,2809).lt(rad.sq()),"splice location");
 if(!core)covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0], eu=y=>eb(y)[1],K0=q(32),sk0=q(565,100),n=q(512),D=q(511),sd=q(226,10),v=D.div(n),C=q(27,8),A=q(42,100),u=q(53,100),pk=q(44,100);
ck(covered[32]>180,"eventual overlap");
ck(q(100,58).lt(lo(q(58,100).sub(q(1,32))))&&q(97,1000).mul(q(3,2)).lt(q(146,1000)),"cycle tail");
ck(o.add(q(694,1000)).add(q(1,126)).lt(q(58,100).mul(q(95,32))),"upper count tail");
const Cmin=q(555,1000);
ck(q(0).lt(q(1693,1000).sub(q(3).mul(Cmin)).sub(q(9).mul(Cmin.sub(q(1,2)).sq())))&&q(4).mul(Cmin).lt(q(1693,1000).add(q(1,2)).add(q(1,36)))&&q(1,36).lt(Cmin)&&o.div(Cmin).lt(q(181,100)),"lower count tail");
ck(pu.div(q(4).mul(sk0)).lt(q(14,100))&&q(66,100).sq().mul(q(228,100)).lt(o)&&o.div(q(2).mul(q(66,100))).lt(q(76,100)),"sharper reference log");
ck(K0.mul(eu(q(1,6*511))).lt(pk.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(31))),"binomial peak");
function geom(x,y){return x.div(o.sub(y));}
function lp(x){return q(31).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))))}
const e=q(14,1000), h=q(149,100), L=q(254,100), R=q(114,100);
ck(q(62,100).sq().mul(q(47,16)).lt(q(3,2).sq())&&q(62,100).sq().mul(q(47,16)).mul(q(11,10).sq()).lt(q(2).div(q(17,10)).sq()),"single size load");
ck(pk.div(sk0.mul(o.sub(q(10,17)))).lt(q(19,100))&&q(10).lt(q(31).mul(q(35,100))),"long tail prefactor and rate");
ck(q(8,1000).add(q(285,1000).mul(geom(em(lp(q(7,10))),em(q(10))))).lt(e),"model error");
ck(eu(o).mul(pk).div(sk0.mul(A.mul(q(9,10)).sq())).lt(h)&&o.add(h.add(two.mul(e)).div(o.sub(e))).lt(L)&&q(11,10).mul(o.add(e)).div(o.sub(e)).lt(R),"profile ratios");
const eH=q(189,1000),lH=q(49,100),aH=q(92,1000),lL=q(42,100),aL=q(14,100);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,33)))))&&L.mul(eH).lt(lH),"high rate");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&q(81,16).div(lH).lt(lo(v.mul(sd).mul(o.div(u).sub(q(50,31))))),"profile exits");
function cv(x,e,a){return x.div(a.mul(o.sub(a))).lt(lo(e));}
ck(cv(L.mul(R),o.div(u.sq()),aH),"high curvature");
for(const [b,eta,fac,r] of [[D.div(q(81)),q(55,1000),q(3,2),9],[D.div(q(100)),q(93,1000),q(11,10),10],[q(10,11).sq().div(A.sq()).sub(q(1,121)),q(112,1000),q(12,11),11]]){
 ck(o.div(eta).lt(lo(b.mul(q(1,2).sub(q(1,3*r)))))&&C.mul(fac).mul(eta).lt(lL),"low ratios");
 ck(cv(C.sq().mul(fac),b,aL),"low curvature");
}
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,10,true)).lt(o),"high witness");
ck(o.div(q(77,1000)).lt(lo(o.div(A.sq()).sub(q(1,64)).mul(q(1,2).sub(q(1,24)))))&&q(100).lt(lo(D.div(q(49)).mul(q(1,2).sub(q(1,21))))),"witness losses");
ck(cost(q(77,1000),8,false).lt(o)&&cost(q(10,1000),1,false).lt(o),"low witnesses");
const dd=q(37,100),bb=q(71,10000),C3=q(362,100);
ck(q(10,3).div(o.sub(o.div(q(13)))).lt(C3)&&C3.mul(u.div(sd).add(pk.div(sk0))).lt(dd)&&C3.div(n).lt(bb),"drift upper");
const xx=q(133,100);
ck(xx.lt(q(4,3).mul(v))&&q(11).lt(q(33,100).mul(K0).add(o)),"drift lower");
ck(C.div(v).mul(xx).mul(pk).div(sk0).mul(geom(em(lp(q(33,100))),em(q(11)))).lt(q(11,100)),"heavy drift value");
for(const [a,l] of [[aH,lH],[aL,lL]]){const z=o.sub(l.sq());ck(two.mul(a).add(dd).add(a.mul(l).mul(dd).div(z)).add(a.mul(dd.div(z).add(bb.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed margins");}
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sd)))).lt(q(4))&&u.div(sd).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sd)).lt(q(1,40)),"floor splice");


const es=[q(16,100000),q(16,100000),q(2,1000),q(2,1000),q(8,100),q(8,100),o,o];let cc=q(0);
for(let i=0;i<8;i++)cc=cc.add(es[i].div(fact(i)));
cc=cc.add(q(3).div(fact(8)).div(o.sub(q(1,9))));
ck(cc.lt(q(8,1000)),"hard-cycle omissions");
```
