# A uniform eventual theorem for k≥12, n≥400k

2026-11-27 04:45 UTC research block. For all integer k≥12 and n≥400k, original E_(n,k) has n−1 simple real roots, and E_(n,k)/t strictly interlaces E_(n+1,k)/t. For k≥64 the all-row theorem already applies, so it is enough to prove 12≤k≤63. This proof avoids any exact individual-row search and fills all sufficiently large n in this previously smaller-k band. It does not settle the remaining n<400k below k=64.

## 1. Exact coefficient and integral normalization

Put d=k−1, t=−q=−exp(−s), a=1/(1+q), p_l=s+(2l+1)pi i, rho=|p_0|, theta=atan(pi/s) including pi/2 at s=0. Write L(z)=log(1+q exp z), the branch from z=0 in |z|<rho, and G_s(z)=sum_(m=2)^d [z^m]L(z) z^m. The full Eulerian EGF at normalized argument z/(1+q) is (1+q)/(exp(−z)+q). Its logarithm equals log(1+q)+z−L(z); the linear term is a z and the degrees 2..d are minus the coefficients summed in G_s. Removing the short cycles by the labeled cycle assembly therefore gives
 H(z)=exp[(1−a)z+G_s(z)]/(1+q exp z), h_n=[z^n]H(z), E_(n,k)(−q)=n!(1+q)^(n+1)h_n.
All coefficients are exact before taking estimates.

The imaginary part of L is bounded by pi on disks |z|=r<rho: the argument 1+q exp z avoids the nonpositive real ray there because such a point would require Re z≥s and Im z an odd multiple of pi. For m>0 the positive Fourier coefficient of Im L is [z^m]L r^m/(2i). Hence taking r→rho from below, the norm of G_s on |z|≤rho(1+1/d) is bounded by 2pi times the mean absolute geometric kernel sum_(m=2)^d u^m exp(imx), where u=|z|/rho. For |z|≤rho it suffices by the maximum modulus principle to bound on the larger radius; now 1≤u≤1+1/d. For d≥11, the kernel is at most min(3d,(21pi/10)/|x|) on 0<|x|≤pi: the geometric numerator ≤u²+u^(d+1)<4.2 and denominator |1−u exp(ix)|≥2|x|/pi, while u^d<e<3. Integrating up to pi gives mean ≤(21/10)(1+log(10d/7)). As d≤62, log(10d/7)<4.5, so J=73 strictly bounds |G_s| for every s≥0 in this disk. This elementary Fourier bound is the main improvement over the previous much larger absolute polynomial bound.

For each s≤S (defined by the dense edge below), take R∈[rho(1+1/(2d)),rho(1+1/d)] separated from each pole modulus by 1/(100d). The number of positive imaginary pole levels with modulus within the interval enlarged by this distance is <rho, since (R_max+1/(100d))/(2pi)+1<rho for rho≥pi and d≥11. The combined excluded interval lengths are <rho/(50d), less than the candidate length rho/(2d). The circle remains at least this distance from all poles. On it, |exp[(1−a)z]|≤e^4 because R q≤(1+1/d)(s+pi)e^(−s)≤(12/11)pi<4. The reciprocal factor 1/|1+exp(z−s)| is at most 300d. Indeed for |Re(z−s)|≥1 it is <2. Otherwise the square of the denominator is (1−e^x)^2+4e^x sin²((y−y_l)/2), with x=Re(z−s), y=Im z, y_l the nearest odd multiple of pi. It is at least one ninth of the squared distance to the pole using e<3 and the lower sine chord. Thus |H|≤300d e^4 e^J on the entire circle.

Define u=s/rho², v=pi/rho², B=2|Res_(p_0) H| rho^(−n−1), beta=pi a−Im G_s(p_0), psi=(n+1)theta+beta. The residue is exp(−a p_0+G_s(p_0))/q, hence |Res|≥e^(−J). By residue subtraction the primary pair contributes −cos psi to h_n/B and +sin psi to (h_(n+1)−u h_n)/(Bv). In the contour integral for the latter the multiplier is 1/z−u, bounded by 2/rho on the circle. Both contour errors therefore are ≤10000dn exp(146−n/(2d+1)) after using rho²≤1.64n from S≤1.25sqrt(n)+1.6 and n≥4800. Here log(R/rho)≥1/(2d+1). At fixed k the bound decreases for n≥400k, so it is less than 10000·62·25200 exp(−54)<.001 (evaluate at n=400k, not at arbitrary large n).

## 2. Far residues on two overlapping s regimes

For any farther included pole l≥1 put x_l=4pi² l(l+1)/rho². Its radial factor is (1+x_l)^(−(n+1)/2)≤exp(−(121/288)n x_l), because 1+x_l≤(12/11)². The centered multiplier weight |1/p_l−u|/v≤2l+1 follows by squaring both sides with y=(2l+1)pi; after clearing denominators the nonnegative difference is (y²−pi²)(s²+y²)(y²+pi²). The ratio of residue moduli to the primary is exp(Re[G_s(p_l)−G_s(p_0)]).

If 0≤s≤8sqrt(d), then n/rho²>6 and the radial loss is at least 98l(l+1). Apply the crude residue ratio e^146. The weighted far half-lattice is <.001, by l(l+1)≥2l and summing the geometric series of 2l+1.

If s≥8sqrt(d), expand L(z) at zero by the convergent q series, and at a pole use (−q)^r exp(rp_l)=1. This gives
 G_s(p_l)=G_*(p_l)+sum_(r≥1)(−q)^r(1+r p_l)/r,
 G_*(w)=−sum_(r≥1)F_d(rw)/r, F_d(w)=exp(−w)sum_(j=0)^d w^j/j!.
The corrective sum is less than .001 in absolute value for included poles, since |p_l|<1.1s and s>26. The series defining G_* and its derivative converge normally on compact subsets of Re w>0. Here G_*(s) is real. The vertical primitive follows from F_d'(w)=−exp(−w)w^d/d!; along s+iy the derivative is at most exp(dy²/(2s²)) sum_(r≥1) exp(−rs)(rs)^d/d!. The nonnegative gamma density at the end is unimodal, so its lattice sum is bounded by 1/s plus its peak ≤1/s+1/sqrt(2pi d) (ordinary Stirling lower bound). For each included y the radius gives d y²/(2s²)<1.15, so exp ≤3.2 and the vertical difference |G_*(s+iy)−G_*(s)|<.51|y|. It follows that |G_s(p_l)−G_s(p_0)|<3.3(l+1). Meanwhile with rho²≤1.64n the radial loss exceeds 10l(l+1). Thus the weighted far error is bounded by sum_(l≥1)(2l+1)e^(−6l(l+1))<.001. These same estimates cover unweighted value errors. Contour plus far error <.002 in both normalized comparisons. Therefore at psi=j pi the value has sign (−1)^(j+1), and every old zero in the center satisfies |cos psi|<.002 and the next row has the sign of sin psi. The deformation made no assumption about old root simplicity.

## 3. Edge up to S, using genuine occupancy coefficients

For n≥400k and 12≤k≤63, set D=n−1, H=n/k, M=floor(.8sqrt(D)), S=D/M. For r≤.9sqrt(n), r/H<3/8. The good-label cycle argument gives A_n(r)≥r Pr(Bin(n,1/r)≥k) with mean ≥8k/3. Since Phi(8/3)>2/3, Chernoff gives .999r<A_n(r)≤r throughout this window. The upper bound A_n(r)≤r holds everywhere.
Use the adaptive balance lemma, exact beta-lattice drift, and quadratic witness estimates of long_cycles_dense_quadratic_witness.md. Here D≥4799 and M≥55, giving first pure ratio <.463 from (25/16)(1/2−1/(3·55)), and at the third witness offset pure ratio <.0014 by 9D/[2M(M+3)]. Low indices m≤15 use pure eta=.001 directly. Take actual outward λ=.493: left factor 1/.999 and right factor (17/16)/.999 in the dense window for the high brackets; for low brackets use 1.5/.999 in the window. Above .9sqrt(n) use the factor 81/16 and at least (D/sqrt(n))(5/4−10/9) right loss. At roots α=.31 from P≤exp(−25/16)/.999². Both witness bounds pass, at high m first pairing exact amplitude upper r/m, followed by the quadratic third-offset bound and .463 geometric progression. At low m use factor (1+a)/.999. At the first witness dominance persists for s>D.

For d_r=r(A_(n+1)(r)−A_n(r))/A_n(r), use the exact beta-lattice formula and Robbins peak <.45/sqrt(k) with variance ≥.99(k−1). When r≤.9sqrt(n), x=D/r≥2.66k. The marked binomial point relative to its peak is at most exp[−(k−1)Phi(xa/(k−1))]; loss increases by >20 per lattice step. With H/A≤(27/8)(n/D)(x/k), the weighted function x exp[−(k−1)Phi(x/(k−1))] decreases for x≥k. At x=2.66k we have Phi(x/(k−1))>.66 because log(2.66)<1 and Phi is increasing. Summing gives d_r<.001. If r≥H/2 the cap 2k gives H/A<4.46 and d_r≤4.46(r/n+.45/sqrt(k)). At other r<H/2 the old geometric Markov bound 7exp(−.299k)<.64 is enough (D/r≥1.998k). Consequently the whole left and right offsets a<6 have drift <.001; at all r≤M+a a uniform bound is .64+.00093a, since sqrt(n)>69. In the signed-mean inequality use small first/left drift, and estimate the entire a≥6 right remainder with αλ^5 and geometric arithmetical tail. Replay verifies strict margins. Therefore all old edge roots are simple and have the correct next-row signs, including the limits of the edge witnesses. S≤1.25sqrt(n)+1.6 by the floor arithmetic.

## 4. Exact splice, parity and interlacing

At s=S, we have S≥1.25sqrt(n−1)≥3d (the worst ratio over 12≤k≤63 is at k=63). At the primary |p_0|≤1.02s. Thus |F_d(r p_0)|≤2^d exp(−.49 r s) by the nonnegative exponential majorant at |rp_0|/2. Since log 2<.7 and s≥3d, the real-sum representation above gives |G_s(p_0)|<.002, including the small logistic correction. Hence beta differs from pi by <.003. At S the (n+1)theta/pi discrepancy from M has positive linear correction ≤1.6/sqrt(D), negative cubic correction ≤((n+1)/D)(10/3)(.8)^3/sqrt(D), each <1/32. Thus psi(S) is within pi/20 of (M+1)pi. At s=0, G_0(i pi) is real since the even-degree coefficients are the only terms after the linear term of log(1+exp z); beta=pi/2, so psi(0)=(n+2)pi/2.

As s runs downward from S to zero, choose the first hits of psi=(M+2)pi, (M+3)pi,... up to the last attained integer phase <= (n+2)pi/2. At each pair of consecutive levels obtain a zero with intermediate phase by using the last hit of the first level before the first hit of the next. The join uses either such a last hit of (M+1)pi or the already signed witness at S if there is no such hit. No phase monotonicity is assumed. The signs on the smaller-s side are (−1)^(j+2) where psi lies between j pi and (j+1)pi, so the next-row sign (−1)^j is opposite the old derivative in t at the zero. For each edge this comparison was verified directly. Edge witnesses give M−1 positive-s zeros, and central witnesses including the join give floor(n/2)−M more. Inversion symmetry from inverse permutations gives the reciprocal zeros; for odd n the root t=−1 is forced by reciprocity of degree n after including the simple zero at t=0. Together they exhaust degree n−1, proving simplicity and uniqueness of the selected sign changes. At the odd central root, the next-row sign from sin psi at (n+2)pi/2 is opposite the old derivative sign from the last witness on the right. Reciprocity then transfers all comparisons to t<−1. With leading signs and quotient at zero, this is strict adjacent interlacing, as in the established root-count lemma.

## Exact constants
The replay checks analytic inequalities only, not rows of the polynomials. JavaScript positive series with directed rational rounding are used for exponentials.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const lo=y=>eb(y)[0],eu=y=>eb(y)[1],pl=q(157,50),pu=q(22,7), d=q(11),D=q(4799),n0=q(4800), sp=q(69), C=q(27,8),A=q(4,5),v=D.div(n0),pi2=pu.sq();
ck(q(620,7).lt(lo(q(9,2))),"log cutoff");
ck(q(12,11).sq().add(q(12,11).mul(eu(o))).lt(q(21,5)),"kernel numerator");
ck(q(2).mul(pu).mul(q(21,10)).mul(q(11,2)).lt(q(73)),"Taylor bound");
ck(q(12,11).mul(pu).lt(q(4)) && eu(q(4)).lt(q(55)),"denominator exponential");
ck(q(300).mul(q(55)).mul(q(164,100)).div(pl).lt(q(10000)),"contour prefactor");
ck(q(10000*62*25200*1000).lt(lo(q(54))),"contour error");
ck(q(5,4).add(q(8,5).div(sp)).sq().add(q(10,4800)).lt(q(164,100)),"rho bound");
ck(q(121,288).mul(q(6)).mul(q(4)).mul(pl.sq()).lt(q(100))&&q(98).lt(q(121,288).mul(q(6)).mul(q(4)).mul(pl.sq())),"short-s radial");
ck(q(10).lt(q(121,288).mul(q(4)).mul(pl.sq()).div(q(164,100))),"long-s radial");
ck(q(10,128).add(q(23,22).mul(o.add(q(10,64*11)))).lt(q(115,100))&&eu(q(115,100)).lt(q(32,10)),"vertical exponential");
ck(q(16,5).mul(q(525,1000)).div(q(331,100)).lt(q(51,100))&&q(331,100).sq().lt(q(11))&&o.lt(q(4,10).sq().mul(two).mul(pl)),"vertical derivative");
ck(q(51,100).mul(two).mul(pu).add(q(2,1000)).lt(q(33,10)),"residue ratio");
ck(q(10000).lt(lo(q(12)))&&q(10000).lt(lo(q(50))),"far-error tails");
ck(q(26).lt(q(8).mul(q(331,100)))&&q(1000).mul(o.add(q(106,100).mul(q(26)))).lt(lo(q(26)).sub(o)),"logistic correction");
ck(q(12,11).sq().mul(o.add(q(10,64*11))).lt(q(11,10).sq()),"pole radius to s");
ck(q(1000).mul(o.add(q(11,10).mul(q(26)))).lt(lo(q(26)).sub(o)),"uniform logistic correction");
ck(q(9).mul(q(62).sq()).lt(q(25,16).mul(q(400*63-1))),"splice s>=3d");
ck(o.add(q(10,33*33)).lt(q(102,100).sq())&&q(2).lt(lo(q(7,10))),"splice incomplete gamma");
ck(q(2000).lt(lo(q(77,100).mul(d)))&&q(2).lt(lo(q(49,100).mul(q(33)))),"splice G small");

const F=q(999,1000),eta=q(463,1000),lambda=q(493,1000),alpha=q(31,100),x3=q(14,10000),pk=q(45,100),sk=q(346,100);
ck(q(9,10).sq().mul(q(63,400)).lt(q(3,8).sq())&&q(8,3).lt(lo(o))&&q(1000).lt(lo(q(8))),"heavy good-label bound");
ck(sk.sq().lt(q(12))&&q(12).mul(eu(q(1,6*4799))).lt(pk.sq().mul(two).mul(pl).mul(q(99,100)).mul(q(11))),"Robbins peak");
ck(o.div(eta).lt(lo(o.div(A.sq()).mul(q(1,2).sub(q(1,165))))),"initial pure loss");
ck(o.div(x3).lt(lo(q(9).div(two.mul(A.sq())).mul(q(55,58)))),"third witness ratio");
ck(q(1000).lt(lo(D.div(q(2*16*17))))&&eta.mul(q(17,16)).div(F).lt(lambda)&&q(81,16).div(lambda).lt(lo(v.mul(sp).mul(q(5,36)))),"outward ratios");
ck(o.div(F.sq().mul(alpha).mul(o.sub(alpha))).lt(lo(o.div(A.sq()))),"curvature");
const z=o.sub(eta.sq());
ck(two.div(F).mul(eta.add(x3.mul(q(19,16).div(z).add(eta.sq().div(q(8).mul(z.sq())))))).lt(o),"opposing witness");
const ex0=q(266,100),C2=q(446,100),small=q(1,1000);
ck(ex0.lt(q(8,3).mul(v))&&q(20).lt(q(166,100).mul(q(12)).add(o)),"small drift spacing");
ck(C.div(v).mul(ex0).mul(pk).div(sk).mul(em(q(66,100).mul(q(11)))).div(o.sub(em(q(20)))).lt(small),"small drift value");
ck(q(7000,640).lt(lo(q(299,1000).mul(q(12)))),"remaining heavy drift");
const dd=q(64,100),db=q(93,100000);
ck(q(4).div(o.sub(o.div(q(978,100)))).lt(C2)&&C2.mul(A.div(sp).add(pk.div(sk))).lt(dd)&&C2.div(n0).lt(db),"large drift values");
const w=o.sub(lambda.sq()),u=o.sub(lambda);let v5=o;for(let j=0;j<5;j++)v5=v5.mul(lambda);
const late=alpha.mul(v5).mul(dd.add(q(6).mul(db)).div(u).add(db.mul(lambda).div(u.sq())));
ck(two.mul(alpha).add(small).add(alpha.mul(lambda).mul(small).div(w)).add(alpha.mul(small).div(w)).add(late).lt(o.sub(alpha)),"signed mean");
ck(o.div(A.sq()).div(o.sub(o.div(A.mul(sp)))).lt(q(8,5)),"floor bound");
ck(two.mul(A).div(sp).lt(q(1,32))&&q(10,3).mul(A.sq()).mul(A).mul(q(4801,4799)).div(sp).lt(q(1,32)),"splice phase");
```
