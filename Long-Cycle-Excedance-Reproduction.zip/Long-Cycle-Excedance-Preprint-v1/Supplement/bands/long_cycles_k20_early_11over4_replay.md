# Early proof at k≥20 through n≤11k/4

Exact BigInt rational checks with directed exponential rounding. Use text(value) or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=20,sk=q(447,100),lo=x=>eb(x)[0];
ck(sk.sq().lt(q(K)),"sqrt k");
for(const [N,H,D,n,sd,alpha,d,slope] of [
 [q(9,4),q(9,4),q(38),q(39),q(616,100),q(105,1000),q(482,1000),q(58,1000)],
 [q(5,2),q(5,2),q(45),q(46),q(67,10),q(132,1000),q(517,1000),q(55,1000)],
]){
 ck(sd.sq().lt(D)&&q(36).lt(D),"floor scale");
 const eta=q(195,1000),l2=q(52,1000),eta3=q(13,100000);
 const loss=q(2).sub(q(4,9)).add(q(1,9)).sub(q(4,135));
 ck(o.div(eta).lt(lo(loss))&&H.mul(eta).lt(q(1,2)),"first ratio");
 ck(H.div(l2).lt(lo(q(39,10)))&&H.div(l2).lt(lo(q(6))),"second ratio");
 ck(H.sq().div(alpha.mul(o.sub(alpha))).lt(lo(q(4))),"curvature");
 ck(o.div(eta3).lt(lo(q(9)))&&two.mul(H).mul(eta.add(eta3.div(o.sub(eta.sq())))).lt(o),"witness");
 const peak=q(59,100);
 ck(q(K).mul(ex(o.div(q(6).mul(D)))).lt(peak.sq().mul(pl).mul(q(K-1))),"modal mass");
 ck(H.mul(q(1,2).div(sd).add(peak.div(sk))).lt(d)&&H.div(n).lt(slope),"drift");
 const z=o.sub(l2.sq());
 const lc=alpha.mul(l2).mul(d).div(z);
 const rc=alpha.mul(d.add(slope)).add(alpha.mul(l2.sq()).mul(d.add(q(3).mul(slope)).div(z).add(two.mul(slope).mul(l2.sq()).div(z.sq()))));
 ck(two.mul(alpha).add(d).add(lc).add(rc).lt(o.sub(alpha)),"signed margin");
 ck(q(1,2).div(sd).lt(q(1,8))&&q(10,3).mul(q(1,8)).mul(n.div(D)).div(sd).lt(q(1,8)),"phase splice");
}
for(const [B,N,av] of [[q(2),q(9,4),q(394,100)],[q(9,4),q(5,2),q(416,100)],[q(5,2),q(11,4),q(436,100)]]){
 const m0=Math.floor((K-1)/2),b=q(4).mul(pl.sq()).div(av.sq().mul(q(K)).add(q(10)));
 ck(q(2).lt(b.mul(q(m0*25**2-312))),"lattice decreasing");
 const rr=o.add(av.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"radius");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,w){
  let z=q(0);
  for(let l=1;l<=12;l++)z=z.add(w(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const f=lat(m0,l=>q(2*l+1)),h=lat(m0,l=>o),g=lat(Math.floor(B.val()*K/2),l=>q(2*l+1)),j=lat(Math.floor(B.val()*K/2),l=>o);
 const fj=lat(Math.floor((B.val()-1)*K/2),l=>q(2*l+1));
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h))),u=o.sub(o.div(N.sub(o).add(q(1,K))));
 const P=p.mul(o.div(B.sub(o)).add(u)),W=x.mul(fj.div(B.sub(o)).add(u.mul(f))).add(g),V=W.div(q(3));
 const P0=p.mul(o.add(u)),e=P0.div(q(K)).add(P0.div(B.mul(q(K)))).add(p.div(q(K+1)));
 const c=o.sub(P),dc=R.mul(o.add(j)).div(B);
 ck(q(0).lt(c)&&V.sq().add(W.add(dc).add(e).sq()).lt(c.sq()),"central ellipse");
 ck(V.lt(c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))))),"central slice");
 if(B.val()===2){
  const go=lat(K-1,l=>q(2*l+1)),jo=lat(K-1,l=>o);
  const wo=go.add(x.mul(f)).add(p).add(R.mul(o.add(jo)).div(two));
  ck(go.div(q(3)).sq().add(wo.sq()).lt(o)&&go.div(q(3)).lt(o.sub(pu.div(q(8)).sq().div(two))),"direct two-cycle onset");
 }
 ck(N.mul(q(63,24).sq()).lt(av.sq())&&q(25,4).mul(N).lt(av.sq()),"floor strip");
 text({B:B.val(),N:N.val(),V:V.val(),W:W.val(),P:P.val()});
}
const e=q(105,1000),a=q(31,1000),H=q(11,4),D=q(50),nn=q(51),m=q(3),d=q(526,1000),b=q(55,1000);
const loss=q(1,18).sub(q(1,81)).add(q(1,324)).sub(q(1,1215)); // x=1/3
ck(q(1).div(e).lt(lo(D.mul(loss))),"third band pure ratio");
const l=H.mul(e);
ck(l.lt(q(1,2))&&H.sq().div(a.mul(o.sub(a))).lt(lo(q(50,9))),"third band curvature");
ck(two.mul(H).mul(e).div(o.sub(e.sq())).lt(o),"third band witness");
ck(H.mul(m.div(nn).add(q(59,100).div(sk))).lt(d)&&H.div(nn).lt(b),"third band drift");
const u=o.sub(l.sq());
const t=two.mul(a).add(d).add(a.mul(l).mul(d).div(u)).add(a.mul(d.div(u).add(b.mul(o.add(l.sq())).div(u.sq()))));
ck(t.lt(o.sub(a)),"third band signed margin");

text("All first three intervals passed.");
```
