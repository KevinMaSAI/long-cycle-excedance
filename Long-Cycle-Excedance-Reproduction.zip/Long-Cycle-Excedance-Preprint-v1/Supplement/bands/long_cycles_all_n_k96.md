# Full n coverage for every k≥96

2026-11-27 03:45 UTC block. For all k≥96 and n≥k the genuine E_(n,k) has n−1 simple real roots and its quotient by the common t strictly interlaces the next quotient. This lowers the all-row threshold from 128 to 96. It remains partial relative to the complete mother conjecture. No original polynomial rows are enumerated.

## Bridge construction
The old early theorem through n=3k for k≥96 appears in long_cycles_adaptive_edge_curvature.md. The all-n theorem for k≥128 has already been audited. For the remaining 96≤k≤127, long_cycles_k96_from_12k.md proves every n≥12k, by the improved geometric binomial tails and central bridge through 912k. It remains only to handle 3k≤n≤12k, including adjacent comparisons there. The proof below is a uniform two-regime edge joined to five analytic central intervals.

## Edge, 3≤H=n/k≤12
Set D=n−1≥287, M=floor(.48sqrt(D))≥8 and S=D/M. If r≥ceil H, use the deterministic occupancy cap L=k: A_n(r)>H/3.16, since (3−2/k)/(1−1/(2sqrt(k)))≤(3−2/127)/(1−1/19.4)<3.16. If r≥H/2, use cap L=2k to get A_n(r)>H/4.17. Always 1≤A_n(r)≤H.

For high brackets m≥ceil H, the pure outward ratio is <.137 by loss ≥(.48)^(-2)(1/2−1/24) to the right and ≥1/(2·.48²) to the left. Actual outward ratio ≤.44: use factor 3.16 within plateau, and when the left base drops below ceil H use factor H≤12 with loss D/(2r²)≥(96H−1)/(2H²)≥1151/288. At a root the curvature products are below .155(1−.155) by 3.16² exp(−1/.48²), so α=.155. Witness opposition costs ≤2·3.16·.137/(1−.137²)<1.

For lower brackets m<ceil H, both main indices are ≤H+1. The first right or left pure loss is at least (96H−1)/(2(H+1)(H+2))≥1151/364, hence ratio <.043. For each outgoing denominator r≥H/2 use amplitude factor 4.17; at smaller r use factor at most 12, with the pure loss now at least (96H−1)/(2(H/2)(H/2+1))≥1151/84. The lower bounds in H decrease on [3,12], as direct differentiation verifies. Thus actual outward ratio is below .18. At main curvature r≥H/2 use 4.17² exp[−(96H−1)/(H+1)²]≤4.17² exp(−1151/169), and at r<H/2 use 144 exp(−1151/36); both below .022(1−.022), with alpha=.022. For witnesses m≥H/2 all amplitude ratios from that witness are at most 4.17 and the pure ratio <.043; if m<H/2, the first pure ratio is <.001 by the stronger pure loss, later pure ratios only decrease, and all amplitude ratios relative to the witness are at most 12. Both opposing witness bounds pass, including m=1, whose dominance persists for all s>D.

For drift, the binomial modal mass <.50/sqrt(k) follows from the Robbins bound at p=(k−1)/D, with Dp(1−p)≥2(k−1)/3. At r≥H/2 the beta lattice and cap L=2k yield d_r≤4.17(r/n+.50/sqrt(k)). At r<H/2 the old geometric Markov sum applies with x=D/r≥1.993k: C·(n/D)·1.993<7 even here, so d_r<7 exp(−.2965k)<.001. Thus for r≤M+a the bound is .335+.0145a, using sqrt(D)>16.9 and sqrt(k)>9.7. The signed-mean inequalities pass for both sets of α, λ with .335 on the left. Old derivative and next-row signs are strict and every bracket has its single zero.

The floor correction S≤(25/12)sqrt(n)+5 uses sqrt(D)>16.9. For the phase, the negative cubic discrepancy bound remains below pi/40. The positive linear bound .48/sqrt(D) alone suffices only for D≥369. For 287≤D<369 use y=M/D≥8/369 and y≤.48/16.9<.03. The upper bound atan(pi y)≤pi y−(pi y)^3/3+(pi y)^5/5 gives a correction in phase units of pi at least 3·288·(8/369)^3·.99, since 1−3pi² y²/5>.99. Subtracting this from the linear bound gives <1/40. Thus the old cosine-window splice works down to D=287.

## Center
Reuse the K=96 two-cycle variation, .125/k total tail beyond degree 2k, shorter variation .083/k before degree 3k, and resulting constants ξ=13/16 and .5/L! from long_cycles_k96_from_12k.md. For 3≤n/k≤7 the absolute recent method in long_cycles_all_n_k128.md applies without requiring s≥4sqrt(k); only the numerical constants and baseline K change. In particular in the far bounds use .125x in place of .116x, and the centered diagonal mismatch .5 in place of .464. The same marked-boundary and interior overlap arguments remain valid. For the other ranges use the dual real-part bounds on the positive primary reference: its scalar via vertical translation and, when p<1, exp(−p)(1−p²/2). The cutoff uses the scalar-only angular exclusion. The five exact central intervals are [3,5], [5,7], [7,8], [8,10], [10,12], with a=5.20, 6.06, 6.42, 7.11, 7.74, respectively. The first two use the absolute norm decomposition, the other three the improved tilt α=.70 and L=3. The splice is valid across all intervals and at both end rows, so the early and later theorems give the announced all-n result. Underlying analytic assumptions are uniform in k and n; no per-k polynomial sweep.

## Exact BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=96,sk=q(97,10),A=q(12,25),sd=q(169,10),xi=q(13,16);
const ca=o.sub(q(18,100).sq().div(two));
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log");
ck(q(4,5).lt(q(82,100).mul(ca)),"vertical positive");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(ca).mul(pu.div(q(40))))),"splice rotation");
const C=q(316,100),Ce=q(27,8),D=q(287),n=q(288);
const rows=[[3,520,5,0,0],[5,606,7,0,0],[7,642,8,70,3],[8,711,10,70,3],[10,774,12,70,3]];
let covered=3;
for(const [B,a0,N,tilt0,L] of rows){
 ck(B<=covered,"interval overlap");
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=47;
 ck(two.lt(b.mul(q(m0*25**2-312))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=12;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0);
 const min=(a,b)=>a.lt(b)?a:b;
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2))))),x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(1,2).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 let W,eps,c,slice;
 if(!tilt0){
  const P=two.mul(ex(xi.mul(p)).sub(o)),xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=two.mul(ex(xc).sub(o).sub(xc)).add(q(125,1000).mul(x));
  W=up(high.mul(f).add(x.mul(j)).add(x.mul(ell).div(two)).add(g));
  let atom=o;for(let j=1;j<B;j++)atom=up(atom.mul(p.div(two)).div(q(j)));
  eps=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(P.div(q(K))).add(P.div(q(B*K))));
  c=o.sub(P);
  slice=c.mul(o.sub(pu.div(q(40)).sq().div(two))).sub(P.mul(pu.div(q(40))));
 }else{
  const al=q(tilt0,100),ea=ex(al);
  ck(ea.lt(q(3)),"tail tilt contraction");
  const tail=q(83,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
  const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
  const delta=q(1,2).div(fact(L)),l=lat(L*K/2,0);
  eps=up(ex(xi.mul(p)).sub(o).mul(delta).add(em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o))));
  const far=o.add(delta).mul(em(al)).mul(j).add(two.add(delta).mul(em(al.mul(q(B-1)))).mul(f)).add(em(al.mul(q(B-L))).mul(l));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));
  const ref=q(4,3).div(a.div(sk).add(two));
  const r2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); c=(ref.lt(r2)?r2:ref).sub(eps);slice=q(98,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(tilt0?two.mul(eps):eps);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const s0=a.sub(q(5).div(sk));
 ck(q(0).lt(s0)&&q(N).div(A.sq()).lt(s0.sq()),"join location "+B);
 covered=N;
 text({B,N,a:a.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
ck(covered>=12,"all intervals joined");
text("All exact bounds passed.");

const lo=y=>eb(y)[0];
ck(q(4*96).mul(ex(q(1,6*287))).lt(q(4,3).mul(pl).mul(q(95))),"Stirling peak");
ck(q(3).sub(q(2,127)).div(o.sub(o.div(q(194,10)))).lt(C),"plateau");
const a=q(155,1000),l=q(44,100),e=q(137,1000),loA=q(22,1000),loL=q(18,100),loE=q(43,1000),C2=q(417,100);
ck(o.div(e).lt(lo(o.div(A.sq()).mul(q(1,2).sub(q(1,24))))),"high pure");
ck(C.mul(e).lt(l)&&q(12).div(l).lt(lo(q(1151,288))),"high actual");
ck(C.sq().div(a.mul(o.sub(a))).lt(lo(o.div(A.sq()))),"high curvature");
ck(two.mul(C).mul(e).div(o.sub(e.sq())).lt(o),"high witness");
ck(C2.mul(loE).lt(loL)&&o.div(loE).lt(lo(q(1151,364)))&&q(12).div(loL).lt(lo(q(1151,84))),"low ratios");
ck(C2.sq().div(loA.mul(o.sub(loA))).lt(lo(q(1151,169)))&&q(144).div(loA.mul(o.sub(loA))).lt(lo(q(1151,36))),"low curvature");
ck(two.mul(C2).mul(loE).div(o.sub(loE.sq())).lt(o)&&q(24,1000).div(o.sub(q(1,1000000))).lt(o)&&q(1000).lt(lo(q(1151,84))),"low witness");
const d=q(335,1000),b=q(145,10000);
ck(q(4).div(o.sub(o.div(q(276,10)))).lt(C2)&&C2.mul(A.div(sd).add(o.div(two.mul(sk)))).lt(d)&&C2.div(n).lt(b),"drift");
ck(q(7000).lt(lo(q(2965,10000).mul(q(96)))),"heavy drift");
for(const [aa,ll] of [[a,l],[loA,loL]]){const z=o.sub(ll.sq());ck(two.mul(aa).add(d).add(aa.mul(ll).mul(d).div(z)).add(aa.mul(d.div(z).add(b.mul(o.add(ll.sq())).div(z.sq())))).lt(o.sub(aa)),"signed mean");}
ck(o.div(A.sq()).div(o.sub(o.div(A.mul(sd)))).lt(q(5)),"floor");
ck(q(40).mul(A).sq().lt(q(369)),"phase linear for D>=369");
ck(q(10,3).mul(A.sq()).mul(A).mul(n.div(D)).div(sd).lt(q(1,40)),"phase negative");
const yy=q(8,369),cut=q(3).mul(n).mul(yy.sq()).mul(yy).mul(q(99,100));
ck(q(6).mul(A.div(sd).sq()).lt(q(1,100))&&A.div(sd).sub(cut).lt(q(1,40)),"phase positive at D<369");
```
