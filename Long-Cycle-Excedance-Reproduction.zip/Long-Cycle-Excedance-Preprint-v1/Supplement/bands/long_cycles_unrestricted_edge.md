# Adaptive occupancy edge with no upper bound on n/k
2026-11-27 02:15 UTC. For 256≤k≤1024 and n≥14k put D=n−1, M=floor(.6 sqrt(D)) and S=D/M. The actual excedance polynomial on the edge s≥S has alternating witness signs, one simple root per bracket between witnesses, and the strict next-row signs needed for interlacing. This improves the useful edge cutoff to S≤(5/3)sqrt(n)+2.9 without limiting n/k. This is not a full-row theorem without a matching central estimate. The earlier unrestricted edge at less favorable S is a distinct result.

Use the established positive amplitude A_n(r) with C^(-1) min(r,H)≤A_n(r)≤min(r,H), C=27/8 and H=n/k (deterministic occupancy theorem), and w_r=exp(−rs)r^D A_n(r). Thus A_n(r−1)/A_n(r)≤C and A_n(r+1)/A_n(r)≤C(1+1/r); more generally A_n(m±a)/A_n(m)≤C(1+a/m) when the numerator index is positive. The 02:00 fixed-n profile provides the sharper 1.58 left and 1.15 right whenever the denominator is in [.45 sqrt(n),.8 sqrt(n)].

## 1. Uniform stronger drift
Write d_r=r(A_(n+1)(r)−A_n(r))/A_n(r). The nonnegative beta-lattice identity in the adaptive edge note gives
 d_r ≤ [H/A_n(r)] sum_(a=1)^(r−1) Pr(Bin(D,a/r)=k−1).
When r≥H/2, H/A≤2C. The sharpened peak bound .45/sqrt(k) from the profile lemma applies by n≥14k (it only uses n≥10k,256≤k≤1024). Its unimodal lattice bound has an integral term r/n, yielding d_r≤2C(r/n+.45/sqrt(k)).
For r<H/2 use A≥r/C and apply Markov to 2^(−X) for each binomial mass. With x=D/r one obtains
 d_r ≤ C(n/D)(x/k)·2^(k−1) /(exp(x/2)−1).
Here x≥1.999k, n/D<1.001, and xe^(−x/2) decreases for x≥2. Use exp(x/2)−1≥exp(x/2)/2 and log 2<.7 to get d_r<7 exp(−.2995k)<.001, including the vacuous sum r=1. Combining the two cases gives d_r<.26 throughout r≤M and d_r<.26+.0019a whenever r≤M+a for a≥0, since sqrt(n)>59, sqrt(k)≥16 and n≥3584. This removes the dependence on H which formerly limited the left-tail drift.

## 2. Complete edge verification
Use the adaptive edge lemma on each bracket m+1≤M and at witnesses s=D/m with m≤M. The pure weight log is −rs+D log r. For the right first outward step with base r and s≥D/r, the loss is ≥D/(2r(r+1)) by 1/r−log(1+1/r)=integral_(0)^(1/r) u/(1+u)du. Its sharper expression D/r²(1/2−1/(3r)) suffices for the high range by evaluating the exact loss at M, where it is smallest. The left loss at s≤D/r is ≥D/(2r²). Pure ratios decrease outward.
- High m≥.45 sqrt(n): the pure ratio is <.26, using M≥35 and loss at least (25/9)(1/2−1/105) to the right; to the left the loss is at least 25/18. Until a denominator departs the profile interval use the 1.58 or 1.15 factors. Below the interval left steps have loss at least (3583/3584)/(2·.45²) with amplitude ratio ≤C, and above the interval right steps have loss at least (D/sqrt(n))(5/3−5/4) with ratio ≤1.5C. This gives actual outward λ=.42. Curvature products at the main indices are ≤(1.58)(1.15)e^(−25/9), so at an old zero α_L,α_R≤.132. At a witness first opposing neighbors cost at most 2.73·.26; subsequent odd offsets on both sides cost ≤2C sum_(odd a≥3) .26^a(1+a/27), since m≥27. Total <1.
- Middle 10≤m<.45 sqrt(n): m+1<.467 sqrt(n), m+2<.484 sqrt(n), hence the first pure loss is at least (3583/3584)/(2·.467·.484). Both pure tails have ratio <.112. All left amplitude ratios ≤C, and right ratios ≤12C/11, giving λ=.42. At either main curvature base r≥22 one has P≤C²(23/22) exp[−(3583/3584)/.467²]; when 2≤r<22 use C²(1.5) exp(−3583/21²) instead. Both bounds are below .148(1−.148), so α_L,α_R≤.148. Opposing witness offsets cost ≤2C sum_(odd a≥1) .112^a(1+a/10)<1.
- Low 1≤m≤9: all pure outward ratios <.001 from the loss D/(2·10·11), including at witnesses. Left steps have amplitude ratio ≤C, and right steps ≤1.5C in the bracket (bases ≥2); thus λ and α are bounded by .006. Witness cost ≤2C sum_(odd a≥1) .001^a(1+a)<1; this formula allows a witness main index of 1.

For each regime, alternating witness signs follow. Put d=.26, b=.0019. The left drift is ≤d anywhere and the right drift ≤d+ba. The signed mean calculation gives the next-row sign (−1)^(m+1) at each old zero provided
 2α+d+αλd/(1−λ²)+α[d/(1−λ²)+b(1+λ²)/(1−λ²)²] < 1−α.
All three pairs above pass; the old derivative also has strict sign (−1)^m in s. The endpoint signs and the fact that all zeros inside each bracket have the same strict derivative sign give uniqueness. There are no additional zeros for s>D: at s=D the m=1 dominance argument also holds for s>D, since every ratio w_r/w_1 decreases in s for r>1.

The same floor correction gives S≤(5/3)sqrt(n)+2.9 and |n atan(pi/S)−M pi|<pi/40 from the earlier proof, now with D≥3583 and M≥35, so this can be stitched whenever the central proof reaches S. Reverse checks: right-tail cutoff uses base index, not the incoming index; median D bounds do not assume plateau A≥H/C; the old next-row signs use its own coefficient change, not a derivative approximation. No new complete full-row range claimed here.

## Exact constant replay
This JavaScript is pure BigInt rational arithmetic. Positive exponential Taylor sums supply strict lower bounds, and odd tails use closed-form geometric sums. The replay passed.
```js
let g=(a,b)=>b?g(b,a%b):a<0n?-a:a;
let mk=(a,b=1n)=>{let z=g(a,b);return [a/z,b/z]};
let q=x=>{x=String(x);let [a,b=""]=x.split(".");return mk(BigInt((a||"0")+b),10n**BigInt(b.length))};
let A=(a,b)=>mk(a[0]*b[1]+b[0]*a[1],a[1]*b[1]),N=a=>[-a[0],a[1]],S=(a,b)=>A(a,N(b)),M=(a,b)=>mk(a[0]*b[0],a[1]*b[1]),D=(a,b)=>mk(a[0]*b[1],a[1]*b[0]),L=(a,b)=>a[0]*b[1]<b[0]*a[1],sq=a=>M(a,a);
let plus=(...x)=>x.reduce(A,q(0)), times=(...x)=>x.reduce(M,q(1));
function ex(x){let a=q(1),s=a;for(let j=1;j<=25;++j){a=D(M(a,x),q(j));s=A(s,a)}return s}
const chk=(flag,key)=>{if(!flag)throw Error(key)};
const C=D(q(27),q(8)), v=D(q(3583),q(3584));
let invexp=(x,y,key)=>chk(L(y,ex(x)),key);
invexp(times(D(q(25),q(9)),S(q(".5"),D(q(1),q(105)))),D(q(1),q(".26")),"high outward");
invexp(D(v,times(q(2),q(".467"),q(".484"))),D(q(1),q(".112")),"middle outward");
invexp(D(q(3583),q(220)),q(1000),"low outward");
invexp(D(v,times(q(2),sq(q(".45")))),D(C,q(".42")),"high left");
invexp(times(q(59),v,D(q(5),q(12))),D(times(C,q("1.5")),q(".42")),"high right");
chk(L(times(C,D(q(12),q(11)),q(".112")),q(".42")),"middle actual");
chk(L(times(q("1.58"),q(".26")),q(".42")),"high actual");
let cur=(c,x,a,key)=>invexp(x,D(c,times(a,S(q(1),a))),key);
cur(times(q("1.58"),q("1.15")),D(q(25),q(9)),q(".132"),"high curvature");
cur(times(sq(C),D(q(23),q(22))),D(v,sq(q(".467"))),q(".148"),"middle curvature");
cur(times(sq(C),q("1.5")),D(q(3583),sq(q(21))),q(".148"),"middle small curvature");
function odd(e,m,far){let z=sq(e),u=S(q(1),z), f=D(e,u), h=D(M(e,A(q(1),z)),sq(u)); if(far){f=S(f,e);h=S(h,e)}return times(q(2),C,A(f,D(h,m)))}
chk(L(A(times(q("2.73"),q(".26")),odd(q(".26"),q(27),true)),q(1)),"high witness");
chk(L(odd(q(".112"),q(10),false),q(1)),"middle witness");
chk(L(odd(q(".001"),q(1),false),q(1)),"low witness");
chk(L(times(D(q(27),q(4)),A(D(q(".6"),q(59)),D(q(".45"),q(16)))),q(".26")),"main drift");
chk(L(D(D(q(27),q(4)),q(3584)),q(".0019")),"drift slope");
invexp(times(q(".2995"),q(256)),q(7000),"tiny drift");
for(let [a,l] of [[".132",".42"],[".148",".42"],[".006",".006"]]){
  let x=q(a),z=q(l), h=S(q(1),sq(z)), d=q(".26"), b=q(".0019");
  let leftExtra=D(times(x,z,d),h);
  let rightExtra=M(x,A(D(d,h),D(times(b,A(q(1),sq(z))),sq(h))));
  chk(L(plus(times(q(2),x),d,leftExtra,rightExtra),S(q(1),x)),"signed margin "+a)
}
```
