# Uniform upper rows at k≥16, and a half-sqrt edge for every n≥3k

2026-11-27 06:30 UTC. For all k≥16 and n≥16k the original E_(n,k) has simple real roots and E_(n,k)/t strictly interlaces the next quotient. The calculations need only 16≤k≤23 because k≥24 was already complete. Additionally, over 16≤k≤23 and n≥3k we prove the edge at M=floor(sqrt(n−1)/2), not an all-row conclusion. The central proof for k≥20 is supplied separately. No original row scans.

## Upper wedge n≥16k
Let D=n−1≥255, M=floor(.6sqrt(D)), S=D/M, H=n/k. For r≤.65sqrt(n) binomial good-label occupancy gives A_n(r)>.75r; for r≤.67sqrt(n) gives A_n(r)>.70r. The starting mean ratios to j=k−1 are ≥1.34 and 1.30 respectively from k/(k−1)≥23/22 and the load n≥16k. Use the Robbins peak .47/sqrt(k), with variance≥(15/16)(k−1), multiply the geometric lower-tail prefactor and the cubic Φ exponent bound; both failure tolerances pass. The amplitude upper bound A≤r holds everywhere.

At the first outward steps use pure η=.278 by M≥9 and loss (1/.6²)(1/2−1/27). In window use left factor ≤1/.75 and right ≤(6/5)/.75 for r≥5; for r≤4 use pure loss from D≥255 yielding <.002 and factor (3/2)/.75. Beyond the .65 window use right loss (D/sqrt(n))(5/3−1/.65), absorbing factor (12/11)·27/8 since r≥11. Thus λ=.49. Curvature from exp(−25/9)/.75² yields α=.128. Witness opposition for m≥6 bounded by η geometric, amplitude (1+a/m)/.75; for m≤5 the first pure ratio is below .013, giving strict signs. At s>D the first witness only improves.

At r≥.75H, cap ceil(4k/3) gives H/A<3.75 and beta-lattice drift ≤3.75(r/n+.47/sqrt(k)). For r<.75H, x=D/r≥1.328k, weighted marked-binomial kernel and geometric exponent increase >6 give d_r<.30. This yields generic .584+.0147a for r≤M+a. For r≤.67sqrt(n), the sharper amplitude lower .70r gives H/A≤(n/D)(x/k)/.70; with x≥1.239k, monotone x exp[−(k−1)Phi(x/(k−1))] and geometric spacing >4.8 show d_r<.16. This includes the entire left tail and the first odd right offset because m+2≤M+1≤.67sqrt(n). Charge the later odd right offsets with αλ² and generic drift. The signed margins and witnesses pass. Floor correction S≤(5/3)sqrt(n)+3.11 and arctan phase error <pi/16.

On the central side, at k≥16 the .591/k count peak for m≥2k and .555/k lower count for m≥3k follow from the usual tangent minimum and harmonic head induction. The two-cycle variation <.119/k gives T(2k)<.179/k, T(Lk)<.358/(k L!), ξ=.84, δ=.716/L!, J with .119 in the prior formula. Use harmonic distance, standard weighted endpoint tilt, and ratios baseline 1+δ plus excess .81−δ since all retained ratios <1.81. The old and next primary errors are epsilon as before.

The improved outer reference is much stronger here. On s≥7sqrt(k) use the exact analytic identity P_*(w)=exp(H_(k−1))/w times exp[−sum_b F_d(bw)/b], w=s+i pi, from the real scalar formula and analytic identity theorem, with normally convergent complex sum on Re w>0. F_d(x)=exp(−x)sum_(a≤d)x^a/a!, d=k−1. For real x≥d use F_d(x)≤exp[−dΦ(x/d)] (truncated Poisson Chernoff), and |F_d(bw)|≤exp(d pi²/(2s²)) F_d(bs). For s≥7sqrt(k) the smallest loss dΦ(s/d) occurs at d=22, s=7sqrt(23). Indeed at minimum s for each d its derivative in d is [d/(2(d+1))](s/d−1)−log(s/d)<0 because s/d≤28/15<2 and log(x)≥(x−1)/x. At d=22 we have x>1.52; the cubic log loss gives the bound used in the replay. Loss increases at least .52d per successive b. Geometric summation and exp(5/49) yield |sum F_d(bw)/b|<.17. Since theta<pi/28 and |w|≤1.01 a sqrt(k) when s≤a sqrt(k), Re P_*>1.3 sqrt(k)/a and the pi/16 angular fraction exceeds .87. On 4sqrt(k)≤s≤7sqrt(k) instead use the ordinary .46 vertical log comparison, .48 real fraction and optional sharper direct log bound .79p from segment factor .64; exact moderate strip row. On 0≤s≤4sqrt(k) use the pure absolute bound 2−exp(ξp) in the exact inner row. These strips overlap, and a splice slightly below s=7sqrt(k) is covered by the checked moderate angular window, not by the outer gamma bound.

Eight outer ratio intervals with n/k from 16 to 187 obey all ellipse and splice inequalities, by exact replay. They overlap the independent eventual theorem (either 180k or now 112k for these k). Thus every n≥16k and every adjacent comparison there is proven.

## Half-sqrt edge from n≥3k
For 16≤k≤23, n≥3k set D≥47,M=floor(sqrt(D)/2)≥3. For main bases 4≤r≤M, β=kr/n≤.5sqrt(23/3)<1.39. Then no-singleton and exactly one singleton lower count gives P_r≥.301+.36p_1(r) for r≥5 or .316+(1/3)p_1(4) for r=4: long b≥2 error <.059 at ratio to j=k−1 >1.5 via geometric cutoff, with Robbins .53/sqrt(k) from variance ≥2(k−1)/3. The upper right neighbor is .38+.64p_1(r), and upper left probability at most 1. Their normalized ratios are <3.33,1.86 when r≥5, <2.38,1.97 at r=4. The product is always <4.20. These follow by differentiating the affine quotient (increases) and the squared-denominator quotient (decreases). At r=3, β≤1, long error <.002 because the initial mean ≥2k, and d_(3,2)=1/3, d_(2,2)=1/2 give P_3≥.331+.5p_1(3). With P_4≤.375+.625p_1(3), the normalized ratios <2.02,1.61 and product <3.10 follow the same way, retaining r−1/r on the left. The quantitative differences .625*.331−.5*.375>0 and .625*.331−.375<0 show both monotonicities. For r≤2 use crude amplitude factors.

First left pure eta .136 from D/(2r²)≥2. Right pure .181 at r≥4 from quartic at M4 or cubic at M≥5; at r3 use .132 by D≥47 and at r≤2 use .020. This gives first actual λ=.46. Curvature factors 4.20 exp(−4) at r≥4, 3.10 exp(−47/9) at r=3 and crude below give α=.085 throughout. The paired first opposing witness terms use the separate amplitude ratios above, later odd offsets use C(1+a/m) times pure powers, C=27/8. At m≤2 use .020 and global geometric opposition. Pure first dominance persists past s=D. After a first outward step, the pure right loss ≥3.9 via D≥4M² and M≥3, left ≥6, yielding actual .104 on both sides by the global amplitude cap.

At r≤M use modal beta convolution bounded by 1.15 times its peak, and at r≤M+1 use 1.34 times peak. Indeed beta parameter (k−1)r/D<1.39 for r≤M, and <1.82 for r≤M+1 by exact square comparison. Split by beta into (0,1.15], [1.15,1.3], [1.3,1.45], [1.45,1.60], [1.60,1.72], [1.72,1.82]. Bound the lower singleton index by its left-cutoff mean rate (or at 1 by unity), then bound a≥2 or ≥3 by geometric loss at the upper cutoff, exactly as in the sharper lattice estimates. All comparisons use j≥15 and the explicit Phi bounds (see replay). For r≥.75H use the cap H/A<3.75; then drift at r≤M <.572 and r≤M+1 <.67. Below .75H the parameter x=D/r≥1.305k and weighted marked estimate give d_r<.35. Generic for r≤M+a is .773+.079a. The asymmetric signed proof uses .572 for main and whole left, .67 for right a=1, and starts later odd adverse terms at α*.104²; all margins pass. The edge and next-row signs are strict.

For this floor M=.5, atan gives oriented splice n theta(S)>M pi because (pi²/3)(n/D)(M²/D)<1. The upper difference in units pi is ≤y−3.18 M y²≤1/(12.72M) with y=M/D and D≥47; follows from the fifth-order bound and pi>3.14. In particular phase lies strictly before (M+1)pi. Therefore no separate angular exclusion is required when this edge is paired with a central ellipse. This completes only the edge for n≥3k; the new upper range above already includes all rows n≥16k.

## Upper-band BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log bound");
ck(q(48,100).lt(q(54,100).mul(o.sub(q(46,100).sq().div(two)))),"vertical real fraction");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(o.sub(q(46,100).sq().div(two))).mul(pu.div(q(16))))),"splice angle fraction");
const rows=[[16,16,40,550,5,16,1],[16,16,70,700,5,16,2],[16,16,83,600,5,20,0],[16,20,98,500,5,29,0],[16,29,120,375,7,45,0],[16,45,146,280,7,68,0],[16,68,172,200,7,97,0],[16,97,198,150,10,130,0],[16,130,220,125,10,161,0],[16,161,236,100,10,187,0]];
const covered={16:16};
for(const [K,B,a2,at,L,N,core] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(4);
 ck(!q(K).lt(sk.sq())&&(core||B<=covered[K])&&B>L&&(core||N>covered[K]),"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(119,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(84,100).mul(p)).sub(o).mul(q(716,1000)).div(fact(L)).add(em(alpha.mul(q(Math.round(4*(B-L)),4))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(716,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(q(181,100).mul(em(alpha.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(q(81,100).sub(delta).mul(em(alpha.mul(q(Math.round(4*(B-L)),4)))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(716,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 const ref=core===1?two.sub(ex(q(84,100).mul(p))):core===2?q(4,5).div(a.div(sk).add(two)):q(13,10).mul(sk).div(a); const rp=p.mul(q(79,100));const ref2=core===2&&rp.lt(o)?dn(o.div(ex(rp)).mul(o.sub(rp.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 if(core!==1)ck(V.lt(q(87,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(311,100).div(sk));
 if(!core)ck(q(0).lt(rad)&&q(Math.round(4*N)*25,36).lt(rad.sq()),"splice location");
 if(!core)covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=x=>eb(x)[0],K0=q(16),D=q(255),n=q(256),sk0=q(4),sd=q(159,10),u=q(3,5),reach=q(65,100),wide=q(67,100),pk=q(47,100),C=q(27,8),v=D.div(n);
ck(covered[16]>180,"eventual overlap");
ck(q(1000,591).lt(lo(q(591,1000).sub(q(1,16))))&&q(119,1000).mul(q(3,2)).lt(q(179,1000)),"cycle peak and variation");
ck(o.add(q(694,1000)).add(q(1,62)).lt(q(591,1000).mul(q(47,16)))&&q(16).mul(ex(q(1,6*255))).lt(pk.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(15))),"count and binomial peaks");
ck(pu.div(q(16)).lt(q(1,5))&&q(64,100).sq().mul(q(24,10)).lt(o)&&o.div(q(2).mul(q(64,100))).lt(q(79,100)),"improved core log");
const ml=q(52,100);
const phi=x=>x.sq().div(two).sub(x.sq().mul(x).div(q(3)));
ck(q(152,100).sq().mul(q(22).sq()).lt(q(49*23))&&q(28,15).lt(two),"gamma ratio");
const ps=em(q(22).mul(phi(ml))).div(o.sub(em(q(15).mul(ml))));
const cj=ex(q(5,49)).mul(ps);
ck(cj.lt(q(17,100)),"complex gamma tail");
const ang=q(17,100).add(pu.div(q(28))),co=o.sub(ang.sq().div(two));
ck(o.sub(q(17,100)).mul(co).mul(q(5,3)).div(q(101,100)).lt(q(13,10))===false && o.add(q(10,49*16)).lt(q(101,100).sq()),"outer reference real");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(ang.div(co).mul(pu.div(q(16))))),"outer reference angular");
const F=q(3,4), G0=q(7,10);
for(const [r,w,a] of [[reach,q(134,100),F],[wide,q(13,10),G0]]){
 ck(w.sq().mul(r.sq()).mul(q(23,16)).lt(q(23,22).sq()),"good-label mean");
 ck(pk.div(sk0.mul(o.sub(o.div(w)))).mul(em(q(15).mul(phi(w.sub(o))))).lt(o.sub(a)),"good-label tail");
}
const e=q(278,1000),l=q(49,100),a=q(128,1000);
ck(o.div(e).lt(lo(q(25,9).mul(q(1,2).sub(q(1,27)))))&&q(6,5).div(F).mul(e).lt(l),"high ratios");
ck(q(500).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12)))))&&q(3,2).div(F).div(q(500)).lt(l),"small ratios");
ck(C.mul(q(12,11)).div(l).lt(lo(v.mul(sd).mul(o.div(u).sub(o.div(reach))))),"outward exit");
ck(o.div(F.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(u.sq()))),"curvature bound");
function witness(e,m){const z=o.sub(e.sq());return two.div(F).mul(e.div(z).add(e.mul(o.add(e.sq())).div(q(m).mul(z.sq())))).lt(o);}
ck(witness(e,6)&&q(1000,13).lt(lo(D.div(q(25)).mul(q(1,2).sub(q(1,15)))))&&witness(q(13,1000),1),"opposing witnesses");
const cap=q(375,100), d=q(584,1000),b=q(147,10000),xn=q(1328,1000),xn2=q(1239,1000),dm=q(16,100);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(u.div(sd).add(pk.div(sk0))).lt(d)&&cap.div(n).lt(b),"generic drift");
ck(xn.lt(q(4,3).mul(v))&&q(6).lt(q(328,1000).mul(K0).add(o)),"heavy drift spacing");
ck(C.div(v).mul(xn).mul(pk).div(sk0).mul(em(q(15).mul(phi(q(328,1000))))).div(o.sub(em(q(6)))).lt(q(30,100)),"heavy drift");
ck(xn2.sq().mul(wide.sq()).mul(q(23,16)).lt(v.sq())&&q(48,10).lt(q(239,1000).mul(q(16)).add(o))&&o.lt(wide.sub(u).mul(q(16))),"near drift window");
ck(o.div(G0.mul(v)).mul(xn2).mul(pk).div(sk0).mul(em(q(15).mul(phi(q(239,1000))))).div(o.sub(em(q(48,10)))).lt(dm),"near drift");
const z=o.sub(l.sq()),tail=d.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l.sq()).div(z.sq()));
ck(two.mul(a).add(dm).add(a.mul(l).mul(dm).div(z)).add(a.mul(dm)).add(a.mul(l.sq()).mul(tail)).lt(o.sub(a)),"signed mean margin");
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sd)))).lt(q(311,100))&&u.div(sd).lt(q(1,16))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sd)).lt(q(1,16)),"floor splice");
```

## Edge replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}



const lo=x=>eb(x)[0], C=q(27,8),pk=q(53,100),K=q(16),sk=q(4),pl=q(157,50),D=q(47),n=q(48),sd=q(685,100),v=D.div(n);
ck(K.mul(ex(q(1,6*47))).lt(pk.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(15))),"Robbins peak");
ck(q(23,12).lt(q(139,100).sq())&&q(3,2).lt(q(2).mul(q(23,22)).div(q(139,100))),"main mean");
const phip=z=>z.sq().div(two).sub(z.sq().mul(z).div(q(3))), phim=z=>z.sq().div(two).add(z.sq().mul(z).div(q(3)));
const geom=(x,y)=>x.div(o.sub(y));
const long=pk.div(sk.mul(o.sub(q(2,3)))).mul(geom(em(q(15).mul(phip(q(1,2)))),em(q(15,4)))).div(two);
ck(long.lt(q(59,1000))&&pk.div(sk.mul(q(1,2))).mul(geom(em(q(45,10)),em(q(75,10)))).div(two).lt(q(2,1000)),"long union");

const hb=q(38,100),pj=q(64,100);
for(const [a,b,lf,rf,pr,L,R] of [[q(301,1000),q(36,100),o,q(6,5),o,q(333,100),q(186,100)],[q(316,1000),q(1,3),q(3,4),q(5,4),q(15,16),q(238,100),q(197,100)]]){
 ck(pj.mul(a).lt(two.mul(b).mul(hb))&&hb.mul(b).lt(pj.mul(a)),"monotone ratios");
 ck(lf.div(a).lt(L)&&rf.mul(hb.add(pj)).div(a.add(b)).lt(R)&&pr.mul(hb).div(a.sq()).lt(q(420,100)),"r≥4 ratios");
}
const pr=q(331,1000),p3=q(375,1000),a3=q(625,1000);
ck(q(2,3).div(pr).lt(q(202,100))&&q(4,3).mul(o.div(pr.add(q(1,2)))).lt(q(161,100)),"r=3 ratios");
ck(a3.mul(pr).lt(p3)&&q(8,9).mul(p3).div(pr.sq()).lt(q(31,10)),"r=3 curvature factor");
const eL=q(136,1000),eR=q(181,1000),e3=q(132,1000),e2=q(20,1000),l=q(46,100),l2=q(104,1000),a=q(85,1000);
ck(o.div(eL).lt(lo(q(2)))&&o.div(eR).lt(lo(q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80))))&&o.div(eR).lt(lo(q(2).sub(q(4,15)))),"first pure high");
ck(o.div(e3).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&o.div(e2).lt(lo(D.div(q(4)).mul(q(1,2).sub(q(1,6))))),"pure low");
ck(q(333,100).mul(eL).lt(l)&&q(197,100).mul(eR).lt(l)&&q(161,100).mul(e3).lt(l)&&C.mul(q(3,2)).mul(e2).lt(l),"first ratios");
ck(C.mul(q(3,2)).div(l2).lt(lo(q(39,10)))&&C.div(l2).lt(lo(q(6))),"steep second");
const zc=a.mul(o.sub(a));
ck(q(420,100).div(zc).lt(lo(q(4)))&&q(31,10).div(zc).lt(lo(D.div(q(9))))&&C.sq().mul(q(3,2)).div(zc).lt(lo(D.div(q(4)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R,e,m] of [[q(333,100),q(186,100),eR,5],[q(238,100),q(197,100),eR,4],[q(202,100),q(161,100),e3,3]])ck(L.mul(eL).add(R.mul(e)).add(cost(e,m,true)).lt(o),"opposing witnesses");
ck(cost(e2,1,false).lt(o),"small witness");
function nlow(w){return em(q(15).mul(phim(o.sub(w))));}
function nhigh(w){return em(q(15).mul(phip(w.sub(o))));}
function tail(j,beta){return geom(nhigh(q(j).div(beta)),em(q(15).mul(o.div(beta).sub(q(1,j)))));}
ck(q(139,100).lt(q(145,100))&&q(1,2).add(o.div(sd)).sq().mul(q(23)).div(q(3).sub(q(1,16))).lt(q(182,100).sq()),"lattice beta ranges");
const s1=q(115,100),s2=q(134,100);
ck(o.add(tail(2,q(115,100))).lt(s1),"lattice 1");
ck(nlow(q(20,23)).add(tail(2,q(13,10))).lt(s1),"lattice 2");
ck(nlow(q(10,13)).add(tail(2,q(145,100))).lt(s1),"lattice 3");
for(const [x,y] of [[q(145,100),q(16,10)],[q(16,10),q(172,100)],[q(172,100),q(182,100)]])ck(nlow(o.div(x)).add(nhigh(q(2).div(y))).add(tail(3,y)).lt(s2),"lattice 4–6");
const cap=q(375,100),d=q(572,1000),right=q(67,100),dt=q(773,1000),b=q(79,1000),xx=q(1305,1000);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(pk).mul(s1).div(sk).lt(d)&&cap.mul(pk).mul(s2).div(sk).lt(right),"near drift");
ck(cap.mul(q(1,2).div(sd).add(pk.div(sk))).lt(dt)&&cap.div(n).lt(b),"outer drift");
ck(xx.lt(q(4,3).mul(v))&&C.div(v).mul(xx).mul(pk).div(sk).mul(geom(nhigh(xx),em(q(5)))).lt(q(35,100)),"heavy drift");
const z=o.sub(l2.sq()),later=dt.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l2.sq()).div(z.sq()));
ck(two.mul(a).add(d).add(a.mul(l2).mul(d).div(z)).add(a.mul(right)).add(a.mul(l2.sq()).mul(later)).lt(o.sub(a)),"signed comparison");
ck(q(10,3).mul(q(48,47)).div(q(4)).lt(o)&&q(318,100).lt(pl.sq().div(q(3)).mul(o.sub(q(6,4*47)))),"oriented phase");
```
