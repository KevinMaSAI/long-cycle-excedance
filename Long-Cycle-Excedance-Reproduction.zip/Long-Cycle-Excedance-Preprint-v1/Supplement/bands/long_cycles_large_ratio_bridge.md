# Verified bridge through high n/k ratios for k≥256

2026-11-27 02:28 UTC Dreamer derivation, independently audited by the parent. Concerns the original excedance polynomials, not an approximation or different cycle restriction.

### Complete bands extend well past the previous n≤40k frontier

For each row n in the following bands, E_(n,k) has n−1 simple real roots and its quotient by t strictly interlaces the next quotient, including the final pair.

| Minimum k | Complete range of old n |
|---:|---:|
| 256 | k≤n≤629k |
| 512 | k≤n≤931k |
| 704 | k≤n≤1104k |

For k≥1024 the separate all-row theorem already applies. For smaller k in the table, the new argument joins the unrestricted occupancy edge to a central estimate using the positive real scalar reference and an adjustable exponential tilt. Earlier complete bands end at 19k, 32k and 40k respectively, as reported to the user at 01:50 UTC. The 27 rows in the replay are overlapping analytic intervals with explicit bounds, each valid for all integer k and n in its interval. No polynomial rows are enumerated. The full conjecture remains open. [Central pole identities and scalar formula](long_cycles_tilted_anchor_band.md) · [Unrestricted occupancy edge](long_cycles_unrestricted_edge.md) · [Exact interval replay](long_cycles_large_ratio_exact_replay.md).

**Sharper lower bound for the primary reference.** Use the existing identity P_*(s)=exp(H_(k−1)) c(s)/s, with c(s)≥s/(s+2k). For k≥10, H_(k−1)−log k increases, and exp(H_9)>50/3, so P_*(s)≥(5/3)k/(s+2k). The proved vertical translation has |log P_*(s+πi)−log P_*(s)|<.11 for k≥256, s≥4√k. Therefore Re P_*(s+πi)>.88 P_*(s) and |Im P_*(s+πi)|≤tan(.11) Re P_*(s+πi). On a strip s≤a√k with k≥K and lower square-root constant u_K≤√K, use c_ref=(22/15)/(a/u_K+2). For distance at most π/40 from a cosine witness, the signed real part after rotation is ≥.98 c_ref, by cos(π/40)−tan(.11)sin(π/40)>.98. This remains effective as a increases. For 0≤s≤4√k the previous central sign theorem already applies because n≥19k in all new intervals.

**Adjust the coefficient tilt to the row interval.** Use n≥Bk, choose integer L<B and 0<α<log 2, and put R_t=exp(α/k). Separating Δ_k=1/k, the remaining unweighted prefix mass is less than 1/(2k) between degrees k+1 and 2k−1. The tail recurrence never uses Δ_k and induces a factor at most exp(α)/2 in the tilted norm. Thus ||δ||_(R_t)≤2J/k with
    J=[exp(α)+exp(2α)/(2−exp(α))]/2.
Write ρ=√(s²+π²), use R>ρ/(π k), and let p=R(1+3h/2), x=R(3/2+4h/3), where h is the unweighted far half-lattice at exponent k−1. Then the prior anchor geometry gives norms of each B_i at radius 1 at most exp(p)−1 or exp(x)−1 for primary or far anchors. Their tilted norms are exp(Jp)−1 or exp(Jx)−1.

On primary anchors evaluate the tilted series against the finite prefix. For b≤N−Lk, N=n or n+1, the relative count difference is ≤6/L! by the single telescoping tail T(Lk) and d_N≥1/(2k−1). For b>N−Lk the relative difference is at most 1, also for an omitted coefficient because the finite prefix only uses n−b≥k. Thus both |C_N−P_*| are at most
    ε=(exp(p)−1)·6/L!+exp[−α(B−L)](exp(Jp)−1).
The primary adjacent drift is at most 2ε.

For a far anchor with q modulus η, the factor η^(n−b)R_t^(−b) is log-affine in b. For k≤b≤n+1−k use the sum of its endpoint bounds η^((B−1)k)exp(−α)+η^(k−1)exp[−α(B−1)]. If f,j,g bound the weighted far half-lattices of exponents k−1,(B−1)k,Bk, then
    W=2(exp(Jx)−1)[exp(−α)j+exp(−α(B−1))f]+g,  V=W/3.
These bound the far centered and value terms. The diagonal mismatch still costs at most 6R(1+g/3)/[B(B−1)!] by the exact count recurrence and (n+1)sin θ>B/R. The common ellipse criterion is V²+[W+2ε+mismatch]²<(c_ref−ε)² with c_ref>ε. It forces next-row sign −sin(nθ) at an old central zero because Re C_n>c_ref−ε. The witness exclusion uses V<.98 c_ref−ε.

**Exact lattice and splice bounds.** For each (K,B,a,α,L,N) in the linked replay, take b=4(157/50)²/(a²K+10), and compare the actual lattices to sums of (1+b l(l+1))^(−m) at K by monotonicity in k. Low exponent uses m=floor((K−1)/2), high exponents use m=(B−1)K/2 and BK/2. Sum the first 16 levels. The weighted summand decreases from 16 since b[m·33²−544]>2. Its remaining integral is 1/[b(m−1)(1+272b)^(m−1)], and the unweighted tail is bounded by this divided by 33. For directed exponent bounds use log(1+z)≥2z/(2+z), then rational exponential sums with interval rounding. The replay verifies both central inequalities throughout every strip, and (25/9)N<(a−2.9/u_K)² to ensure S≤(5/3)√n+2.9<a√k for n≤Nk. The unrestricted edge furnishes witnesses up to its split M and proves its phase deviation from Mπ is <π/40. Use the central exclusion near Mπ and the inherited parity, reciprocal pairing and degree exhaustion to recover strict interlacing. Every interval starts at or before the previous covered ratio. The earlier 19k, 32k and 40k bands start the three chains.


## Reverse audit

The scalar lower bound can be checked directly without the earlier occupancy lower bound. If G is Gamma(k,1) and B_s=ceil(G/s), then −log c(s)=E H_(B_s−1). For every integer b≥1, H_(b−1)≤log(2b−1): it is equality at b=1 and log[(2b+1)/(2b−1)]=2 artanh(1/(2b))≥1/b. Jensen and E B_s≤1+k/s give −log c(s)≤log(1+2k/s). Further, H_k−log(k+1)−[H_(k−1)−log k]=1/k−log(1+1/k)>0. The exact harmonic lower bound at k=10 yields exp(H_(k−1))>(5/3)k. See long_cycles_tilted_anchor_band.md for the derivation of the exact scalar identity and the vertical estimate omitting j=0.

Tilt audit: the initial mass of |Δ_(k+j)| for 1≤j<k is 1/k−1/(2k−1)<1/(2k), since d_m=1/m for k≤m<2k. For a≥2k only j=a−k+1,...,a−1 appear, so the atom at k is absent and each summand in the summed tilted recurrence is charged at most (k−1)exp(α)/(2k)<exp(α)/2. In the primary tail d_(N−b)/d_N lies between 0 and 2 for finite retained terms and is 0 if omitted; hence the error relative to 1 is at most 1. At the upper centered boundary b=n+1−k the power of |q_i| is exactly k−1; at b=k it is n−k. A far level has weight ≥3, yielding the independent unweighted value bound W/3 (same envelope), not an inference from the signed centered error. For lattice monotonicity differentiate (k−c)log(1+C/(a²k+10)) with c=0 or 1 and use log(1+x)≥x/(1+x). Thus the baseline K dominates both absolute and weighted lattices. The weighted tail integral follows by u=1+b x(x+1). The smaller unweighted integral is bounded by dividing the weighted integrand by 33 for x≥16.

Interlacing sign audit: write the primary amplitude for the old row as C_n=x+iy, x≥c_ref−ε, and let φ=nθ. The two rotated primary components are f=x cos φ+y sin φ and g=y cos φ−x sin φ, and x=f cos φ−g sin φ. At a zero of the old row, |f|≤V. With w=W+2ε+mismatch, a wrong or zero next-row sign would imply x≤V|cos φ|+w|sin φ|≤√(V²+w²), contradiction (and the same identity excludes sin φ=0). The separate exclusion bound holds throughout the pi/40 windows, providing the splice. The upper bound n≤Nk controls only S of this row, not the adjacent comparison; the next row is evaluated directly with N=n+1 in the identity. The last adjacent pair therefore needs no extra upper hypothesis. For s≤4√k use the earlier independently audited near-primary region, whose lower threshold n≥6k holds. For k≥1024 use the separate all-row result. No individual E-polynomial tests enter the certificate.

The parent re-executed every exact check in the following replay. All 27 interval and splice inequalities passed. Remaining ranges, including smaller k and higher n/k before the separate eventual estimate, are not covered here.

# Exact replay for the extended long-cycle ratio bands

The rows are analytic parameter intervals, each covering all integer k and n in its stated band. Arithmetic uses BigInt rationals with directed rounding for exponential bounds. A floating-point square-root estimate proposes R and exact squaring verifies it. The text function only prints diagnostics.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(508)).mul(ex(q(5,16)).sq()).lt(q(11,100).sq()),"vertical log bound");
ck(q(22,25).lt(q(89,100).mul(o.sub(q(11,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(11,100).div(o.sub(q(11,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[
 [256,19,23,400,6,46],[256,46,35,225,8,107],[256,107,48,125,10,204],
 [256,204,60,75,12,320],[256,320,69,50,12,423],[256,423,75,40,14,501],
 [512,32,33,250,8,96],[512,96,50,125,10,222],[512,222,66,75,12,388],
 [512,388,79,40,12,557],[512,557,88,30,14,692],[512,692,94,30,14,790],
 [704,40,37,225,8,121],[704,121,56,100,10,279],[704,279,74,50,12,489],
 [704,489,88,40,14,693],[704,693,98,30,14,860],[704,860,104,25,14,969],
 [256,501,79,40,14,556],[256,556,82,35,14,599],[256,599,84,35,14,629],
 [512,790,98,25,14,859],[512,859,100,25,16,895],[512,895,102,25,16,931],
 [704,969,108,20,14,1045],[704,1045,110,20,14,1084],[704,1084,111,20,16,1104],
];
const covered={256:19,512:32,704:40};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({256:16,512:22,704:26}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,w){
  let z=q(0);
  for(let l=1;l<=16;l++)z=z.add(q(w?2*l+1:1).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(272))).div(b.mul(q((m-1)*(w?1:33))))));
 }
 const f=lat(m0,true),h=lat(m0,false),j=lat((B-1)*K/2,true),g=lat(B*K/2,true);
 const p=up(R.mul(o.add(q(3,2).mul(h)))),x=up(R.mul(q(3,2).add(q(4,3).mul(h))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const W=up(q(2).mul(ex(tilt.mul(x)).sub(o)).mul(em(alpha).mul(j).add(em(alpha.mul(q(B-1))).mul(f))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(22,15).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(29,10).div(sk));
 ck(q(0).lt(rad)&&q(25*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

```

