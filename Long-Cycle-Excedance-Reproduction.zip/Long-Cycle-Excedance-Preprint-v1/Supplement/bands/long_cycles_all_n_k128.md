# Full n coverage for every k≥128

2026-11-27 03:28 UTC Computational proof checkpoint; the estimates and exact replay are given below. Original excedance polynomial only. No claim for the complete mother conjecture.

### The all-row threshold drops from k=256 to k=128

For every integer k≥128 and n≥k, E_(n,k)(t) has n−1 simple real roots and E_(n,k)(t)/t strictly interlaces the next quotient. The new proof supplies all 3k≤n≤14k, including both endpoints as old rows in adjacent pairs. It joins the audited early theorem k≤n≤3k for k≥96 and the 03:15 UTC theorem n≥14k for k≥128. This settles every n in the previously missing 128≤k<256 band. Smaller k remain open in general. [Early theorem](long_cycles_adaptive_edge_curvature.md) · [Upper theorem](long_cycles_two_sensitive_sizes.md) · [Exact replay](long_cycles_all_n_k128_exact_replay.md).

**A smaller coefficient tail from the two-cycle band.** Write Δ_j=d_j−d_(j−1), T(J)=sum_(j≥J)|Δ_j|, with d_j the normalized long-cycle counts. For 2k≤j≤3k−1, put x=(j−k)/k. Then k d_j≤[1+1/k+log x]/(1+x)<.570. The second inequality follows by minimizing .570(1+x)−1−1/k−log x at x=100/57 and verifying exp(.570−1/128)>100/57. On this interval the sign of Δ_j changes at most once from positive to negative: it is the sign of
    (k−1)/(j−k)−sum_(a=k)^(j−k−1)1/a,
which decreases in j. Also d_(2k−1)>.500/k and d_(3k−1)≥(1+log 2)/(3k−1)>.563/k. Thus T(2k)−T(3k)<.077/k. For j≥3k the Δ recurrence uses only preceding indices ≥2k and gives T(3k)≤T(2k)/3 by summing multiplicities. Consequently T(2k)<.116/k and T(Lk)<.232/(k L!) for integer L≥2 by successive contractions. The unweighted norm is <1.616/k, because the atom is 1/k and degrees k+1 through 2k−1 have mass <.5/k. At radius exp(α/k), summing the recurrence from 3k gives norm ≤2J/k with
    J=[e^α+e^(2α)/2+.077e^(3α)/(1−e^α/3)]/2,   e^α<3.
The tail factor e^α/3 is what permits the stronger tilts below.

**Central signs in six overlapping intervals.** Use the established anchor prefix identities and harmonic distance. Let p,x bound the primary and far factor-norm sums in the old 2/k units, with both the harmonic and earlier unweighted lattice bounds available. Let f,j,g be the weighted far half-lattices at powers k−1,(B−1)k,Bk for n≥Bk. Set ξ=.808 and use `||B_i||_1≤exp(ξp)−1` at a primary. The centered diagonal mismatch is ≤.464 R(1+g/3)/[B(B−1)!] by the improved T((B−1)k) and (n+1)sin θ>B/R.

| n/k interval | Strip s≤a√k | α | L |
|---|---:|---:|---:|
| [3,5] | 5.10 | absolute norm | — |
| [5,7] | 6.00 | absolute norm | — |
| [7,8] | 6.40 | .70 | 3 |
| [8,10] | 7.10 | .75 | 3 |
| [10,12] | 7.70 | .75 | 4 |
| [12,14] | 8.25 | .80 | 4 |

In the first two intervals let P=2(exp(ξp)−1), c=1−P and let ℓ bound the weighted lattice at power (B−2)k. The far centered budget is
    W=[2(exp(ξx)−1−ξx)+.116x]f+xj+xℓ/2+g.
The bracket retains the nonlinear absolute product and the small mass T(2k) after the atom and the 1/a prefix are removed. The two prefix pieces get exponents (B−1)k and (B−2)k. The primary adjacent drift is bounded by the earlier marked tail and boundary-atom calculation, namely p exp(p)/(K+1)+2(p/2)^(B−1)exp(p/2)/(B−1)!+P/K+P/(BK), with K=128. The final term uses relative count drift <1/(n+1).

For the other intervals use the positive scalar reference, with c_ref=(4/3)/(a/11.3+2), by exp(H_(k−1))≥5k/3 and the .18 vertical log bound for s≥4√k. For smaller s reuse the proved inner strip. Set δ=.464/L!. The primary errors are at most ε=(exp(ξp)−1)δ+exp(−α(B−L))(exp(Jp)−1), by the refined single telescoping tail. The harmonic endpoint bound gives
    W=(exp(Jx)−1)[(1+δ)e^(−α)j+(2+δ)e^(−α(B−1))f+e^(−α(B−L)) f_L]+g,
where f_L is weighted at exponent Lk. Use c=c_ref−ε and adjacent primary drift 2ε. The replay checks (W/3)²+(W+drift+mismatch)²<c² for all six intervals. It also checks the corresponding splice exclusion, using c(1−π²/3200)−Pπ/40 for the absolute proof or .98 c_ref−ε for the tilted proof. The rational lattice sums use twelve terms and a decreasing integral, with each coefficient bounded using log(1+u)≥2u/(2+u). Hence central witnesses have cosine signs and old zeros have next-row sign −sin(nθ). [Anchor formulas](long_cycles_tilted_anchor_band.md) · [Harmonic endpoint refinement](long_cycles_harmonic_anchor_bridge.md).

**A common edge bound on 3≤H=n/k≤14.** Put D=n−1≥383, M=floor(.48√D), S=D/M. At r≥ceil H the cap k gives A_n(r)>H/3.15. For bracket m≥ceil H, M≥9, the first right pure loss is at least (1/.48²)(1/2−1/27), and the left loss is at least 1/(2·.48²). Ratios improve outward. Use η=.135 and actual λ=.426. Descending below the plateau, a left denominator r≤H gives loss ≥(128H−1)/(2H²)≥1791/392, absorbing factor H≤14. Curvature ≤3.15² exp(−1/.48²)<.155(.845) gives α=.155 at old roots. Witness opposition uses 2·3.15η/(1−η²)<1.

For m<ceil H both main indices are ≤H+1. The correlated bound for actual outward ratios is at most H exp(−(128H−1)/(2(H+1)(H+2))). This increases with H≥3 and is <.34 at 14. The pure ratio is <.025. The curvature bound H² exp(−(128H−1)/(H+1)²) also increases and is <.076(.924) at 14, so α=.076. The opposing witness bound 2·.34/(1−.025²) passes.

For drift, use the exact beta lattice, now with binomial modal mass <.50/√k from the Stirling remainder bound. At p=(k−1)/D the variance is ≥2(k−1)/3 and the modal bound is exp(1/(12D))/√(2π Dp(1−p)), which suffices already at k=128. If r≥H/2 the deterministic min(r,H) lower bound gives D_r≤(27/4)(r/n+.50/√k). For r<H/2 the geometric Markov argument yields D_r<7exp(−.297k)<.001 since D/r≥1.994k. Small brackets therefore use drift .370+.018b at distance b from a main index. Large brackets use .218+.0083b for the main left and right, by the plateau, and .466 for the whole left. The generic and even-left/odd-right signed margins both pass with the listed α and λ. All old edge zeros have the required next-row sign. [Beta lattice and signed margins](long_cycles_adaptive_edge_curvature.md) · [Geometric Markov proof](long_cycles_unrestricted_edge.md) · [Robbins's Stirling bounds](https://dornsife.usc.edu/sergey-lototsky/wp-content/uploads/sites/211/2024/02/Stirling-Robbins.pdf).

**Exact joins.** The floor gives S≤(25/12)√n+4.9, and |n atan(π/S)/π−M|<1/40 by separate linear and cubic bounds at D≥383. For each interval the replay verifies S<a√k up to its right endpoint, so the phase exclusion handles the short joining slice. The edge witnesses up to M and the central witnesses through floor(n/2), then inversion, parity and the simple zero at zero, exhaust the degree. The strict next-row signs give interlacing. At n=14k the new proof includes the adjacent comparison, and the established n≥14k theorem provides continued coverage.


## Independent reverse audit

The one-turn sign follows from jΔ_j=d_(j−k)−d_(j−1) and the exact two-cycle formula j d_j=1+sum_(a=k)^(j−k)1/a for 2k≤j≤3k−1. Its upper integral bound includes the first 1/k term; the right endpoint lower sum is at least log 2 by the decreasing left Riemann sum. The sign can only change + to − on the band, so its variation is at most twice the bound on the maximum minus both actual endpoints (including d_(2k−1)). The tail contractions sum a finite recurrence first: each coefficient on a preceding block is used at most k−1 times with denominator at least Lk (tilt multiplies by at most exp(α)), so T(Lk)≤T((L−1)k)/L, L≥3, and the same bound applies in the weighted recurrence from 3k. There is no assumption about root structure or convergence outside what this contraction gives.

In the two short central ranges the linear term in the absolute product divides into the atom at degree k, the subsequent single-cycle coefficient mass <.5/k below degree 2k, and .116/k thereafter. Their pole powers n−k, n−2k, k−1 yield the stated weights; all nonlinear products have total absolute sum ≤exp(ξx)−1−ξx. Both value and centered budgets include the upper shift b=n+1−k, so n−b≥k−1 everywhere. Division by three for V bounds the unweighted far envelope, not the actual signed centered sum. The primary drift bound follows by splitting the overlap, denominator, and new boundary coefficient. On the overlap |Δ_a|≤1/[k(k+1)] for a>k, using the explicit 1/a range and, for a≥2k, the difference recurrence with both counts in [1/(2k−1),1/k]; the normalized overlap cost is ≤P/K. The denominator change uses the same recurrence to bound the relative change by 1/(n+1), costing ≤P/(BK). For the boundary coefficient, any product containing a degree >k factor is marked once (overcount is safe); its coefficient supremum is ≤p/[2(k+1)] before multiplication by the remaining product bounds ≤exp(p). After the d-ratio ≤2 this costs p exp(p)/(K+1). The products using only atoms at degree k must contain at least B−1 factors to make degree n+1−k, and their coefficient bound is the corresponding exponential tail with argument p/2, times 2. Thus no division of the entire mixed adjacent change by sin θ is needed.

For the edge, the correlated low-index exponent (128H−1)/(2(H+1)(H+2)) is decreasing for H≥3, since its derivative has numerator proportional to −128H²+2H+259. The high-index left exit exponent (128H−1)/(2H²) decreases on the same range. The low curvature bound increases because the derivative of its logarithm is 2/H+(128H−130)/(H+1)^3. The two load cuts are respectively the plateau r≥ceil H and heavy r<H/2, and are only applied where their hypotheses hold. For the Stirling bound, factorial estimates give max mass ≤exp(1/(12D))/sqrt(2π Dp(1−p)) at p=(k−1)/D because k−1 and D−k+1 are positive; cubing or squaring rational bounds is unnecessary except for the verified peak comparison. Witness indices and the floor correction have M≥9. For the small outside endpoint s>D, the dominance at m=1 only improves. The join uses separate linear and negative cubic arctangent errors, each <π/40; last adjacent pairs are covered directly by the old-row t-root comparison.

Independently ran the entire exact replay below; all six interval ellipses, splice exclusions and witness/drift constraints passed. The previously audited k≥96 theorem through 3k and k≥128 theorem from 14k both include adjacent comparisons at their endpoints, giving coverage for all n≥k at every k≥128. Earlier coverage for k≥256 or the narrower intermediate bands remains valid but is superseded here. The focus now is the general k<128 range without per-k searches of the original polynomials.

# Exact central and edge replay for 3k≤n≤14k, k≥128

All proof comparisons use BigInt rationals. The floated radius proposal is checked by exact squaring. Directed exponential rounding bounds all computations. Replace text with console.log when running outside the functions environment.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=128,sk=q(113,10),A=q(12,25),sd=q(39,2),xi=q(808,1000);
ck(q(100,57).lt(eb(q(57,100).sub(q(1,128)))[0]),"two-cycle maximum");
ck(q(69,100).lt(two.mul(q(1,3).add(q(1,81)))),"log two");
ck(q(77,1000).mul(q(3,2)).lt(q(116,1000)),"block mass");
ck(!two.mul(xi).lt(q(1).add(q(1,2)).add(q(116,1000))),"unweighted norm");
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
ck(pu.div(q(252)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log");
const ca=o.sub(q(18,100).sq().div(two));
ck(q(4,5).lt(q(82,100).mul(ca)),"vertical positive");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(ca).mul(pu.div(q(40))))),"splice rotation");
ck(q(4*128).mul(ex(q(1,6*383))).lt(q(4,3).mul(pl).mul(q(127))),"binomial peak");
const C=q(315,100),Ce=q(27,8),D=q(383),n=q(384);
ck(sk.sq().lt(q(K))&&sd.sq().lt(D)&&q(9).lt(A.mul(sd)),"edge endpoints");
ck(q(3).div(o.sub(o.div(two.mul(sk)))).lt(C),"plateau");
const e=q(135,1000),l=q(426,1000),a=q(155,1000);
ck(o.div(e).lt(eb(o.sub(q(2,27)).div(two.mul(A.sq())))[0]),"large outward");
ck(C.mul(e).lt(l)&&q(14).div(l).lt(eb(q(1791,392))[0]),"large ratios");
ck(C.sq().div(a.mul(o.sub(a))).lt(eb(o.div(A.sq()))[0]),"large curvature");
ck(two.mul(C).mul(e).div(o.sub(e.sq())).lt(o),"large witness");
const es=q(25,1000),ls=q(34,100),as=q(76,1000);
ck(o.div(es).lt(eb(q(1791,480))[0])&&q(14).div(ls).lt(eb(q(1791,480))[0]),"small outward");
ck(q(196).div(as.mul(o.sub(as))).lt(eb(q(1791,225))[0]),"small curvature");
ck(two.mul(ls).div(o.sub(es.sq())).lt(o),"small witness");
ck(q(7000).lt(eb(q(297,1000).mul(q(K)))[0]),"tiny drift");
const general=q(27,4),slopeS=q(18,1000),driftS=q(370,1000),slope=q(83,10000),drift=q(218,1000),left=q(466,1000);
const baseDrift=A.div(sd).add(o.div(two.mul(sk)));
ck(C.mul(baseDrift).lt(drift)&&C.div(n).lt(slope)&&general.mul(baseDrift).lt(left),"large drifts");
ck(general.mul(q(4,3*128).add(o.div(two.mul(sk)))).lt(driftS)&&general.div(n).lt(slopeS),"small drifts");
let d=o.sub(ls);
ck(two.mul(as).add(driftS).add(as.mul(driftS.div(d).add(slopeS.div(d.sq())))).lt(o.sub(as)),"small margin");
d=o.sub(l.sq());
const ev=a.mul(l).mul(left).div(d),od=a.mul(drift.div(d).add(slope.mul(o.add(l.sq())).div(d.sq())));
ck(two.mul(a).add(drift).add(ev).add(od).lt(o.sub(a)),"large margin");
ck(A.div(sd).lt(q(1,40))&&n.div(D).mul(q(10,3)).mul(A.sq().mul(A)).div(sd).lt(q(1,40)),"atan splice");
ck(o.div(A.sq()).div(o.sub(o.div(A.mul(sd)))).lt(q(49,10)),"floor correction");

const rows=[[3,510,5,0,0],[5,600,7,0,0],[7,640,8,70,3],[8,710,10,75,3],[10,770,12,75,4],[12,825,14,80,4]];
let covered=3;
for(const [B,a0,N,tilt0,L] of rows){
 ck(B<=covered,"interval overlap");
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=63;
 ck(two.lt(b.mul(q(m0*25**2-312))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=12;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0);
 const min=(a,b)=>a.lt(b)?a:b;
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2))))),x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(464,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 let W,eps,c,slice;
 if(!tilt0){
  const P=two.mul(ex(xi.mul(p)).sub(o)),xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=two.mul(ex(xc).sub(o).sub(xc)).add(q(116,1000).mul(x));
  W=up(high.mul(f).add(x.mul(j)).add(x.mul(ell).div(two)).add(g));
  let atom=o;for(let j=1;j<B;j++)atom=up(atom.mul(p.div(two)).div(q(j)));
  eps=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(P.div(q(K))).add(P.div(q(B*K))));
  c=o.sub(P);
  slice=c.mul(o.sub(pu.div(q(40)).sq().div(two))).sub(P.mul(pu.div(q(40))));
 }else{
  const al=q(tilt0,100),ea=ex(al);
  ck(ea.lt(q(3)),"tail tilt contraction");
  const tail=q(77,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
  const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
  const delta=q(464,1000).div(fact(L)),l=lat(L*K/2,0);
  eps=up(ex(xi.mul(p)).sub(o).mul(delta).add(em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o))));
  const far=o.add(delta).mul(em(al)).mul(j).add(two.add(delta).mul(em(al.mul(q(B-1)))).mul(f)).add(em(al.mul(q(B-L))).mul(l));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));
  const ref=q(4,3).div(a.div(sk).add(two));
  c=ref.sub(eps);slice=q(98,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(tilt0?two.mul(eps):eps);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const s0=a.sub(q(49,10).div(sk));
 ck(q(0).lt(s0)&&q(N).div(A.sq()).lt(s0.sq()),"join location "+B);
 covered=N;
 text({B,N,a:a.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
ck(covered>=14,"all intervals joined");
text("All exact bounds passed.");

```

