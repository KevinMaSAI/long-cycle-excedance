# Uniform early band for k≥48 through n=3k

2026-11-27 05:00 UTC. For every k≥48 and k≤n≤3k, E_(n,k) has simple real roots and E_(n,k)/t strictly interlaces the next quotient, including n=3k as an old row. This and long_cycles_k48_from_16k.md leave the single middle gap 3k<n<16k for 48≤k<64; all k≥64 already have all rows.

The ordinary Eulerian one-cycle proof covers n<2k−1 directly. For later rows use M=floor(sqrt(D)/2), D=n−1. The central original signs hold throughout s≤4.14sqrt(k) at K=48 by the early absolute-anchor method, ξ=.816 and R=.192. The exact k−1,2k−2 far sums give V<.75 and V²+W²<1, with mismatch contribution (1+j)R/2 because (n+1)sin theta>2/R. Relative count drift <1/(n+1) applies since n≥2k−1. Cosine signs and the next-row sign follow; the pi/8 windows exclude splice roots. This uses no central uniqueness assumption.

For 2k−1≤n≤(5/2)k we have D≥94, M≥4 and A∈[1,2.5]. The first right pure loss ≥4(1/2−1/12)=5/3, hence eta=.19 and actual lambda=.476. Curvature ≤(2.5)^2 exp(−4) gives alpha=.133. Both-tail opposing witness denominator is 1−eta²; under .19 the strict witness cost is <1. Robbins gives peak .58/sqrt(k) from variance ≥(k−1)/2; then beta lattice gives .34+.027a and uniform left .34. Signed margin passes. If M=4 use S²/k≤2.5·99²/(16·100), and if M≥5 use S²/k<10(1+1/5)². Both <16. Phase error is <π/8 by cubic atan.

For (5/2)k<n≤3k, D≥120, H≤3 and M≥5. For r≥6 cap ceil(k/2) gives H/A<2.79. High m≥6 uses eta=.166, lambda=.464, alpha=.174: the pure first right loss uses M≥6, and at left exit below base 6 use A ratio ≤3 and loss ≥120/50. The curvature product and witness use the stated cap; their margins pass. Robbins peak now <.55/sqrt(k) from variance ≥(3/5)(k−1). Main left and outbound right in plateau use drift .351+.024a; whole left .364, checking at r≤5 directly with H≤3. The signed margin passes. If m≤4, eta=.136 from pure loss ≥120/(2·5·6), lambda=.41, alpha=.082 from curvature ≤9 exp(−120/25). Drift .39+.025a and the geometric witness test suffice. At m=5 when verifying the old-root bracket one has M≥6 and D≥144. The pure first ratios are under .166, so actual λ≤1/2. Use distinct curvature choices alpha_left=.030 from 9 exp(−144/25), alpha_right=.174 from the r=6 plateau and exp(−4). At witness m=5 the pure loss is ≥144/60 when M≥6, and eta=.092 suffices; when M=5 use eta=.136 as for the smaller witnesses. For the old-root sign use the one-sided signed cost: divide the left derivative/main/even-drift costs by 1−alpha_left, and the right derivative/odd-drift costs by 1−alpha_right. With d=.39, gamma=.025 and lambda=.5 the sum is below one. This avoids incorrectly trying to use equal alphas in this small boundary bracket.

For the second early band, M=5 implies S²/k≤3·143²/(25·144)<4.14², while M≥6 implies S²/k<12(1+1/6)²<4.14². The pi/8 arctan splice holds. The first witness always continues to dominate for s>D. Standard sign witnesses, inversion/parity, degree exhaustion and next-row sign comparison now give the announced result. Exact replay passed all analytic comparisons; no original polynomial checking was used.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}

const lo=x=>eb(x)[0], pl=q(157,50),pu=q(22,7),k0=q(48),sk=q(69,10),xi=q(816,1000);
function center(a,rr,B){
 const b=q(4).mul(pl.sq()).div(a.sq().mul(k0).add(q(10)));
 ck(o.add(a.sq().mul(k0).div(pl.sq())).div(k0.sq()).lt(rr.sq())&&two.lt(b.mul(q(23*25**2-312))),"core lattice scale");
 function sc(m,w){let x=q(0);for(let l=1;l<=12;l++){const u=b.mul(q(l*(l+1))); x=x.add(q(w?2*l+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return x.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(w?1:27)))));}
 const f=sc(23,true),h=sc(23,false),g=sc(47,true),j=sc(47,false);
 const P=two.mul(ex(xi.mul(rr).mul(o.add(q(3,2).mul(h)))).sub(o));
 const Z=two.mul(ex(xi.mul(rr).mul(q(3,2).add(q(4,3).mul(h)))).sub(o));
 const V=P.add(Z.mul(h)).add(j),W=P.add(Z.mul(f)).add(g).add(o.add(j).mul(rr).div(B));
 ck(V.sq().add(W.sq()).lt(o)&&V.lt(q(3,4)),"central ellipse and slice");
 text({V:V.val(),W:W.val()});
}
center(q(414,100),q(192,1000),q(2));
function chkCur(C,s,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(s));}
function wit(C,e){return two.mul(C).mul(e).div(o.sub(e.sq())).lt(o);}
function margin(a,l,d,b,dL=d,al=a,ar=a){
 const zz=o.sub(l.sq());
 const left=al.add(d).add(al.mul(l).mul(dL).div(zz)).div(o.sub(al));
 const right=ar.add(ar.mul(d.div(zz).add(b.mul(o.add(l.sq())).div(zz.sq())))).div(o.sub(ar));
 return left.add(right).lt(o);
}
const C0=q(5,2),e0=q(19,100),l0=q(476,1000),a0=q(133,1000),pk0=q(58,100);
ck(o.div(e0).lt(lo(q(5,3)))&&C0.mul(e0).lt(l0)&&chkCur(C0,q(4),a0)&&wit(C0,e0),"first band");
ck(q(48).mul(ex(q(1,6*94))).lt(pk0.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(47))),"first peak");
const d0=q(34,100),b0=q(27,1000);
ck(C0.mul(q(1,2).div(q(969,100)).add(pk0.div(sk))).lt(d0)&&C0.div(q(95)).lt(b0)&&margin(a0,l0,d0,b0),"first drift and margin");
ck(q(5*99*99,2*16*100).lt(q(16))&&q(72,5).lt(q(16)),"first upper S");
const C=q(279,100),e=q(166,1000),l=q(464,1000),a=q(174,1000),pk=q(55,100);
ck(q(5,2).div(o.sub(o.div(q(978,100)))).lt(C),"cap");
ck(q(48).mul(ex(q(1,6*120))).lt(pk.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(47))),"second peak");
ck(o.div(e).lt(lo(q(2).sub(q(4,18)).add(q(1,36)).sub(q(4,1080))))&&C.mul(e).lt(l)&&q(3).div(l).lt(lo(q(120,50)))&&chkCur(C,q(4),a)&&wit(C,e),"high");
const d=q(351,1000),b1=q(24,1000),dl=q(364,1000);
ck(C.mul(q(1,2).div(q(1095,100)).add(pk.div(sk))).lt(d)&&q(3).mul(q(5,121).add(pk.div(sk))).lt(dl)&&C.div(q(121)).lt(b1)&&margin(a,l,d,b1,dl),"high drift");
const em1=q(136,1000),lm=q(41,100),am=q(82,1000),dm=q(39,100),bm=q(25,1000);
ck(o.div(em1).lt(lo(q(2)))&&q(3).mul(em1).lt(lm)&&chkCur(q(3),q(120,25),am)&&wit(q(3),em1),"m<=4 ratios");
ck(q(3).mul(q(6,121).add(pk.div(sk))).lt(dm)&&q(3).div(q(121)).lt(bm)&&margin(am,lm,dm,bm),"m<=4 drift");
ck(q(3).mul(e).lt(q(1,2))&&chkCur(q(3),q(144,25),q(30,1000))&&chkCur(C,q(4),a)&&margin(a,q(1,2),dm,bm,dm,q(30,1000),a),"m5 sign");
ck(q(1000,92).lt(lo(q(144,60)))&&wit(q(3),q(92,1000)),"m5 witness");
ck(q(3*143*143,25*144).lt(q(414,100).sq())&&q(49,3).lt(q(414,100).sq()),"second splice radius");
for(const [D,n,root] of [[94,95,q(969,100)],[120,121,q(1095,100)]]){
 ck(q(1,2).div(root).lt(q(1,8))&&q(10,24).mul(q(n,D)).div(root).lt(q(1,8)),"phase correction");
}
```
