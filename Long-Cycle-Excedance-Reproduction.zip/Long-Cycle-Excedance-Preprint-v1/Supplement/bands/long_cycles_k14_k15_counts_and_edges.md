# Remaining k=14 and 15: count lemma and exterior estimates
This checkpoint contains the rigorous count, exterior and onset ingredients, not by itself a claim about the whole mother conjecture.
 
## Normalized counts independent of t
Write g(z)=exp(sum_(a≥k)z^a/a)=sum_j d_jz^j and Δ_j=d_j−d_(j−1), with d_0=1, d_1 through d_(k−1)=0. Differentiation gives jΔ_j=d_(j−k)−d_(j−1), equivalently d_j=((j−1)d_(j−1)+d_(j−k))/j. In particular every interval containing k consecutive positive-index counts is forward invariant. Rational count seeds give .533<k d_j<.589 for j≥2k and .580<k d_j<.584 for j≥3k. For T(Lk)=sum_(j≥Lk)|Δ_j|, use jΔ_j=−sum_(j−k<i<j)Δ_i. A block A_L=sum_(Lk≤j<(L+1)k)|Δ_j| satisfies A_L≤(A_(L−1)+A_L)/L. This proves summability before using the tail comparison T(Lk)≤T((L−1)k)/L. Sum through 7k−1 and majorize T(7k) by (8/7)A_7. This gives kT(2k)<.077, kT(3k)<.0038, kT(4k)<.000102, kT(5k)<.0000054, kT(6k)<1.5e−7, kT(7k)<3e−9 and the factorial continuation. The plain norm in units 2/k is <.780, and kA_2<.074. Exact quarter maxima include the whole atom separately; before 2k use the upper-closed bins excluding 2k, and after 2k use lower-closed bins. No excedance polynomial row is needed for these bounds.
 
For n≥3k, the ratio d_(n−b)/d_n of retained counts is <1.725, and <1.016 when residual≥2k. The absolute difference from 1 is ≤.089 for residual≥2k, ≤.0066 for residual≥3k, ≤.0394/L! for residual≥Lk with L≥4: use T(Lk)/d_n or the invariant interval widths as appropriate. Diagonal relative cost uses .089 or .0394/floor(B−1)!, as n+1−k≥2k at n≥3k. For γ∈[1,2) the bound is max(.089,1/(.580γ)−1) since those counts are exactly 1/j and the possible downward discrepancy is bounded by .089; when omitted, charge 1.
 
## Onset
For n<2k, E_(n,k)/t=A_(n−1), with the Eulerian polynomial indexed by descents on m elements and A_0=1. Eulerian recursion gives strict interlacing at all n for which the two rows consist exclusively of a single cycle. For n=2k−1,2k replay four exact consecutive pairs (two per k) below, including the first two-cycle row and its successor. The cycle formula adds one term for each unordered pair of lengths and a one-half coefficient for equal lengths. A full-degree signed Euclidean chain with positive leading coefficients gives strict interlacing: backwards start with constant and linear, and evaluate each recurrence P_(i−1)=a_iP_i−c_iP_(i+1), c_i>0, on the simple ordered roots of P_i; at both ends the leading coefficients give the missing sign intervals. Primitive pseudo-division multiplies only by positive numbers, so the computed signs certify the rational Euclidean chain.
 
## Sparse edge
For 2k+1≤n≤3k, D=n−1 and M=3. The exterior sign arguments from the k16 sparse proof allow two curvatures now. The left old-root bases r≤2 satisfy product ≤H² exp(−D/4), H=n/k. At r=3: a full label-cycle gives P_3≥1/3, so the left normalized neighbor ratio is ≤2. For r=4 use P_4≤3/8+(5/8)p_4, with p_4=Pr(Bin(n,1/4)≥k). The binomial tilted Robbins peak .60/√k is valid under n≥2k+1; take μ/k≤9/14 for 28≤D≤35 and ≤.75 for D≥36. Geometric upper tail and cubic lower bound on Φ(μ/k) give P_4≤.468 and .616, respectively. The right normalized ratio is ≤4P_4 and the curvature product ≤8P_4 exp(−D/9). This gives curvature pairs (.007,.215) or (.002,.102). At m=3, use the first left pure .212 or .136 and right .281 or .195, with those sharper amplitude ratios; the third opposing pure term is exp(−9D/36), and subsequent odd terms are geometrically bounded by the square of the first pure ratio. At m≤2 the pure loss is at least D/12. After the first outward step use pure loss at least 3.9D/36 right and D/6 left. The remaining actual neighboring ratios are .126 or .061. Left drift d_1=0 and d_2≤H(.60/√k); all right drift ≤.679+.089a or .726+.082a using index≤3+a. The exact unequal-curvature signed mean uses the denominators 1−α_L and 1−α_R separately. The arctangent correction is less than π/8.
 
## Middle edge
For n≥3k take M=floor(√D/2), only needed through 16k. No exceptional cutoff. For r≥4 the occupancy parameter kr/n<1.12. For label cycles of size b≥2, the mean ratio to the threshold j=k−1 is ≥1.9 at b=2, and increases linearly with b. Since log(1.9)<.65, use (k−1)Φ≥13/4 there and first derivative in b at least 117/20. Weighted union bound over 1/b gives the earlier <.059 long-cycle error. At r=3 the analogous rate ratio ≥2 gives the <.003 long error, hence P_3≥.330+.5p_1. The r≥4 affine bounds, curvature, and oriented splice are otherwise exactly as in the k16 half-sqrt edge. For r≤3 the pure right constants are .172 at r=3 and .034 for r≤2 from D≥41. Beta at main and left bases is ≤1.06 by (k−1)^2≤14², D≥3k−1; first adverse right beta ≤1.325 since at M=3 it is at most max(52/41,56/44), and at M≥4 use 14(M+1)/(4M²). For β≤1.06 the lattice sum is ≤1.06; for β≤1.325 it is ≤1.24, using the exact geometric progression beyond j=2 and the alternating seventh-order lower polynomial for Φ(1+z), with all z within [0,1]. The near drift bounds .602 and .68 and the right generic .835+.090a then follow. When r≥.75 n/k, the deterministic truncated occupancy bound gives H/A<3.75: for L=ceil(4k/3), (2k+L−2)/k≤45/14. Let μ=n/r≤4k/3. The ratio E[min(Bin(n,μ/n),L)]/μ decreases in μ by the binomial size-bias identity; at the maximum mean, the variance bound and μ≤L give loss at most 1/(2√(4k/3))<5/43. For r<.75H, x=D/r≥1.30k, use the inherited geometric exponent kernel with spacing >5 and the global lower A≥(8/27)r, yielding drift <.45. All witnesses, signed mean, and oriented phase comparisons are exact.
 
## Upper edge
For n≥16k, use M=floor(.6√D). At r≤.66√n and .67√n the good-label occupancy lower probabilities are >.75 and >.70, respectively, with mean ratios to j=k−1 at least 1.66,1.64 and Robbins peak .49/√k. The outward loss beyond the first window from v√D(5/3−1/.66) absorbs (11/10)·27/8. At small m the pure first bounds come from D≥223. The same α=.128, λ=.49 and signed mean apply with near drift .16; the latter uses x≥1.53k. Generic drift .645+.0168a for r≥.75H comes from the cap just proved. Below this regime x≥1.327k and successive loss >5.5 give drift <.40. Floor S≤(5/3)√n+3.13 and phase error <π/16. Reuse the exact signed shape argument, not an asymptotic formula for roots.
 
## Exact replays
Each block is a separate JS script; replace text with console.log locally. Directed interval upper and lower bounds are used in each.
 
### Counts
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=16,sk=q(4),xi=q(84,100),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;

const aa=x=>x.lt(q(0))?q(0).sub(x):x;
const cap=[882352943,784313727,524475526,324074076,251256239,91160178,22319961,17905597,13692186,1576387,2267073,1065241,184152,203435,111219,9062,17735,7395,1164,958,541,65,76,25];
for(const k of [14,15]){
 const d=[o];for(let j=1;j<8*k;j++)d[j]=j<k?q(0):q(j-1).mul(d[j-1]).add(d[j-k]).div(q(j));
 const u=j=>q(k).mul(d[j]);
 function cu(n,m){let v=q(0);for(let j=n;j<m;j++)v=v.add(aa(u(j).sub(u(j-1)))); return v;}
 function tail(n){return cu(n,7*k).add(q(8,7).mul(cu(7*k,8*k)));}
 let peak=q(589,1000),bot=q(533,1000),min3=q(580,1000),max3=q(584,1000);
 for(let j=2*k;j<4*k;j++){ck(bot.lt(u(j))&&u(j).lt(peak),"general d");if(j>=3*k)ck(min3.lt(u(j))&&u(j).lt(max3),"3k d");}
 const C=[77,38,102,54,15,3];
 const den=[1000,10000,1000000,10000000,100000000,1000000000];
 let vs=[];
 for(let i=0;i<C.length;i++){const L=i+2,v=tail(L*k);ck(v.lt(q(C[i],den[i])),"tail "+L);vs.push(v.val());}
 const v=cu(k+1,2*k).add(tail(2*k));
 ck(o.add(v).div(two).lt(q(780,1000)),"total");
 ck(cu(2*k,3*k).lt(q(74,1000)),"two-cycle");
 const vals=[];for(let i=0;i<24;i++){const b=4+i;const j=b<8?Math.min(2*k,Math.floor((b+1)*k/4)+1):Math.ceil((b+1)*k/4),l=b<8?Math.floor(b*k/4)+1:Math.ceil(b*k/4);let w=cu(l,j).div(two); ck(w.lt(q(cap[i],10000000000)),"quarter mass "+b);}
 text({k,tail:vs,total:v.val()});
}

ck(q(45,14).div(o.sub(q(5,43))).lt(q(15,4))&&q(43,10).sq().lt(q(56,3)),"truncated occupancy");ck(q(589,580).lt(q(1016,1000))&&q(1000,580).lt(q(1725,1000))&&q(51,580).lt(q(89,1000))&&q(38,5800).lt(q(66,10000))&&q(38*6,5800).lt(q(394,10000)),"normalized count bounds");
```
### Onset
```javascript

const gcd=(a,b)=>{while(b){[a,b]=[b,a%b]}return a<0n?-a:a;};
let bin=(n,r)=>{let x=1n;for(let i=1;i<=r;i++)x=x*BigInt(n-i+1)/BigInt(i);return x};
const A=[[1n]];for(let n=1;n<=31;n++){A[n]=Array.from({length:n},(_,j)=>BigInt(j+1)*(A[n-1][j]??0n)+BigInt(n-j)*(A[n-1][j-1]??0n));}
function E(n,k){let f=A[n-1].slice();if(n<2*k)return f;for(let m=k;m<=n-k;m++)for(let i=0;i<A[m-1].length;i++)for(let j=0;j<A[n-m-1].length;j++){
 let v=bin(n,m)*A[m-1][i]*A[n-m-1][j];if(m===n-m){if(v%2n)throw Error("parity");v/=2n;}
 if(m<=n-m)f[i+j+1]+=v;
 }return f;}
function rem(f,g){let v=f.slice(),lc=g.at(-1);if(lc<=0n)throw Error("negative divisor");while(v.length>=g.length){let a=v.at(-1),d=v.length-g.length;v=v.map(x=>x*lc);for(let j=0;j<g.length;j++)v[j+d]-=a*g[j];while(v.at(-1)===0n)v.pop();let z=v.reduce(gcd,0n);if(z>1n)v=v.map(x=>x/z);}return v.map(x=>-x);}
for(let k of [14,15])for(let n of [2*k-1,2*k]){
 let f=E(n+1,k),g=E(n,k),ds=[f.length-1,g.length-1];
 while(g.length>1){let h=rem(f,g);if(h.length!==g.length-1||h.at(-1)<=0n)throw Error("non-Sturm");ds.push(h.length-1);[f,g]=[g,h];}
 if(g[0]<=0n||ds.at(-1)!==0)throw Error("constant");text([k,n,ds]);}

```
### Sparse edge
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(17)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}



const pl=q(157,50),pu=q(22,7),lo=x=>eb(x)[0],sk=q(374,100),K=q(14),pk=q(60,100),M=q(3);
ck(sk.sq().lt(K),"sqrt"); 
ck(K.mul(ex(q(1,6*28))).lt(pk.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(13))),"Robbins peak");
for(const [D,H,H4,LR,RL,pw,aL,aR,d,j,r,b] of [
 [28,q(18,7),q(9,14),q(212,1000),q(281,1000),q(468,1000),q(7,1000),q(215,1000),q(414,1000),q(126,1000),q(679,1000),q(89,1000)],
 [36,q(3),q(3,4),q(136,1000),q(195,1000),q(616,1000),q(2,1000),q(102,1000),q(482,1000),q(61,1000),q(726,1000),q(82,1000)]
]){
 const Dq=q(D),N=q(D+1),dz=o.sub(H4),lx=q(1,3);
 const L3=lx.sq().div(two).sub(lx.sq().mul(lx).div(q(3))).add(lx.sq().sq().div(q(4))).sub(lx.sq().sq().mul(lx).div(q(5)));
 const p4=pk.div(sk).div(dz).mul(em(K.mul(dz.sq().div(two).add(dz.sq().mul(dz).div(q(3))))));
 ck(q(3,8).add(q(5,8).mul(p4)).lt(pw),"r4 upper");
 ck(o.div(LR).lt(lo(Dq.div(q(18))))&&o.div(RL).lt(lo(Dq.mul(L3))),"first pure at 3");
 const el=q(D===28?98:51,1000);ck(o.div(el).lt(lo(Dq.div(q(12)))),"pure at ≤2");
 ck(H.sq().div(aL.mul(o.sub(aL))).lt(lo(Dq.div(q(4))))&&q(8).mul(pw).div(aR.mul(o.sub(aR))).lt(lo(Dq.div(q(9)))),"curvature deductions");
 const opp=em(q(9*D,36)), zz=o.sub(RL.sq());
 ck(two.mul(LR).add(q(4).mul(pw).mul(RL)).add(two.mul(H).mul(opp).div(zz)).lt(o),"m3 witness");
 ck(two.mul(H).mul(el).div(o.sub(el.sq())).lt(o),"m≤2 witness");
 ck(H.div(j).lt(lo(q(39*D,360)))&&H.div(j).lt(lo(q(D,6))),"later ratios");
 ck(H.mul(pk.div(sk)).lt(d)&&H.mul(q(3).div(N).add(pk.div(sk))).lt(r)&&H.div(N).lt(b),"drift");
 const zz2=o.sub(j.sq()),tail=r.add(q(3).mul(b)).div(zz2).add(two.mul(b).mul(j.sq()).div(zz2.sq()));
 let vl=aL.add(d).add(aL.mul(j).mul(d).div(zz2)).div(o.sub(aL));
 let vr=aR.add(aR.mul(r.add(b))).add(aR.mul(j.sq()).mul(tail)).div(o.sub(aR));
 ck(vl.add(vr).lt(o),"two-alpha sign");
}
ck(q(3,28).lt(q(1,8))&&q(10,3).mul(q(29)).mul(q(3,28).sq()).mul(q(3,28)).lt(q(1,8)),"phase");

```
### Middle edge
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}



const lo=x=>eb(x)[0], C=q(27,8),pk=q(54,100),K=q(14),sk=q(374,100),pl=q(157,50),D=q(41),n=q(42),sd=q(64,10),v=D.div(n);
ck(K.mul(ex(q(1,6*41))).lt(pk.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(13))),"Robbins peak");
ck(q(15,12).lt(q(112,100).sq())&&q(19,10).lt(q(2).mul(q(15,14)).div(q(112,100))),"main mean");
const phip=z=>z.sq().div(two).sub(z.sq().mul(z).div(q(3))), phim=z=>z.sq().div(two).add(z.sq().mul(z).div(q(3)));
const geom=(x,y)=>x.div(o.sub(y));
ck(q(19,10).lt(lo(q(65,100)))&&q(2).lt(lo(q(7,10))),"log bounds");
const long=pk.div(sk.mul(o.sub(q(10,19)))).mul(geom(em(q(13,4)),em(q(117,20)))).div(two);
ck(long.lt(q(59,1000))&&pk.div(sk.mul(q(1,2))).mul(geom(em(q(39,10)),em(q(65,10)))).div(two).lt(q(3,1000)),"long union");

const hb=q(38,100),pj=q(64,100);
for(const [a,b,lf,rf,pr,L,R] of [[q(301,1000),q(36,100),o,q(6,5),o,q(333,100),q(186,100)],[q(316,1000),q(1,3),q(3,4),q(5,4),q(15,16),q(238,100),q(197,100)]]){
 ck(pj.mul(a).lt(two.mul(b).mul(hb))&&hb.mul(b).lt(pj.mul(a)),"monotone ratios");
 ck(lf.div(a).lt(L)&&rf.mul(hb.add(pj)).div(a.add(b)).lt(R)&&pr.mul(hb).div(a.sq()).lt(q(420,100)),"r≥4 ratios");
}
const pr=q(330,1000),p3=q(375,1000),a3=q(625,1000);
ck(q(2,3).div(pr).lt(q(2021,1000))&&q(4,3).mul(o.div(pr.add(q(1,2)))).lt(q(161,100)),"r=3 ratios");
ck(a3.mul(pr).lt(p3)&&q(8,9).mul(p3).div(pr.sq()).lt(q(31,10)),"r=3 curvature factor");
const eL=q(136,1000),eR=q(181,1000),e3=q(172,1000),e2=q(34,1000),l=q(46,100),l2=q(104,1000),a=q(85,1000);
ck(o.div(eL).lt(lo(q(2)))&&o.div(eR).lt(lo(q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80))))&&o.div(eR).lt(lo(q(2).sub(q(4,15)))),"first pure high");
ck(o.div(e3).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&o.div(e2).lt(lo(D.div(q(4)).mul(q(1,2).sub(q(1,6))))),"pure low");
ck(q(333,100).mul(eL).lt(l)&&q(197,100).mul(eR).lt(l)&&q(161,100).mul(e3).lt(l)&&C.mul(q(3,2)).mul(e2).lt(l),"first ratios");
ck(C.mul(q(3,2)).div(l2).lt(lo(q(39,10)))&&C.div(l2).lt(lo(q(6))),"steep second");
const zc=a.mul(o.sub(a));
ck(q(420,100).div(zc).lt(lo(q(4)))&&q(31,10).div(zc).lt(lo(D.div(q(9))))&&C.sq().mul(q(3,2)).div(zc).lt(lo(D.div(q(4)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R,e,m] of [[q(333,100),q(186,100),eR,5],[q(238,100),q(197,100),eR,4],[q(2021,1000),q(161,100),e3,3]])ck(L.mul(eL).add(R.mul(e)).add(cost(e,m,true)).lt(o),"opposing witnesses");
ck(cost(e2,1,false).lt(o),"small witness");
function nlow(w){return em(q(13).mul(phim(o.sub(w))));}
function nhigh(w){const z=w.sub(o);let L=q(0),p=z;for(let i=2;i<=7;i++){p=p.mul(z);L=i%2?L.sub(p.div(q(i))):L.add(p.div(q(i)));}return em(q(13).mul(L));}
function tail(j,beta){return geom(nhigh(q(j).div(beta)),em(q(13).mul(o.div(beta).sub(q(1,j)))));}
ck(q(14*14,4*44).lt(q(106,100).sq())&&q(56,44).lt(q(1325,1000))&&q(70,53).lt(q(1325,1000))&&q(70,64).lt(q(1325,1000)),"lattice beta ranges");
const s1=q(106,100),s2=q(124,100);
ck(o.add(tail(2,q(106,100))).lt(s1),"lattice first");
for(const [x,y] of [[o,q(115,100)],[q(115,100),q(123,100)],[q(123,100),q(1325,1000)]])ck(nlow(o.div(x)).add(tail(2,y)).lt(s2),"lattice right");
const cap=q(375,100),d=q(602,1000),right=q(68,100),dt=q(835,1000),b=q(90,1000),xx=q(130,100);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(pk).mul(s1).div(sk).lt(d)&&cap.mul(pk).mul(s2).div(sk).lt(right),"near drift");
ck(cap.mul(q(1,2).div(sd).add(pk.div(sk))).lt(dt)&&cap.div(n).lt(b),"outer drift");
ck(xx.lt(q(4,3).mul(v))&&C.div(v).mul(xx).mul(pk).div(sk).mul(geom(nhigh(xx),em(q(5)))).lt(q(45,100)),"heavy drift");
const z=o.sub(l2.sq()),later=dt.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l2.sq()).div(z.sq()));
ck(two.mul(a).add(d).add(a.mul(l2).mul(d).div(z)).add(a.mul(right)).add(a.mul(l2.sq()).mul(later)).lt(o.sub(a)),"signed comparison");
ck(q(10,3).mul(q(42,41)).div(q(4)).lt(o)&&q(316,100).lt(pl.sq().div(q(3)).mul(o.sub(q(6,4*41)))),"oriented phase");

```
### Upper edge
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log bound");
ck(q(48,100).lt(q(54,100).mul(o.sub(q(46,100).sq().div(two)))),"vertical real fraction");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(o.sub(q(46,100).sq().div(two))).mul(pu.div(q(16))))),"splice angle fraction");
const lo=x=>eb(x)[0],K0=q(14),D=q(223),n=q(224),sk0=q(374,100),sd=q(149,10),u=q(3,5),reach=q(66,100),wide=q(67,100),pk=q(49,100),C=q(27,8),v=D.div(n);

ck(q(14).mul(ex(q(1,6*223))).lt(pk.sq().mul(two).mul(pl).mul(q(15,16)).mul(q(13))),"binomial peak");
const phi=x=>x.sq().div(two).sub(x.sq().mul(x).div(q(3)));
const F=q(3,4), G0=q(7,10);
for(const [r,w,a] of [[reach,q(166,100),F],[wide,q(164,100),G0]]){
 ck(w.sq().mul(r.sq()).mul(q(15,16)).lt(q(15,14).sq()),"good-label mean");
 ck(pk.div(sk0.mul(o.sub(o.div(w)))).mul(em(q(13).mul(phi(w.sub(o))))).lt(o.sub(a)),"good-label tail");
}
const e=q(278,1000),l=q(49,100),a=q(128,1000);
ck(o.div(e).lt(lo(q(25,9).mul(q(1,2).sub(q(1,27)))))&&q(6,5).div(F).mul(e).lt(l),"high ratios");
ck(q(250).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12)))))&&q(3,2).div(F).div(q(250)).lt(l),"small ratios");
ck(C.mul(q(11,10)).div(l).lt(lo(v.mul(sd).mul(o.div(u).sub(o.div(reach))))),"outward exit");
ck(o.div(F.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(u.sq()))),"curvature bound");
function witness(e,m){const z=o.sub(e.sq());return two.div(F).mul(e.div(z).add(e.mul(o.add(e.sq())).div(q(m).mul(z.sq())))).lt(o);}
ck(witness(e,6)&&q(1000,22).lt(lo(D.div(q(25)).mul(q(1,2).sub(q(1,15)))))&&witness(q(22,1000),1),"opposing witnesses");
const cap=q(375,100), d=q(645,1000),b=q(168,10000),xn=q(1327,1000),xn2=q(153,100),dm=q(16,100);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(u.div(sd).add(pk.div(sk0))).lt(d)&&cap.div(n).lt(b),"generic drift");
ck(xn.lt(q(4,3).mul(v))&&q(11,2).lt(q(327,1000).mul(K0).add(o)),"heavy drift spacing");
ck(C.div(v).mul(xn).mul(pk).div(sk0).mul(em(q(13).mul(phi(q(327,1000))))).div(o.sub(em(q(11,2)))).lt(q(40,100)),"heavy drift");
ck(xn2.sq().mul(wide.sq()).mul(q(15,16)).lt(v.sq())&&q(48,10).lt(q(53,100).mul(q(14)).add(o))&&o.lt(wide.sub(u).mul(sd)),"near drift window");
ck(o.div(G0.mul(v)).mul(xn2).mul(pk).div(sk0).mul(em(q(13).mul(phi(q(53,100))))).div(o.sub(em(q(48,10)))).lt(dm),"near drift");
const z=o.sub(l.sq()),tail=d.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l.sq()).div(z.sq()));
ck(two.mul(a).add(dm).add(a.mul(l).mul(dm).div(z)).add(a.mul(dm)).add(a.mul(l.sq()).mul(tail)).lt(o.sub(a)),"signed mean margin");
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sd)))).lt(q(313,100))&&u.div(sd).lt(q(1,16))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sd)).lt(q(1,16)),"floor splice");

```
