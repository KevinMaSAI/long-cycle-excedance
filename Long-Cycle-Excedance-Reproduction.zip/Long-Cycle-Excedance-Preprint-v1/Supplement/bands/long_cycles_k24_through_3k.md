# Early rows for k≥24 through 3k

2026-11-27 06:15 UTC. For all k≥24 and k≤n≤3k genuine E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient. This adds 24≤k≤31 only, since k≥32 has all rows. Earlier universal onset and Eulerian comparisons cover old n≤2k. No new original polynomial rows were tested.

## Sparse central expansion
Use the earlier exact anchor formulas in the true normalized coefficient. For 2k+1≤n≤2.75k all retained shifts b≤n+1−k are <2k, so one linear factor at a time is the entire mixed part. For successive upper ratios N=2.25,2.5,2.75 the nonatom mass of delta in that prefix is at most (1−1/(N−1+1/24))/k = (7/31,13/37,19/43)/k, from telescoping d_j=1/j for k≤j<2k. Normalized count ratios are <2. Thus use P=(1+q_tail)p for old primary, and W=x j_1+q_tail x f+g for the far envelope, where j_1 is the weighted lattice at (B−1)k for the atom, f is at k−1, g the Bk diagonal. The direct primary drift uses P/k+P/(Bk)+p/(k+1), as the boundary degree exceeds k and the expansion is linear. True diagonal relative mismatch (before multiplying by (1+j)R/B) is at most 1,.60,1/3 on the three lower ratio starts B=2,2.25,2.5. Indeed (n+1)Delta_(n+1)=d_(n+1−k)−d_n, the lag count is between .5/k and max(.584,1/(B−1))/k, and the old/next d counts are in [.5,.584]/k. The sparse core ellipses pass at a=3.95,4.16,4.30 respectively.

For 2.75k≤n≤3k, d_n and d_(n+1) are ≥.555/k, by the two-cycle lower envelope (2+3y)/(2+y)^2≥5/9 on y∈[.75,1] and the subsequent invariant lower bound. The normalized ratio cap is 1.81. With retained degree b=k (atom), n−b≥1.75k so numerator count ≤.584/k, ratio <1.053. For the linear pre-prefix b≤1.5k, n−b≥1.25k, so numerator ≤.8/k, ratio <1.442. The linear pre masses up to and after 1.5k are ≤1/(3k),1/(6k). A maximum of two mark factors can enter the prefix b≤2k+1, either two atoms or one atom and one degree-(k+1) factor. Along with linear shifts 2k,2k+1 their absolute bound in scale y=p or x is ≤1.81[y/(k+1)+y²(1/8+1/[4(k+1)])]. Add the corresponding far envelopes with radial exponents 1.75k for the atom, 1.25k for the first pre-prefix, and k−1 for all other non-diagonal parts. The mismatch relative factor is <.16 before (1+j)R/B, by d_(n+1−k)∈[.5,.584]/k and d old and new≥.555/k. Use the standard marked-boundary drift with at least two pure atoms in b>k, and the usual overlap and denominator terms with plain absolute norm ξ=.829. The ellipse and π/8 root exclusion pass through a=4.14.

## Early edges
Let D=n−1 and M=floor(sqrt(D)/2). For 2k+1≤n≤2.5k, D≥48, M≥3 and H=n/k≤2.5. First pure ratio at most .181; use quartic expansion at M≥4, and D≥48 at M=3. Then actual first ratio <.453 and curvature alpha=.133 by 2.5² exp(−4). After the first step the pure right loss is ≥4(3/4+9/40)=3.9 and left ≥6, so actual ratio <.052 in both directions, since amplitude factors ≤2.5. This sharper slope applies to even-left and late odd-right tail contributions. Robbins modal factor .59/sqrt(k) from variance ≥(k−1)/2; exact beta lattice gives d_r<.483+.052a for r≤M+a, and <.483 on the left. Separate first odd right a=1 from a≥3, using alpha(.483+.052) for the first and alpha·.052² for the starts of later odd terms. Replay signed margin passes. Witness geometric opposition with .181 passes.

For 2.5k<n≤3k at 24≤k≤31, D≥60 and M∈{3,4}. If m+1≤3, use pure .075 from D≥60 and r≤3, λ=.43 (in fact .225), alpha=.012 from 9 exp(−60/9); witness with factor 3. At m=3 bracket with m+1=4≤M, use a direct occupancy singleton or doubleton sandwich for the r=4 base. Here β=r/H≤1.6. The modal point peak .54/sqrt(k) from variance ≥3(k−1)/5 applies. If β≤1.4, take no or exactly one singleton: P_4≥.333+(1/3)p_1(4) by d_(4,2)=.375, d_(3,2)=1/3, and unconditional long error <.042. The right bound P_5≤.38+.64p_1(4) and trivial left P_3≤1 give normalized ratios <2.26,1.92 and normalized product ≤(15/16)·.38/.333². If β>1.4, take size≥3 permutations to get P_4≥.246 (d_(4,3)=.25 minus long error <.004); P_5≤.459 by the singleton upper bound with right mean ratio ≤5/7. Then normalized ratios <3.05,2.34 and product ≤(15/16)·.459/.246². All probability upper limits follow by the same marked binomial ratios used in the K24 n≥3k edge, with the .54 peak. Since D≥64, left curvature alpha_L=.008 from 9 exp(−64/9), right alpha_R=.155 from the stated product and exp(−4). Right first pure .181 gives actual ratio <.43; after the first it is absorbed by log loss ≥D(1/4−1/5) and amplitude factor 3. Whole left drift <.48 and right <.53+.05a from beta lattice and H≤3, left r≤3, right main r≤4. Signed mean with separate alphas passes. Witness m=4 uses .136 to the left, .181 to the right and the local opposing ratios, then factor 3 on the later odd geometric tails; passes. All first witnesses remain dominant for s>D.

Splice exactly using M=3 or 4: in B=2 first subband n≤2.25k, ratio bound at M=3 is sqrt(2.25·63²/(9·64)), and beyond M≥4 smaller by 2sqrt(2.25)(1+1/M); in B=2.25 band replace 2.25 by 2.5. At n≤2.75k but k≥24, cap M=3 by 63/(3sqrt(24)), and for M≥4 use 2sqrt(2.75)(1+1/M). In the final B=2.75 band, M=4 because D≥65 and D≤92, giving sqrt(3·92²/(16·93)). Each fits its earlier core a. Phase deviation <π/8 by cubic arctan. Standard half-interval sign witnesses, symmetry and parity complete the count and yield strict interlacing, including old n=3k. All exact tests below passed.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}


const pl=q(157,50),pu=q(22,7),K=q(24),sk=q(489,100),lo=x=>eb(x)[0];
const rows=[[395,261,8,7,31,1,1],[416,274,9,13,37,3,5],[430,283,10,19,43,1,3],[414,274,11,0,1,4,25]];
for(const [a0,R0,B4,m1,m2,i1,i2] of rows){
 const a=q(a0,100),R=q(R0,1000),B=q(B4,4),b=q(4).mul(pl.sq()).div(a.sq().mul(K).add(q(10)));
 ck(o.add(a.sq().mul(K).div(pl.sq())).div(K.sq()).lt(R.sq())&&two.lt(b.mul(q(11*25**2-312))),"lattice");
 function lat(m,v){let s=q(0);for(let j=1;j<=12;j++){const u=b.mul(q(j*(j+1)));s=s.add(q(v?2*j+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return s.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(v?1:27)))));}
 const f=lat(11,true),h=lat(11,false),g=lat(3*B4,true),j0=lat(3*B4,false),j=lat(3*(B4-4),true);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 let P,W,d;
 if(B4<11){
  const r=q(m1,m2);P=o.add(r).mul(p);
  W=x.mul(j).add(r.mul(x).mul(f)).add(g);
  d=p.div(q(25)).add(P.div(K)).add(P.div(B.mul(K)));
 }else{
  const u=q(1053,1000),v=q(1442,1000),z=q(181,100);
  function mask(p){return z.mul(p.div(q(25)).add(p.sq().mul(q(1,8).add(q(1,100)))));}
  P=u.mul(p).div(two).add(v.mul(p).div(q(6))).add(z.mul(p).div(q(12))).add(mask(p));
  W=u.mul(x).mul(j).div(two).add(v.mul(x).mul(lat(15,true)).div(q(6))).add(z.mul(x).mul(f).div(q(12))).add(mask(x).mul(f)).add(g);
  const ne=two.mul(ex(q(829,1000).mul(p)).sub(o));
  d=p.mul(ex(p)).div(q(25)).add(p.div(two).sq().mul(ex(p.div(two)))).add(ne.div(K)).add(ne.div(B.mul(K)));
 }
 const V=W.div(q(3)),mis=q(i1,i2).mul(o.add(j0)).mul(R).div(B),c=o.sub(P),slice=c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))));
 text({a:a.val(),W:W.val(),d:d.val(),mis:mis.val(),c:c.val(),slice:slice.val()});
 ck(q(0).lt(c)&&V.sq().add(W.add(d).add(mis).sq()).lt(c.sq())&&V.lt(slice),"sparse ellipse");
}

const pk1=q(59,100),pk2=q(54,100),C=q(5,2),H=q(3),D1=q(48),D2=q(60);
function amp(C,x,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(x))}
function wit(C,x){return two.mul(C).mul(x).div(o.sub(x.sq())).lt(o)}
function driftMain(a,b,l,d,g,dr){const z=o.sub(l.sq());
 const m=a.add(d).add(a.mul(l).mul(d).div(z)).div(o.sub(a));
 const qx=b.add(b.mul(dr.div(z).add(g.mul(o.add(l.sq())).div(z.sq())))).div(o.sub(b));
 return m.add(qx).lt(o);
}
ck(K.mul(ex(q(1,6*48))).lt(pk1.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(23)))&&K.mul(ex(q(1,6*60))).lt(pk2.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(23))),"Robbins peaks");
const e1=q(181,1000),a1=q(133,1000),d1=q(483,1000),b1=q(52,1000),l2=q(52,1000);
ck(o.div(e1).lt(lo(q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80))))&&o.div(e1).lt(lo(D1.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&amp(C,q(4),a1)&&wit(C,e1),"first pure and witness");
ck(C.div(l2).lt(lo(q(39,10)))&&C.mul(q(1,2).div(q(692,100)).add(pk1.div(sk))).lt(d1)&&C.div(q(49)).lt(b1),"first drifts");
const z0=o.sub(l2.sq()),s0=d1.add(q(3).mul(b1)).div(z0).add(two.mul(b1).mul(l2.sq()).div(z0.sq()));
ck(two.mul(a1).add(d1).add(a1.mul(l2).mul(d1).div(z0)).add(a1.mul(d1.add(b1))).add(a1.mul(l2.sq()).mul(s0)).lt(o.sub(a1)),"first sign");
const e2=q(75,1000),l=q(43,100),a2=q(12,1000),aa=q(8,1000),ar=q(155,1000),d=q(48,100),dr=q(53,100),g=q(5,100);
ck(o.div(e2).lt(lo(q(70,27)))&&H.mul(e2).lt(l)&&amp(H,q(60,9),a2)&&wit(H,e2),"small second");
ck(H.mul(q(3,61).add(pk2.div(sk))).lt(d)&&H.mul(q(4,61).add(pk2.div(sk))).lt(dr)&&H.div(q(61)).lt(g),"second drifts");
ck(amp(H,q(64,9),aa)&&driftMain(a2,a2,l,d,g,dr)&&driftMain(aa,ar,l,d,g,dr),"second signs");
function lower(w){const z=w.sub(o);return pk2.div(sk.mul(o.sub(o.div(w)))).mul(em(q(23).mul(z.sq().div(two).sub(z.sq().mul(z).div(q(3))))));}
function bad(b,w){return lower(w).div(q(b).mul(o.sub(em(q(23).mul(w.sub(o)).div(q(b))))));}
function upper(w){const z=o.sub(w);return pk2.div(sk.mul(z)).mul(em(q(24).mul(z.sq().div(two).add(z.sq().mul(z).div(q(3))))));}
ck(bad(2,q(10,7)).lt(q(42,1000))&&bad(3,q(15,8)).lt(q(4,1000))&&upper(q(5,7)).lt(q(123,1000)),"four-base tails");
ck(q(38,100).div(q(3)).lt(q(64,100).mul(q(333,1000)))&&q(64,100).mul(q(333,1000)).lt(q(76,300)),"four-base monotonicity");
ck(q(3,4).div(q(333,1000)).lt(q(226,100))&&q(5,4).mul(q(102,100)).div(q(333,1000).add(q(1,3))).lt(q(192,100)),"four-base singleton ratios");
const den=q(246,1000),right=q(459,1000);
ck(q(3,4).div(den).lt(q(305,100))&&q(5,4).mul(right).div(den).lt(q(234,100)),"four-base doubleton ratios");
ck(q(15,16).mul(right).div(den.sq()).div(ar.mul(o.sub(ar))).lt(lo(q(4)))&&q(15,16).mul(q(38,100)).div(q(333,1000).sq()).div(ar.mul(o.sub(ar))).lt(lo(q(4))),"four-base curvature");
ck(q(234,100).mul(e1).lt(l)&&H.div(l).lt(lo(q(64).mul(q(1,4).sub(q(1,5))))),"four-base outward");
const o4=q(305,100).mul(q(136,1000)).add(q(234,100).mul(e1));
ck(q(1000,136).lt(lo(q(2)))&&o4.add(q(6).mul(e1.sq()).mul(e1).div(o.sub(e1.sq()))).lt(o),"four-base witness");
ck(q(9*63*63,4*9*64).lt(q(395,100).sq())&&q(9).mul(q(5,4).sq()).lt(q(395,100).sq()),"first splice a");
ck(q(5*63*63,2*9*64).lt(q(416,100).sq())&&q(10).mul(q(5,4).sq()).lt(q(416,100).sq()),"first splice b");
ck(q(63,3).div(sk).lt(q(43,10))&&q(11).mul(q(5,4).sq()).lt(q(43,10).sq()),"second splice a");
ck(q(3*92*92,16*93).lt(q(414,100).sq()),"second splice b");
ck(q(1,2).div(q(692,100)).lt(q(1,8))&&q(10,24).mul(q(49,48)).div(q(692,100)).lt(q(1,8)),"phase");
```
