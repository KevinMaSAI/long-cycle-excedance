
# A smooth Poisson profile for the actual occupancy amplitudes
2026-11-27 00:45 UTC. The new idea is to control A_n(r) on adjacent edge indices from a smooth profile, rather than compare every amplitude to the worst-case plateau. The following identities and uniform numerical bounds are proved; they do not yet bridge the remaining middle sign interval.

## Exact occupancy and Poissonization

Let P_r(N) be the probability that every cycle of a uniform permutation of r labels contains at least k balls when N labeled balls independently select uniform labels. Then A_n(r)=r P_r(n). To cross-check directly, a permutation cycle of length b receiving m balls contributes b^m/m! in the exponential generating variable for labels of balls, with m≥k, and t^b/b for the usual permutation cycle index. Hence r^n P_r(n) is n! times the coefficient of z^n t^r in
    exp(sum_(b≥1) (t^b/b) sum_(m≥k) (b z)^m/m!).
The same expression follows from the original cycle EGF after dividing by (1−t)^n, by the single-cycle identity C_m(t)/(1−t)^m=sum_(b≥1)b^(m−1)t^b. This verifies B_n(r)=r^n P_r(n)=r^(n−1)A_n(r).

Give each label independent Pois(λ) weights. Disjoint cycles having b labels then have independent Pois(bλ) total weights, and conditioning the total on N yields the preceding uniform model. Thus the Poissonized success probability is
    p_r(λ)=[z^r] g_λ(z), g_λ(z)=exp(sum_(b≥1) Pr(Pois(bλ)≥k) z^b/b)
          =(1−z)^(-1) exp(−P_λ(z)),
    P_λ(z)=sum_(b≥1) Pr(Pois(bλ)<k) z^b/b.
Use G with Gamma(k,1) density f_k(x)=exp(−x)x^(k−1)/(k−1)! and B=ceil(G/λ). Then Pr(Pois(bλ)<k)=Pr(G>bλ)=Pr(B>b); the Gamma-Poisson identity follows by differentiating the finite Poisson sum and taking the value at 0. Thus P_λ(z) is the expectation of sum_(b=1)^(B−1) z^b/b wherever it converges. Put c(λ)=exp(−P_λ(1)). Elementary harmonic bounds log B≤H_(B−1)≤log(2B−1) and Jensen give
    1/(1+2k/λ) ≤ c(λ) ≤ E(1/B) ≤ min(1, λ/(k−1)) ≤ 4c(λ).
For the upper Gamma inverse bound use E(1/G)=1/(k−1), and for the lower harmonic bound use a left-endpoint integral; the upper harmonic bound uses convexity of 1/x on intervals centered at j.

## Uniform coefficient-error bound without a power-of-k prefactor

Let R=exp[λ/(2(k+λ))]>1. Then for all r≥0,
    |p_r(λ)−c(λ)| ≤ 600 R^(−r).
Here g_λ−c/(1−z)=(exp(−P_λ(z))−c)/(1−z) is analytic on |z|≤R by the removable singularity and the exponential moment of B. To bound it, note that for each deterministic integer B and |w|=1,
    |exp(−sum_(b<B)w^b/b)| ≤ e² (|1−w|+1/B).
When |1−w|≥1/B apply Abel summation to the harmonic tail sum_(b≥B) w^b/b, which has modulus at most 2/(B |1−w|); the infinite identity is obtained by radial limiting from the disk. When |1−w|<1/B use |w^b−1|≤b |w−1| and exp(−H_(B−1))≤1/B, also valid when B=1. For random B the same bound with E(1/B) follows by geometric-mean ≤ arithmetic-mean. For |z|=R write w=z/R; then
    |P_λ(z)−P_λ(w)| ≤ E sum_(b<B) (R^b−1)/b ≤ E[R^B]−1 < 1.
In fact E[R^B]≤R (1−log R/λ)^(-k); writing K=k+λ and using −log(1−x)≤x/(1−x) gives log E[R^B]≤λ/(2K)+k/(2K−1)≤1/2+1/[2(2k−1)]≤.6<log 2. Hence |exp(−P_λ(z))|≤e³(|1−w|+4c). Moreover |1−z|≥max(|1−w|,R−1), and c/(R−1)≤5 because c≤min(1,λ/(k−1)) and R−1≥λ/[2(k+λ)]. Thus the analytic difference on |z|=R has modulus at most 27(1+20)+5=572<600. Cauchy coefficient extraction proves the bound. The corresponding relative bound is at most
    600(1+2k/λ) exp(−rλ/[2(k+λ)]).

## Adjacent variation of the smooth profile

Termwise differentiation on every compact λ interval in (0,∞) gives c'(λ)/c(λ)=sum_(b≥1) f_k(bλ). The Gamma density is unimodal with integral 1, zero at the origin for k≥2. Its equally spaced lattice sum times λ differs from 1 by at most λ sup f_k: use inward rectangles away from the one interval containing the mode for the upper bound and outward rectangles plus that interval for the lower bound. The peak f_k(k−1) is the mass at the mean of Pois(k−1). Fourier coefficient extraction, 1−cos θ≥2θ²/pi² on [−pi,pi], and a Gaussian integral give sup f_k≤sqrt(pi)/[2 sqrt(2(k−1))]<1/sqrt(k) for k≥3.

Define U(r)=r c(n/r) for real r>0. Then
    |(log U)'(r)| = |1−λ c'(λ)/c(λ)|/r ≤ n sup f_k/r².
Consequently |log(U(r+1)/U(r))|≤n sup f_k/[r(r+1)] and
    |log(U(r−1)U(r+1)/U(r)^2)| ≤ 2n sup f_k/(r²−1)   (r>1).
This is the sign-proof-relevant curvature estimate for the smooth profile around r of order sqrt(n).

## Explicit de-Poisson sandwich

Monotonicity of P_r(N) in N follows by adding balls with the same permutation and labeling experiment. For integer n and real 0<a<n take λ_±=(n±a)/r. Conditioning Poisson variables of means n±a on their total, and bounding the two bad tails by q=exp(−a²/[2(n+a)]) via their exponential moments, gives
    r[p_r(λ_−)−q] ≤ A_n(r) ≤ r[p_r(λ_+)+q].
The analytic coefficient bound therefore estimates each endpoint explicitly by c(λ_±) with absolute errors 600 R_±^(−r). Also the logarithmic profile shift satisfies
    |log(c(λ_±)/c(n/r))| ≤ |log(1±a/n)|+(a/r) sup f_k,
by integrating 0≤c'/c≤1/λ+sup f_k. One can now bound real neighboring amplitudes and curvature with no enumerated polynomial rows in regimes where these three error terms are small. Near fixed moderate n/k the absolute coefficient bound is not scale-sharp and the de-Poisson error needs optimization; no uniform middle-interval or full interlacing theorem is claimed from it yet.


## Adjustable analytic radius and a direct de-Poisson estimate (01:00 UTC)

The unit-circle estimate can use 9/4 in place of e². Let t=B|1−w|. If t≤5/3, the near-point bound gives ratio e^t/(1+t) to |1−w|+1/B, increasing in t and <9/4 at 5/3 (e^(5/3)<6). If t≥5/3, the harmonic-tail bound gives ratio exp(2/t)t/(1+t), decreasing in t and <9/4 at 5/3 (e^(6/5)<18/5). Thus the claimed constant is explicit. For any 0<a<k choose R=exp(aλ/(k+λ)). The previous calculation yields
    log E[R^B] ≤ a+a²k/[(k+λ)(k+λ−a)] ≤ a+a²/(k−a).
Use E(1/B)≤λ/(k−1) directly, without replacing it by 4c. Put X=(k+λ)/(a(k−1)). The coefficient error is at most
    [(9/4) exp(exp(a+a²/(k−a))−1)(1+X)+X] exp(−a rλ/(k+λ)).
Indeed the ratio E(1/B)/|1−z| and the corresponding c ratio on |z|=R are both bounded by X, since R−1≥aλ/(k+λ). This reduces the previous absolute prefactor in the moderate regime and lets a be chosen to balance degree attenuation against the exponential moment. It still becomes an absolute rather than relative bound when c tends to zero.

There is also a direct de-Poisson bound using asymmetric threshold crossing rather than shifting the Poisson means. For a fixed uniform permutation of the labels, adding ball N+1 first causes success only when exactly one deficient cycle had k−1 balls and the new ball hits that cycle. Omitting the restrictions on all other cycles yields
    0≤P_r(N+1)−P_r(N)≤(1/r) sum_(b=1)^r Pr(Bin(N,b/r)=k−1).
To see the prefactor, a length-b cycle is chosen by the new ball with probability b/r and its expected number in a uniform permutation is 1/b, by counting choices of the cycle. The summand polynomial of p=b/r is unimodal, has integral 1/(N+1), and peak at p=(k−1)/N. The same equally-spaced Riemann bound and Fourier binomial estimate as in the adaptive edge proof give, for N≥2k−2,
    P_r(N+1)−P_r(N) ≤ 1/(N+1) + sqrt(pi)/[2r sqrt(k−1)].
In the Fourier bound the variance Np(1−p) is at least (k−1)/2. The sum includes p=1, where the summand vanishes for the stated N and k≥3.

Fix n and any integer N0 in [2k−2,n]. For a Pois(n) total Y, compare P_r(Y) to P_r(n) by the last Lipschitz bound on Y≥N0 and the trivial error at most 1 when Y<N0. Use E|Y−n|≤sqrt(n) and the ordinary lower-tail bound. This proves
    |P_r(n)−p_r(n/r)| ≤ sqrt(n)[1/(N0+1)+sqrt(pi)/(2r sqrt(k−1))]
                           + exp(−(n−N0)²/(2n)).
This bound neither loses a factor exp(constant times a Poisson shift) nor requires assessing the right and left shifted expectations. It can still be too large relative to c on moderate rows. A next possible improvement would keep the event that other cycles were already admissible instead of discarding it; the exact first difference above isolates where such an improvement must enter.


## Exact first difference keeping the other cycles, and a centered second-difference bound (01:02 UTC)

For r≥2 and integer N≥k−1 the exact replacement for the coarse monotone derivative is
    ΔP_r(N)=(1/r) sum_(b=1)^r B_N(b/r) P_(r−b)(N−k+1),
    B_N(p)=Pr(Bin(N,p)=k−1).
For b=r set P_0(0)=1 and P_0(other)=0, which matters only when N=k−1. Condition on the length-b cycle hit by the new ball and on its size being k−1 just before it is hit. The permutation on the complement is uniform and independent, and the conditional labels of the remaining balls are independent uniform labels there. This gives the factor P_(r−b), with no double-counting since there is exactly one deficient cycle just before first success. The expected number of b-cycles is 1/b and the hit probability is b/r, giving the coefficient 1/r.

For k≥64 and N≥8k, introduce beta peak constant J=sqrt(pi)/(2 sqrt(k−1)). The second difference is bounded by the following function, decreasing in N:
    M(N) =
       [4(N+1)/(3 k r (N−k+2))] [sqrt(k+1)/(N+1)+2/r]
       + [1/(N−k+2)+4J/(3r)] [1/(N+2)+J/r]
       + 2(63/64)^N.
Proof: split the exact difference at b=r/4. On b>r/4 and N≥8k, B_N(b/r)≤Pr(Bin(N,b/r)≤N/8)≤[2^(1/8)(7/8)]^N<(63/64)^N by applying Markov to 2^(−Bin), using (9/8)^8>2. Both successive first differences cost at most this tail each. On b≤r/4, the other-cycle weight is bounded by P_(r−b)(N−k+1)≤(N+1)/(k(r−b))≤4(N+1)/(3kr), by the ordinary amplitude upper bound. Expand
    B_(N+1) P(other at next N)−B_N P(other at N)
     = (B_(N+1)−B_N) P(other at N)+B_(N+1) ΔP(other at N).
The second term is bounded by the product of the coarse beta-lattice first-difference bound on the complement and the lattice mass for row N+1. This is exactly the second summand of M, because r−b≥3r/4 and N−k+1≥2k−2.

For the first term use B_(N+1)−B_N=B_N[(k−1)−(N+1)p]/(N−k+2). Put g(p)=|k−1−(N+1)p|B_N(p). Each side of the zero of the absolute-value factor is log-concave, hence unimodal on that subinterval, by log concavity of the affine positive factor and B_N. The integral of g is ≤sqrt(k+1)/(N+1): divide (N+1)B_N by its integral to get the Beta(k,N−k+2) density, whose mean and variance give E[(k−1−(N+1)p)^2]≤k+1. Its lattice sum divided by r is at most integral plus 2 sup g/r by the same unimodal rectangle argument on each of the two humps (extend each by zero outside its interval). The peak sup g<1 follows by Fourier extraction: for X=Bin(N,p),
    E[(X−Np)exp(iθX)] = Np(1−p)(exp(iθ)−1)(1−p+p exp(iθ))^(N−1).
Use |exp(iθ)−1|≤|θ| and the earlier Gaussian integrand. The absolute coefficient at k−1 is ≤[N/(N−1)]pi/4. Add p B_N≤J to replace Np by (N+1)p. Their sum is <1 for k≥64, N≥8k. Endpoints p=0,1 follow directly (both B_N=0). This gives the first summand of M.

For an independent Pois(n) total Y, take any integer N0 between 8k and n. On Y≥N0 the centered discrete Taylor formula, with slope ΔP_r(n), has remainder bounded by (M(N0)/2)(Y−n)(Y−n−1). This follows by telescoping forward or backward, and the product is nonnegative for integer Y. Over all Y its expectation is n, while the linear term averages to zero. On the exceptional Y<N0 the remainder is bounded by 1+n (since P and its first difference lie in [0,1]). Thus a new de-Poisson estimate is
    |P_r(n)−p_r(n/r)| ≤ n M(N0)/2 + (1+n)exp(−(n−N0)²/(2n)).
This retains the other-cycle probability in the first term and explicitly cancels the mean shift, instead of using only monotonicity or a first absolute difference. It is an amplitude error bound, not a sign theorem; making it tight enough across adjacent amplitudes in the remaining moderate ratio range is still open.


## A fixed-n critical-cycle model avoids de-Poisson loss (01:15 UTC)

Near edge indices r of order sqrt(n), a cycle of b labels contains n b/r balls on average. Only a few integer b near k r/n should need probabilistic treatment. This section derives exact finite critical-cycle formulas and rigorous upper/lower errors without changing n or assuming independent multinomial coordinates.

Choose integers 1≤L<U≤r+1. Use a model in which lengths b<L are forbidden, lengths b≥U always accepted, and lengths L≤b<U accepted precisely when their actual ball count is ≥k. Denote its probability by M_(L,U)(n,r). Let d_(j,U) denote the usual normalized permutation count on j labels with all cycle lengths ≥U, with d_(0,U)=1 and zero if 0<j<U. For critical counts m_b put B=sum_(L≤b<U) b m_b and m=sum m_b. If Q_n(r; b_1,...,b_m) denotes the multinomial probability that every critical cycle count is ≥k, with individual cell probabilities b_i/r and one leftover cell of mass 1−B/r, the model is exactly
    M_(L,U)(n,r) =
    sum_(m_b≥0, B≤r, m≤floor(n/k)) d_(r−B,U) Q_n(r; b_1,...,b_m)
             · prod_(b=L)^(U−1) 1/[b^(m_b) m_b!].
The cycle index gives the parity-free weight and the remaining long-cycle factor; allocating balls to critical cycles only depends on the cell sizes. The sum includes m=0 with Q=1. This is not a finite-row check; it is a coefficient identity and a low-dimensional approximation when the critical band is narrow.

The genuine occupancy probability obeys
    M_(L,U) − sum_(b≥U, b≤r) (d_(r−b,L)/b) Pr(Bin(n,b/r)<k) ≤ P_r(n)
    ≤ M_(L,U) + sum_(b<L) (1/b) Pr(Bin(n,b/r)≥k) min(1,(n−k)/(k(r−b))).
For the lower bound, model success but actual failure requires a long bad cycle. Condition on a specified length-b cycle: the residual permutation must at least have no lengths below L, giving factor d_(r−b,L), and the probability its ball count is below k is independent of the residual permutation. For the upper bound, actual success but model failure implies a short good cycle. Condition on its ball count M≥k and use the ordinary upper bound on actual complement success P_(r−b)(n−M)≤min(1,(n−k)/(k(r−b))). The expected number of specified b-cycles gives 1/b in both bounds. Use positive lower bound zero when n<k, or restrict to n≥k as in the application. Binomial tails can be bounded explicitly by exp[k−μ−k log(k/μ)] with μ=n b/r, using the appropriate side of k and the binomial exponential MGF bounded by the Poisson MGF; if μ=k the bound is 1. This supplies rigorous errors without requiring all P_r(N) in a window.

One can truncate the model to m≤J with explicit nonnegative additive error. Let H_c=sum_(b=L)^(U−1) 1/b. The all-critical compositions with r−B=0 can only have m≥ceil(r/(U−1)); they cost at most sum_(m≥max(J+1,ceil(r/(U−1)))) H_c^m/m!. All other nonzero long factors are ≤1/U, so the remainder is at most the previous quantity plus (1/U)sum_(m>J)H_c^m/m!. In a one-critical-length approximation this verifies the 0-, 1- and 2-cycle contributions exactly and controls all higher counts, including the zero-complement boundary.

### Smoothness of each critical factor at fixed n

For B>0 and real r>B, condition on the total X in the critical cells. Then X=Bin(n,γ), γ=B/r, and the conditional distribution within the cells uses probabilities b_i/B independent of r. Thus Q_n(r)=E F(X) for a monotone F taking values in [0,1] (add labeled balls inside the critical cells). Its Bernstein derivative in γ is
    n sum_(j=0)^(n−1) [F(j+1)−F(j)] Pr(Bin(n−1,γ)=j).
The differences are nonnegative with sum ≤1. Therefore the derivative is at most n times the peak, bounded by n sqrt(pi)/[2 sqrt(2(n−1)γ(1−γ))] by the Fourier estimate. A second derivative differentiates the masses and subtracts neighboring Bin(n−2,γ) masses against the very same first differences. Their pointwise adjacent difference is at most pi/[4(n−2)γ(1−γ)] for n≥3, by inserting |1−exp(iθ)|≤|θ| in the Gaussian Fourier estimate. Consequently the second γ derivative in absolute value is at most pi n(n−1)/[4(n−2)γ(1−γ)]. Compose with γ'=−B/r² and γ''=2B/r³ to get explicit fixed-n neighbor variation. When r−B≥U is large, the factorial-tail count estimate with threshold U can also replace the deterministic factors d_(r−B,U) by their common limit, with an explicit error. Together these give a way to bound locality of the actual edge amplitudes without a Poisson sandwich. The main remaining step is to choose the critical band and error margins uniformly enough to certify the mixed parameter range; no sign result is claimed from this subsection alone.
