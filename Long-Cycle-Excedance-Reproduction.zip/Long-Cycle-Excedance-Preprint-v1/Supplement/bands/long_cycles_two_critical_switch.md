# Switching the critical cycle size reaches n≥20k at k≥128

2026-11-27 03:00 UTC. For every integer k≥128 and n≥20k the original E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient, without an upper bound on n. For k≥256 the separate all-n result applies. The smaller-n gap for 128≤k<256 remains. No original row enumeration.

## New occupancy profile in the transition
Handle 128≤k≤255, n≥20k. At r0∈[.45sqrt(n),.62sqrt(n)], define β0=kr0/n. For nearby integers r=r0−1,r0,r0+1 we find a decreasing model F≥c with |P_r(n)−F(r)|<εc and |F'|<hc, then A_n(r0−1)/A_n(r0)<1.68 and A_n(r0+1)/A_n(r0)<1.12. Use models retaining exact multinomial success for independent marked cycle sizes, not independent occupancies.

- If β0≤1.5, take the length-one-only critical model with c=e^(−1), m≤7, just as in the previous single-critical proof. Here r0≥23, r−m≥15 and the hard-count plus omitted mass costs <.0014 in units of c, by 6/7! plus 3 times the exponential tail from m=8. A long cycle of size b≥2 has μ/k=b/(kr/n)≥23/18 at b=2, and the Chernoff exponent decreases by at least 17 per step in b. This gives `relative error < .0014+1.5 exp[−128(.277²/2−.277³/3)]/(1−exp(−17)) < .033`. There are no forbidden short cycles. The multinomial derivative bound gives h=.59 since r≥(22/23).45sqrt(n).
- If β0>1.5, forbid singleton cycles, allow length-two cycles independently according to their joint occupancy event, and accept cycles of length ≥3 in the model. Put c=e^(−3/2) and retain m≤5 marked length-two cycles with multiplicity weight (1/2)^m/m!. Here r0≥30, hence r−2m≥19 and the relative replacement error of d_(r−2m,3) by c is at most .00016. The sum of allowed critical weights is at most exp(.5), and the omitted mass in units c is bounded by 5 sum_(m≥6)(1/2)^m/m!, including a possible zero complement. Thus the total relative hard-count/omission cost is <.0004. For a short (singleton) cycle μ/k≤20/29<.69. Its success probability is ≤exp[−128(.31²/2+.31³/3)] from the upper-tail Chernoff bound. The expected number of singleton cycles is one, so ignoring admissible singletons costs at most five times this in units c. For the long cycles kr/n≤.62sqrt(255/20)(31/30)<30/13, giving μ/k≥1.30 at b=3 and exponent decrease ≥12 per extra b. In the union bound a bad long cycle contributes weight 1/b≤1/3; the positive complement with no singletons has d_(j,2)≤1/2, and the zero complement's failure event is impossible. Thus its total relative cost is at most (5/6) exp[−128(.30²/2−.30³/3)]/(1−exp(−12)). Combined ε=.014 suffices. The derivative bound is h=.36: the marking argument now uses exp(.5) rather than exp(1), plus r≥(29/30).45sqrt(n).

In both cases the Fourier point-mass bound .45/sqrt(k) follows from variance ≥.95(k−1), using the same Gaussian and remainder bounds as before. The ratio checks are 1+(h+2ε)/(1−ε)<1.68 and (1+1/r0)(1+ε)/(1−ε)<1.12 in both cases. Switching the modeled critical cycle is what avoids counting many mutually incompatible sensitive events in one derivative bound.

## Edge and exact center
Use the established adaptive edge with D=n−1≥2559, M=floor(.6sqrt(D)), S=D/M. In the high band m≥.45sqrt(n), neighbor profile window [.45,.62] sqrt(n), take (eta,lambda,alpha)=(.26,.44,.14). Outside the window the outgoing pure log losses are ≥(2559/2560)/(2·.45²) to the left and ≥(D/sqrt(n))(5/3−50/31) to the right, absorbing C=27/8 and 1.5C respectively. The curvature cost is bounded by 1.68·1.12 exp(−25/9). The first opposing witness pair costs (1.68+1.12)·.26, the remaining odd offsets at most 2C sum_(odd a≥3) .26^a(1+a/23); combined <1.
For 10≤m<.45sqrt(n) take (.116,.43,.16), because m+1<.47sqrt(n), m+2<.49sqrt(n), and use the old C min(r,H) ratio and curvature bounds. For small r≤21 in the curvature estimate use D/r²≥2559/441 to absorb 1.5C². For 1≤m≤9 take (.001,.006,.006). The standard geometric witness margins pass. The exact beta drift is <.35+.0027a for r≤M+a: use (27/4)(r/n+.45/sqrt(k)) at r≥H/2 and the <.001 geometric Markov bound below. Signed-mean margins pass all three regimes. The old floor correction is <2.9 using M≥30, and phase discrepancy <π/40: the positive linear correction is ≤.6/sqrt(D) and the negative cubic correction by (n/D)(10/3)(.6)^3/sqrt(D), each individually <1/40. Thus the usual splice and degree argument apply.

Use the K=128 central harmonic profile, .18 vertical log and .8 real-part fraction, with shorter shift cutoff L=6. Eight replayed analytic intervals cover all 20k≤n≤68k; the earlier results supply n≥44k through infinity. The finite replay is on uniform analytic bounds, not actual rows.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[128,20,16,200,6,21],[128,21,17,200,6,22],[128,22,17,200,6,23],[128,23,17,200,6,24],[128,24,18,200,6,25],[128,25,18,200,6,26],[128,26,21,200,6,37],[128,37,29,200,6,68]];
const covered={128:20};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(29,10).div(sk));
 ck(q(0).lt(rad)&&q(25*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const exl=y=>eb(y)[0],exu=y=>eb(y)[1],C=q(27,8), v=q(2559,2560), sk=q(113,10), n0=q(2560), eM=q(116,1000), eH=q(26,100), eL=q(1,1000);
ck(covered[128]>=44,"overlap");
ck(o.lt(q(4).mul(q(43,100).sq()).mul(pl).mul(q(11,24)).mul(q(95,100)).mul(q(127,128))),"Fourier main");
ck(q(800).lt(exl(q(40))),"Fourier tail");
function geo(first,ratio){return first.div(o.sub(ratio));}
function expbad(x){return em(q(128).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3)))));}
const rate1=q(23,36),c1=q(277,1000), c2=q(3,10),f1=q(33,1000),f2=q(14,1000),L=q(168,100),R=q(112,100);
ck(o.add(c1).lt(q(23,18))&&q(17).lt(q(128).mul(rate1.sub(q(1,2)))),"long b2");
ck(q(14,10000).add(q(3,2).mul(geo(expbad(c1),em(q(17))))).lt(f1),"one-cycle model error");
let mx=q(62,100).sq().mul(q(255,20)).mul(q(31,30).sq());
ck(mx.lt(q(30,13).sq())&&q(12).lt(q(128).mul(q(13,30).sub(q(1,3)))),"long b3");
let x=q(31,100), sh=q(128).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3))));
ck(q(4,10000).add(q(5).mul(em(sh))).add(q(5,6).mul(geo(expbad(c2),em(q(12))))).lt(f2),"two-cycle model error");
const A=q(45,100),r1=A.mul(q(22,23)),r2=A.mul(q(29,30));
ck(exu(o).mul(A).div(sk.mul(r1.sq())).lt(q(59,100)),"one-cycle derivative");
ck(exu(q(1,2)).mul(A).div(sk.mul(r2.sq())).lt(q(36,100)),"two-cycle derivative");
for(const [h,eps,b] of [[q(59,100),f1,q(24,23)],[q(36,100),f2,q(31,30)]]){
ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L) && b.mul(o.add(eps)).div(o.sub(eps)).lt(R),"profile ratios");
}
const lH=q(44,100),lM=q(43,100), lL=q(6,1000),aH=q(14,100),aM=q(16,100);
ck(o.div(eH).lt(exl(q(25,9).mul(q(1,2).sub(q(1,90))))),"high pure");
ck(o.div(eM).lt(exl(v.div(two.mul(q(47,100)).mul(q(49,100))))),"middle pure");
ck(q(1000).lt(exl(q(2559,220))),"low pure");
ck(C.div(lH).lt(exl(v.div(two.mul(A.sq())))) && q(81,16).div(lH).lt(exl(v.mul(q(50)).mul(q(5,3).sub(q(50,31))))),"profile exit");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(exl(q(25,9))),"high curvature");
ck(C.sq().mul(q(23,22)).div(aM.mul(o.sub(aM))).lt(exl(v.div(q(47,100).sq()))) && C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(exl(q(2559,441))),"middle curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,23,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witness");
const d=q(35,100),b=q(27,10000),C2=two.mul(C);
ck(C2.mul(q(6,10).div(q(50)).add(A.div(sk))).lt(d)&&C2.div(n0).lt(b),"drift");
ck(q(7000).lt(exl(q(2995,10000).mul(q(128)))),"heavy drift");
for (const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){
const z=o.sub(l.sq());
ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");
}
```
