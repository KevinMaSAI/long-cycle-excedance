# Full n coverage for every k≥32

2026-11-27 06:00 UTC block. For all integer k≥32 and n≥k, genuine E_(n,k) has n−1 simple real roots, and E_(n,k)/t strictly interlaces the next quotient. This lowers the all-row threshold from 48 to 32. All original assumptions unchanged, including excedances, not descents. The conjecture for smaller k remains open in this work. No original polynomial rows were enumerated.

For 32≤k≤47, earlier notes long_cycles_k32_through_3k.md and long_cycles_k32_from_16k.md cover n≤3k and n≥16k. The edge in long_cycles_k32_edge_two_marks.md gives all edge witnesses and next-row signs throughout the missing interval 3k≤n≤16k. Here is the central bridge. Larger k already have all rows. All joining adjacent pairs already follow from the strict sign comparison on the old row.

## 1. Block-degree majorization for the far anchors

Use the previous exact anchor prefix and centered formula. For absolute degree marks of δ(z)=(1−z)(g(z)−1), classify support in units of k, with norm upper bounds expressed in units 2/k:
  [1,1] atom: 1/2;
  (1,1.5] earlier linear prefix: 1/6;
  (1.5,2) later linear prefix: 1/12;
  [2,3) two-cycle variation: .0485;
  [j,j+1) for j≥3: .146/j!.
The first prefix bound is the exact telescoped difference 1/k−1/floor(1.5k)≤1/(3k). The second is at most 1/floor(1.5k)−1/(2k−1)≤1/(6k), using floor(1.5k)≥(3k−1)/2 and clearing denominators. The two-cycle variation is <.097/k, and T(jk)<.292/(k j!) as verified in the K32 upper proof. We may overapproximate a half-open mark interval by its closed endpoints.

For a distinguished anchor i, the absolute coefficient norms of the mark classes in B_i are bounded by their class masses times y=p for a primary or y=x for any farther anchor. This uses the fixed distance bounds in units 2/k and |ξ|^b≤|ξ|^k, exactly as in the old anchor proof. The remaining expansion consists of products of distinct linear factors. Enlarge to ordered arbitrary factors with the usual division by m! for m factors. Then the total coefficient-norm upper bound for classes having aggregate lower and upper degree bounds (ell,h) is the corresponding coefficient of
  (y^m/m!) (sum_classes mass · z^ell w^h)^m,
where ell,h are encoded in quarter-k units. This follows by grouping positive absolute weights for each ordered mark selection; allowing factors to repeat only enlarges the sum. Merge classes with identical degree brackets using the positive convolution. The construction uses deterministic degree ranges of coefficients, not samples or numerical roots.

For an analytic ratio interval B≤n/k≤N keep only ell≤4(N−1)+4/K, with K=32, since centered shifts satisfy b≤n+1−k. This necessary condition cannot discard any retained term. Both count ratios d_(n−b)/d_n and d_(n+1−b)/d_(n+1) are <1.81, and when n−b≥2k they are <1.046 by d_n≥.555/k and d_j≤.58/k for j≥2k; those bounds are proved in the K32 upper note. In each aggregate degree class use factor 1.046 when B−h/4≥2, and 1.81 otherwise. At a far anchor radial power n−b is at least max(k−1,(B−h/4)k), where k−1 also covers the extra centered shift b=n+1−k. Thus its contribution is bounded by the weighted far lattice at exponent corresponding to the integer half-power max(15,floor((4B−h)K/8)). The factor 15 is below (K−1)/2; floors round attenuation in the conservative direction. Pure diagonal far contribution is g. Sum all these positive upper bounds to obtain W, and use W/3 for the unweighted value since every far level weight≥3. For old primary amplitude, the same class convolution with y=p and no far lattice bounds |C_n−1|. It slightly overcounts by allowing the new boundary degree; this is safe. One can take the minimum with the old hybrid tilted amplitude comparison at L=2: baseline 1.046 and excess .764 after shift n−2k.

For larger ratio intervals also compute the standard tilted far bound and take its minimum with the new block bound. For the reference prefix short difference at L=3 the tolerance .046 follows from [.555,.58]/k for both d counts. Beyond the short cutoff including omitted coefficients use tolerance 1. The primary real lower bound takes the better of 1−P from the block amplitude, and the earlier reference comparison Re P_*−epsilon. The latter uses the positive scalar bound .64 of the real-axis reference for s≥4sqrt(k), the unweighted bound 2−exp(ξp), and the sharpened direct log bound exp(−.76p)(1−(.76p)^2/2) when .76p<1. For s≤4sqrt(k) explicitly check the same ratio intervals using a=4 and using only 2−exp(ξp) as reference; no vertical comparison with positive real s is assumed there. Adjacent drift may use the smaller of the primary 2epsilon bound and the already-proved direct overlap + denominator + new boundary estimates. On fractional B the pure-atom new boundary requires at least ceil(B−1) atoms (for an integer B we safely use B−1). The diagonal mismatch uses T(floor(B−1)k) and angle factor 1/B, so uses floor(B−1)! rather than a factorial of a noninteger. All these choices are explicit in the exact replay.

The exact central ellipse holds on every analytic interval in the replay. The absolute/block branch supplies 3≤n/k≤9.25, with quarter-spaced cutoffs used only to sharpen constants; the combined block/tilted branch supplies 9.25≤n/k≤16. Old row witnesses at n theta=j pi have sign (−1)^j; at every old central zero the next-row sign equals −sin(n theta), because the real primary amplitude exceeds the Euclidean norm of the two residual budgets. No target real-root assumption is used.

## 2. Phase and exact discrete floor splice

Set D=n−1≥95, M=floor(sqrt(D)/2), S=D/M and y=M/D. The usual exact quadratic floor bound for any fixed M is
 S/sqrt(k) ≤ min{ [4(M+1)^2−1]/(M sqrt(K)), sqrt(N)·[4(M+1)^2−1]/[2M(M+1)]}.
The second follows from n≤Nk and monotonicity of D/sqrt(D+1), reaching its indicated envelope at D_max=4(M+1)^2−1. The first increases with M (M≥2); the second decreases, as the last factor equals 2+2/M−1/[2M(M+1)]. Split at M_ref=floor(sqrt(NK−1)/2); compare the first at M_ref−1, their minimum at M_ref, and the second at M_ref+1. This is an exact stronger radius estimate, not a sweep of k values. It is replayed at each interval's right endpoint.

There is no need for a separate angular exclusion to the previous cosine witness at the floor splice. Indeed (n theta(S))/pi−M is positive by atan x≥x−x³/3: it is at least y[1−(pi²/3)(n/D)(M²/D)]>0 using n/D≤96/95 and M²/D≤1/4. For the upper half use the fifth-order bound atan x≤x−x³/3+x⁵/5. Since y²≤1/(4·95), the cubic net factor is >3.2, so this difference is ≤y−3.2 M y²≤1/(12.8 M)<1/40. Thus the splice is already strictly on the correct side of M pi in phase, and strictly before (M+1)pi. The edge witness at S provides phase-index M sign; after it the central witnesses begin with phase index M+1. Because n theta varies monotonically here, the join sign at any located old root is in the intended phase interval. The familiar half-line count and parity, reciprocal symmetry, simple zero at 0 and degree n−1 now give the full row with simple real roots and next-row signs, hence strict quotient interlacing. Endpoint rows and their adjacent comparisons are part of the verified bounds. Combined with the earlier three ranges, this proves all n for k≥32 and no farther lower-k coverage is inferred.

## Exact central and splice replay

This uses BigInt rationals, finite geometric/tail upper estimates, and directed exponential series. The few square root guesses are checked by exact squaring or integer interval membership. Interval constants represent analytic statements over a range, not individual E polynomials. Parent checked the overlap order explicitly, the quarter-degree concatenation bounds, and the oriented phase sign. All checks passed.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=32,sk=q(565,100),xi=q(823,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[9.25,400,60,3,11.25],[11.25,400,60,3,13.25],[13.25,400,60,3,15.25],[15.25,400,60,3,16],[3,439,55,2,3.25],[3.25,462,50,2,3.75],[3.75,477,60,2,4],[4,492,60,2,4.25],[4.25,507,60,2,4.75],[4.75,532,60,2,5.25],[5.25,557,60,2,5.75],[5.75,581,60,2,6.5],[6.5,614,60,2,7.25],[7.25,634,60,2,7.75],[7.75,654,60,2,8.5],[8.5,673,65,2,9],[9,683,65,2,9.25],[9.25,744,60,3,11.25],[11.25,800,60,3,13.25],[13.25,855,60,3,15.25],[15.25,872,60,3,16]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(32,100).sq().div(two));
ck(pu.div(q(60)).mul(ex(q(5,16)).sq()).lt(q(32,100).sq()),"vertical log");
ck(q(64,100).lt(q(68,100).mul(ca)),"vertical positive");
ck(q(90,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(32,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=15;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(584,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(97,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(14,100):L===3?q(46,1000):q(584,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1046,1000):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const core=a0===400;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 {
  const types=[[4,4,q(1,2)],[4,6,q(1,6)],[6,8,q(1,12)],[8,12,q(97,2000)]];
  for(let j=3;j<=Math.ceil(N);j++)types.push([4*j,4*(j+1),q(146,1000).div(fact(j))]);
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=o,wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const factor=4*B-h>=8?q(1046,1000):U0;
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1046,1000).mul(abs).add(q(764,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const eps=up(abs.mul(delta).add(ps));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=core?o.sub(abs):max(q(16,15).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(76,100)); if(!core&&pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  c=max(c,ref.sub(eps));slice=q(90,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 
 const mr=Math.floor(Math.sqrt(N*K-1)/2);
 ck(4*mr*mr<=N*K-1 && N*K-1<4*(mr+1)*(mr+1),"cut index");
 const wcut=q(4*mr*mr-1,mr-1).div(sk), w1=q(4*(mr+1)*(mr+1)-1,mr).div(sk), vm=q(Math.round(4*N),4).mul(q(4*(mr+1)*(mr+1)-1,2*mr*(mr+1)).sq()),v2=q(Math.round(4*N),4).mul(q(4*(mr+2)*(mr+2)-1,2*(mr+1)*(mr+2)).sq());
 if(!core)ck(wcut.lt(a)&&(w1.lt(a)||vm.lt(a.sq()))&&v2.lt(a.sq()),"floor splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0], D=q(95), y2=q(1,4*95);
ck(pl.sq().div(q(3)).mul(o.sub(q(6).mul(y2))).lt(q(16,5))===false,"positive arctangent correction");
ck(q(10,3).mul(q(96,95)).div(q(4)).lt(o)&&q(1,4).div(q(4).mul(q(16,5))).lt(q(1,40)),"floor phase orientation and width");
let nCover=q(3);
for(const [B,a,at,L,N] of rows)if(a!==400){
 const old=q(Math.round(4*B),4),next=q(Math.round(4*N),4);
 ck(!nCover.lt(old)&&nCover.lt(next),"interval overlap");
 nCover=next;
}
ck(!nCover.lt(q(16)),"last interval");
```
