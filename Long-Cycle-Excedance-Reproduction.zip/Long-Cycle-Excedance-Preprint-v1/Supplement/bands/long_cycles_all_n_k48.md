# Full n coverage for every k≥48

2026-11-27 05:30 UTC. For all integer k≥48 and n≥k the original cycle-restricted excedance polynomial E_(n,k) has n−1 simple real roots, and E_(n,k)/t strictly interlaces the next quotient. This lowers the complete all-n threshold from 64 to 48. The mother conjecture for smaller k remains open in this work. No original polynomial rows were enumerated.

The earlier initial and upper proofs long_cycles_k48_through_7k.md and long_cycles_k48_from_16k.md cover the outer ranges, and k≥64 is already complete. Here we fill 7≤H=n/k≤16 at 48≤k≤63. Adjacent comparisons at the endpoints are included.

## 1. Sharper direct logarithm bound at the primary pole
Put w=s+pi i, xi_j=w/(w+2pi i j), j nonzero. On s≥4sqrt(k), |xi_j|≤1 and arg xi_j differs from zero by at most pi/2+theta, theta=atan(pi/s), with sin theta<1/8. For any xi among these and 0≤t≤1,
 |1−xi t| ≥ (2/3)|1−xi|.
To see this, write r=|xi| and c=cos(arg xi). If c≥0 and r≤c, the segment minimum is at t=1. For c≥0 and r>c it is sqrt(1−c²), while |1−xi|²≤2−2c, giving ratio ≥1/sqrt(2). If c<0 the segment minimum is 1, and |1−xi|²≤2+2sin(theta)<9/4. Thus the old integral log g(xi)=xi^k integral_0^1 t^(k−1)/(1−xi t) dt now gives |log P_*(w)|≤3p/4, replacing p for the direct reference bound only. The absolute coefficient norm, tilt and drift still use the original p,x. Hence when 3p/4<1 include exp(−3p/4)(1−(3p/4)^2/2) in the lower bound on Re P_*. Take its maximum with the old scalar and unweighted lower bounds. The relative angular error stays below .26 as before, so each lower bound also gives the .92 angular margin for a phase window of width π/16.

The shorter count ratios from long_cycles_k48_through_7k.md give baseline U=1.04 as long as n−b≥2k and retained d-ratio U0=1.81 otherwise. For a split L=3 the symmetric relative difference from 1 for n−b≥3k is <.037; beyond the split it is at most 1, including omitted coefficients. Use the same finite-prefix tilt as before with δ=.037 for primary ε, and with U=1.04 and excess U0−U=.77 for the far envelope. Its weighted bound is
 W=(exp(Jx)−1)[U exp(−α)j+U0 exp(−α(B−1))f+(U0−U)exp(−α(B−L)) f_L]+g .
This separates the early and late weight by endpoint convexity exactly as in the old harmonic method. V=W/3 bounds the unweighted envelope. Use the earlier direct primary adjacent drift based on the overlapping old prefix, denominator difference and new boundary coefficient, not 2ε, with the larger absolute coefficient norm for that drift. The diagonal mismatch uses .524. The replay checks the signed ellipse with these constants for six overlapping strip intervals 7→8→9→11→13→15→16. They have respective a values 6.30,6.61,7.25,7.83,8.36,8.63 for s≤a sqrt(k), α=.60,L=3. For s≤4sqrt(k) the already proved small-s signs are available from K48, even in n≥2k−1. For the splice M=floor(sqrt(D)/2) the exact quadratic floor-envelope comparison of the preceding proof selects the endpoint radius; angular width is π/16 throughout.

## 2. Local occupancy profile at 7≤H≤16

Put D=n−1≥335, choose r0∈[.42,.62]sqrt(n) and β0=kr0/n. As before only marked critical-cycle sizes require joint multinomial success. Small hard-count complements are checked by the earlier relative bounds .00016,.002,.08 for residual ≥4U,3U,2U, respectively, and bound 1 for positive residual below 2U from 0≤d≤1/U<2c. A zero complement with U=2 has error exp(1)−1<1.72, and omitted tails include all zero complements via the factor 1/c. The beta and long-tail estimates use the exact binomial probability ratio loss jΦ(w) and geometric progression of probabilities; mode peak .45/sqrt(k) from Robbins and variance ≥6(k−1)/7, with j=k−1 or k as appropriate. Relative long union factor is 3/2 for U=2, 5/6 for U=3. The profile F is decreasing and ≥c.

- β0≤1.25: r0≥8, U=2, retain at most seven singleton cycles. For m=0,1 critical cycles complements ≥6; m=2,3 ≥4; m=4,5,6 positive; m=7 nonnegative. Thus use errors (.002,.002,.08,.08,1,1,1,1.72) weighted by 1/m! and omission 3 times its tail. Cost <.110. Long mean at b=2 exceeds 1.42 in threshold units, with geometric prefactor <.222 and exponent loss ≥47(.42²/2−.42³/3), increasing >9/step. Total error .130, derivative <1.32 in c units from exp(1)·.45/[sqrt(k)(.42·7/8)²].
- 1.25<β0≤1.4: r0≥9. Same model with hard errors (.00016,.002,.002,.08,.08,1,1,1), and omission, costing <.031. At b=2 the mean ratio ≥9/7>1.285, prefactor <.295, long exponent loss via .285 and step >6. Total .130, derivative <1.28 using r≥(8/9).42sqrt(n).
- 1.4<β0≤1.5: r0≥10. Hard singleton cost <.008 (two each of .00016,.002,.08,1). Mean ratio at b=2 relative to k−1 is ≥(40/33)(63/62)>1.23, prefactor <.35, step >5; total error .195. The marked singleton derivative is suppressed: for its p=1/r, w=Dp/(k−1)≤(48/47)(10/9)(5/7)<.812. Its peak has an extra factor exp[−47(.188²/2+.188³/3)]. With r≥(9/10).42sqrt(n), derivative <.50.
- β0>1.5: r0≥11, U=3, forbid singletons, retain m≤4 critical size-two cycles. Hard errors (.002,.08,.08,1,1) with weights (1/2)^m/m!, and omission factor 5; cost <.078. Singleton upper-tail mean ratio ≤11/15<.734 and prefactor .25 by the exact binomial ratio, exponent ≥48(.266²/2+.266³/3), with relative union factor 5. Long b=3 mean ratio >1.478 since β0≤.62sqrt(63/7)=1.86 and neighbor factor ≤12/11. Prefactor .204, step >11, exponent via .478; total error .260. The marked derivative exp(.5)·.45/[sqrt(k)(.42·10/11)²]<.74.
All four cases give common amplitude ratios <2.82 to the left, <1.86 to the right by 1+(derivative+2epsilon)/(1−epsilon) and (1+1/r0)(1+epsilon)/(1−epsilon). Every hard-count total and bound is replayed exactly.

## 3. Adaptive edge with the same floor M

High m≥.42sqrt(n): M≥9, the pure first ratio <.156 from the quartic bound on the right loss at M=9 with D≥4M². The actual outward ratio is <.45 by the neighbor profile; beyond it left outgoing loss ≥D/[2(.42sqrt(n))²] absorbs factor 27/8, and right outgoing loss ≥(D/sqrt(n))(2−50/31) absorbs 81/16. At old roots curvature factor 2.82·1.86 exp(−4) gives α=.11. First opposing witnesses cost (2.82+1.86)·.156 and odd offsets a≥3 use global factor C(1+a/8) with C=27/8. Total <1.

Low m<.42sqrt(n): for either main center, put r=m+1 when bounding the first right step, so D≥(r−1)^2/.42²−1, and also D≥335. For r≤8 use D/r²≥335/64 to get pure ratio .091; for r=9,10 use D/r²≥(8/9)^2/.42²−1/81 to get .127; above r=10 use (10/11)^2/.42²−1/121 and .112. These are from the log loss ≥(D/r²)(1/2−1/(3r)), whose formula in r decreases for r≥2 at fixed D before each uniform reduction; last loss increases with r under the stated lower n relation. For the first left step with center m, use D/(2m²) instead, which is stronger. Actual ratios are <.48 using factors C(1+1/r) for outgoing right bases (≤1.5C at r=2..8, ≤10C/9 at 9..10, ≤12C/11 thereafter) and C to the left. Pure ratios improve outward, while right amplitude factors decrease. The same three D/r² lower bounds, now for either main curvature center including m, and C²(1+1/r) give both alphas .18. At witness m≥8 the pure first loss is ≥(1/.42²−1/64)(1/2−1/24), so use .077; at m≤7 use .046 from D≥335. The standard linear amplitude-ratio opposition sums pass. The first witness again dominates for s>D.

For the drift when r≥.75H, use cap ceil(4k/3) giving H/A<3.58 and beta lattice d_r≤3.58(r/n+.45/sqrt(k)). Below .75H, use the exact binomial tail convolution as in long_cycles_k48_from_16k.md, now x=D/r≥1.329 k, geometric loss >16, and bound d_r<.10. Thus .333+.011a is a uniform right-tail budget and .333 a uniform left budget. Signed-mean margins hold with both alpha/lambda pairs. The cubic phase error bound in units pi is <1/16 because sqrt(D)>18.3, sufficient for the replayed central angular exclusion. The standard degree/inversion/parity argument now proves all rows in 7≤H≤16, including both endpoint pairs. All neighboring rows are the actual E_(n,k), and all strict inequalities were verified by the exact arithmetic below.

## BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=48,sk=q(69,10),xi=q(816,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[7,630,60,3,8],[8,661,60,3,9],[9,725,60,3,11],[11,783,60,3,13],[13,836,60,3,15],[15,863,60,3,16]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(26,100).sq().div(two));
ck(pu.div(q(92)).mul(ex(q(5,16)).sq()).lt(q(26,100).sq()),"vertical log");
ck(q(71,100).lt(q(74,100).mul(ca)),"vertical positive");
ck(q(92,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(26,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=23;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(q(524,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(87,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(136,1000):L===3?q(37,1000):q(524,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(104,100):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const ps=em(al.mul(q(B-L))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 if(B<8 && L===2){
  const P=min(U0.mul(abs),U.mul(abs).add(E.mul(ps))), xc=xi.mul(x),ell=lat((B-2)*K/2,0);
  const high=U0.mul(ex(xc).sub(o).sub(xc)).add(q(119,1000).mul(x));
  W=up(high.mul(f).add(U.mul(x).mul(j).div(two)).add((B>=4?U:U0).mul(x).mul(ell).div(q(4))).add(g));
  let atom=o;for(let u=1;u<B;u++)atom=up(atom.mul(p.div(two)).div(q(u)));
  drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(atom).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }else{
  const eps=up(abs.mul(delta).add(ps));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(B-1)))).mul(f)).add(E.mul(em(al.mul(q(B-L))).mul(fl)));
  W=up(ex(J.mul(x)).sub(o).mul(far).add(g));let at=o;for(let j=1;j<B;j++)at=up(at.mul(p.div(two)).div(q(j)));drift=up(p.mul(ex(p)).div(q(K+1)).add(two.mul(at).mul(ex(p.div(two)))).add(two.mul(abs).div(q(K))).add(two.mul(abs).div(q(B*K))));
  let ref=max(q(71,60).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(3,4)); if(pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  c=ref.sub(eps);slice=q(92,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 ck(V.lt(slice),"central splice "+B);
 const mr=Math.floor(Math.sqrt(N*K-1)/2);
 ck(4*mr*mr<=N*K-1 && N*K-1<4*(mr+1)*(mr+1),"cut index");
 const wcut=q(4*mr*mr-1,mr-1).div(sk), w1=q(4*(mr+1)*(mr+1)-1,mr).div(sk), vmax=q(4*N).mul(o.add(q(1,mr)).sq()),v2=q(4*N).mul(o.add(q(1,mr+1)).sq());
 ck(wcut.lt(a)&&(w1.lt(a)||vmax.lt(a.sq()))&&v2.lt(a.sq()),"floor splice");
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
const lo=x=>eb(x)[0], pk=q(45,100),k0=q(48),sk0=q(69,10),D=q(335),n0=q(336),sp=q(183,10),v=D.div(n0),A=q(42,100),C=q(27,8);
ck(q(48).mul(ex(q(1,6*335))).lt(pk.sq().mul(two).mul(pl).mul(q(6,7)).mul(q(47))),"modal binomial");
function lp(x){return q(47).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))))}
function upL(x){return x.sq().div(two).add(x.sq().mul(x).div(q(3)))}
function geom(x,y){return x.div(o.sub(y));}
const a1=q(13,100),a2=q(13,100),a3=q(195,1000),a4=q(26,100);
ck(q(142,100).lt(q(64,45))&&q(9).lt(q(47).mul(q(21,100))),"case 1 long slope");
ck(q(285,1000).add(o).lt(q(9,7))&&q(6).lt(q(47).mul(q(285,2000))),"case 2 long slope");
ck(q(123,100).lt(q(40,33).mul(q(63,62)))&&q(5).lt(q(47).mul(q(23,200))),"case 3 long slope");
ck(q(1478,1000).lt(q(3).div(q(186,100).mul(q(12,11))))&&q(11).lt(q(47).mul(q(478,2000))),"case 4 long slope");
for(const [eps,hard,x,ge,pf,other] of [
[a1,q(11,100),q(42,100),9,q(222,1000),q(0)],
[a2,q(31,1000),q(285,1000),6,q(295,1000),q(0)],
[a3,q(8,1000),q(23,100),5,q(35,100),q(0)],
[a4,q(78,1000),q(478,1000),11,q(204,1000),q(5,4).mul(em(q(48).mul(upL(q(266,1000)))))]
]){
 ck(pk.div(sk0.mul(o.sub(o.div(o.add(x))))).lt(pf),"long prefactor");
 const fac=eps===a4?q(5,6):q(3,2);
 ck(hard.add(fac.mul(pf).mul(geom(em(lp(x)),em(q(ge))))).add(other).lt(eps),"profile error");
}
ck(q(11,15).lt(q(734,1000))&&pk.div(sk0.mul(q(266,1000))).lt(q(1,4)),"short prefactor");
ck(q(48,47).mul(q(10,9)).mul(q(5,7)).lt(q(812,1000)),"singleton suppressed derivative");
const L0=q(282,100),R0=q(186,100),oneB=q(188,1000);
for(const [e,r,h,r1,mul,sup] of [
[a1,q(9,8),q(132,100),q(7,8),o,o],
[a2,q(10,9),q(128,100),q(8,9),o,o],
[a3,q(11,10),q(50,100),q(9,10),o,em(q(47).mul(upL(oneB)))],
[a4,q(12,11),q(74,100),q(10,11),ex(q(1,2)),o]
]){
 ck(mul.mul(pk).mul(sup).div(sk0.mul(A.mul(r1).sq())).lt(h),"derivative");
 ck(o.add(h.add(two.mul(e)).div(o.sub(e))).lt(L0)&&r.mul(o.add(e)).div(o.sub(e)).lt(R0),"neighbor ratios");
}
const eH=q(156,1000),lH=q(45,100),aH=q(11,100),lL=q(48,100),aL=q(18,100);
const e1=q(91,1000),e2=q(127,1000),e3=q(112,1000);
ck(o.div(eH).lt(lo(q(2).sub(q(4,27)).add(q(1,81)).sub(q(4,3645))))&&L0.mul(eH).lt(lH),"high step");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&q(81,16).div(lH).lt(lo(v.mul(sp).mul(q(2).sub(q(50,31))))),"profile exits");
function curv(x,y,a){return x.div(a.mul(o.sub(a))).lt(lo(y));}
ck(curv(L0.mul(R0),q(4),aH),"high curvature");
const dl1=D.div(q(64)), dl2=q(8,9).sq().div(A.sq()).sub(q(1,81)), dl3=q(10,11).sq().div(A.sq()).sub(q(1,121));
for(const [base,eta,fac,minR] of [[dl1,e1,q(3,2),8],[dl2,e2,q(10,9),9],[dl3,e3,q(12,11),11]]){
 ck(o.div(eta).lt(lo(base.mul(q(1,2).sub(q(1,3*minR)))))&&C.mul(fac).mul(eta).lt(lL),"low pure region");
 ck(curv(C.sq().mul(fac),base,aL),"low curvature region");
}
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L0.add(R0).mul(eH).add(cost(eH,8,true)).lt(o),"high witness");
ck(o.div(q(77,1000)).lt(lo(o.div(A.sq()).sub(q(1,64)).mul(q(1,2).sub(q(1,24)))))&&o.div(q(46,1000)).lt(lo(D.div(q(49)).mul(q(1,2).sub(q(1,21))))),"witness loss");
ck(cost(q(77,1000),8,false).lt(o)&&cost(q(46,1000),1,false).lt(o),"low witness");
const d=q(333,1000),b=q(11,1000),C3=q(358,100),x=q(1329,1000);
ck(q(10,3).div(o.sub(o.div(q(16)))).lt(C3)&&C3.mul(q(1,2).div(sp).add(pk.div(sk0))).lt(d)&&C3.div(n0).lt(b),"drift");
ck(x.lt(q(4,3).mul(v))&&q(16).lt(q(329,1000).mul(k0).add(o)),"drift spacing");
ck(C.div(v).mul(x).mul(pk).div(sk0).mul(geom(em(lp(q(329,1000))),em(q(16)))).lt(q(1,10)),"drift below cap");
for(const [a,l] of [[aH,lH],[aL,lL]]){const zz=o.sub(l.sq());ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(zz)).add(a.mul(d.div(zz).add(b.mul(o.add(l.sq())).div(zz.sq())))).lt(o.sub(a)),"signed means");}
ck(q(1,2).div(sp).lt(q(1,16))&&q(10,24).div(v.mul(sp)).lt(q(1,16)),"phase");
ck(q(1,8).sq().lt(o)&&pu.div(q(4).mul(sk0)).lt(q(1,8)),"sharper log separation");

function hardSum(weights,err,begin,c,n=10){
 let s=q(0);for(let i=0;i<begin;i++){
 let w=o;for(let j=1;j<=i;j++)w=w.mul(weights).div(q(j));
 s=s.add(w.mul(err[i]));
 }
 let w=o;for(let j=1;j<=begin;j++)w=w.mul(weights).div(q(j));
 return s.add(c.mul(w).div(o.sub(weights.div(q(begin+1)))));
}
const ea=q(16,100000), eb0=q(2,1000), ec=q(8,100), ee=q(172,100);
ck(hardSum(o,[eb0,eb0,ec,ec,o,o,o,ee],8,q(3)).lt(q(11,100)),"hard cost case 1");
ck(hardSum(o,[ea,eb0,eb0,ec,ec,o,o,o],8,q(3)).lt(q(31,1000)),"hard cost case 2");
ck(hardSum(o,[ea,ea,eb0,eb0,ec,ec,o,o],8,q(3)).lt(q(8,1000)),"hard cost case 3");
ck(hardSum(q(1,2),[eb0,ec,ec,o,o],5,q(5)).lt(q(78,1000)),"hard cost case 4");
```
