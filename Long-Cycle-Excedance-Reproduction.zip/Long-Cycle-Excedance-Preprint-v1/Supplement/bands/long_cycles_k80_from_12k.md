# Uniform upper band for k≥80, n≥12k

2026-11-27 04:00 UTC. For 80≤k≤95 and every n≥12k, the genuine E_(n,k) has simple real roots and its quotient by t strictly interlaces the next quotient. Larger k already have full coverage. The central joins below overlap the independent eventual theorem; no actual polynomial row was enumerated.

## Uniform profile and edge for 12≤H≤323
Use k≥80, n≥12k, D=n−1≥959 and H=n/k. The binomial peak .43/sqrt(k) applies by Robbins, for either j=k−1 or j=k and the n or n−1 row used here, where appropriate; the smallest relevant variance is (11/12)(k−1). At j=k−1 for n−1 trials, p0≤1/12; at j=k for n trials also p0≤1/12. The geometric tail prefactors follow from the exact backward/forward ratios and exponential loss j(w−1−log w), as in long_cycles_k96_from_12k.md.

For r0∈[.45,.62]sqrt(n), β0=kr0/n, split at 1.5.
- β0≤1.5: r0≥14. Use U=2, retain m≤7 critical singletons. For m≤5 the complement ≥8, so replacement relative error ≤.00016; for m=6,7 complement ≥6, so error ≤.002. These weighted costs plus 3 sum_(m≥8)1/m! total <.0006. Long-b first mean ratio at b=2 is ≥56/45>1.244, giving geometric prefactor <.25 and minimum point loss 79(.244²/2−.244³/3); the loss increases by at least 9 per increment. Use relative union factor 3/2. Total ε=.055 suffices. The profile derivative in units c is bounded by .76, using r≥(13/14).45sqrt(n).
- β0>1.5: r0≥19. U=3, forbid singleton cycles and retain m≤4 critical size-two cycles. All retained complements ≥10, so .002 exp(.5)+5 sum_(m≥5)(.5)^m/m!<.0048 is safe. For singleton success the mean ratio ≤19/27<.71 gives geometric prefactor .17 and loss 80(.29²/2+.29³/3), with relative factor 5. Long mean ratio at b=3 is >1.6 since β_r≤.62sqrt(95/12)(20/19)<15/8; take prefactor .13, loss 79(.6²/2−.6³/3), exponent increase >15 per b, and relative factor 5/6. Thus ε=.022 suffices. The derivative with mass exp(.5) and r≥(18/19).45sqrt(n) costs <.44.
In both branches the marked exact multinomial derivative and monotone profile give ratios 1.93 left and 1.20 right. No assumption of independent occupancy cells.

Use M=floor(.55sqrt(D)), S=D/M, C=27/8. High m≥.45sqrt(n) uses (eta,lambda,alpha)=(.205,.41,.10); M≥17, giving the right pure log loss ≥(.55)^(-2)(1/2−1/51). For denominators outside the high profile, left loss ≥D/[2(.45sqrt(n))²] with factor C, right loss ≥(D/sqrt(n))(20/11−50/31) with factor C·21/20. At old zeros curvature products involve factors 1.93·1.20 exp(−1/.55²). High witness first opposing offsets use local ratios, the remaining odd offsets use C(1+a/14). Medium 10≤m<.45sqrt(n) uses (.135,.499,.215), from m+1<.483sqrt(n) and m+2<.515sqrt(n). For curvature at r≥14 use C²·15/14 and exp(−D/r²); for r≤13 use 1.5C² exp(−959/169). At a medium witness, left amplitude ratio ≤C, right ≤C(1+a/m); total opposition is ≤2C times [η/(1−η²)+η(1+η²)/(2m(1−η²)²)]. This accounts for the factor 2m rather than m. Small m≤9 uses (.013,.066,.066) and the old all-direction bound.

For a uniformly sharper drift, if r≥3H/4 use occupancy cap L=ceil(4k/3), giving H/A<3.52. Thus d_r≤3.52(r/n+.43/sqrt(k)). For r<3H/4 put x=D/r≥1.331k. In the exact beta lattice the j=k−1 mass at a/r costs ≤(.43/sqrt(k)) exp[−jΦ(xa/j)] with Φ(w)=w−1−log w. Its exponent increase as a grows is ≥x−j≥.331k+1>26. Since H/A≤C(n/D)(x/k), use the decreasing function x exp[−jΦ(x/j)] for x≥k to bound the weighted lattice from x=1.331k. The exact replay verifies d_r<.01 there, via cubic log truncation and a geometric tail. Thus at r≤M+a overall drift <.235+.0037a. Signed-mean margins pass in each band. The floor gives S≤(20/11)sqrt(n)+3.6 and phase error <π/40. No H upper assumption was used by this edge; the center needs it only on its indicated intervals.

## Dense edge for H≥300
For 80≤k≤95, n≥300k, use M=floor(.8sqrt(D)). For r≤.85sqrt(n), r<H/2 and good-label occupancy yields .999r<A≤r. Use the earlier quadratic witness proof, with D≥23999 and M≥123: first pure ratio η=.46, third opposing offset pure ratio <.0012 from 9D/[2M(M+3)], and subsequent ratios decrease. For m≤15 use η=.001 directly. Outward λ=.49 and curvature α=.31 still hold. For right tails, all a<7 remain in r<H/2 since (.85−.8)sqrt(n)>7. Their drift, and the entire left drift, are <.001. Use other right drift .23+.00015a via the same cap proof above. The signed numerator includes the late tail a≥7 with factor αλ^6, and passes. Splice S≤(5/4)sqrt(n)+1.6, phase <π/40.

## Central link and eventual threshold
The two-cycle count peak is <.575/k by the earlier minimization, with the other endpoint estimates unchanged. Block variation <.087/k entails T(2k)<.131/k, T(Lk)<.262/(k L!) and weighted tilt J=[e^α+e^(2α)/2+.087e^(3α)/(1−e^α/3)]/2. The unweighted coefficient mass ≤1.632/k. The old harmonic-anchor center now uses δ=.524/L!, mismatch coefficient .524, and vertical log <.20 for k≥80, s≥4sqrt(k); thus Re P_*(s+iπ)>.78 P_*(s), with angular margin >.98. The positive scalar floor is (13/10)/(a/u_K+2), improved by exp(−p)(1−p²/2) when p<1. Earlier small-s signs cover the remaining strip.
The exact replay covers analytic intervals from 12k through 323k with the first edge; the second edge and exact intervals from 300k through 4896k continue coverage. For k≤95, 2(k−1)≤188<exp(5.3), and the known eventual n≥900(k−1)log(2(k−1)) theorem therefore starts before 4770k, strictly overlapping. Final adjacent pairs are included.

## Exact BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(156)).mul(ex(q(5,16)).sq()).lt(q(20,100).sq()),"vertical log bound");
ck(q(78,100).lt(q(80,100).mul(o.sub(q(20,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(20,100).div(o.sub(q(20,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[80,12,90,650,5,22],[80,22,132,425,5,49],[80,49,186,250,7,100],[80,100,246,125,10,176],[80,176,304,75,10,272],[80,272,331,60,10,323],[80,300,367,60,16,851],[80,851,526,25,16,1752],[80,1752,666,15,16,2823],[80,2823,775,10,16,3824],[80,3824,853,8,16,4635],[80,4635,877,8,16,4896]];
const covered={80:12};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(89,10);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(87,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(816,1000).mul(p)).sub(o).mul(q(524,1000)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(524,1000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(524,1000).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(13,10).div(a.div(sk).add(two)); const ref2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const dense=B>=300; const rad=a.sub((dense?q(8,5):q(18,5)).div(sk));
 ck(q(0).lt(rad)&&(dense?q(25*N,16):q(400*N,121)).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1],C=q(27,8),sk=q(89,10),A=q(45,100), mt=q(43,100),sp=q(309,10),n0=q(960),D=q(959),v=D.div(n0),u=q(55,100);
ck(q(188).lt(lo(q(53,10)))&&covered[80]>4770,"eventual overlap");
ck(q(1000,575).lt(lo(q(575,1000).sub(q(1,80))))&&q(87,1000).mul(q(3,2)).lt(q(131,1000)),"cycle tail");
ck(q(80).mul(eu(q(1,6*959))).lt(mt.sq().mul(two).mul(pl).mul(q(11,12)).mul(q(79))),"Stirling peak");
function geom(x,y){return x.div(o.sub(y))}
function upp(x){return q(80).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3))));}
function low(x){return q(79).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))));}
const e1=q(55,1000),e2=q(22,1000);
ck(q(1244,1000).lt(q(56,45))&&q(9).lt(q(79).mul(q(28,45).sub(q(1,2)))),"long singleton profile");
ck(mt.div(sk.mul(o.sub(o.div(q(1244,1000))))).lt(q(1,4)),"prefactor b2");
ck(mt.div(sk.mul(o.sub(q(71,100)))).lt(q(17,100))&&mt.div(sk.mul(o.sub(q(5,8)))).lt(q(13,100)),"other prefactors");
ck(q(62,100).sq().mul(q(95,12)).mul(q(20,19).sq()).lt(q(15,8).sq())&&q(15).lt(q(79).mul(q(8,15).sub(q(1,3)))),"long doubleton profile");
ck(q(6,10000).add(q(3,8).mul(geom(em(low(q(244,1000))),em(q(9))))).lt(e1),"error singleton");
ck(q(48,10000).add(q(5).mul(q(17,100)).mul(em(upp(q(29,100))))).add(q(5,6).mul(q(13,100)).mul(geom(em(low(q(6,10))),em(q(15))))).lt(e2),"error doubleton");
const L=q(193,100),R=q(120,100);
for (const [h,eps,r,ss,m] of [[q(76,100),e1,A.mul(q(13,14)),o,q(15,14)],[q(44,100),e2,A.mul(q(18,19)),q(1,2),q(20,19)]]){
 ck(eu(ss).mul(mt).div(sk.mul(r.sq())).lt(h),"profile derivative");
 ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L)&&m.mul(o.add(eps)).div(o.sub(eps)).lt(R),"neighbor ratios");
}
const eH=q(205,1000),lH=q(41,100),aH=q(10,100),eM=q(135,1000),lM=q(499,1000),aM=q(215,1000),eL=q(13,1000),lL=q(66,1000);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,51))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(483,1000)).mul(q(515,1000))))),"mid pure");
ck(o.div(eL).lt(lo(D.div(q(220)))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&C.mul(q(21,20)).div(lH).lt(lo(v.mul(sp).mul(o.div(u).sub(q(50,31))))),"exits");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM)&&C.mul(q(3,2)).mul(eL).lt(lL),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(o.div(u.sq()))),"high curvature");
ck(C.sq().mul(q(15,14)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(483,1000).sq())))&&C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(D.div(q(169)))),"mid curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,14,true)).lt(o)&&cost(eM,20,false).lt(o)&&cost(eL,1,false).lt(o),"witnesses");
const d=q(235,1000),b=q(37,10000),C3=q(352,100);
ck(q(10,3).div(o.sub(o.div(q(20)))).lt(C3)&&C3.mul(u.div(sp).add(mt.div(sk))).lt(d)&&C3.div(n0).lt(b),"main drift");
ck(q(1331,1000).lt(q(4,3).mul(v))&&q(26).lt(q(331,1000).mul(q(80)).add(o)),"lower drift spacing");
ck(C.div(v).mul(q(1331,1000)).mul(mt).div(sk).mul(geom(em(low(q(331,1000))),em(q(26)))).lt(q(1,100)),"lower drift magnitude");
for(const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){const z=o.sub(l.sq());ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");}
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sp)))).lt(q(18,5)),"floor");
ck(u.div(sp).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sp)).lt(q(1,40)),"phase");
const dense=q(4,5),f=q(999,1000),de=q(46,100),dl=q(49,100),da=q(31,100),dn0=q(24000),v0=q(23999,24000),s0=q(154);
ck(q(17,20).sq().mul(q(95,300)).lt(q(1,4))&&q(1000).lt(lo(q(24))),"dense lower amplitudes");
ck(o.div(de).lt(lo(o.div(dense.sq()).mul(q(1,2).sub(q(1,369))))),"dense pure");
ck(o.div(q(12,10000)).lt(lo(q(9).div(two.mul(dense.sq())).mul(q(123,126)))),"third witness");
ck(de.mul(q(17,16)).div(f).lt(dl)&&q(81,16).div(dl).lt(lo(v0.mul(s0).mul(q(5,68)))),"dense actual");
ck(o.div(f.sq().mul(da).mul(o.sub(da))).lt(lo(o.div(dense.sq()))),"dense curvature");
const z0=o.sub(de.sq());
ck(two.div(f).mul(de.add(q(12,10000).mul(q(19,16).div(z0).add(de.sq().div(q(8).mul(z0.sq())))))).lt(o),"dense witness");
const dd=q(23,100), db=q(15,100000),full=q(1,1000),u0=o.sub(dl),w0=o.sub(dl.sq());let p=o;for(let j=0;j<6;j++)p=p.mul(dl);
ck(C3.mul(dense.div(s0).add(mt.div(sk))).lt(dd)&&C3.div(dn0).lt(db),"dense drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(80)))),"dense small drift");
const late=da.mul(p).mul(dd.add(q(7).mul(db)).div(u0).add(db.mul(dl).div(u0.sq())));
ck(two.mul(da).add(full).add(da.mul(dl).mul(full).div(w0)).add(da.mul(full).div(w0)).add(late).lt(o.sub(da)),"dense margin");
ck(o.div(dense.sq()).div(o.sub(o.div(dense.mul(s0)))).lt(q(8,5)),"dense floor");
ck(dense.div(s0).lt(q(1,40))&&q(10,3).mul(dense.sq()).mul(dense).div(v0.mul(s0)).lt(q(1,40)),"dense phase");
```
