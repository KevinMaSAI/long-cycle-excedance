# All-n occupancy edge for 32≤k≤47, n≥3k via at most one critical mark

2026-11-27 05:45 UTC block. This establishes the edge and its next-row signs at M=floor(sqrt(n−1)/2), with S=(n−1)/M, throughout 32≤k≤47 and n≥3k. It is **not** an all-row result: the central region must still join this edge when 3k<n<16k. No original-polynomial rows checked. Earlier verified ranges in these k are n≤3k and n≥16k.

## Short exact occupancy sandwich

Let P_r=A_n(r)/r, the success probability. Write β=kr/n and p_b(r)=Pr(Bin(n,b/r)≥k) at size b. From n≥3k, the binomial point peak at j=k−1 or k is <.50/sqrt(k) using Robbins and variance ≥2(k−1)/3. The exact point probability relative to its mode is bounded by exp[−jΦ(w)], w=np/j, Φ(w)=w−1−log w. For w>1 a lower tail ending at j=k−1 has geometric multiplier 1/(1−1/w), and for w<1 an upper tail from j=k has 1/(1−w), by the exact probability ratios. The long-cycle failure costs at most sum_(b≥U)(1/b)(1−p_b(r)), since a uniform permutation has expected 1/b cycles of size b. Its first mass bound uses the ratio w≥U/β and exponent loss 31Φ(U/β); the loss increases by ≥31((U/β)−1)/U per extra b and the multiplier decreases. Thus the absolute costs below follow even without physical independence of the cycle occupancy cells.

Hard normalized counts d_(r,2) lie in [.36,.38] for r≥4 by the alternating derangement formula. Also d_(r,3)≥.2 for r≥3: check r=3,..,7 directly, and for r≥8 recurrence r d_r=sum_(a≤r−3)d_a with hard head a<5 gives (1+1/3+1/4)+.2(r−7)≥.2r. Necessity of a successful singleton when the random permutation has any yields P_r≤d_(r,2)+(1−d_(r,2))p_1(r), where one singleton is selected deterministically conditional on the permutation. To lower-bound P_r, take disjoint permutations with no short cycles and with exactly one marked critical cycle. Singleton critical gives P_r≥d_(r,2)+d_(r−1,2)p_1(r)−long error at U=2. Doubleton critical and no singleton give P_r≥d_(r,3)+(1/2)d_(r−2,3)p_2(r)−long error at U=3. The multiplicity 1/2 for a size-2 mark is exact. Since these are disjoint restrictions on a permutation, subtracting the unconditional probability of any bad long cycle is safe.

For every 5≤r≤M, β≤.5sqrt(47/3)<2. The shape-dependent bounds below give uniform ratios A_(r−1)/A_r, A_(r+1)/A_r and their product. The upper expressions use p_1(r+1)≤p_1(r); to bound p_1(r−1), use neighbor correction r/(r−1)≤5/4. Use d bounds on all neighbors even if r+1>M.
- β≤1.4: U=2 long error <.021 at first mean >10/7. Then P_r≥.339+.36 p_1(r), while P_(r−1)≤1 and P_(r+1)≤.38+.64p_1(r). The ratio (linear numerator)/(linear denominator) is maximized at p=1; with 6/5 this gives right <1.76. The product ratio neglecting (r−1)(r+1)/r² is maximized at p=0 by differentiating (linear numerator)/(linear denominator)^2; it is <3.32. Left <2.95.
- 1.4<β≤1.7: U=3 long error <.002 at first mean ≥30/17. For p_2(r) the lower-tail mean ratio to k−1 is ≥(20/17)(47/46)>1.2, yielding p_2(r)>.68. Thus P_r≥.266. Left singleton mean ratio ≤25/28 gives p_1(r−1)<.68, so P_(r−1)≤.8152; on the right the mean ratio ≤5/7 yields p_1(r+1)<.066, so P_(r+1)≤.42224. The normalized amplitude ratios are <3.08,1.92, product <4.88.
- 1.7<β≤2: U=3 long error <.007 (initial ratio≥1.5), so P_r≥.193 without a critical-mark term. Mean ratios ≤25/34 and 10/17 give singleton success probabilities <.09 and .007 to each side respectively. Thus neighbor probability bounds .4376,.38448 and normalized ratios <2.28,2.40 with product <4.55.
The numerical losses, maxima and costs above are exact rational comparisons in the replay.

## Edge sign and drift bounds
Take D=n−1≥95,H=n/k and M=floor(sqrt(D)/2)≥4. For r≤M the left first pure loss is ≥2, hence ratio .136; the right loss gives .172 by the quartic expansion at M≥5 or directly by D≥95 at M=4. Use the occupancy ratios above whenever the denominator base r≥5. If a first right base r≤4 use pure loss ≥(95/16)(1/2−1/12), absorbing even 1.5C, C=27/8; below 5 left pure loss ≥95/32 with amplitude ≤C. Hence at all brackets λ=.44, since for right later ratios both pure ratios and crude factors C(1+1/r) decrease, and the later left factors ≤C are absorbed by the stronger second-step log loss ≥6. More explicitly, after the first right step, pure loss at base r+1 with r=m+1≤M is ≥D/[r(r+1)]+D/[2(r+1)(r+2)]≥4(4/5+4/15); any remaining factor ≤1.5C still gives <.44. For r≥5 curvature product ≤4.88 exp(−4); below 5 use C²·1.5 exp(−95/16), giving α=.10 throughout. At m≥5 the first witness pair is estimated by its actual left ratio times .136 and right ratio times .172 from the matching beta case; later odd offsets use the same .172 geometric and global amplitude C(1+a/5). At m=4 use pure .085 and C(1+a/4), and at m≤3 use .017 and C(1+a). All witness budgets pass, and the first remains dominant past s=D.

For drift r≥.75H, cap ceil(4k/3) gives H/A<3.62, hence beta lattice d_r≤3.62(r/n+.50/sqrt(k)). Below that use x=D/r≥1.319k and the weighted probability ratio bound as in the K32 upper proof, step exponent >11 and d_r<.12. Thus for r≤M+a one has .51+.038a, with .51 on the whole left. The standard signed-mean margin with α=.10,λ=.44 is positive, giving simple zeros in every edge bracket and strict next-row signs. The phase adjustment at S=D/M is <π/16 by n≥96 and cubic atan. No conclusion is made for s<S by this note.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}

const lo=x=>eb(x)[0],eu=x=>eb(x)[1],C=q(27,8),K=q(32),sk=q(565,100),pl=q(157,50),p=q(1,2),n0=q(96),D=q(95),sv=q(974,100),A=q(1,2),F=q(3,5);
ck(sk.sq().lt(K)&&sv.sq().lt(D)&&q(47,12).lt(q(4)),"range and beta ceiling");
ck(K.mul(eu(q(1,6*95))).lt(p.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(31))),"Robbins a");
function Phi(w,upper){const x=upper?o.sub(w):w.sub(o), cubic=x.sq().mul(x).div(q(3));return upper?x.sq().div(two).add(cubic):x.sq().div(two).sub(cubic);}
function lowerTail(w){return p.div(sk.mul(o.sub(o.div(w)))).mul(em(q(31).mul(Phi(w,false))));}
function upperTail(w){return p.div(sk.mul(o.sub(w))).mul(em(q(32).mul(Phi(w,true))));}
function bad(U,w){return lowerTail(w).div(q(U).mul(o.sub(em(q(31).mul(w.sub(o)).div(q(U))))));}
ck(bad(2,q(10,7)).lt(q(21,1000)),"U2 long");
ck(bad(3,q(30,17)).lt(q(2,1000))&&bad(3,q(3,2)).lt(q(7,1000)),"U3 long");
ck(q(68,100).lt(o.sub(lowerTail(q(6,5))))&&q(6,5).lt(q(20,17).mul(q(47,46))),"doubleton success");
ck(upperTail(q(25,28)).lt(q(68,100))&&upperTail(q(5,7)).lt(q(66,1000))&&upperTail(q(25,34)).lt(q(9,100))&&upperTail(q(10,17)).lt(q(7,1000)),"singleton success");
const bp=q(339,1000),qp=q(36,100),right=q(38,100),rp=q(64,100);
ck(rp.mul(bp).lt(two.mul(qp).mul(right))&&right.mul(qp).lt(rp.mul(bp)),"monotonic ratios A");
ck(o.div(bp).lt(q(295,100))&&q(6,5).mul(right.add(rp)).div(bp.add(qp)).lt(q(176,100))&&right.div(bp.sq()).lt(q(332,100)),"neighbors A");
for(const [den,left,u,L,R,cur] of [[q(266,1000),q(8152,10000),q(42224,100000),q(308,100),q(192,100),q(488,100)],[q(193,1000),q(4376,10000),q(38448,100000),q(228,100),q(240,100),q(455,100)]]){
ck(left.div(den).lt(L)&&q(6,5).mul(u).div(den).lt(R)&&left.mul(u).div(den.sq()).lt(cur),"neighbors B,C");
}
const eta=q(172,1000),eL=q(136,1000),lam=q(44,100),alpha=q(10,100);
ck(q(1000,136).lt(lo(q(2)))&&o.div(eta).lt(lo(q(2).sub(q(4,15)).add(q(1,25)).sub(q(4,625))))&&o.div(eta).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"pure first");
ck(q(308,100).mul(eL).lt(lam)&&q(240,100).mul(eta).lt(lam)&&C.mul(q(3,2)).div(lam).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"actual ratios");
ck(q(488,100).div(alpha.mul(o.sub(alpha))).lt(lo(q(4)))&&C.sq().mul(q(3,2)).div(alpha.mul(o.sub(alpha))).lt(lo(D.div(q(16)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R] of [[q(295,100),q(176,100)],[q(308,100),q(192,100)],[q(228,100),q(240,100)]])ck(L.mul(eL).add(R.mul(eta)).add(cost(eta,5,true)).lt(o),"high witness");
const tiny=q(17,1000),t4=q(85,1000);
ck(o.div(tiny).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&o.div(t4).lt(lo(D.div(q(16)).mul(q(1,2).sub(q(1,12))))),"low pure");
ck(cost(tiny,1,false).lt(o)&&cost(t4,4,false).lt(o),"low witness");
const C3=q(362,100),dd=q(51,100),bb=q(38,1000),xx=q(1319,1000),v=D.div(n0);
ck(q(10,3).div(o.sub(o.div(q(13)))).lt(C3)&&C3.mul(A.div(sv).add(p.div(sk))).lt(dd)&&C3.div(n0).lt(bb),"cap drift");
ck(xx.lt(q(4,3).mul(v))&&q(11).lt(q(319,1000).mul(K).add(o)),"lower drift threshold");
ck(C.div(v).mul(xx).mul(p).div(sk).mul(em(q(31).mul(Phi(xx,false)))).div(o.sub(em(q(11)))).lt(q(12,100)),"lower drift bound");
const z=o.sub(lam.sq());
ck(two.mul(alpha).add(dd).add(alpha.mul(lam).mul(dd).div(z)).add(alpha.mul(dd.div(z).add(bb.mul(o.add(lam.sq())).div(z.sq())))).lt(o.sub(alpha)),"signed margin");
ck(q(1,2).div(sv).lt(q(1,16))&&q(10,24).mul(n0.div(D)).div(sv).lt(q(1,16)),"phase near splice");
```
