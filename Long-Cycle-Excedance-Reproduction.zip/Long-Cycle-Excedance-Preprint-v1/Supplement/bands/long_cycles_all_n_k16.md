# All n for k≥16: central bridge and exceptional edge
November 27, 2026. Result: for every k≥16 and n≥k, E_(n,k) has simple real roots including one zero, and the quotients by t strictly interlace from n to n+1. The remaining k in the mother conjecture after combining prior proofs are 14 and 15. This is not a claim that the mother conjecture is completely solved.
 
## Division of proof
For k≥20 use long_cycles_all_n_k20.md. For 16≤k≤19 the onset and sparse proof through old n=3k are in long_cycles_k16_through_3k.md and its prior onset reference. For old n≥16k use long_cycles_k16_upper_and_edge.md. For 3k≤n≤16k use its edge with M=floor(sqrt(n−1)/2), except D=n−1∈[53,63] where M=4. The central proof below is for that same closed range. Every pair bound uses the old row n but includes row n+1, so the joins do not omit crossing pairs.
 
## Central glue
Use the main residue, farther residue and adjacent drift conventions in long_cycles_all_n_k20.md. B≤n/k≤N and a denotes the upper s/√k. The old and new normalization count peak for j≥2k is .591/k, lower for j≥3k is .555/k; two-cycle Δ variation .119/k, all Δ mass at j≥2k .179/k, and tail at Lk bounded by .358/(kL!) when the threshold is Lk. The exponent coefficient total is ξ=.84 in 2/k units. Relative error .154 for residual≥2k, .065 for ≥3k, .716/L! for ≥Lk, L≥4; compatible unsigned count upper 1.065 at residual≥2k and 1.81 globally.
 
Use quarter-degree marks for the exact sum. Weight .5 is the isolated atom at degree k. For [r,r+.25) up to 2, telescope the pre-2k variation, using [1/(r−1/16)−1/(r+.25)]/2, cutting off the left denominator at 1 for the first bin. Above 2, the number of integer degrees is at most (.25+1/16)k. Multiplication by 1/(rk) gives 5/(32r) in the chosen units; use the maximum of the two possible signs for the count difference, with bounds max(1/(r−1)−.5,.591−1/(r−.75)) on [2,3), .091 on [3,4), .036 thereafter; also cap each bin by the full tail .179/floor(r)!. Store both lower and upper total marked degrees: the first decides admissibility and the second bounds minimum residual, hence the lattice exponent and maximum residual factor. Direct comparison of old and new common terms costs P/k+P/(Bk). New boundary contributes only a feasible pure-atom degree or at least one marked nonatom of size at most p/(2(k+1)); the program charges all feasible pure powers and upper bounds the nonatom case by a single marked position and the remaining exponential mass. Use the previous diagonal mismatch with min(.165,.716/floor(B−1)!). As in k20, set V=W/3 and total next-row allowance W+D0+drift.
 
The optional real-reference bound uses P_*(w)=exp(H_(k−1)) w^(-1) exp[−sum_(b≥1) F_(k−1)(bw)/b], where F_d(z)=exp(−z) sum_(j≤d) z^j/j!, and w=s+iπ. On s/√k∈[ℓ,a], ℓ≥4, s≥s0=4ℓ. Since d≤18, |F_d(bw)|≤exp(5/ℓ²) F_18(bs0); this uses |w|/s≤exp(π²/(2s²)) and monotonicity of F_d on the real axis. For b≥2, the derivative of log F_18(bs0) is ≤−s0+18/b≤−s0+9 by termwise differentiation of the positive polynomial. Thus J=exp(5/ℓ²)[F_18(s0)+F_18(2s0)/(2(1−exp(−(s0−9))))] bounds the absolute logarithmic sum. Put ζ=J+π/s0. From exp(H_(k−1))≥5k/3 the lower bound Re P_*≥(5/3)/(πR) exp(−J)(1−ζ²/2) holds whenever the final factor is positive, R bounding ρ/(πk). Take the maximum with the previous real references; the primary-reference difference epsilon is bounded by the upper-degree DP, charging respectively .716/r!, .065, .154, max(.154,1/(.555γ)−1), or 1 in residual ranges γ≥4, 3≤γ<4, 2≤γ<3, 1≤γ<2, γ<1. A capped upper-degree state remains overbound for all further marks; terms after mark count 16 cost exp(pA)(pA)^17/17!. Use twice epsilon only as an alternative upper bound for the difference of normalized old and new primaries referenced to the same P_*.
 
## Exceptional edge and phase
For 53≤D≤63 use M=4. At r=4 normalized neighbor factors are ≤2.38 and 1.97 with product ≤3.57; r=3 factors <2.02 and 1.61 and product <3.10, r≤2 crude. First pure ratios at r=4 .191 left and .242 right via the alternating expansion of log; the actual first ratios are <.49. Smaller pure ratios .091 at r=3 and .013 at r≤2. Later ratios .15 via pure losses at least 53(1/20+1/60) right and 159/32 left, and the same linear amplitude caps as in the normal edge. Use separate actual-root curvature .010 left (r≤3) and .155 right (r=4). At witness m=4 the next opposing pure term is <.00021 by the loss 9·53/(2·4·7), and the first witnesses for smaller m follow from the respective smaller first terms. The sharp first right lattice drift is ≤.67 since r≤5 and (k−1)r/D≤90/53. Leave the main and left .572 as in the normal edge; the generic right is .78+.079a for offset a. Signed bounds pass.
 
At S=D/4 the primary phase differs from 4π by less than π/32, using the alternating cubic arctangent bound and the net cubic correction. If the phase is below 4π, the absence of zeros in this short overlap follows from the separate central exclusion checked on the corresponding low-s rows; S/√k≤63/16<4. Otherwise normal orientation suffices. Finite checks use whole analytic slabs, not evaluation of original row polynomials: the exact rational code accepts 38 central subslabs, all ratio and s intervals cover continuously, and the edge splice bounds by D ranges at constant M.
 
Reverse-audit correction: the positive real floor uses a downward enclosure of exp(−J), not the upper enclosure used for attenuation estimates. All 38 tests passed again with the corrected direction.

## Central exact replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=16,sk=q(4),xi=q(84,100),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[3,430,40,2,3.25,0,0],[3.25,434,40,2,4,0,0],[4,465,40,2,4.5,0,1],[4,484,40,3,4.5,465,0],[4.5,485,40,2,4.75,0,1],[4.5,512,40,3,4.75,485,0],[4.75,490,40,2,5,0,1],[4.75,530,40,3,5,490,1],[4.75,540,40,3,5,530,0],[5,400,40,2,5.25,0,1],[5,530,40,3,5.25,400,1],[5,565,40,3,5.25,530,0],[5.25,400,40,2,5.5,0,1],[5.25,540,40,3,5.5,400,1],[5.25,581,40,3,5.5,540,0],[5.5,400,40,2,6,0,1],[5.5,550,40,3,6,400,1],[5.5,595,40,3,6,550,1],[5.5,607,40,3,6,595,0],[6,400,40,2,7,0,1],[6,565,40,3,7,400,1],[6,615,40,3,7,565,1],[6,619,40,3,7,615,0],[7,400,40,2,8,0,1],[7,610,40,3,8,400,1],[7,675,40,3,8,610,0],[8,400,40,2,10,0,1],[8,650,40,3,10,400,1],[8,723,40,3,10,650,0],[10,400,40,2,12,0,1],[10,720,40,3,12,400,1],[10,805,40,3,12,720,0],[12,400,40,2,14,0,1],[12,795,40,3,14,400,1],[12,852,40,3,14,795,0],[14,400,40,2,16,0,1],[14,865,40,3,16,400,1],[14,911,40,3,16,865,0]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(46,100).sq().div(two));
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log");
ck(q(48,100).lt(q(54,100).mul(ca)),"vertical positive");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N,low=0,skip=0] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=7;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(min(q(165,1000),q(716,1000).div(fact(Math.floor(B-1)))).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4)));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(119,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(154,1000):L===3?q(65,1000):q(716,1000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1065,1000):o.add(delta),U0=q(181,100),E=U0.sub(U);
 const core=low===0;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 function typesOf(jlast){const types=[[4,4,q(1,2)]]; for(let j=4;j<8;j++){const den=j===4?q(1):q(j,4).sub(q(1,16));types.push([j,j+1,o.div(den).sub(q(4,j+1)).div(two)]);}
 for(let j=8;j<4*jlast;j++){const r=q(j,4);let v;if(j<12){v=max(o.div(r.sub(o)).sub(q(1,2)),q(591,1000).sub(o.div(r.sub(q(3,4))))).mul(q(5,32)).div(r);}else{v=q(j<16?91:36,1000).mul(q(5,32)).div(r);}
 v=min(v,q(179,1000).div(fact(Math.floor(j/4))));types.push([j,j+1,v]);}return types;}

 {
  const types=typesOf(Math.ceil(N));
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=q(0),wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const rem=q(Math.max(4,4*B-h),4); const factor=4*B-h>=8?q(1065,1000):min(U0,max(q(1065,1000),o.div(q(555,1000).mul(rem))));
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1065,1000).mul(abs).add(q(745,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let bw=q(0),t=o,pow=o, jmax=Math.floor(N-1+1/K);
  const pp=p.div(two),slot=xi.mul(p);
  for(let j=1;j<=jmax;j++){t=t.mul(pp).div(q(j));if(j>B-1)bw=bw.add(t);}
  let sum=o;for(let j=1;j<jmax;j++){pow=pow.mul(slot).div(q(j));sum=sum.add(pow);}
  drift=up(P.div(q(K)).add(P.div(q(B*K))).add(U0.mul(bw.add(pp.div(q(K+1)).mul(sum)))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const Qmax=Math.ceil(4*B)+4, Jlast=Math.ceil(B)+1, md=16, es=[[4,q(1,2)],[6,q(1,6)],[8,q(1,12)],[12,q(105,2000)]];
  for(let j=3;j<Jlast;j++)es.push([4*(j+1),q(179,1000).div(fact(j))]);
  es.push([Qmax,q(179,1000).div(fact(Jlast))]);
  const msum=es.reduce((s,[_,w])=>s.add(w),q(0)).mul(p);
  let epsDP=q(0),prod=o,dp=new Map([[0,o]]);
  const pref=new Map();
  function modLoss(h){
   if(pref.has(h))return pref.get(h);
   const r=Math.floor((4*B-h)/4);let v=q(1);
   if(r>=4)v=q(716,1000).div(fact(r));
   else if(r===3)v=q(65,1000);
   else if(r===2)v=q(154,1000);
   else if(r===1)v=max(q(154,1000),o.div(q(555,1000).mul(q(4*B-h,4))).sub(o));
   pref.set(h,v);return v;
  }
  for(let m=1;m<=md;m++){
   const tmp=new Map();
   prod=prod.mul(p).div(q(m));
   for(const [h,v] of dp)for(const [s,w] of es){let f=Math.min(Qmax,h+s);tmp.set(f,(tmp.get(f)??q(0)).add(v.mul(w)));}
   dp=tmp;
   for(const [h,v] of dp)epsDP=epsDP.add(prod.mul(v).mul(modLoss(h)));
  }
  let rem=o;for(let i=1;i<=md+1;i++)rem=rem.mul(msum).div(q(i));
  epsDP=up(epsDP.add(rem.mul(ex(msum))));
  const eps=min(epsDP,up(abs.mul(delta).add(ps)));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=core?o.sub(abs):max(q(4,5).div(a.div(sk).add(two)),o.sub(abs));
  const pr=p.mul(q(79,100)); if(!core&&pr.lt(o))ref=max(ref,dn(o.sub(pr.sq().div(two)).div(ex(pr))));
  if(low>=400){const s=q(low,25),m=q(18); function FD(z){let v=o,sum=o;for(let j=1;j<=18;j++){v=v.mul(z).div(q(j));sum=sum.add(v);}return sum.mul(em(z));}
   const J0=ex(q(50000,low*low)).mul(FD(s).add(FD(s.mul(two)).div(two.mul(o.sub(em(s.sub(q(9))))))));
   const aarg=J0.add(pu.div(s)),cos=o.sub(aarg.sq().div(two));
   if(q(0).lt(cos))ref=max(ref,q(5,3).mul(dn(o.div(ex(J0)))).mul(cos).div(pu.mul(R)));
  }
  c=max(c,ref.sub(eps));const angle=pu.div(q(32));if(core)slice=max(slice,ref.mul(o.sub(angle.sq().div(two))).sub(abs.mul(angle)).sub(eps));else slice=q(87,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);if(B<=4&&low===0)ck(V.lt(slice),"exception phase exclusion");
 
 if(!skip){
  const minD=Math.ceil(B*K)-1,maxD=Math.floor(N*19)-1,Nq=q(Math.round(4*N),4);
  let M=Math.floor(Math.sqrt(minD)/2);
  ck(4*M*M<=minD&&minD<4*(M+1)*(M+1),"minimum M");
  for(; (M===4?53:4*M*M)<=maxD; M++){
    if(M===3&&minD>=53)continue;const d=Math.min(maxD, M===3?52:4*(M+1)*(M+1)-1);
    const s1=q(d*d,M*M*K),s2=Nq.mul(q(d*d,M*M*(d+1)));
    ck(min(s1,s2).lt(a.sq()),"finite M envelope");
  }
 }
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
```
 
## Exceptional edge exact replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}



const lo=x=>eb(x)[0], C=q(27,8),pk=q(53,100),K=q(16),sk=q(4),pl=q(157,50),D=q(47),n=q(48),sd=q(685,100),v=D.div(n);
ck(K.mul(ex(q(1,6*47))).lt(pk.sq().mul(two).mul(pl).mul(q(2,3)).mul(q(15))),"Robbins peak");
ck(q(23,12).lt(q(139,100).sq())&&q(3,2).lt(q(2).mul(q(23,22)).div(q(139,100))),"main mean");
const phip=z=>z.sq().div(two).sub(z.sq().mul(z).div(q(3))), phim=z=>z.sq().div(two).add(z.sq().mul(z).div(q(3)));
const geom=(x,y)=>x.div(o.sub(y));
const long=pk.div(sk.mul(o.sub(q(2,3)))).mul(geom(em(q(15).mul(phip(q(1,2)))),em(q(15,4)))).div(two);
ck(long.lt(q(59,1000))&&pk.div(sk.mul(q(1,2))).mul(geom(em(q(45,10)),em(q(75,10)))).div(two).lt(q(2,1000)),"long union");

const hb=q(38,100),pj=q(64,100);
for(const [a,b,lf,rf,pr,L,R] of [[q(301,1000),q(36,100),o,q(6,5),o,q(333,100),q(186,100)],[q(316,1000),q(1,3),q(3,4),q(5,4),q(15,16),q(238,100),q(197,100)]]){
 ck(pj.mul(a).lt(two.mul(b).mul(hb))&&hb.mul(b).lt(pj.mul(a)),"monotone ratios");
 ck(lf.div(a).lt(L)&&rf.mul(hb.add(pj)).div(a.add(b)).lt(R)&&pr.mul(hb).div(a.sq()).lt(q(420,100)),"r≥4 ratios");
}
const pr=q(331,1000),p3=q(375,1000),a3=q(625,1000);
ck(q(2,3).div(pr).lt(q(202,100))&&q(4,3).mul(o.div(pr.add(q(1,2)))).lt(q(161,100)),"r=3 ratios");
ck(a3.mul(pr).lt(p3)&&q(8,9).mul(p3).div(pr.sq()).lt(q(31,10)),"r=3 curvature factor");
const eL=q(136,1000),eR=q(181,1000),e3=q(132,1000),e2=q(20,1000),l=q(46,100),l2=q(104,1000),a=q(85,1000);
ck(o.div(eL).lt(lo(q(2)))&&o.div(eR).lt(lo(q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80))))&&o.div(eR).lt(lo(q(2).sub(q(4,15)))),"first pure high");
ck(o.div(e3).lt(lo(D.div(q(9)).mul(q(1,2).sub(q(1,9)))))&&o.div(e2).lt(lo(D.div(q(4)).mul(q(1,2).sub(q(1,6))))),"pure low");
ck(q(333,100).mul(eL).lt(l)&&q(197,100).mul(eR).lt(l)&&q(161,100).mul(e3).lt(l)&&C.mul(q(3,2)).mul(e2).lt(l),"first ratios");
ck(C.mul(q(3,2)).div(l2).lt(lo(q(39,10)))&&C.div(l2).lt(lo(q(6))),"steep second");
const zc=a.mul(o.sub(a));
ck(q(420,100).div(zc).lt(lo(q(4)))&&q(31,10).div(zc).lt(lo(D.div(q(9))))&&C.sq().mul(q(3,2)).div(zc).lt(lo(D.div(q(4)))),"curvatures");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
for(const [L,R,e,m] of [[q(333,100),q(186,100),eR,5],[q(238,100),q(197,100),eR,4],[q(202,100),q(161,100),e3,3]])ck(L.mul(eL).add(R.mul(e)).add(cost(e,m,true)).lt(o),"opposing witnesses");
ck(cost(e2,1,false).lt(o),"small witness");
function nlow(w){return em(q(15).mul(phim(o.sub(w))));}
function nhigh(w){return em(q(15).mul(phip(w.sub(o))));}
function tail(j,beta){return geom(nhigh(q(j).div(beta)),em(q(15).mul(o.div(beta).sub(q(1,j)))));}
ck(q(139,100).lt(q(145,100))&&q(1,2).add(o.div(sd)).sq().mul(q(23)).div(q(3).sub(q(1,16))).lt(q(182,100).sq()),"lattice beta ranges");
const s1=q(115,100),s2=q(134,100);
ck(o.add(tail(2,q(115,100))).lt(s1),"lattice 1");
ck(nlow(q(20,23)).add(tail(2,q(13,10))).lt(s1),"lattice 2");
ck(nlow(q(10,13)).add(tail(2,q(145,100))).lt(s1),"lattice 3");
for(const [x,y] of [[q(145,100),q(16,10)],[q(16,10),q(172,100)],[q(172,100),q(182,100)]])ck(nlow(o.div(x)).add(nhigh(q(2).div(y))).add(tail(3,y)).lt(s2),"lattice 4–6");
const cap=q(375,100),d=q(572,1000),right=q(67,100),dt=q(773,1000),b=q(79,1000),xx=q(1305,1000);
ck(q(10,3).div(o.sub(o.div(q(92,10)))).lt(cap)&&cap.mul(pk).mul(s1).div(sk).lt(d)&&cap.mul(pk).mul(s2).div(sk).lt(right),"near drift");
ck(cap.mul(q(1,2).div(sd).add(pk.div(sk))).lt(dt)&&cap.div(n).lt(b),"outer drift");
ck(xx.lt(q(4,3).mul(v))&&C.div(v).mul(xx).mul(pk).div(sk).mul(geom(nhigh(xx),em(q(5)))).lt(q(35,100)),"heavy drift");
const z=o.sub(l2.sq()),later=dt.add(q(3).mul(b)).div(z).add(two.mul(b).mul(l2.sq()).div(z.sq()));
ck(two.mul(a).add(d).add(a.mul(l2).mul(d).div(z)).add(a.mul(right)).add(a.mul(l2.sq()).mul(later)).lt(o.sub(a)),"signed comparison");
ck(q(10,3).mul(q(48,47)).div(q(4)).lt(o)&&q(318,100).lt(pl.sq().div(q(3)).mul(o.sub(q(6,4*47)))),"oriented phase");

const dE=q(53),sE=q(54),e4=q(242,1000),et=q(91,1000),q2=q(15,100),j0=q(21,100000);
const x=q(1,4),log4=x.sq().div(two).sub(x.sq().mul(x).div(q(3))).add(x.sq().sq().div(q(4))).sub(x.sq().sq().mul(x).div(q(5)));
ck(o.div(e4).lt(lo(dE.mul(log4)))&&q(197,100).mul(e4).lt(q(49,100)),"exception right");
const el0=q(191,1000);
ck(o.div(el0).lt(lo(q(53,32)))&&q(238,100).mul(el0).lt(q(49,100)),"exception left");
const cx=q(1,3),log3=cx.sq().div(two).sub(cx.sq().mul(cx).div(q(3))).add(cx.sq().sq().div(q(4))).sub(cx.sq().sq().mul(cx).div(q(5)));
ck(o.div(et).lt(lo(dE.mul(log3)))&&q(161,100).mul(et).lt(q(49,100)),"exception smaller indices");
ck(C.mul(q(3,2)).div(q2).lt(lo(q(53).mul(q(1,20).add(q(1,60)))))&&C.div(q2).lt(lo(q(159,32))),"exception later ratios");
const aL=q(10,1000),aR=q(155,1000),cur4=q(15,16).mul(q(38,100)).div(q(316,1000).sq());
ck(q(31,10).div(aL.mul(o.sub(aL))).lt(lo(q(53,9)))&&cur4.div(aR.mul(o.sub(aR))).lt(lo(q(53,16))),"exception curvature");
const e2t=q(13,1000);ck(o.div(e2t).lt(lo(q(53,12)))&&cost(et,3,false).lt(o)&&cost(e2t,1,false).lt(o),"small witnesses");
const zx=o.sub(e4.sq());
ck(o.div(j0).lt(lo(q(9*53,2*4*7)))&&q(238,100).mul(el0).add(q(197,100).mul(e4)).add(two.mul(C).mul(j0).mul(q(7,4).div(zx).add(e4.sq().div(two.mul(zx.sq()))))).lt(o),"exception witness 4");
const zE=o.sub(q2.sq()), tailE=q(78,100).add(q(3).mul(b)).div(zE).add(two.mul(b).mul(q2.sq()).div(zE.sq()));
const leftE=aL.add(d).add(aL.mul(q2).mul(d).div(zE)).div(o.sub(aL));
const rightE=aR.add(aR.mul(right)).add(aR.mul(q2.sq()).mul(tailE)).div(o.sub(aR));
ck(leftE.add(rightE).lt(o),"exception signed margin");
ck(q(18*5,53).lt(q(182,100))&&q(4,54).add(pk.div(sk)).mul(cap).lt(q(78,100)),"exception beta and base drift");
ck(q(4,53).mul(q(10,3).mul(q(54,53)).mul(q(16,53)).sub(o)).lt(q(1,32))&&q(3).lt(pl.sq().div(q(3)).mul(o.sub(q(6).mul(q(4,53).sq())))),"exception phase");

```
