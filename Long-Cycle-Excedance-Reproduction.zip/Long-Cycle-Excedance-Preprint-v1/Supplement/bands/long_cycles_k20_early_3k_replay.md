# Last early interval at 20≤k≤23 through n≤3k

Exact BigInt rational checks with directed exponential rounding. Use text(value) or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=20,sk=q(447,100),lo=x=>eb(x)[0];
// Last quarter of the early band, using sparse degrees through 2k+1.
{
const B=q(11,4),av=q(455,100),H=q(3);
ck(q(100,59).lt(lo(q(59,100).sub(q(1,K)))),"upper count one-turn");
ck(o.add(q(694,1000)).add(q(1,4*K-2)).lt(q(59,100).mul(q(3).sub(q(1,K)))),"upper count recurrence");
ck(q(2).lt(lo(q(694,1000)))&&q(693,1000).lt(two.mul(q(1,3).add(q(1,81)).add(q(1,1215)).add(q(1,15309)))),"log two");
ck(q(555,1000).lt(q(5,9))&&q(3).mul(q(555,1000)).lt(q(1693,1000)),"row count lower");
ck(q(59,100).div(q(555,1000)).lt(q(1064,1000))&&q(8,10).div(q(555,1000)).lt(q(1442,1000))&&o.div(q(555,1000)).lt(q(181,100)),"count ratios");
ck(q(9,100).div(q(555,1000)).lt(q(17,100)),"count drift ratio");
{
 const b=q(4).mul(pl.sq()).div(av.sq().mul(q(K)).add(q(10))),m0=9;
 ck(q(2).lt(b.mul(q(m0*25**2-312))),"last lattice");
 const rr=o.add(av.sq().mul(q(K)).div(pl.sq())).div(q(K*K)),R=q(330,1000);
 ck(rr.lt(R.sq()),"last radius");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,w){
  let z=q(0);for(let l=1;l<=12;l++)z=z.add(w(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(156))).mul(w(13)).div(b.mul(q((m-1)*27)))));
 }
 const wf=l=>q(2*l+1), f=lat(m0,wf),h=lat(m0,l=>o),g=lat(27,wf),j=lat(27,l=>o);
 const fj=lat(17,wf),fl=lat(12,wf);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 const twoMark=y=>y.sq().mul(q(1,8).add(q(1,4*(K+1))));
 const late=y=>q(181,100).mul(y.div(q(12)).add(y.div(q(K+1))).add(twoMark(y)));
 const P=q(1064,2000).mul(p).add(q(1442,6000).mul(p)).add(late(p));
 const W=q(1064,2000).mul(x).mul(fj).add(q(1442,6000).mul(x).mul(fl)).add(late(x).mul(f)).add(g);
 const P0=q(3,2).mul(p).add(two.mul(p.div(q(K+1)).add(twoMark(p))));
 const drift=P0.div(q(K)).add(P0.div(B.mul(q(K)))).add(p.div(q(K+1))).add(two.mul(twoMark(p)));
 const mismatch=q(17,100).mul(R).mul(o.add(j)).div(B);
 const c=o.sub(P),V=W.div(q(3));
 ck(q(0).lt(c)&&V.sq().add(W.add(drift).add(mismatch).sq()).lt(c.sq()),"last central ellipse");
 ck(V.lt(c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))))),"last central splice");
 ck(q(3).mul(q(63,24).sq()).lt(av.sq())&&q(3).mul(q(68,4).sq()).div(q(69)).lt(av.sq()),"M3 or M4 radius");
 text({lastV:V.val(),lastW:W.val(),lastP:P.val(),lastDrift:drift.val()});
}
{
 const d=q(562,1000),b=q(55,1000),e=q(87,1000),l=H.mul(e),a=q(24,1000);
 const l0=q(1,18).sub(q(1,81)).add(q(1,324)).sub(q(1,1215));
 ck(o.div(e).lt(lo(q(54).mul(l0)))&&H.sq().div(a.mul(o.sub(a))).lt(lo(q(6))),"last M3 ratio");
 ck(H.mul(q(3,55).add(q(59,100).div(sk))).lt(d)&&H.div(q(55)).lt(b),"last M3 drift");
 ck(two.mul(H).mul(e).div(o.sub(e.sq())).lt(o),"last M3 witness");
 function ms(aL,aR,l,d0,b0){
  const z=o.sub(l.sq());
  const le=aL.add(d0).add(aL.mul(l).mul(d0).div(z)).div(o.sub(aL));
  const ro=aR.add(aR.mul(d0.div(z).add(b0.mul(o.add(l.sq())).div(z.sq())))).div(o.sub(aR));
  return le.add(ro).lt(o);
 }
 ck(ms(a,a,l,d,b),"last M3 signs");
 const e0=q(55,1000),lf=q(34,100),aL=q(8,1000),aR=q(56,1000);
 ck(o.div(e0).lt(lo(q(64).mul(l0)))&&H.sq().div(aL.mul(o.sub(aL))).lt(lo(q(64,9))),"M4 left");
 ck(q(20).mul(ex(q(1,6*64))).lt(q(54,100).sq().mul(two).mul(pl).mul(q(3,5)).mul(q(19))),"M4 modal peak");
 const pk=q(54,447),bin=w=>{
  const u=w.sub(o),loss=u.sq().div(two).sub(u.sq().mul(u).div(q(3))).add(u.sq().sq().div(q(4))).sub(u.sq().sq().mul(u).div(q(5)));
  return pk.mul(w.div(w.sub(o))).mul(em(q(19).mul(loss)));
 };
 ck(bin(q(65,44)).lt(q(85,1000)),"M4 pair failure");
 const v3=q(195,88);ck(v3.lt(lo(q(8,10)))&&pk.mul(v3.div(v3.sub(o))).mul(em(q(19).mul(v3.sub(q(18,10))))).lt(q(2,1000)),"M4 triple failure");
 const d4=q(353,1000);
 ck(q(1,4).add(q(1,8).mul(o.sub(q(17,100)))).sub(q(2,3000)).lt(d4)===false,"M4 success lower");
 ck(q(64,100).mul(d4).lt(two.mul(q(1,3)).mul(q(38,100))),"neighbor product monotone");
 ck(q(15,16).mul(q(38,100)).div(d4.sq()).div(aR.mul(o.sub(aR))).lt(lo(q(4))),"M4 right curvature");
 const lL=q(3,4).div(d4),lR=q(5,4).mul(q(102,100)).div(d4.add(q(1,3))),eta=q(181,1000);
 ck(q(136,1000).mul(lL).add(eta.mul(lR)).add(two.mul(H).mul(eta.sq().mul(eta)).div(o.sub(eta.sq()))).lt(o),"M4 witness");
 ck(lR.mul(eta).lt(lf)&&H.div(lf).lt(lo(q(64,20))),"M4 actual ratios");
 ck(H.mul(q(4,65).add(pk)).lt(d)&&H.div(q(65)).lt(b),"M4 drift");
 ck(ms(aL,aR,lf,d,b)&&ms(aL,aL,H.mul(e0),d,b),"M4 signed margins");
}
}
text("All exact early bounds passed.");

```
