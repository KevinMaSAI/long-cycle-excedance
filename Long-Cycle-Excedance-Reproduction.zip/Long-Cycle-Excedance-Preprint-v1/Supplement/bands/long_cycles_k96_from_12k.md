# The k≥96 large-n band now starts at n=12k

2026-11-27 03:45 UTC. For every k≥96 and n≥12k, E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient. This does not close the early gap for 96≤k≤127, because the separate early theorem currently covers only n≤3k in this k band. Existing k≥128 all-n theorem is unchanged. No original row enumeration.

## Profile with geometric binomial tail prefactor
Treat 96≤k≤127 and n≥12k. At r0∈[.45,.62]sqrt(n) set β0=kr0/n. For any p and X=Bin(n,p), the point mass at j is at most its maximal value over p times exp[−j(w−1−log w)] with w=np/j, by log(1−u)≤−u for the factor (1−p)^(n−j). At j=k−1,k the peak is <.43/sqrt(k) by Robbins's bound, with variance at least (11/12)(k−1). The same variance bound applies to j=k−1 for Bin(n−1,p), which is used for derivatives and drift. For a lower tail ending at j when np≥j, consecutive backward ratios are ≤1/w: use n(1−p)≤n−j and the exact binomial ratio. Thus P(X≤j) is bounded by the point-mass estimate times 1/(1−1/w). For the upper tail starting at j when np≤j, forward ratios are ≤w by the exact ratio and n−j≤n(1−p), giving multiplier 1/(1−w). This is a strict improvement on a Chernoff-only estimate when the tail is modestly separated.

For β0≤1.5, r0≥16. Use U=2, retain at most seven critical singleton cycles. The hard complement is ≥8, hence count replacement error <.00016, costing <.00016 exp(1)+3 sum_(m≥8)1/m!<.0006 including omission. At b=2 the long mean ratio np/k≥64/51>1.25 and thus w=np/(k−1)≥1.25. The lower-tail geometric prefactor is <.23, and the loss at first b is ≥95(.25²/2−.25³/3). The loss increases by at least 12 per extra b, via derivative (k−1)(1/β_r−1/b) or the larger equivalent n-scaled bound. Long marked factor remains 3/2 in relative units. The entire error is <.033. Marked multinomial derivative in units c_2 is at most exp(1)·.43/[sqrt(k)(.45·15/16)²]<.68.
For β0>1.5, r0≥19; U=3, forbid singleton cycles, retain at most four critical size-two cycles. At every m≤4 complement r−2m≥10>3U, so count replacement costs ≤.002 exp(.5), plus omitted ≤5 sum_(m≥5)(.5)^m/m!, together <.0048. Singleton success has w=np/k≤19/27<.71; upper-tail geometric prefactor is <.16 and loss ≥96(.29²/2+.29³/3). For long cycles b≥3, β_r≤.62 sqrt(127/12)(20/19) gives np/k≥1.41 at b=3, so the lower-tail prefactor is <.16, loss ≥95(.41²/2−.41³/3), and increase per b >12. Relative union factors are 5 for singleton success and 5/6 for long failures by positive complements with hard minimum 2. Total error is <.012. The derivative in units c_3 is at most exp(.5)·.43/[sqrt(k)(.45·18/19)²]<.42. Using decreasing profiles F≥c, these budgets give neighboring actual amplitude ratios <1.78 left and <1.14 right on the entire window.

## Edge
Use M=floor(.58 sqrt(D)), D=n−1≥1151, H=n/k, C=27/8. High m≥.45sqrt(n) has (eta,lambda,alpha)=(.24,.43,.125); first pure right log loss ≥(.58)^(-2)(1/2−1/57) since M≥19, and curvature product ≤1.78·1.14 exp(−1/.58²). Exiting the profile to the left costs at least D/(2r²), and to right at least (D/sqrt(n))(50/29−50/31), absorbing amplitude factors C and C·22/21 respectively. The first two witness neighbors use the profile ratios; remaining odd offsets use C(1+a/16). Medium m≥10 below the profile uses (.131,.49,.20) since m+1<.480sqrt(n) and m+2<.510sqrt(n). Curvature for r≥16 uses C²·17/16 and exp(−D/r²); for r≤15 use 1.5C² and exp(−1151/225). For m≤9 use (.006,.031,.031). All witness and curvature bounds are strict. At every r≥H/2 use occupancy cap L=2k to get H/A<4.17, then d_r≤4.17(r/n+.43/sqrt(k)); below H/2 the geometric bound is <.001. For r≤M+a this gives d_r<.26+.0037a. Signed-mean budgets pass for all regimes. The same floor and phase comparison applies with S≤(50/29)sqrt(n)+3.2 and error <pi/40.

## Improved two-cycle coefficient tail and center
The all-n k≥128 proof's two-cycle variation argument works at k≥96 after minor constant changes. On 2k≤j<3k, k d_j<.573 (minimum of .573(1+x)−1−1/k−log x at x=1/.573), with endpoints at least .500 and .563. Thus variation in the block is <.083/k and T(2k)<.125/k after contraction by 1/3. Consequently T(Lk)<.25/(k L!) for L≥2. The unweighted norm is <1.625/k, and the tilted norm in the 2/k units is J=[e^α+e^(2α)/2+.083 e^(3α)/(1−e^α/3)]/2. Reuse harmonic-distance minima, the .18 vertical log comparison for k≥96 and s≥4sqrt(k), and the small-s core. In the central ellipse the scalar count tolerance is .5/L! and the diagonal mismatch uses .5 instead of 6. Remove the absolute primary log bound when p≥1; otherwise it may strengthen the real-part lower bound. The exact replay certifies eight analytic intervals from 12k through 912k. This overlaps the already verified all k≥96, n≥900k region, completing the announced large-n band. The older k≥128 all-n theorem covers those larger k directly.

## Exact BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[96,12,93,650,5,27],[96,27,149,350,5,71],[96,71,223,150,8,162],[96,162,301,100,12,298],[96,298,377,50,12,469],[96,469,440,40,12,640],[96,640,489,30,12,791],[96,791,524,25,12,912]];
const covered={96:12};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(97,10);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(83,1000).mul(ex(alpha.mul(q(3)))).div(o.sub(ea.div(q(3))))).div(two));
 const eps=up(ex(q(13,16).mul(p)).sub(o).mul(q(1,2)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(1,2).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(1,2).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)); const ref2=p.lt(o)?dn(o.div(ex(p)).mul(o.sub(p.sq().div(two)))):q(0); const c=(ref.lt(ref2)?ref2:ref).sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(16,5).div(sk));
 ck(q(0).lt(rad)&&q(2500*N,841).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=y=>eb(y)[0],eu=y=>eb(y)[1], C=q(27,8),v=q(1151,1152),n=q(1152), u=q(58,100),sk=q(97,10),sD=q(339,10);
ck(covered[96]>900,"coverage overlap");
ck(q(1000,573).lt(lo(q(573,1000).sub(q(1,96)))),"count peak");
ck(q(83,1000).mul(q(3,2)).lt(q(125,1000)),"count tail");
ck(q(96).mul(eu(q(1,6*1151))).lt(q(43,100).sq().mul(two).mul(pl).mul(q(11,12)).mul(q(95))),"modal binomial");
const p1=q(23,100),p2=q(16,100),p3=q(16,100),e1=q(33,1000),e2=q(12,1000);
ck(q(43,100).div(sk.mul(o.sub(q(4,5)))).lt(p1),"geometric long b2");
ck(q(43,100).div(sk.mul(o.sub(q(1).div(q(141,100))))).lt(p2),"geometric long b3");
ck(q(43,100).div(sk.mul(o.sub(q(71,100)))).lt(p3),"geometric short b1");
function uploss(x){return q(96).mul(x.sq().div(two).add(x.sq().mul(x).div(q(3))))}
function lgloss(x){return q(95).mul(x.sq().div(two).sub(x.sq().mul(x).div(q(3))))}
function geom(x,y){return x.div(o.sub(y))}
ck(q(5,4).lt(q(64,51))&&q(12).lt(q(95).mul(q(32,51).sub(q(1,2)))),"b2 slope");
ck(q(6,10000).add(q(3,2).mul(p1).mul(geom(em(lgloss(q(1,4))),em(q(12))))).lt(e1),"error singleton");
let maxb=q(62,100).sq().mul(q(127,12)).mul(q(20,19).sq());
ck(maxb.lt(q(3).div(q(141,100)).sq())&&q(12).lt(q(95).mul(q(141,300).sub(q(1,3)))),"b3 slope");
ck(q(19,27).lt(q(71,100)),"short mean");
ck(q(48,10000).add(q(5).mul(p3).mul(em(uploss(q(29,100))))).add(q(5,6).mul(p2).mul(geom(em(lgloss(q(41,100))),em(q(12))))).lt(e2),"error doubleton");
const A=q(45,100), L=q(178,100),R=q(114,100);
for(const [h,eps,m,ss,rr] of [[q(68,100),e1,q(17,16),o,A.mul(q(15,16))],[q(42,100),e2,q(20,19),q(1,2),A.mul(q(18,19))]]){
 ck(eu(ss).mul(q(43,100)).div(sk.mul(rr.sq())).lt(h),"derivative");
 ck(o.add(h.add(two.mul(eps)).div(o.sub(eps))).lt(L)&&m.mul(o.add(eps)).div(o.sub(eps)).lt(R),"neighbor ratios");
}
const eH=q(24,100),eM=q(131,1000),eL=q(6,1000),lH=q(43,100),lM=q(49,100),lL=q(31,1000),aH=q(125,1000),aM=q(20,100);
ck(o.div(eH).lt(lo(o.div(u.sq()).mul(q(1,2).sub(q(1,57))))),"high pure");
ck(o.div(eM).lt(lo(v.div(two.mul(q(48,100)).mul(q(51,100))))),"medium pure");
ck(o.div(eL).lt(lo(q(1151,220))),"low pure");
ck(C.div(lH).lt(lo(v.div(two.mul(A.sq()))))&&C.mul(q(22,21)).div(lH).lt(lo(v.mul(sD).mul(o.div(u).sub(q(50,31))))),"outside profile");
ck(L.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM)&&C.mul(q(3,2)).mul(eL).lt(lL),"actual ratios");
ck(L.mul(R).div(aH.mul(o.sub(aH))).lt(lo(o.div(u.sq()))),"high curvature");
ck(C.sq().mul(q(17,16)).div(aM.mul(o.sub(aM))).lt(lo(v.div(q(48,100).sq())))&&C.sq().mul(q(3,2)).div(aM.mul(o.sub(aM))).lt(lo(q(1151,225))),"medium curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(L.add(R).mul(eH).add(cost(eH,16,true)).lt(o)&&cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"witness");
const d=q(26,100),b=q(37,10000), C2=q(417,100);
ck(q(4).div(o.sub(o.div(q(276,10)))).lt(C2)&&C2.mul(u.div(sD).add(q(43,100).div(sk))).lt(d)&&C2.div(n).lt(b),"drift");
ck(q(7000).lt(lo(q(299,1000).mul(q(96)))),"heavy drift");
for(const [a,l] of [[aH,lH],[aM,lM],[lL,lL]]){const z=o.sub(l.sq());ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");}
ck(o.div(u.sq()).div(o.sub(o.div(u.mul(sD)))).lt(q(16,5)),"floor");
ck(u.div(sD).lt(q(1,40))&&q(10,3).mul(u.sq()).mul(u).div(v.mul(sD)).lt(q(1,40)),"phase");
```
