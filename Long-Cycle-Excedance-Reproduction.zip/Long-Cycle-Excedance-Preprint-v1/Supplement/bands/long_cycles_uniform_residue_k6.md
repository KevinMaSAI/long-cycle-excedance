# Uniform small-k eventual residue bound

2026-11-27 05:28 UTC Dreamer proof, independently audited by parent. This strengthens uniform analytic methodology rather than reopening the separate fixed-value proofs for k=6 through 11.

### Large n is now covered at k=6 through k=11

For every 6≤k≤11 and n≥120k, the genuine E_(n,k) has n−1 simple real roots and its quotient by t strictly interlaces the next quotient. Joined to the established k≥12 theorem from n≥180k, this gives a common eventual bound n≥180k for all k≥6. This is new below the existing k=12 eventual cutoff. The contour argument itself covers only its stated high range. Separate fixed-k results at k=6,…,11 already cover the lower rows; this gives a uniform analytic proof of their high ranges, not new individual row coverage there. [Exact replay](long_cycles_k6_eventual_replay.md) · [Coefficient and residue identities](long_cycles_uniform_residue_400k.md) · [Existing k≥12 theorem](long_cycles_uniform_residue_180k.md).

**Contour and central signs.** Use the normalized H,h_n,B,u,v,p_l,ρ and phase ψ from the 400k proof, with d=k−1∈[5,10]. On |z|≤ρ(1+1/d), the Fourier representation of G_s gives |G_s|≤2π times the mean absolute value of the short geometric kernel. Cauchy–Schwarz bounds this mean by [Σ_(m=2)^d (1+1/d)^(2m)]^(1/2). The sum is at most e²+(d/2)(e²−1)<39.4, by an integral and endpoint for the increasing exponential. Thus |G_s|<40 uniformly. Choose R∈[ρ(1+.95/d),ρ(1+1/d)] separated by 1/(100d) from every pole modulus. The interval width is .05ρ/d, and at most ρ distinct positive-height levels need exclusion, so excluded length is <.02ρ/d. The old denominator estimate gives |H|≤300d exp(44); the primary residue modulus is ≥exp(−40).

The edge below gives ρ²≤1.84n. On the circle the centered multiplier |1/z−u|≤2/ρ, and log(R/ρ)>.95/k. Therefore in either value or centered-next units the contour error is bounded by 10000dn exp(80−.95n/k). For fixed k this decreases past 120k, and at that threshold it is <.001 by d≤10, n≤1320 and exponent −34.

For a far residue at height (2l+1)π the radial loss is at least n·4π²l(l+1)/(2·1.2²ρ²), and the centered weight is at most 2l+1. At s≤14, ρ²≤206 and n≥720, so the loss exceeds 47l(l+1). The crude ratio of residue magnitudes is exp(80), giving far error <.001 by a geometric sum. At s≥14, included |p_l|≤1.24s. Use the exact decomposition G_s(p_l)=−Σ_(r≥1) F_d(rp_l)/r+Σ_(r≥1)(−q)^r(1+rp_l)/r. The nonnegative exponential majorant gives |F_d(rp_l)|≤2^d exp(−rs+r|p_l|/2)≤1024 exp(−.38rs). Including the logistic correction gives |G_s(p_l)|<5.1, uniformly on the large-s region. Compare far residue sizes by exp(10.2). Since radial loss exceeds 7.4l(l+1), their weighted sum is <.031. Thus both normalized errors are <.04 relative to the primary oscillations −cos ψ and +sin ψ. This gives witness signs and the correct centered-next sign at old central zeros.

**Dense edge.** Set D=n−1, H=n/k, M=floor(.78√D), S=D/M. In the window r≤.9√n, n/r≥3.6k. Conditional on the label occupancies, a permutation whose every cycle meets a label with at least k balls certainly succeeds. The chance all cycles meet a fixed good-label set of size g is g/r by sequential insertion after starting with the permutation on the good set. So A_n(r)≥r Pr(Bin(n,1/r)≥k)>.999r, by Φ(3.6)>1.3. Always A_n(r)≤r.

M≥20. The first pure ratio is <.453 from loss ≥(.78)^(-2)(1/2−1/60); the third witness pure ratio is <.0017 by 9D/[2M(M+3)]. For m≥13 the actual step factor in the dense window is ≤(14/13)/.999 for outward right moves and 1/.999 for left moves. For m≤12 the pure η=.14 works by loss ≥719/364, even after the actual factor 1.5/.999. Above the dense window use global factor ≤81/16, absorbed by pure loss ≥(D/√n)(1/.78−1/.9). Thus λ=.49 everywhere. Curvature ≤exp(−1/.78²)/.999² gives root α=.27. At a high witness the first opposing pair costs ≤2·.453/.999, then use the quadratic third ratio and geometric continuation with amplitude factor (1+a/m)/.999. Low witnesses use the entire odd series with (1+a)/.999. Both pass, and the first witness's dominance persists at s>D.

For drift use the beta lattice and the peak <.46/√k from Robbins, since p0=(k−1)/D<1/120 and variance ≥.99(k−1). If r≤.9√n then x=D/r≥3.6k. The marked binomial point has loss ≥(k−1)Φ(x/(k−1))≥6.5, increasing by more than 16 per lattice step. With H/A≤(27/8)(n/D)x/k, the weighted x times the exponential loss decreases for x≥k. Hence D_r<.004 in the dense window. Outside it, r<H/2 is still controlled by the same monotone bound at x≥1.99k. At r≥H/2 the cap 2k gives H/A<4.7. Together these give D_r<1.03+.0066a for r≤M+a. The entire left and first three right offsets lie in the dense window, since (.9−.78)√n>3. In the signed-mean inequality only odd right offsets can hurt. The first possibly large drift therefore starts at a=5, with factor αλ^4 and the odd geometric tail. The exact signed numerator is below .568 versus threshold .73. This avoids including the favorable even offset a=4. [Robbins's Stirling bounds](https://dornsife.usc.edu/sergey-lototsky/wp-content/uploads/sites/211/2024/02/Stirling-Robbins.pdf).

**Splice.** The floor gives S≤(50/39)√n+1.74 and S>34. The same large-s estimate gives |G_s(p_0)|<.003 there. Thus the scalar phase shift differs from π by <.004. The two atan corrections put ψ(S) within π/12 of (M+1)π. At that splice phase no root can occur in the short exclusion slice, since cos(π/12)>.04. At s=0 the phase is exactly (n+2)π/2. The inherited first/last hit construction, edge signs, reciprocity and parity exhaust degree n−1, give simplicity and transfer the old-root signs into strict adjacent interlacing. All constants were verified with directed BigInt rationals.



## Independent reverse audit

The Cauchy–Schwarz mean bound follows by Parseval on the geometric polynomial. Comparing the increasing exponential with its integral plus its endpoint gives e²+(d/2)(e²−1), <39.4 at d≤10 by e²<7.4. The 2π factor still applies because the imaginary coefficient relation is the analytic branch from z=0. The circle width .05rho/d exceeds excluded length .02rho/d using only the number of distinct moduli, not a cancellation between poles. The R ratio, rho square and contour normalization use n≥120k and n≥720 only. Evaluate the decreasing n-dependent error at 120k separately for each k, then upper-bound d and that minimum n by 10 and 1320. They are not being used as an upper bound for arbitrary rows. Both polar remainders include the weight 2l+1 and absolute modulus loss, independent of phase.

The good-label fraction g/r may also be checked directly by the two-color cycle assembly (1−y)/(1−x−y): a permutation avoids all-bad cycles if and only if each cycle contains a good label; the coefficient difference divides by the total to yield g/r. When r≤.9sqrt(n), D/r≥3.6k already with the n−1 correction, so the adjacent drift bound can be sharper than the old mean cutoff. The ratio mode exponent loss for first point j=k−1 is ≥5Phi(3.6)>6.5, and its rate rises by at least x−j>16. For the crude case outside the window but below H/2, 1.99 threshold gives loss >1.45 and exponent increment >6.9. The cap-2k drift is only used when n/r≤2k. For m≤12 the first pure ratio lower log loss uses main base ≤13, hence 719/(2·13·14) as claimed. Higher outward ratios use the dense amplitude factors and weaker global outside factor only where the outgoing base exceeds .9sqrt(n). At the relevant old zeros, odd right offsets 1,3 are in the small drift window, whereas offset 4 is favorable and must not be included in the adverse cost; the large-drift sum starts at a=5, with αλ^4. The derivative test still includes both signed mean offsets.

At S, the positive and negative arctangent discrepancies from M are separately bounded using n+1 in the phase, not n. Phase shift beta differs from pi by <.004. The inherited first/last-hit argument yields exactly the degree count, tests old-root signs without a phase monotonicity assumption, and continuously includes s=0 by parity. I independently re-ran the full BigInt replay: all eventual checks passed. Combined with the parent n≥180k result for k≥12, we obtain the uniform range n≥180k for all k≥6; the narrower 120k threshold here is from this specific small-k proof. No new all-n floor or individual polynomial row check.

# Uniform residue and edge inequalities for 6≤k≤11 and n≥120k

Exact rational checks with directed exponential rounding. Run with text(value), or substitute console.log.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),nn=q(720),DD=q(719),sD=q(268,10),sk=q(244,100),A=q(39,50),Drel=q(719,720),C=q(27,8);
const lo=x=>eb(x)[0],geom=(f,r)=>f.div(o.sub(r));
ck(sD.sq().lt(DD)&&sk.sq().lt(q(6))&&q(20).lt(A.mul(sD)),"scale");
ck(ex(q(2)).lt(q(74,10))&&two.mul(pu).sq().mul(q(394,10)).lt(q(40).sq()),"Fourier L2 bound");
ck(q(6,5).mul(pu).lt(q(4))&&q(10000).lt(lo(q(10))),"contour elementary");
const floor=o.div(A.sq()).div(o.sub(o.div(A.mul(sD))));
ck(floor.lt(q(174,100)),"floor correction");
const rho2=o.div(A).add(q(174,100).div(sD)).sq().add(q(10,720));
ck(rho2.lt(q(184,100)),"rho^2");
ck(q(300).div(pl).mul(q(184,100)).mul(ex(q(4))).lt(q(10000))&&q(150).mul(ex(q(4))).lt(q(10000)),"contour units");
ck(q(10000*10*1320*1000).lt(lo(q(34))),"contour attenuation");
const rate=two.mul(pl.sq()).div(q(6,5).sq());
ck(q(47).lt(rate.mul(q(720,206))),"small radial");
const odd=(x)=>q(3).div(o.sub(x)).add(two.mul(x).div(o.sub(x).sq()));
ck(em(q(14)).mul(odd(em(q(94)))).lt(q(1,1000)),"small far poles");
ck(q(6,5).sq().mul(o.add(q(10,196))).lt(q(124,100).sq()),"pole / s");
function Gbound(s){
 const s0=q(s),rt=em(q(38,100).mul(s0)),qq=em(s0);
 return q(1024).mul(geom(rt,rt)).add(o.add(q(124,100).mul(s0)).mul(geom(qq,qq)));
}
ck(Gbound(14).lt(q(51,10))&&Gbound(34).lt(q(3,1000)),"large pole size");
ck(q(34).lt(sD.div(A))&&pu.mul(em(q(34))).lt(q(1,1000)),"large splice s");
ck(q(74,10).lt(rate.div(q(184,100))),"large radial");
ck(em(q(46,10)).mul(odd(em(q(148,10)))).lt(q(31,1000)),"large far poles");
const phase=two.mul(A).div(sD),phase2=q(721,719).mul(q(10,3)).mul(A.sq()).mul(A).div(sD);
ck(phase.add(q(4,1000).div(pl)).lt(q(1,12))&&phase2.add(q(4,1000).div(pl)).lt(q(1,12)),"splice phase");

const reach=q(9,10),pk=q(46,100),near=q(4,1000),eta=q(453,1000),lambda=q(49,100),alpha=q(27,100),C2=q(47,10);
ck(reach.sq().mul(q(11,120)).lt(o.div(q(36,10).sq())),"dense mean");
ck(q(36,10).lt(lo(q(13,10)))&&q(1000).lt(lo(q(78,10))),"dense failure");
ck(q(36,10).sq().lt(Drel.sq().mul(q(120,11)).div(reach.sq())),"dense D/r");
ck(q(3).lt(reach.sub(A).mul(sD)),"first 3 dense offsets");
ck(q(99,100).lt(o.sub(q(1,120)))&&q(6).mul(ex(q(1,6*719))).lt(pk.sq().mul(two).mul(pl).mul(q(99,100)).mul(q(5))),"binomial peak");
const ge=(x,loss,step)=>C.div(Drel).mul(x).mul(pk.div(sk)).mul(geom(em(loss),em(step)));
ck(ge(q(36,10),q(65,10),q(16)).lt(near),"near drift");
ck(q(199,100).lt(lo(q(7,10)))&&ge(q(199,100),q(145,100),q(69,10)).lt(q(103,100)),"non-dense small-index drift");
ck(q(346,100).sq().lt(q(12))&&q(4).div(o.sub(o.div(two.mul(q(346,100))))).lt(C2),"cap 2k");
const d=q(103,100),b=q(66,10000);
ck(C2.mul(A.div(sD).add(pk.div(sk))).lt(d)&&C2.div(nn).lt(b),"all drifts");
const dense=q(999,1000);
ck(o.div(eta).lt(lo(q(1,2).sub(q(1,60)).div(A.sq())))&&q(14,13).div(dense).mul(eta).lt(lambda),"first ratio");
const lowEta=q(14,100);
ck(o.div(lowEta).lt(lo(q(719,364)))&&q(3,2).div(dense).mul(lowEta).lt(lambda),"small witnesses");
ck(o.div(dense.sq().mul(alpha).mul(o.sub(alpha))).lt(lo(o.div(A.sq()))),"curvature");
const beyond=Drel.mul(sD).mul(o.div(A).sub(o.div(reach)));
ck(q(81,16).div(lambda).lt(lo(beyond)),"outside dense");
const eta3=q(17,10000);
ck(o.div(eta3).lt(lo(q(9,2).div(A.sq()).mul(q(20,23)))),"third offset");
const u=o.sub(eta.sq()),v=o.sub(lowEta.sq());
const far=two.mul(eta3).div(dense).mul(o.add(q(3,13)).div(u).add(q(2,13).mul(eta.sq()).div(u.sq())));
ck(two.mul(eta).div(dense).add(far).lt(o),"high witness sign");
ck(two.div(dense).mul(lowEta.div(v).add(lowEta.mul(o.add(lowEta.sq())).div(v.sq()))).lt(o),"low witness sign");
const z=o.sub(lambda.sq());
const later=alpha.mul(lambda.sq().sq()).mul(d.add(q(5).mul(b)).div(z).add(two.mul(b).mul(lambda.sq()).div(z.sq())));
const cost=two.mul(alpha).add(near).add(alpha.mul(lambda).mul(near).div(z)).add(alpha.mul(near).div(z)).add(later);
ck(cost.lt(o.sub(alpha)),"signed margin");
text({rho2:rho2.val(),cost:cost.val(),G14:Gbound(14).val(),G34:Gbound(34).val()});
text("All exact eventual bounds passed.");
```

