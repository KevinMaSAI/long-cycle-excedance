# Uniform early range through n=3k at k≥32

2026-11-27 05:45 UTC block. For all k≥32 and k≤n≤3k, E_(n,k) has n−1 simple real roots and E_(n,k)/t strictly interlaces the next quotient, including n=3k as old row. The previously focused range 32≤k≤47 is the only new one because k≥48 is already complete. Together with the independent n≥16k theorem, only 3k<n<16k is then open in this range. No new original polynomial row enumeration. Reuse the established universal first-cycle/onset comparisons for n≤2k; this proof directly begins with old n=2k+1.

## Sparse-prefix central signs

Use the normalized polynomial h_n and pole factors q_i, with v=sin theta, and the exact anchor and centered formulas of the earlier work. A distinguished factor B_i(u) expands as products of δ(q_j u)/(1−q_j/q_i), each with support beginning at k. Only shifts b≤n+1−k matter for the two normalized comparisons. Let p,x be the primary/far sum-distance bound in units of 2/k, as usual, and use the standard unweighted and weighted far lattices at powers k−1 and Bk. All retained d-ratios are ≤2, since the old and new row counts are ≥1/(2k−1) and retained numerator counts at most 1/k. The far centered multiplier contributes weight 2l+1, and unweighted envelope costs at most W/3. True diagonal mismatch uses relative d difference <1/(n+1), giving (1+j)R/B with n≥Bk and j at power Bk. No artificial division by v of the whole adjacent mixed drift.

For 2k+1≤n≤2.5k, the retained prefix has b<2k, so all mixed products are single-factor only. Their degree-k atom Δ_k=1/k costs x at far anchors in the centered envelope; all non-atom linear terms cost at most x/2 because the pre-2k variation after k is <.5/k. Give both the weighted far lattice f at k−1. The overall W is (3x/2)f+g, and |C_n−1|≤3p/2. The same restricted norm bounds the overlap and denominator drift by (3p/2)/k and (3p/2)/(Bk); the new boundary b=n+1−k>k cannot be an atom, so its direct cost ≤p/(k+1), from |Δ_b|≤1/[k(k+1)] for b>k. These bounds pass the ellipse and π/8 angle test for s≤3.92sqrt(k), B=2.

For 2.5k<n≤3k, the last allowed shift is 2k+1. The two-factor terms have only two degree-k atoms or one atom and one degree-(k+1) factor. In unweighted absolute amplitude at scale y=p or x, these have total ≤y²/4+y²/[2(k+1)] after the count factor 2: the pure pair uses elementary symmetric bound (y/2)^2/2 before the ratio, and the cross term uses aggregate coefficients ≤y/2 and y/[2(k+1)]. The extra linear degrees 2k,2k+1 cost at most 2y/(k+1). No higher product can enter. Set F(y)=y²(1/4+1/[2(k+1)])+2y/(k+1). Then |C_n−1|≤1.5p+F(p), and the far centered envelope W=x j_1+(.5x+F(x))f+g: the atom j_1 has the sharper exponent n−k≥1.5k, because it appears at degree k. The diagonal g uses B=2.5. Adjacent primary drift can use the old general overlap/denominator bound with P0=2(exp(ξp)−1), ξ=.823. The new boundary products with a marked degree>k cost ≤p exp(p)/(k+1); otherwise at least two atoms are needed since its degree exceeds k, with total ≤(p/2)^2 exp(p/2). This passes the ellipse and the π/8 exclusion for s≤4.3sqrt(k). Count-prefix estimates apply to actual E polynomials, not a surrogate of low-degree modes.

## Edge and exact splice

For both bands M=floor(sqrt(D)/2), D=n−1. For n≥2k+1 through 2.5k one has D≥64, M≥4 and amplitude A∈[1,2.5]. The right pure ratio is <.181 from the quartic log loss at M=4 or cubic ≥2−4/15 at M≥5. Use actual .453 and alpha=.133 by curvature ≤2.5² exp(−4). The opposing witness and signed margins pass. Robbins peak .58/sqrt(k) is valid by variance ≥(k−1)/2; with H≤2.5 the exact beta lattice gives d≤.414+.039a on right, .414 on left. The floor splice if M=4 gives S²/k≤2.5·99²/(16·100)<3.92²; if M≥5 use 10(1+1/5)^2, smaller. At the first witness the old sign persists for s>D.

For 2.5k<n≤3k, D≥80 but D≤140 when k≤47; hence M∈{4,5}. If m+1≤4, pure ratio .125 by log loss ≥25/12, actual .376, alpha .066 by curvature ≤9 exp(−5). The low witness and signed margins pass. If m=4 and m+1=5≤M, necessarily D≥100. At r≥5 occupancy cap ceil(3k/5) gives H/A<2.92; first and later right ratios below .5 via the pure .171 from 2−4/15+1/25−4/625. On the left m≤4, pure first loss ≥D/(2·4²), absorbing factor 3. Distinct curvature choices alpha_L=.018 by 9 exp(−100/16) and alpha_R=.195 by 2.92² exp(−4) give a strict signed margin. In this whole second band Robbins peak .54/sqrt(k) uses variance ≥3(k−1)/5. With H≤3 and main indices ≤5 the drift budget .475+.04a holds, including on the left at a=0 without growth. Witness at m=5 uses first pure .171 and third pure <.000014 from quadratic loss ≥45/4; geometric continuation and 2.92 amplitude ratio give opposing sum <1. Witnesses m≤4 use the earlier .125 and factor 3, regardless of bracket. For the splice, M=4 implies S²/k≤3·99²/(16·100) and M=5 gives <12(1+1/5)^2; both <4.3². Phase errors in both bands are <π/8 via separate cubic and linear estimates. Then the tested real-part/phase margins, sign witnesses, parity and reciprocal pairs prove the full row and its strict comparison. No assumption of desired real roots was used.

## Exact BigInt checks
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}

const pl=q(157,50),pu=q(22,7),K=q(32),sk=q(565,100),lo=x=>eb(x)[0];
function sc(a,RR,B,short){
 const R=q(RR,1000),b=q(4).mul(pl.sq()).div(a.sq().mul(K).add(q(10)));
 ck(o.add(a.sq().mul(K).div(pl.sq())).div(K.sq()).lt(R.sq())&&two.lt(b.mul(q(15*25**2-312))),"lattice radius");
 function latEarly(m,weighted){
 let s=q(0);for(let l=1;l<=12;l++){const u=b.mul(q(l*(l+1)));s=s.add(q(weighted?2*l+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return s.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(weighted?1:27)))));
 }
 const f=latEarly(15,true),h=latEarly(15,false),g=latEarly(short?32:40,true),j0=latEarly(short?32:40,false),j=short?f:latEarly(24,true);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 const coeff=q(1,4).add(q(1,66));
 const ext=y=>short?q(0):y.sq().mul(coeff).add(y.mul(q(2,33)));
 const P=p.mul(q(3,2)).add(ext(p)), c=o.sub(P);
 const W=x.mul(j).add(x.div(two).add(ext(x)).mul(f)).add(g), V=W.div(q(3));
 const mismatch=o.add(j0).mul(R).div(B);
 const norm=two.mul(ex(q(823,1000).mul(p)).sub(o));
 const drift=short?p.div(q(33)).add(P.div(K)).add(P.div(B.mul(K))):p.mul(ex(p)).div(q(33)).add(p.div(two).sq().mul(ex(p.div(two)))).add(norm.div(K)).add(norm.div(B.mul(K)));
 const slice=c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))));
 text({a:a.val(),V:V.val(),W:W.val(),c:c.val(),drift:drift.val(),mismatch:mismatch.val(),slice:slice.val()});
 ck(q(0).lt(c)&&V.sq().add(W.add(drift).add(mismatch).sq()).lt(c.sq())&&V.lt(slice),"signed ellipse and splice no-root slice");
}
sc(q(392,100),225,q(2),true);
sc(q(43,10),246,q(5,2),false);

const pk1=q(58,100),pk2=q(54,100),H1=q(5,2),H2=q(3),D1=q(64),D2=q(80),C5=q(292,100);
function curv(C,s,a){return C.sq().div(a.mul(o.sub(a))).lt(lo(s))}
function wit(C,e){return two.mul(C).mul(e).div(o.sub(e.sq())).lt(o)}
function margin(al,ar,l,d,b){let z=o.sub(l.sq());
 const f=al.add(d).add(al.mul(l).mul(d).div(z)).div(o.sub(al));
 const r=ar.add(ar.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).div(o.sub(ar));
 return f.add(r).lt(o);
}
ck(K.mul(ex(q(1,6*64))).lt(pk1.sq().mul(two).mul(pl).mul(q(1,2)).mul(q(31)))&&K.mul(ex(q(1,6*80))).lt(pk2.sq().mul(two).mul(pl).mul(q(3,5)).mul(q(31))),"Robbins modes");
const e1=q(181,1000),l1=q(453,1000),a1=q(133,1000),d1=q(414,1000),b1=q(39,1000);
const L4=q(2).sub(q(1,3)).add(q(1,16)).sub(q(1,80));
ck(o.div(e1).lt(lo(L4))&&o.div(e1).lt(lo(q(2).sub(q(4,15))))&&H1.mul(e1).lt(l1)&&curv(H1,q(4),a1)&&wit(H1,e1),"first witnesses and ratios");
ck(H1.mul(q(1,16).add(pk1.div(sk))).lt(d1)&&H1.div(q(65)).lt(b1)&&margin(a1,a1,l1,d1,b1),"first signed margin");
const e2=q(125,1000),l2=q(376,1000),a2=q(66,1000),d2=q(475,1000),b2=q(4,100);
ck(o.div(e2).lt(lo(q(25,12)))&&H2.mul(e2).lt(l2)&&curv(H2,q(5),a2)&&wit(H2,e2),"second low brackets");
ck(H2.mul(q(5,81).add(pk2.div(sk))).lt(d2)&&H2.div(q(81)).lt(b2)&&margin(a2,a2,l2,d2,b2),"second low sign");
ck(q(13,5).sub(q(1,47)).div(o.sub(o.div(q(874,100)))).lt(C5),"cap at five");
const e5=q(171,1000),r5=q(14,1000000),al=q(18,1000),ar=q(195,1000),l5=q(1,2);
const L5=q(2).sub(q(4,15)).add(q(1,25)).sub(q(4,625));
ck(o.div(e5).lt(lo(L5))&&C5.mul(e5).lt(l5)&&q(3).div(l5).lt(lo(q(100,32))),"cap at five ratios");
ck(curv(H2,q(100,16),al)&&curv(C5,q(4),ar)&&margin(al,ar,l5,d2,b2),"cap at five sign");
ck(o.div(r5).lt(lo(q(45,4)))&&two.mul(C5).mul(e5.add(r5.div(o.sub(e5.sq())))).lt(o),"cap five witness");
ck(q(5*99*99,2*16*100).lt(q(392,100).sq())&&q(72,5).lt(q(392,100).sq()),"first S");
ck(q(3*99*99,16*100).lt(q(43,10).sq())&&q(432,25).lt(q(43,10).sq()),"second S");
ck(q(1,16).lt(q(1,8))&&q(10,24).mul(q(65,64)).div(q(8)).lt(q(1,8)),"phase");
```
