# A lower-k dense-occupancy splice: all n≥900k for k≥160

2026-11-27. For the original excedance polynomial E_(n,k), the following rows have simple real roots and strict consecutive interlacing after division by t. Every right endpoint has the adjacent-pair conclusion too.
- 96≤k≤255 and 900k≤n≤3396k.
- 128≤k≤255 and 900k≤n≤4589k.
- Every k≥160 and n≥900k, with no upper bound on n. This joins the newly proved lower part of the high-row region to the existing eventual theorem.
The separate all-n result for k≥256 still applies. No new all-n threshold is claimed below 256. In particular the low and middle rows for 160≤k<256 are not covered by this note.

## Stronger dense edge, 96≤k≤255, n≥900k
Use H=n/k, D=n−1, M=floor(.75 sqrt(D)), S=D/M. All r≤.8 sqrt(n) satisfy r<H/2 since (.8)^2·256/900<1/4. The good-label cycle argument from long_cycles_all_n_k256.md gives A_n(r)/r≥Pr(Bin(n,1/r)≥k). Here the mean is ≥2k, so Chernoff, log 2<.7 and k≥96 yield .999r<A_n(r)≤r. The upper inequality holds at all r.

Use the adaptive edge balance lemma on each bracket between s=D/m and D/(m+1) for m+1≤M. For m≥16 the pure weights' outward ratios are <η=.413: the right first log loss is ≥(16/9)(1/2−1/660), since M≥220 by D≥86399, and the left first loss ≥8/9. For m≤15 use η=.001 from minimum log loss D/(2·16·17). Both extend to later pure outward ratios by log-concavity and also hold at witnesses s=D/m. On the left the occupancy ratio is ≤1/.999. On the right with denominator index between 16 and .8sqrt(n) it is ≤(17/16)/.999, or ≤1.5/.999 at indices 2..15 where the small pure η applies. Beyond .8sqrt(n), use global ratio ≤(27/8)(1+1/r)≤81/16 and right loss ≥(D/sqrt(n))(4/3−5/4). This gives λ=.45. The curvature products are ≤exp(−16/9)/.999²<.22(1−.22), because the center lies in the dense range and the numerator occupancies are bounded above by r−1 and r+1. Thus α=.22 at a zero.

At witnesses m≥16, pair the two odd offsets a whenever a<m. The factors (m−a)/(.999m) and (m+a)/(.999m) sum to exactly 2/.999, and the pure weights are each bounded by η^a. For a≥m use the sole right upper bound (1+a/m)/.999. A convenient total upper bound is [2η/(1−η²)+η^16(2/(1−η)+η/[16(1−η)^2])]/.999, by extending the unpaired supplement over all a≥16, even as well as odd. It is strictly below one. For m≤15 use the simpler bound with η=.001 and 2(1+a)/.999. Thus the alternating witness signs hold. The first witness keeps its sign for all larger s, as every relative weight decreases there.

The exact beta-lattice formula from the adaptive edge note gives d_r<.001 for r<H/2, by the same geometric Markov argument as in long_cycles_unrestricted_edge.md: x=(n−1)/r≥1.999k, n/(n−1)<1.001, and 7exp(−.2995k)<.001 for k≥96. This covers the entire left tail. For r≥H/2, use d_r≤(27/4)(r/n+.45/sqrt(k)). The beta-mode Fourier bound has variance (n−1)p(1−p)≥.99(k−1) at p=(k−1)/(n−1); integrate the Gaussian on |θ|≤1 with 1−cos θ≥11θ²/24 and use the bound exp[−(11/24)·.99(k−1)] elsewhere. The Gaussian is <.43/sqrt(k) and the remainder <.02/sqrt(k), uniformly for 96≤k≤255. Since sqrt(n)>293 and sqrt(k)>9.7, the right-tail drift at offset a is <.34+.000079a. In the signed-mean comparison, put .001 in the adverse main-left and even-left terms, and put .34,.000079 in the odd-right terms, with α=.22 and λ=.45. The resulting strict margin yields the correct old derivative and next-row signs. Therefore each bracket contains exactly one simple root, not merely an odd number.

The floor correction gives S≤(4/3)sqrt(n)+1.8, and |n atan(pi/S)/pi−M|<1/40 from the same cubic arctangent estimate with D≥86399. These are the only changes in the edge-to-center degree-count argument.

## Center from the harmonic-anchor method
For s≥4 sqrt(k) use the positive scalar reference P_*(s)> (5/3)k/(s+2k) and the exact logarithmic vertical estimate, now bounded by .18 for k≥96 (pi/[2(k−2)]≤(22/7)/188 and exponent ≤5/16). Then Re P_*(s+pi i)>.8P_*(s) and the imaginary part relative to the real part is ≤tan(.18). The splice fraction cos(pi/40)−tan(.18)sin(pi/40) remains >.98. Thus change the center lower bound to c_ref=(4/3)/(a/u_K+2) and use the improved splice test (16/9)N<(a−1.8/u_K)^2.
For s≤4 sqrt(k), the earlier exact central signs use k≥64 and n≥4k (long_cycles_two_pole_surrogate.md), so that strip is already valid. The final splice itself is at s≫4sqrt(k). Every other proof term is exactly as in long_cycles_harmonic_anchor_bridge.md, including the two harmonic norms, the L=18 split, the 64-term weighted lattice plus integral tail, the primary drift and the diagonal mismatch. No result for one k is extrapolated to smaller values of k.

The exact checks give end ratios 3396,4589,5440,5827 at baselines 96,128,160,192. The first interval in each chain starts at 900 itself; no previously known result at that point is needed. At 160≤k≤191, 2(k−1)≤380<exp(6), so the existing eventual theorem starts before 5400k. At 192≤k≤255, 2(k−1)≤508<exp(6.3), placing its start before 5670k. Both overlap the new bands. For k≥256 use long_cycles_all_n_k256.md. All computations below certify only analytic inequalities and interval coverage, not samples of the polynomials.

## Exact reproducible replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[96,900,103,25,18,1471],[96,1471,121,20,18,2042],[96,2042,135,15,18,2543],[96,2543,145,12,18,2934],[96,2934,152,10,18,3225],[96,3225,156,10,18,3396],[128,900,108,25,18,1621],[128,1621,131,15,18,2392],[128,2392,148,12,18,3063],[128,3063,160,10,18,3584],[128,3584,168,8,18,3945],[128,3945,174,8,18,4236],[128,4236,177,8,18,4387],[128,4387,179,8,18,4488],[128,4488,181,8,18,4589],[160,900,111,25,18,1721],[160,1721,137,15,18,2622],[160,2622,157,10,18,3453],[160,3453,172,8,18,4144],[160,4144,182,8,18,4635],[160,4635,188,8,18,4946],[160,4946,192,6,18,5167],[160,5167,194,6,18,5268],[160,5268,196,6,18,5379],[160,5379,197,6,18,5440],[192,900,113,25,18,1781],[192,1781,142,15,18,2822],[192,2822,165,10,18,3813],[192,3813,181,8,18,4584],[192,4584,192,8,18,5165],[192,5165,199,6,18,5546],[192,5546,204,6,18,5827]];
const covered={96:900,128:900,160:900,192:900};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(9,5).div(sk));
 ck(q(0).lt(rad)&&q(16*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const elo=y=>eb(y)[0];
ck(q(380).lt(elo(q(6)))&&q(508).lt(elo(q(63,10))),"eventual logs");
ck(covered[160]>=5400 && covered[192]>=5670,"eventual overlap");
const t=q(3,4), F=q(999,1000),loEta=q(1,1000), hiEta=q(413,1000),n0=q(86400),D0=q(86399);
const a0=q(22,100), l0=q(45,100), rr=q(27,4), dd=q(34,100), gg=q(79,1000000);
ck(q(16,25).mul(q(256,900)).lt(q(1,4)),"heavy occupancy");
ck(q(1000).lt(elo(q(3,10).mul(q(96)))),"occupancy threshold");
ck(o.div(hiEta).lt(elo(o.div(t.sq()).mul(q(1,2).sub(q(1,660))))),"high pure ratio");
ck(q(1000).lt(elo(D0.div(q(2*16*17)))),"low pure ratio");
ck(q(81,16).div(l0).lt(elo(D0.div(n0).mul(q(293)).mul(q(1,12)))),"far right loss");
ck(hiEta.mul(q(17,16)).div(F).lt(l0),"local right ratio");
ck(o.div(F.sq().mul(a0).mul(o.sub(a0))).lt(elo(o.div(t.sq()))),"curvature");
const pow=(x,i)=>{let p=o;while(i--)p=p.mul(x);return p};
const zz=o.sub(hiEta.sq()),za=o.sub(hiEta);
const remainder=pow(hiEta,16).mul(two.div(za).add(hiEta.div(q(16).mul(za.sq()))));
ck(two.mul(hiEta).div(zz).add(remainder).div(F).lt(o),"high witness with paired envelope");
const zlo=o.sub(loEta.sq());
ck(two.mul(loEta).mul(o.div(zlo).add(o.add(loEta.sq()).div(zlo.sq()))).div(F).lt(o),"low witness");
ck(q(100).lt(elo(q(5))),"Fourier far peak");
ck(o.lt(q(4).mul(q(43,100).sq()).mul(pl).mul(q(11,24)).mul(q(99,100)).mul(q(95,96))),"Fourier Gaussian peak");
ck(q(800).lt(elo(q(40))),"Fourier remainder less than .02/sqrt(k)");
ck(rr.mul(t.div(q(293)).add(q(45,100).div(q(97,10)))).lt(dd)&&rr.div(n0).lt(gg),"right drift");
ck(q(7000).lt(elo(q(2995,10000).mul(q(96)))),"small-index drift");
const z=o.sub(l0.sq());
ck(two.mul(a0).add(q(1,1000)).add(a0.mul(l0).div(q(1000).mul(z))).add(a0.mul(dd.div(z).add(gg.mul(o.add(l0.sq())).div(z.sq())))).lt(o.sub(a0)),"signed mean");
ck(o.div(t.sq()).div(o.sub(o.div(t.mul(q(293))))).lt(q(9,5)),"floor correction");
ck(t.add(q(10,3).mul(t.sq()).mul(t).mul(n0.div(D0))).div(q(293)).lt(q(1,40)),"phase correction");
```
