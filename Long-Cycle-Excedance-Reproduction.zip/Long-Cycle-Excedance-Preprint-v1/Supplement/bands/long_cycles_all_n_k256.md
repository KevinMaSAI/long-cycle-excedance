# The full n-range for all k≥256

2026-11-27 02:30 UTC wake. The genuine E_(n,k) has n−1 simple real roots for every integer k≥256, n≥k, and E_(n,k)/t strictly interlaces E_(n+1,k)/t. This lowers the previously established complete all-n threshold from k≥1024 to k≥256. It does not settle the full mother conjecture for 3≤k<256. No per-k or per-row enumeration of the original polynomials is used.

## 1. Dense-occupancy edge can begin at a smaller s
It suffices to treat 256≤k≤1024 and n≥1250k (the central extensions below lie there). Put D=n−1, H=n/k, M=floor((18/25)sqrt(D)), S=D/M. If r≤.8 sqrt(n), r/H≤.8 sqrt(1024/1250)<8/11. Mark an occupancy-bin label good when it contains ≥k balls. Conditional on the occupancies, if the uniform bin permutation has no cycle entirely of bad labels, then it is admissible. For g good and b bad labels with g+b=r, the fraction of such permutations is g/r: the bivariate exponential generating function by color is (1−y)/(1−x−y), since all permutations have EGF 1/(1−x−y) and the all-bad cycles have assembly EGF 1/(1−y). Coefficient comparison gives the stated fraction, including no good labels. Thus A_n(r)≥r Pr(Bin(n,1/r)≥k). The binomial mean is ≥11k/8. From Markov on exp(−uX), with exp(−u)=k/μ, Pr(X<k)≤exp[−k(μ/k−1−log(μ/k))]. The expression inside the parentheses is increasing in μ/k≥1. At μ/k=11/8, log(1+x)≤x−x²/2+x³/3 gives exponent at least 27/2 for k≥256. Hence .999r < A_n(r) ≤ r in the stated r window. The upper bound A_n(r)≤r holds everywhere.

For all edge brackets m+1≤M use the adaptive edge lemma. Pure outward ratios decrease along each tail. From D≥319999 we have sqrt(D)>565 and M≥407. For m≥16 the first pure right ratio is <η=.382, because the log loss at r≤M is ≥ (25/18)²(1/2−1/1200) by the cubic log estimate at M. The first left ratio is smaller. For m≤15 the loss D/(2·16·17) suffices for η=.001. These bounds also apply at the corresponding witnesses s=D/m. For left ratios, the denominator index is always below .8 sqrt(n), giving an amplitude factor ≤1/.999. For a right denominator in [16,.8 sqrt(n)] the amplitude factor is ≤(17/16)/.999; for the small m brackets and denominator ≥2 apply at worst 1.5/.999 multiplying their much smaller pure ratio. Above .8 sqrt(n) the amplitude ratio is at most (27/8)(1+1/r)≤81/16 by the global occupancy lower bound, while the pure right loss is at least (D/sqrt(n))(25/18−5/4). Hence λ=.41 controls all actual outward steps.

At either curvature center r (r≥2) one has A(r−1)A(r+1)/A(r)^2≤1/.999², since A(r)≥.999r while each numerator ≤r±1. Thus P≤exp(−(25/18)²)/.999²<.18(1−.18), so α_L,α_R≤.18 at old zeros, including the r=1 convention. At witnesses m≥16, the opposed odd offsets a contribute at most (2/.999) sum_(odd a≥1) .382^a(1+a/16)<1. For m≤15 use .001 and 1+a instead. This gives strict witness signs, and the m=1 argument also excludes zeros for s>D, because all relative contributions decrease in s.

Use the uniform drift proof in long_cycles_unrestricted_edge.md, now with .72 in place of .6. For r≥H/2, d_r≤(27/4)(r/n+.45/sqrt(k)); below H/2 the former bound d_r<.001 still applies. Thus for r≤M+a we have d_r<.20+.000022a, using sqrt(n)>565. The even-left/odd-right signed-mean margin is positive for α=.18, λ=.41 with these d,gamma. Every old edge root is simple and has the required next-row sign.

Finally S≤(25/18)sqrt(n)+2 by rounding M downward, because the additive floor loss is ≤(25/18)²/[1−25/(18 sqrt(D))]<2. The phase difference |n atan(pi/S)/pi−M| is ≤[.72+(n/D)(10/3)(.72)^3]/sqrt(D)<1/40 via the cubic arctangent estimate. Thus the same central splice and degree-count argument applies whenever the central strip reaches this new S.

## 2. Finish at the independent eventual proof without a gap
Reuse the two harmonic-distance norms, adjustable tilt, refined short/long-shift far bound, and positive primary scalar reference of long_cycles_harmonic_anchor_bridge.md. There is no change to the central ellipse; the improved radial splice inequality is (625/324)N<(a−2/u_K)², where u_K≤sqrt(K) and a is the central multiplier for sqrt(k). The 14 analytic intervals in the exact replay start within known complete coverage and extend it to:
- n≤6087k at k≥256;
- n≤6893k at k≥384;
- n≤7024k at k≥512.

For 256≤k≤383, use 2(k−1)≤764<exp(27/4), so 900(k−1) log(2(k−1))<6075k. For 384≤k≤511, the exponent comparison uses 1020<exp(7), hence the eventual bound starts before 6300k. For 512≤k≤1023, use 2044<exp(39/5), so the eventual bound starts before 7020k. All three ranges are strictly below the verified coverage for their k bands. The earlier uniform eventual theorem for k≥64 therefore fills all larger n, including adjacent pairs; its source assets are UNIFORM_K_LOG.md and check_uniform_k_log.py, summarized in long_cycles_k3_research.md. The earlier independent theorem for k≥1024 fills the remainder. Every comparison is on the original polynomial, not the pure or two-pole model.

## Reverse audit and replay
The denser edge depends on n/k≥1250, and all added intervals start at n/k≥2349, so the sharper weights were never extrapolated to the light-occupancy side. Curvature uses both neighbors, and in the low-index case the witness at m=1 does not assume a left neighbor exists. The far-right loss uses the actual outgoing base r, allowed to exceed the load window only after the uniform left threshold has already been passed. For the next-row comparison the drift is old-to-new and nonnegative; it is not a continuous interpolation. The sign at the final row in any band is checked with its next row directly. Exact log upper thresholds use positive series lower bounds for exp, not computed floating logs. All exact arithmetic below passed. The only floating operation proposes an upper bound on a square root, which is verified by rational squaring before any use. This proves no new results below k=256.

```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(508)).mul(ex(q(5,16)).sq()).lt(q(11,100).sq()),"vertical log bound");
ck(q(22,25).lt(q(89,100).mul(o.sub(q(11,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(11,100).div(o.sub(q(11,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[256,2349,162,10,18,3390],[256,3390,182,8,18,4281],[256,4281,196,8,18,4962],[256,4962,205,6,18,5433],[256,5433,211,6,18,5754],[256,5754,214,6,18,5915],[256,5915,216,5,18,6026],[256,6026,217,5,18,6087],[512,3882,208,6,18,5593],[512,5593,233,5,18,7024],[384,2349,171,10,18,3780],[384,3780,199,8,18,5121],[384,5121,218,6,18,6142],[384,6142,231,5,18,6893]];
const covered={256:2349,384:2349,512:3882};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({256:16,384:19,512:22}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(22,15).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(2).div(sk));
 ck(q(0).lt(rad)&&q(625*N,324).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const lo=x=>eb(x)[0];
ck(q(764).lt(lo(q(27,4))) && q(1020).lt(lo(q(7))) && q(2044).lt(lo(q(39,5))),"eventual logs");
ck(covered[256]>=6075 && covered[384]>=6300 && covered[512]>=7020,"eventual overlap");
const eta=q(382,1000), A=q(999,1000),lambda=q(41,100),a=q(18,100),d=q(20,100),b0=q(22,1000000),r0=q(18,25),Dmin=q(319999),nmin=q(320000);
ck(q(16,25).mul(q(1024,1250)).lt(q(8,11).sq()),"small load threshold");
ck(q(1000).lt(lo(q(27,2))),"occupancy close");
ck(o.div(eta).lt(lo(o.div(r0.sq()).mul(q(1,2).sub(q(1,1200))))),"pure high ratio");
ck(q(1000).lt(lo(Dmin.div(q(2*16*17)))),"pure low");
ck(q(81,16).div(lambda).lt(lo(Dmin.div(nmin).mul(q(565)).mul(q(25,18).sub(q(5,4))))),"far right purity");
ck(eta.mul(q(17,16)).div(A).lt(lambda),"near right ratio");
ck(o.div(A.sq().mul(a).mul(o.sub(a))).lt(lo(o.div(r0.sq()))),"curvature");
const odd=o.sub(eta.sq());
ck(two.div(A).mul(eta.div(odd).add(eta.mul(o.add(eta.sq())).div(q(16).mul(odd.sq())))).lt(o),"high witness");
const small=q(1,1000), smallOdd=o.sub(small.sq());
ck(two.div(A).mul(small.div(smallOdd).add(small.mul(o.add(small.sq())).div(smallOdd.sq()))).lt(o),"low witness");
ck(q(27,4).mul(r0.div(q(565)).add(q(45,1600))).lt(d) && q(27,4).div(nmin).lt(b0),"global drift");
const z=o.sub(lambda.sq());
ck(two.mul(a).add(d).add(a.mul(lambda).mul(d).div(z)).add(a.mul(d.div(z).add(b0.mul(o.add(lambda.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");
ck(o.div(r0.sq()).div(o.sub(o.div(r0.mul(q(565))))).lt(two),"floor correction");
ck(r0.add(q(10,3).mul(r0.sq()).mul(r0).mul(nmin.div(Dmin))).div(q(565)).lt(q(1,40)),"phase correction");
```

## Next work below 256 (not a theorem)

Do not repeat row enumeration. Targets are a lower-threshold uniform large-ratio edge and a better small-to-medium n/k splice. The load calculation becomes easier once k is capped by 256, but the lower Chernoff exponent and beta peak constants must be rechecked for the proposed k floor. At s=D/m the combined amplitude upper bounds for offsets a<m are exactly 2/.999 times their common pure geometric envelope, since r=m−a and r=m+a and A_n(r)≤r; use the unpaired linear tail only for a≥m. That may move the favorable edge cutoff from .72 sqrt(D) to .75 sqrt(D) without spending a new witness margin. Improving this cutoff and combining the stronger central harmonic geometry with the earlier signed-log-anchor cancellation may lower both the k floor and the eventual O(k log k) constant. The most restrictive gaps may instead be at small n/k; use the earlier isolated n≤2.5k theorem and do not infer that the dense-occupancy edge covers them.