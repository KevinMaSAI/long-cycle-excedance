# Uniform low-degree quadrature for the signed lag

This is a substantive structural positivity result for every parameter pair in the induction, not a new n/k range. It proves that the lag form is positive on a growing subspace and identifies the high modes still needed for a complete proof.

Let F=F_n be the Cayley polynomial, d=n−2, and L=binom(n,k−1) F_k F_(n+1−k). Use the lag-free convention; otherwise put s=lc(L)/lc(F)=d_(n+1−k)/d_n>0, where d_j=E_(j,k)(1)/j! as in the variance note. Under the usual induction hypothesis F has simple real roots r_i in (−1,1); set rho_i=L(r_i)/F'(r_i).

**Exact quadrature.** For any real polynomial p with deg p<k,
    sum_i rho_i p(r_i) = (s/n) [sum_i p(r_i)+p(−1)+p(1)].
In the lag-free case both sides are zero with s=0. In particular, with active lag the signed lag Gram form by itself is strictly positive on nonzero polynomials q of degree at most floor((k−1)/2), by using p=q². A nonzero q of that degree cannot vanish at all d distinct old roots since n>=2k−1. This does not contradict earlier indefinite examples: their adverse directions are outside the preserved low-degree subspace.

## Proof of moment matching from the single-cycle recurrence
Let C_m(t)=t A_(m−1)(t) for m>=2 be the excedance polynomial of one m-cycle. Inserting the largest label into the same cycle yields the derivative recurrence with no lag. Therefore C_(m+1)(t)/(1−t)^(m+1) = t d/dt [C_m(t)/(1−t)^m]. The base m=2 is C_2=t, so C_m(t)/(1−t)^m=sum_(j>=1) j^(m−1)t^j on |t|<1. Put t=e^(−u), u>0 tending to zero. The series is (−d/du)^(m−1)(1/(e^u−1)). The latter meromorphic function equals 1/u plus an analytic function near zero; consequently the series is (m−1)! u^(−m)+O(1). This proves the exact finite Taylor agreement
    e^(m u/2) C_m(e^(−u))/(m−1)! = [2 sinh(u/2)/u]^m + O(u^m).
Analytic continuation extends this local Taylor identity. Independence of the cycle weights in the cycle exponential formula, and positive weights over cycle types, give for every n>=k
    e^(n u/2) E_(n,k)(e^(−u))/E_(n,k)(1) = [2 sinh(u/2)/u]^n+O(u^k).
In particular no restriction on n/k is required.

Set z=1/x, u=2 atanh z, and define `A(z)=z/atanh z`, analytic at zero with A(0)=1. Using the Cayley change and sinh(atanh z)=z/sqrt(1−z²), obtain
    F_n(x)/(lc(F_n) x^(n−2)) = (1−z²)^(-1) A(z)^n + O(z^k).
For active lag the two normalized factors have total cycle lengths n+1 and total degree n−3, so dividing the expansions gives L/F = s z (D(z)+O(z^k)) with D(z)=A(z)/(1−z²). Partial fraction expansion therefore gives sum_i rho_i r_i^j=s [z^j]D(z), for all 0<=j<k.
Meanwhile, logarithmically differentiating the normalized expression for F_n using −z d/dz gives
    sum_i r_i^j = n [z^j]D(z) − (1+(-1)^j)  for 0<=j<k.
For j=0 this is just n−2; for j>=1 use −z(log A)'=D−1 and the logarithmic derivative of (1−z²)^(-1). The error O(z^k) is not worsened by z d/dz. Combining the two moment identities proves the asserted quadrature.

## Implications and remaining gap
The exact second root moment is sum r_i²=2n/3−2, since [z²]D=2/3. Thus the critical variance weight mass from the prior note is exactly (2n/3−2)/(n−2)². The first signed moment after centering by s/d vanishes at degree 0 and equals 2s/(3d) at degree 2. The entire low-degree centered part is determined by the quadrature, not by numerical root positions. For example, when k>4 one can form its degree-two projection explicitly from the same fourth root moment. The unexplained part lies in orthogonal degrees >=k (or, for the lag Gram positivity statement, squares with degree >=k); the low-degree positivity does not give a uniform variance upper bound or exclude a negative weight at an individual root. Do not extend the identity to higher degrees without accounting for the Taylor remainders. Full mother conjecture remains unresolved in this work.

The replay verifies the two coefficient identities from literal integer rows and exact fractions at a few diagnostic active pairs, also checking the sign and order conventions. The proof above is for all pairs independently of this replay.

## Exact replay
```javascript
const gcd=(a,b)=>{while(b!==0n){const t=a%b;a=b;b=t}return a<0n?-a:a};
class Q{constructor(a,b=1n){a=BigInt(a);b=BigInt(b);if(b<0n){a=-a;b=-b}const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return this.add(new Q(-y.a,y.b))}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}}
const q=(a,b=1)=>new Q(a,b),one=q(1),two=q(2),three=q(3),pi=q(157,50);
function expUp(x){let t=one,z=one;for(let j=1;j<=13;j++){t=t.mul(x).div(q(j));z=z.add(t)}return z.add(t.mul(x).div(q(14)).div(one.sub(x.div(q(15)))))}
function assert(v){if(!v)throw Error("margin failed")}


const zeros=n=>Array(n).fill(0n);
const abs=x=>x<0n?-x:x;
function choose(n,k){let a=1n;for(let j=1;j<=k;j++)a=a*BigInt(n+1-j)/BigInt(j);return a}
function rows(k,N){const F=[];let p=[1n];
 for(let j=3;j<=k;j++){const r=zeros(p.length+1);for(let i=0;i<p.length;i++){r[i+1]+=BigInt(2+i)*p[i];if(i)r[i-1]-=BigInt(i)*p[i]}p=r}F[k]=p;
 for(let n=k;n<N;n++){const r=zeros(p.length+1);for(let i=0;i<p.length;i++){r[i+1]+=BigInt(2+i)*p[i];if(i)r[i-1]-=BigInt(i)*p[i]}
 const b=lag(F,k,n);if(b)for(let j=0;j<b.length;j++){r[j+2]+=b[j];r[j]-=b[j]}F[n+1]=p=r;}
 return F}
function lag(F,k,n){const f=F[k],g=F[n+1-k];if(!g)return null;const r=zeros(f.length+g.length-1),c=choose(n,k-1);
 for(let i=0;i<f.length;i++)for(let j=0;j<g.length;j++)r[i+j]+=c*f[i]*g[j];return r}
function series(a,b,M){const z=[],d=a.length-b.length,l=q(b.at(-1));for(let i=0;i<=M;i++){
 let s=q(a[a.length-i-1]??0n);for(let j=1;j<=Math.min(i,b.length-1);j++)s=s.sub(q(b.at(-j-1)).mul(z[i-j]));z.push(s.div(l));}
 return z}
function bound(F,k,n){
const p=F[n-1],m=Math.floor((p.length-1)/2),b=series(F[n],p,4*m+1),g=series(lag(F,k,n),p,2*m);
const rhs=Array.from({length:m},(_,i)=>g[2*i+2]),R=rhs.slice();
const M=Array.from({length:m},(_,i)=>Array.from({length:m},(_,j)=>q(0).sub(b[4+2*(i+j)])));
for(let i=0;i<m;i++){const d=M[i][i];if(!q(0).lt(d))return null;for(let j=i+1;j<m;j++){
 const h=M[j][i].div(d);for(let v=i;v<m;v++)M[j][v]=M[j][v].sub(h.mul(M[i][v]));R[j]=R[j].sub(h.mul(R[i]));}}
const x=new Array(m);for(let i=m-1;i>=0;i--){let z=R[i];for(let j=i+1;j<m;j++)z=z.sub(M[i][j].mul(x[j]));x[i]=z.div(M[i][i]);}
const loss=rhs.reduce((a,y,i)=>a.add(y.mul(x[i])),q(0));const t=b[0].add(g[0]).mul(q(4));return [loss,t]}


for(const [k,n] of [[3,5],[4,9],[6,14],[11,21]]){
 const F=rows(k,n),p=F[n],L=lag(F,k,n),N=k-1,Z=q(0),I=q(1),m=p.length-1,s=q(L.at(-1),p.at(-1));
 const norm=Array.from({length:N+1},(_,j)=>q(p[m-j]??0n,p[m]));
 const A=Array.from({length:N+1},(_,j)=>j%2?Z:q(1,j+1)),u=[];
 for(let j=0;j<=N;j++){let z=j%2?Z:I;for(let h=1;h<=j;h++)z=z.sub(A[h].mul(u[j-h]));u.push(z);}
 const P=[q(m)],r=series(L,p,N);
 for(let j=1;j<=N;j++){let z=q(j).mul(norm[j]);for(let h=1;h<j;h++)z=z.add(norm[h].mul(P[j-h]));P.push(Z.sub(z));}
 for(let j=0;j<=N;j++) {
  assert(r[j].sub(s.mul(u[j])).a===0n);
  assert(P[j].add(j%2?Z:q(2)).sub(q(n).mul(u[j])).a===0n);
 }
 text("PASS: k="+k+", n="+n+" rational low-mode and endpoint quadrature identities");
}
```

## Exact projection of the low modes (while preparing a Windows check)
Let d=n−2, m=floor((k−1)/2), s=sum rho, and retain only even polynomials of degree <=m (odd modes of centered rho vanish). Write G for the positive reference moment matrix from the first-high-moment note in any basis of that subspace, v for endpoint evaluation at 1, and K=v^T G^(-1)v. The old-root Gram is exactly nG−2vv^T by the low-degree root moments, because products of basis polynomials have degree <k. It is positive definite by the induction hypothesis and degree. Its endpoint kernel is K/(n−2K) by the rank-one inverse calculation. The centered correction functional is (2s/n)[q(1)−(1/d)sum_i q(r_i)], so the squared projection onto the stated subspace equals (4s²/n²)[K/(n−2K)−1/d]. This is exact (including the constant-only subspace, where it vanishes). The reference density is >=(2/pi) times arcsine, so K<=(pi/2)(1+2 floor(m/2)) by the Chebyshev endpoint kernel. With active lag n>=2k−1 and k>=7, 2K/n<=88/91 using pi<22/7 and (k+1)/(2(2k−1)) maximized at 7. Thus the low-mode squared projection is below 235/n² for k>=7 using s<2. This bounds only the already understood piece; the high-mode orthogonal complement remains the proof obstacle.

## Nodewise leverage bound for the high modes (2026-11-26 13:45 UTC)
Retain the even evaluation subspace U of degree <= m=floor((k−1)/2) as above, with inner product the unweighted sum over old roots. Use H(x,y)=b(x)^T (nG−2vv^T)^(-1)b(y), b the chosen basis vector and v=b(1). Let u_i=rho_i−s/d and q(x)=(2s/n)(H(x,1)−1/d); quadrature shows P_U u=(q(r_i))_i because integration of the kernel against constants reproduces the constant. Its norm squared W is the low-mode energy already given. For a nonzero old root r, let e=(delta_r+delta_−r)/2. Then <e,u>=u(r), ||e||²=1/2, P_U e is the root evaluations of H(·,r), and ||P_U e||²=H(r,r). Hence 0<=h(r)=1/2−H(r,r) and
    rho(r) >= s/d + q(r) − sqrt((V−W) h(r)).
If h=0 the value is fixed by the low modes; otherwise if 1+s/d+q(r)>0, exclusion of a bad weight rho(r)<=−1 only requires V−W < (1+s/d+q(r))²/h(r). The estimate is sharp for the available low moments plus the squared norm on the even subspace alone (unless the residual space is zero): align the unknown residual with −(I−P_U)e when h>0. Compare the crude centered bound h<=1/2−1/d, from the constant mode, giving exactly the prior variance threshold using only that mode. If needed, all node kernel values before the final evaluation follow from H(x,y)=n^(-1)[b(x)^T G^(-1)b(y)+2(b(x)^T G^(-1)v)(v^T G^(-1)b(y))/(n−2v^TG^(-1)v)]. This uses the already verified rank-one Gram formula, with n−2v^TG^(-1)v>0 from positive definiteness. The refinement applies to all n,k under the old-row induction hypothesis, but does not bound the high-mode energy itself and does not prove the mother conjecture.