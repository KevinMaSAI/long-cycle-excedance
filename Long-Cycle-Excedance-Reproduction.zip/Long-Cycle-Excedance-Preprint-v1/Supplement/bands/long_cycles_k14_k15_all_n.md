# All rows for the final two k values: complete strip certificates
November 27, 2026. For k=14,15 and all n≥k, the long-cycle excedance polynomial E_(n,k) has n−1 simple real roots and the quotients by t strictly interlace for adjacent n. This reduction uses the same pole anchor, real-root sign stitch and occupancy expansion as the earlier ranges. This note supplies the middle inequalities and a coverage map; count, edge and onset proof with exact replays are in long_cycles_k14_k15_counts_and_edges.md.
 
## Exhaustive coverage by analytic strips
For old n<2k−1 use classical Eulerian interlacing; n=2k−1,2k use the four exact Euclidean chains from the preceding note. For old 2k+1≤n≤3k use the sparse proof below with M=3. For 3k≤n≤16k use the middle proof with M=floor(√(n−1)/2). For 16k≤n≤114k use the upper proof with M=floor(.6√(n−1)); thereafter the independently checked uniform bound n≥112k in long_cycles_uniform_residue_112k.md applies to both k. Each strip is for the old n and the actual next row; all transition pairs are covered. The cap in the upper strip can exceed 112k to ensure positive overlap.
 
## Sparse central ellipse
Use the anchor normalizations and notation from long_cycles_k16_through_3k.md. Four ratio slabs have boundaries 2, 2.25, 2.5, 2.75, 3, with maximum s/√k respectively 2.79,3.13,3.46,3.80. In the first three slabs the mixed products are linear. The pre-two-cycle nonatom counts give u=1−1/(N−1+1/14), respectively 9/37,4/11,23/51. As before use P=(1+u)p, W=x j_(B−1)+u x f+g. Direct drift P/14+P/(14B)+p/15 is valid, and the true diagonal mismatch factor is 1,.6,1/3. In the last slab retained numerator after degree k is at most max(1/(1.75k),.589/k); with d_n,d_(n+1)≥.555/k the ratio is <1.065. For the earlier linear prefix it is <1.442 and globally <1.81. The three prefix masses, quadratic cross price, exact new boundary and .17 relative diagonal mismatch are precisely as in the k16 sparse proof, replacing K by 14. Lower pole lattice exponents are floored in half powers (k−1 contributes 6 in the replay). The angular exclusion uses π/8, and the analytic radii use D bounds 32,36,40,44 and the upper ratio N so S/√k≤sqrt(N D²/[9(D+1)]).
 
## Middle central ellipse
The K16 quarter-degree scheme is strengthened by the exact quarter masses and tail bounds in the count note. A lower total degree marks possible inclusion in b≤n+1−k. The upper total degree gives the smaller residual γ=B−h/4, which bounds the pole attenuation and d-ratio. For residual≥2k use 1.016; otherwise use min(1.725,max(1.016,1/(.580 max(1,γ)))). The direct drift from the overlapping retained prefix remains P/K+P/(BK). The precise new boundary permits only pure-atom degrees j in (B−1,floor(N−1+1/K)], and other terms can mark one nonatom with supremum p/[2(K+1)]. Here K=14 is the lower bound, not a substitution for the actual k in definitions. The normalized diagonal mismatch uses min(.089,.0394/floor(B−1)!). The reference error sums the high-degree-shift convolution in upper degree, charging the relative errors from the count note, with separate analytic tails for degree and factor count. Uniform tilted baseline 1.016 can independently bound the absolute term sum, and the upper tilted W is used only as a minimum with the degree-indexed W.
 
The only real primary floors used after reverse audit are the absolute 2−exp(.780p) and the complex Poisson reference. The latter is derived in long_cycles_all_n_k16.md; here the exact same proof takes d≤14 and s0=3.74ℓ, where ℓ is the substrip lower s/√k. The tail from b≥2 is bounded by F_14(2s0)/[2(1−exp(−(s0−7)))]. Positive real floor multiplies a downward enclosure of exp(−J), while J uses upper enclosures. Rational subdivision requires finitely many analytic stripes, not evaluation of finitely many original polynomials. All strips cover continuously from ratio 3 through 16. Standard half-sqrt phase is between Mπ and (M+1)π, so no exception or exclusion slice is used here.
 
## Upper central ellipse
Same endpoint-weighted tilt and reference identity as for k≥16. The sharper tilted mass is capped by [e^α+e^(2α)/2+.074e^(3α)+.0038e^(4α)/(1−e^α/4)]/2, using the two-cycle block and the T(3k) contraction. Absolute plain norm .780, retained ratio 1.725, and long relative error .0394/L! give the normal formulas. Small core [0,4] in units s/√k uses the absolute principal bound. Strips [4,5],[5,6],[6,7] use the Poisson lower bound; the same lower starting point 7 is used for the outer part. The splice S/√k is ≥(5/3)sqrt(16−1/14)>6, so on [6,7] and outer part verify angular exclusion for |phase−Mπ|<π/16 by Re P_* cos δ−|Im P_*|sin δ. Bounding arg P_* by ζ gives the checked multiplier (1−ζ²/2)(1−δ²/2)−ζδ. Beyond s/√k=7, seven contiguous ratio strips reach n/k=114. The exact floor formula S≤(5/3)√n+3.13 fits every strip.
 
## Exact replays
Each block is standalone JS. Replace text with console.log locally. The exact test for each candidate inequality is rational with directed exponent enclosures, not floating roots; the double square-root operation proposes a rational upper radius that is then verified by exact squaring.
 
### Sparse center
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(15)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}


const pl=q(157,50),pu=q(22,7),K=q(14),sk=q(374,100),lo=x=>eb(x)[0];
const rows=[[279,249,8,9,37,1,1],[313,277,9,4,11,3,5],[346,305,10,23,51,1,3],[380,333,11,0,1,17,100]];
for(const [a0,R0,B4,m1,m2,i1,i2] of rows){
 const a=q(a0,100),R=q(R0,1000),B=q(B4,4),b=q(4).mul(pl.sq()).div(a.sq().mul(K).add(q(10)));
 ck(o.add(a.sq().mul(K).div(pl.sq())).div(K.sq()).lt(R.sq())&&two.lt(b.mul(q(6*25**2-312))),"lattice");
 function lat(m,v){let s=q(0);for(let j=1;j<=12;j++){const u=b.mul(q(j*(j+1)));s=s.add(q(v?2*j+1:1).mul(em(q(2*m).mul(u).div(two.add(u)))));}
 const u=b.mul(q(156));return s.add(em(q(2*(m-1)).mul(u).div(two.add(u))).div(b.mul(q((m-1)*(v?1:27)))));}
 const f=lat(6,true),h=lat(6,false),g=lat(Math.floor(7*B4/4),true),j0=lat(Math.floor(7*B4/4),false),j=lat(Math.floor(7*(B4-4)/4),true);
 const p=R.mul(o.add(q(3,2).mul(h))),x=R.mul(q(3,2).add(q(4,3).mul(h)));
 let P,W,d;
 if(B4<11){
  const r=q(m1,m2);P=o.add(r).mul(p);
  W=x.mul(j).add(r.mul(x).mul(f)).add(g);
  d=p.div(q(15)).add(P.div(K)).add(P.div(B.mul(K)));
 }else{
  const u=q(1065,1000),v=q(1442,1000),z=q(181,100);
  function mask(p){return z.mul(p.div(q(15)).add(p.sq().mul(q(1,8).add(q(1,68)))));}
  P=u.mul(p).div(two).add(v.mul(p).div(q(6))).add(z.mul(p).div(q(12))).add(mask(p));
  W=u.mul(x).mul(j).div(two).add(v.mul(x).mul(lat(8,true)).div(q(6))).add(z.mul(x).mul(f).div(q(12))).add(mask(x).mul(f)).add(g);
  const ne=two.mul(ex(q(84,100).mul(p)).sub(o));
  d=P.div(K).add(P.div(B.mul(K))).add(q(181,100).mul(p.div(q(30)).add(p.sq().div(q(8)))));
 }
 const V=W.div(q(3)),mis=q(i1,i2).mul(o.add(j0)).mul(R).div(B),c=o.sub(P),slice=c.mul(o.sub(pu.div(q(8)).sq().div(two))).sub(P.mul(pu.div(q(8))));
 text({a:a.val(),W:W.val(),d:d.val(),mis:mis.val(),c:c.val(),slice:slice.val()});
 ck(q(0).lt(c)&&V.sq().add(W.add(d).add(mis).sq()).lt(c.sq())&&V.lt(slice),"sparse ellipse");
}

for(const [N,D,a] of [[q(9,4),32,q(279,100)],[q(5,2),36,q(313,100)],[q(11,4),40,q(346,100)],[q(3),44,q(380,100)]])ck(N.mul(q(D*D,9*(D+1))).lt(a.sq()),"splice radius");
```
### Middle center
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
const pl=q(157,50),pu=q(22,7),K=14,sk=q(374,100),xi=q(780,1000),o44=q(1,2);
const min=(a,b)=>a.lt(b)?a:b,max=(a,b)=>a.lt(b)?b:a;
const rows=[[3,408,40,2,3.25,0,0],[3.25,442,40,2,3.5,0,0],[3.5,465,40,2,3.75,0,1],[3.5,475,40,3,3.75,465,0],[3.75,473,40,2,4,0,1],[3.75,508,40,3,4,473,0],[4,482,40,2,4.25,0,1],[4,537,40,3,4.25,482,0],[4.25,487,40,2,4.5,0,1],[4.25,552,40,3,4.5,487,1],[4.25,557,40,3,4.5,552,0],[4.5,497,40,3,5,0,1],[4.5,562,40,3,5,497,0],[5,520,40,3,5.5,0,1],[5,525,40,3,5.5,520,0],[5.5,535,40,3,6,0,1],[5.5,575,40,3,6,535,0],[6,550,40,3,7,0,1],[6,655,40,3,7,550,0],[7,572,40,3,8,0,1],[7,662,40,3,8,572,0],[8,584,40,3,10,0,1],[8,754,40,3,10,584,0],[10,591,40,3,12,0,1],[10,771,40,3,12,591,0],[12,594,40,3,14,0,1],[12,869,40,3,14,594,0],[14,592,40,3,16,0,1],[14,882,40,3,16,592,0]];
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic floor");
const ca=o.sub(q(46,100).sq().div(two));
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log");
ck(q(48,100).lt(q(54,100).mul(ca)),"vertical positive");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(ca).mul(pu.div(q(16))))),"splice rotation");
for(const [B,a0,tilt0,L,N,low=0,skip=0] of rows){
 const a=q(a0,100),r0=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(r0.val())*1e6)+1,1000000);
 ck(r0.lt(R.sq()),"radius");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=6;
 ck(two.lt(b.mul(q(m0*33**2-544))),"lattice tail monotone");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const w=l=>mode===0?q(2*l+1):mode===1?q(1):mode===2?q(1,l).add(q(1,l+1)):q(2,l+1);
  let s=q(0);for(let j=1;j<=16;j++)s=s.add(w(j).mul(decay(m,b.mul(q(j*(j+1))))));
  return up(s.add(decay(m-1,b.mul(q(272))).mul(w(17)).div(b.mul(q((m-1)*35)))));
 }
 const f=lat(m0,0),h=lat(m0,1),j=lat(Math.floor((B-1)*K/2),0),g=lat(Math.floor(B*K/2),0),fl=lat(L*K/2,0);
 const p=up(R.mul(min(o.add(q(3,2).mul(h)),o.add(lat(m0,2)))));
 const x=up(R.mul(min(q(3,2).add(q(4,3).mul(h)),two.add(lat(m0,3)))));
 const D0=up(min(q(89,1000),q(394,10000).div(fact(Math.floor(B-1)))).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4)));
 const al=q(tilt0,100),ea=ex(al);
 ck(ea.lt(q(3)),"tail tilt contraction");
 const tail=q(119,1000).mul(ex(al.mul(q(3)))).div(o.sub(ea.div(q(3))));
 const J=up(ea.add(ex(al.mul(two)).div(two)).add(tail).div(two));
 const delta=L===2?q(89,1000):L===3?q(66,10000):q(394,10000).div(fact(L)),abs=ex(xi.mul(p)).sub(o),U=L<=3?q(1016,1000):o.add(delta),U0=q(1725,1000),E=U0.sub(U);
 const core=low===0;
 const ps=em(al.mul(q(Math.round(4*(B-L)),4))).mul(ex(J.mul(p)).sub(o));
 let W,drift,c,slice;
 const caps=[882352943,784313727,524475526,324074076,251256239,91160178,22319961,17905597,13692186,1576387,2267073,1065241,184152,203435,111219,9062,17735,7395,1164,958,541,65,76,25]; const T=[0,0,77e-3,38e-4,102e-6,54e-7,15e-8,3e-9];const TF=[null,null,q(77,1000),q(38,10000),q(102,1000000),q(54,10000000),q(15,100000000),q(3,1000000000)]; function mkTail(j){return j<=7?TF[j]:TF[7].mul(fact(7)).div(fact(j));}
 function typesOf(jlast){const types=[[4,4,q(1,2)]]; for(let j=4;j<4*jlast;j++)types.push([j,j+1,j<28?q(caps[j-4],10000000000):mkTail(Math.floor(j/4)).div(two)]);return types;}

 {
  const types=typesOf(Math.ceil(N));
  const maxLo=Math.floor(4*(N-1)+4/K);
  let dp=new Map([[0,o]]);
  const cache=new Map(), span=8*Math.ceil(N)+16;
  function lpow(m){if(!cache.has(m))cache.set(m,lat(m,0));return cache.get(m);}
  let pw=o,xw=o,old=q(0),wfar=g;
  for(let m=1;m<=Math.floor(maxLo/4);m++){
    const nd=new Map();pw=pw.mul(p).div(q(m));xw=xw.mul(x).div(q(m));
    for(const [key,v] of dp){
      const l=Math.floor(key/span),h=key%span;
      for(const [b,e,w] of types){
        if(l+b>maxLo)continue;
        const H=h+e;ck(H<span,"span");const key1=(l+b)*span+H;
        nd.set(key1,(nd.get(key1)??q(0)).add(v.mul(w)));
      }
    }
    dp=nd;
    for(const [key,v] of dp){
      const h=key%span;
      const rem=q(Math.max(4,4*B-h),4); const factor=4*B-h>=8?q(1016,1000):min(U0,max(q(1016,1000),o.div(q(580,1000).mul(rem))));
      const mp=Math.max(m0,Math.floor((4*B-h)*K/8));
      old=old.add(factor.mul(pw).mul(v));
      wfar=wfar.add(factor.mul(xw).mul(v).mul(lpow(mp)));
    }
  }
  const P=min(old,q(1016,1000).mul(abs).add(q(709,1000).mul(em(al.mul(q(Math.round(4*(B-2)),4)))).mul(ex(J.mul(p)).sub(o))));
  W=up(wfar);
  let bw=q(0),t=o,pow=o, jmax=Math.floor(N-1+1/K);
  const pp=p.div(two),slot=xi.mul(p);
  for(let j=1;j<=jmax;j++){t=t.mul(pp).div(q(j));if(j>B-1)bw=bw.add(t);}
  let sum=o;for(let j=1;j<jmax;j++){pow=pow.mul(slot).div(q(j));sum=sum.add(pow);}
  drift=up(P.div(q(K)).add(P.div(q(4*B*K,4))).add(U0.mul(bw.add(pp.div(q(K+1)).mul(sum)))));
  c=o.sub(P);slice=c.mul(o.sub(pu.div(q(16)).sq().div(two))).sub(P.mul(pu.div(q(16))));
 }
 if(L>=3){
  const Qmax=Math.ceil(4*B)+4, Jlast=Math.ceil(B)+1, md=16, es=typesOf(Jlast).map(([l,h,w])=>[h,w]);
 es.push([Qmax,mkTail(Jlast).div(two)]);
 const msum=es.reduce((s,[_,w])=>s.add(w),q(0)).mul(p);
  let epsDP=q(0),prod=o,dp=new Map([[0,o]]);
  const pref=new Map();
  function modLoss(h){
   if(pref.has(h))return pref.get(h);
   const r=Math.floor((4*B-h)/4);let v=q(1);
   if(r>=4)v=q(394,10000).div(fact(r));
   else if(r===3)v=q(66,10000);
   else if(r===2)v=q(89,1000);
   else if(r===1)v=max(q(89,1000),o.div(q(580,1000).mul(q(4*B-h,4))).sub(o));
   pref.set(h,v);return v;
  }
  for(let m=1;m<=md;m++){
   const tmp=new Map();
   prod=prod.mul(p).div(q(m));
   for(const [h,v] of dp)for(const [s,w] of es){let f=Math.min(Qmax,h+s);tmp.set(f,(tmp.get(f)??q(0)).add(v.mul(w)));}
   dp=tmp;
   for(const [h,v] of dp)epsDP=epsDP.add(prod.mul(v).mul(modLoss(h)));
  }
  let rem=o;for(let i=1;i<=md+1;i++)rem=rem.mul(msum).div(q(i));
  epsDP=up(epsDP.add(rem.mul(ex(msum))));
  const eps=min(epsDP,up(abs.mul(delta).add(ps)));
  const far=U.mul(em(al)).mul(j).add(U0.mul(em(al.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(E.mul(em(al.mul(q(Math.round(4*(B-L)),4))).mul(fl)));
  W=min(W,up(ex(J.mul(x)).sub(o).mul(far).add(g)));drift=min(drift,two.mul(eps));
  let ref=o.sub(abs);
  if(low>=400){const s=q(low*374,10000),m=q(14); function FD(z){let v=o,sum=o;for(let j=1;j<=14;j++){v=v.mul(z).div(q(j));sum=sum.add(v);}return sum.mul(em(z));}
   const J0=ex(q(50000,low*low)).mul(FD(s).add(FD(s.mul(two)).div(two.mul(o.sub(em(s.sub(q(7))))))));
   const aarg=J0.add(pu.div(s)),cos=o.sub(aarg.sq().div(two));
   if(q(0).lt(cos))ref=max(ref,q(5,3).mul(dn(o.div(ex(J0)))).mul(cos).div(pu.mul(R)));
  }
  c=max(c,ref.sub(eps));const angle=pu.div(q(32));if(core)slice=max(slice,ref.mul(o.sub(angle.sq().div(two))).sub(abs.mul(angle)).sub(eps));else slice=q(87,100).mul(ref).sub(eps);
 }
 const V=W.div(q(3)),w=W.add(D0).add(drift);
 ck(q(0).lt(c)&&V.sq().add(w.sq()).lt(c.sq()),"ellipse "+B);
 
 if(!skip){
  const minD=Math.ceil(B*K)-1,maxD=Math.floor(N*15)-1,Nq=q(Math.round(4*N),4);
  let M=Math.floor(Math.sqrt(minD)/2);
  ck(4*M*M<=minD&&minD<4*(M+1)*(M+1),"minimum M");
  for(; (4*M*M)<=maxD; M++){
    const d=Math.min(maxD, 4*(M+1)*(M+1)-1);
    const s1=q(d*d,M*M*K),s2=Nq.mul(q(d*d,M*M*(d+1)));
    ck(min(s1,s2).lt(a.sq()),"finite M envelope");
  }
 }
 text({B,a:a.val(),W:W.val(),drift:drift.val(),c:c.val()});
}
text("All central intervals passed.");
```
### Upper center
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(28)).mul(ex(q(5,16)).sq()).lt(q(46,100).sq()),"vertical log bound");
ck(q(48,100).lt(q(54,100).mul(o.sub(q(46,100).sq().div(two)))),"vertical real fraction");
ck(q(87,100).lt(o.sub(pu.div(q(16)).sq().div(two)).sub(q(46,100).div(o.sub(q(46,100).sq().div(two))).mul(pu.div(q(16))))),"splice angle fraction");
const rows=[[14,16,40,550,5,16,1],[14,16,50,550,5,16,4],[14,16,60,600,5,16,5],[14,16,70,600,5,16,6],[14,16,87,450,4,22,0],[14,22,100,350,5,30,0],[14,30,116,350,5,41,0],[14,41,134,350,7,56,0],[14,56,154,350,7,76,0],[14,76,178,250,7,103,0],[14,103,187,350,7,114,0]];
const covered={14:16};
for(const [K,B,a2,at,L,N,core] of rows){
 const a=q(a2,10),alpha=q(at,1000),sk=q(374,100);
 ck(!q(K).lt(sk.sq())&&(core||B<=covered[K])&&B>L&&(core||N>covered[K]),"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):mode===2?q(2,l+1):o;
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const mn=(x,y)=>x.lt(y)?x:y; const hh=lat(m0,3); const p=up(R.mul(mn(o.add(lat(m0,1)),o.add(q(3,2).mul(hh))))),x=up(R.mul(mn(two.add(lat(m0,2)),q(3,2).add(q(4,3).mul(hh)))));
 const ea=ex(alpha);
 ck(ea.lt(q(3)),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two)).add(q(74,1000).mul(ex(alpha.mul(q(3)))).add(q(38,10000).mul(ex(alpha.mul(q(4)))).div(o.sub(ea.div(q(4)))))).div(two));
 const eps=up(ex(q(780,1000).mul(p)).sub(o).mul(q(394,10000)).div(fact(L)).add(em(alpha.mul(q(Math.round(4*(B-L)),4))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(394,10000).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(q(1725,1000).mul(em(alpha.mul(q(Math.round(4*(B-1)),4)))).mul(f)).add(q(725,1000).sub(delta).mul(em(alpha.mul(q(Math.round(4*(B-L)),4)))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(394,10000).mul(R).mul(o.add(g.div(q(3)))).div(q(Math.round(4*B),4).mul(fact(Math.floor(B-1)))));
 let ref=two.sub(ex(q(780,1000).mul(p))), angular=q(0);
 if(core!==1){
  const ell=q(core||7),s=sk.mul(ell);
  const fd=z=>{let t=o,u=o;for(let j=1;j<=14;j++){t=t.mul(z).div(q(j));u=u.add(t);}return em(z).mul(u);};
  const J=ex(q(5).div(ell.sq())).mul(fd(s).add(fd(s.mul(two)).div(two.mul(o.sub(em(s.sub(q(7))))))));
  const z=J.add(pu.div(s)),c0=o.sub(z.sq().div(two)),ph=pu.div(q(16));
  ck(q(0).lt(c0),"gamma angle");
  const a0=q(5,3).mul(dn(o.div(ex(J)))).div(pu.mul(R));
  ref=a0.mul(c0);angular=a0.mul(c0.mul(o.sub(ph.sq().div(two))).sub(z.mul(ph)));
 }
 const c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 if(core===0||core===6)ck(V.lt(angular.sub(eps)),"splice phase");
 const rad=a.sub(q(313,100).div(sk));
 if(!core)ck(q(0).lt(rad)&&q(Math.round(4*N)*25,36).lt(rad.sq()),"splice location");
 if(!core)covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
ck(covered[14]>112,"eventual overlap");
text(covered);


```
