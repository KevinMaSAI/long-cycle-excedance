# Distance-weighted anchor norms and the next complete bands

2026-11-27 02:30 UTC. For the genuine E_(n,k), simple real roots and strict consecutive interlacing after removal of t now hold for all n≥k through 2349k at k≥256, 3882k at k≥512, and 4784k at k≥704. Final adjacent pairs included. The proof merges the preceding complete bands and the already established k≥1024 all-row theorem. The remaining middle range for some k and the smaller-k cases are not solved. No individual polynomial row was tested for this result.

## Harmonic anchor geometry
Use the notation of long_cycles_large_ratio_bridge.md, write r_l=|q_l|^(k−1) for l≥0, q_(−l−1) its conjugate. Then r_0=1 and the r_l are decreasing. The norm of the linear factor indexed by j in anchor i uses the precise distance
  ||δ(q_j z)/(1−q_j/q_i)||_(R_t) ≤ J [ρ/(πk)] |q_j|^(k−1)/|i−j|.
This follows from |1−q_j/q_i|=2π|i−j||q_j|/ρ and the δ support in degrees at least k. At radius 1 take J=1. The same primary distance controls the absolute sum of reference logarithms. For i=0 the weighted sum is exactly 1+sum_(l≥1) r_l(1/l+1/(l+1)), using partner −1 and farther indices l,−l−1. For any anchor i the weighted sum is at most 2+2 sum_(l≥1) r_l/(l+1): each kernel value 1/d occurs twice, and the decreasing rearrangement of the remaining r-values is bounded by the full list 1,1,r_1,r_1,r_2,r_2,... . Pairing sorted lists maximizes the scalar product by exchange; apply first for a finite radius kernel and then use monotone convergence. Hence in the preceding bridge bounds replace the norm exponents with
  p = R[1+sum_(l≥1)r_l(1/l+1/(l+1))],
  x = R[2+sum_(l≥1)2r_l/(l+1)].
This retains the inverse-distance decay instead of estimating all far poles by the same constant.

## The refined weighted far bound
Let Δ=6/L! here denote the relative count tolerance, not the earlier coefficient differences. On shifts b≤n−Lk, both row counts divided by their own diagonals are at most 1+Δ. On the other shifts they are at most 2. Therefore dominate by 1+Δ on the full prefix plus an extra 1 on b>n−Lk. Estimate the baseline by the two log-affine endpoints b=k,n+1−k as before, and the extra by b=n−Lk,n+1−k. The latter may use a continuous left endpoint even though the extra starts at the strictly following integer. At the first extra endpoint the factor is |q_i|^(Lk) exp(−α(n/k−L)). For the second it is |q_i|^(k−1) exp(−α(n+1−k)/k). In both center and value bounds this yields
  W=(exp(J x)−1)[(1+Δ) exp(−α)j+(2+Δ)exp(−α(B−1)) f+exp(−α(B−L)) f_L]+g,
where f_L is the weighted far half-lattice at exponent Lk. Again V=W/3 bounds the value error because all levels carry weight at least three. The splice, diagonal mismatch, primary comparison and derivative-free sign test are unchanged.

The exact replay below uses L=18 and 64 lattice terms. For weighted terms (weight 2l+1), beyond 64 the decreasing integral remains an upper bound. For modes with map(l)=1/l+1/(l+1) or 2/(l+1), bound map(l)/(2l+1) by map(65)/131 at each integer l≥65 and then use the same integral. The monotonic-weight derivative condition reduces to b[m·129²−8320]>2 at 64 and improves thereafter. The decay uses log(1+y)≥2y/(2+y); exp clamping at 45 in the replay only enlarges an upper bound for negative powers. Approximate optimization proposed the interval endpoints, but every proof inequality and splice is checked exactly below. Thirty-one interval chains passed independently of the earlier 27 certificates. No full mother-conjecture claim.

## BigInt rational replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(508)).mul(ex(q(5,16)).sq()).lt(q(11,100).sq()),"vertical log bound");
ck(q(22,25).lt(q(89,100).mul(o.sub(q(11,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(11,100).div(o.sub(q(11,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[256,629,105,30,18,980],[256,980,122,20,18,1331],[256,1331,135,15,18,1622],[256,1622,144,15,18,1853],[256,1853,150,12,18,2014],[256,2014,155,12,18,2145],[256,2145,158,12,18,2236],[256,2236,160,12,18,2287],[256,2287,161,10,18,2318],[256,2318,162,10,18,2349],[512,931,131,20,18,1532],[512,1532,155,15,18,2153],[512,2153,173,10,18,2684],[512,2684,186,8,18,3095],[512,3095,194,8,18,3376],[512,3376,199,8,18,3547],[512,3547,203,8,18,3698],[512,3698,205,8,18,3769],[512,3769,206,8,18,3800],[512,3800,207,8,18,3841],[512,3841,208,8,18,3882],[704,1104,145,15,18,1885],[704,1885,173,12,18,2686],[704,2686,194,8,18,3377],[704,3377,208,8,18,3878],[704,3878,217,6,18,4229],[704,4229,223,6,18,4460],[704,4460,227,6,18,4621],[704,4621,229,6,18,4702],[704,4702,230,6,18,4743],[704,4743,231,6,18,4784]];
const covered={256:629,512:931,704:1104};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({256:16,512:22,704:26}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(22,15).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(29,10).div(sk));
 ck(q(0).lt(rad)&&q(25*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);
```
