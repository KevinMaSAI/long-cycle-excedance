# Exact replay for the smaller-k central and edge bounds

Run the JavaScript below in an environment that provides text(value), or substitute console.log. All bounds are compared as BigInt rationals. The displayed decimal values are for convenience.

```javascript
function gcd(a,b){while(b!==0n){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g} add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)} sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)} mul(y){return new Q(this.a*y.a,this.b*y.b)} div(y){return new Q(this.a*y.b,this.b*y.a)} pow(n){return new Q(this.a**BigInt(n),this.b**BigInt(n))} lt(y){return this.a*y.b<y.a*this.b} val(){return Number(this.a)/Number(this.b)}}
const q=(a,b)=>new Q(a,b),one=q(1),two=q(2),pi=q(157,50);
const upper=(x)=>q((100000000n*x.a+x.b-1n)/x.b,100000000n);
function expS(x){let t=one,z=one;for(let i=1;i<=16;i++){t=t.mul(x).div(q(i));z=z.add(t)}return [z,z.add(t.mul(x).div(q(17)).div(one.sub(x.div(q(18)))))]}
function assert(condition,label){if(!condition)throw Error(label)}
for(const [K,a,Ri,fi,hi,gi,ji,Li] of [[80,4,1430,3035,1003,277,93,1398],[300,5,920,6824,2208,1325,441,2173]]){
 const R=q(Ri,10000),f=q(fi,10000),h=q(hi,10000),g=q(gi,10000),j=q(ji,10000),L=q(Li,100);
 const b=q(4).mul(pi.pow(2)).div(q(a*a*K+10));
 function lat(m,weighted){let t=q(0);for(let l=1;l<=6;l++)t=t.add(upper(q(weighted?2*l+1:1).div(one.add(b.mul(q(l*(l+1)))).pow(m))));return t.add(upper(one.div(b.mul(q((m-1)*(weighted?1:13))).mul(one.add(b.mul(q(42))).pow(m-1)))))}
 assert(one.add(q(a*a*K).div(pi.pow(2))).div(q(K*K)).lt(R.pow(2)),"R");
 assert(L.mul(R).lt(two),"L");
 assert(lat(Math.floor((K-1)/2),true).lt(f)&&lat(Math.floor((K-1)/2),false).lt(h),"low lattice");
 assert(lat(K-1,true).lt(g)&&lat(K-1,false).lt(j),"high lattice");
 const P=two.mul(upper(expS(R.mul(one.add(q(3,2).mul(h))))[1]).sub(one));
 const Z=two.mul(upper(expS(R.mul(q(3,2).add(q(4,3).mul(h))))[1]).sub(one));
 const V=P.add(Z.mul(h)).add(j), W=P.add(Z.mul(f)).add(g);
 const product=one.add(V).div(two).add(two.mul(h)).add(h.pow(2));
 const early=W.add(one.add(j).add(q(4).mul(product)).div(L)).add(q(1,K));
 const lateLag=q(12,5).mul(one.add(h)).mul(one.add(V));
 const late=W.add(one.add(j).add(lateLag).div(q(3,2).mul(L)));
 assert(h.lt(V),"lag available");assert(h.pow(2).add(f.pow(2)).lt(one),"no lag");assert(V.pow(2).add(early.pow(2)).lt(one),"early");assert(V.pow(2).add(late.pow(2)).lt(one),"late");
 text({K,a,V:V.val(),W:W.val(),early:early.val(),late:late.val()});
}
const C=q(64,25), eta=q(4,25), lambda=q(41,100), alpha=q(1,10), d=q(39,100),gamma=q(17,1000),D=q(158),N=q(159),rootD=q(25,2),m=q(12,25),mp=q(14,25),sqrtK=q(89,10);
assert(rootD.pow(2).lt(D)&&sqrtK.pow(2).lt(q(80)),"sqrt bounds");
assert(C.mul(eta).lt(lambda),"outward ratios");
assert(one.div(eta).lt(expS(one.div(two.mul(m).mul(mp)))[0]),"pure decay");
assert(C.pow(2).div(alpha.mul(one.sub(alpha))).lt(expS(one.div(m.pow(2)))[0]),"curvature");
assert(two.mul(C).mul(eta).div(one.sub(eta.pow(2))).lt(one),"edge witness");
assert(C.mul(m.div(rootD).add(one.div(sqrtK))).lt(d)&&C.div(N).lt(gamma),"drift");
const denom=one.sub(lambda);
const lagTail=d.div(denom).add(gamma.div(denom.pow(2)));
const edgeCost=two.mul(alpha).add(d).add(alpha.mul(lagTail));
assert(edgeCost.lt(one.sub(alpha)), "edge sign");
assert(m.div(rootD).add(N.div(D).mul(q(10,3)).mul(m.pow(3)).div(rootD)).lt(q(1,8)),"phase stitch");
text("All exact integer/rational comparisons passed.")
const c=q(27,10), e=q(83,500), l=q(449,1000), a0=q(162,1000), dp=q(364,1000), gp=q(11,1000), dg=q(404,1000), n=q(246), dd=q(245), xd=q(78,5), xk=q(979,100);
assert(xd.pow(2).lt(dd)&&xk.pow(2).lt(q(96)),"ratio-three square roots");
assert(q(69,10).pow(2).lt(q(48)),"plateau root");
assert(q(5,2).div(one.sub(one.div(q(69,5)))).lt(c),"plateau constant");
const rightLoss=q(2).sub(q(4,18)).add(q(1,36)).sub(q(4,1080));
assert(one.div(e).lt(expS(rightLoss)[0]),"radius-tail sharpened decay");
assert(q(3).div(l).lt(expS(dd.div(q(50)))[0])&&c.mul(e).lt(l),"large outward ratios");
assert(c.pow(2).div(a0.mul(one.sub(a0))).lt(expS(q(4))[0]),"large curvature");
assert(two.mul(c).mul(e).div(one.sub(e.pow(2))).lt(one),"large witness");
const driftBasis=one.div(two.mul(xd)).add(one.div(xk));
assert(c.mul(driftBasis).lt(dp)&&q(3).mul(driftBasis).lt(dg)&&c.div(n).lt(gp),"large drift");
const delta=one.sub(l.pow(2));
const left=a0.mul(l).mul(dg).div(delta);
const right=a0.mul(dp.div(delta).add(gp.mul(one.add(l.pow(2))).div(delta.pow(2))));
assert(two.mul(a0).add(dp).add(left).add(right).lt(one.sub(a0)),"large signed margin");
const es=q(55,1000), ls=q(165,1000), ds=q(38,100), gs=q(13,1000);
assert(one.div(es).lt(expS(dd.div(q(84)))[0])&&q(3).mul(es).lt(ls.add(q(1,100000))),"small edge decay");
assert(two.mul(q(3)).mul(es).div(one.sub(es.pow(2))).lt(one),"small witness");
assert(q(3).mul(q(6).div(n).add(one.div(xk))).lt(ds)&&q(3).div(n).lt(gs),"small drift");
const denomS=one.sub(ls);
const smLag=ds.div(denomS).add(gs.div(denomS.pow(2)));
assert(two.mul(ls).add(ds).add(ls.mul(smLag)).lt(denomS),"small signed margin");
assert(q(4).div(one.sub(two.div(xd))).lt(q(23,5))&&q(23,5).lt(xk.div(two)),"ratio-three splice width");
assert( q(1,2).div(xd).add(n.div(dd).mul(q(10,3)).mul(q(1,8)).div(xd)).lt(q(1,8)),"ratio-three phase stitch");
assert(q(22,7).mul(q(80)).lt(q(4*79)),"Fourier peak for all k>=80");
text("Extended ratio-three comparisons passed.");
```
