# Single critical cycle bridge from n=44k below k=256

2026-11-27 02:45 UTC research block. The original E_(n,k) has simple real roots and its quotient by t strictly interlaces the next quotient for each of:
- every k≥160 and n≥44k (no upper bound);
- 128≤k≤159 and 44k≤n≤4589k.
As always the last adjacent pair is included. This does not claim lower k coverage for all n≥k. Uses analytic interval bounds, with no original polynomial enumeration.

## Fixed-n neighboring amplitudes
It suffices to treat 128≤k≤255. Let n≥44k and integer r0∈[.45 sqrt(n),.62 sqrt(n)]. Then r0≥34 and β0=kr0/n≤.62 sqrt(255/44)<1.5. For the three neighboring r, use only bin-permutation cycles of length one as critical. This is the U=2 case of long_cycles_fixed_n_edge_stitch.md: retain m≤7 length-one cycles, multiply their exact multinomial success Q_n(r;m copies of 1) by c_2/m!, and sum to define F(r), where c_2=exp(−1).
For integer r, |P_r(n)−F(r)|<.022 c_2. The hard-count substitution and m≥8 truncation cost <.0002 in units c_2, just as in the earlier U=2 proof: r−m≥26 for retained terms, use the factorial continuation 6/9!, and bound the omitted mass by 3 sum_(m≥8)1/m!. There is no forbidden-short error. Long-cycle failure has μ/k=b/β_r, where β_r≤(35/34)·1.5=105/68, so μ/k≥136/105>1.29 for b≥2. Chernoff and log(1+x)≤x−x²/2+x³/3 give failure probability ≤exp[−128(.29²/2−.29³/3)] at b=2; its exponent decreases at rate at least k(68/105−1/2)>18 for later b. Mark a bad long cycle with weight ≤1/2 in the counting product; d_(r−b,1)≤1 and 1/c_2<3. The cost relative to c_2 is thus at most 1.5 exp[−128(.29²/2−.29³/3)]/(1−exp(−18)). This and the .0002 cost together are <.022.
F≥c_2 and decreases. The signed multinomial derivative bound gives |F'|/c_2≤exp(1)(n/r²)·.45/sqrt(k)<.57. For the binomial point mass at its mode, Np(1−p)≥.97(k−1) with N=n−1, p=(k−1)/N; the same Fourier cutoff at |θ|=1 gives a Gaussian <.43/sqrt(k) and tail <.02/sqrt(k). Here r≥(33/34).45sqrt(n) and sqrt(k)>11.3. The symmetric endpoints and the monotone profile then give the amplitude ratios
 A_n(r0−1)/A_n(r0)<1.63, A_n(r0+1)/A_n(r0)<1.08,
via 1+(.57+.044)/.978 and (35/34)·1.022/.978 respectively.

## Edge n≥44k
Set D=n−1, H=n/k, M=floor(.6 sqrt(D)), S=D/M. The edge argument in long_cycles_unrestricted_edge.md carries over with the new cutoff interval and the following constants. Uniform ratio bounds of A use C=27/8 and the exact min(r,H) occupancy bound. With m≥.45sqrt(n), pure eta=.26 since M≥45, actual λ=.43, and curvature α=.132 from 1.63·1.08 exp(−25/9). Left outgoing bases below the profile lose at least (5631/5632)/(2·.45²) in the pure log, and right outgoing bases above it lose at least (D/sqrt(n))(5/3−50/31); these absorb factors C and 1.5C, respectively. At the witness the first opposing offsets cost (1.63+1.08)·.26, and remaining odd offsets cost ≤2C sum_(odd a≥3) .26^a(1+a/34); the total is <1.
For 10≤m<.45sqrt(n) the first outward loss uses m+1<.464sqrt(n), m+2<.477sqrt(n), so eta=.105. The global ratio bounds give λ=.39 (right ratio at most 12C/11). The two curvature products are under .136(1−.136), checking r≥22 with C²·23/22 and exponent D/r²≥(5631/5632)/.464²; for r≤21 the stronger exponent D/21² absorbs factor 1.5C². Witnesses cost ≤2C sum_(odd a≥1) .105^a(1+a/10)<1. For 1≤m≤9 use eta=.001 and λ=α=.006, with low witness cost ≤2C sum_(odd a≥1) .001^a(1+a)<1.
The global occupancy drift uses the beta lattice bound d_r≤(27/4)(r/n+.45/sqrt(k)) for r≥H/2, and otherwise the small drift <.001 from the earlier Markov formula. Thus for r≤M+a it is less than .33+.0012a; use .33 on the entire left. The signed-mean inequality of long_cycles_unrestricted_edge.md passes in each of the three regimes. Edge uniqueness and next-row signs follow. The m=1 witness again rules out zeros at s>D. The splice needs only S≤(5/3)sqrt(n)+2.9 and phase deviation <π/40, already verified for the weaker D≥3583. No high-H or density assumption was applied.

## Center and completed joins
Use long_cycles_dense_edge_k96.md's central bounds on both s ranges: for s≤4sqrt(k), the original small-s signs; beyond it, the positive reference (4/3)/(a/u_K+2) with .18 vertical log deviation. The harmonic distance, tilt, and split at L=18 are unchanged. The exact replay certifies central chains starting at 44k and ending at 991k for the K=128 baseline and 990k for K=160. Both overlap the previous n≥900k proof; this yields the assertions above. The K=160 auxiliary central chain is redundant after merging K=128 but gives independent margins. The gap k≤n<44k for these k has not been resolved. The preexisting separate large-n theorem for k≥64 also remains in force, so the uncovered n>4589k at k=128..159 is only below that eventual range.

## BigInt replay
```javascript
function gcd(a,b){while(b){[a,b]=[b,a%b]}return a<0n?-a:a}
class Q{
 constructor(a,b=1){a=BigInt(a);b=BigInt(b);const g=gcd(a,b);this.a=a/g;this.b=b/g}
 add(y){return new Q(this.a*y.b+y.a*this.b,this.b*y.b)}
 sub(y){return new Q(this.a*y.b-y.a*this.b,this.b*y.b)}
 mul(y){return new Q(this.a*y.a,this.b*y.b)}
 div(y){return new Q(this.a*y.b,this.b*y.a)}
 sq(){return this.mul(this)}
 lt(y){return this.a*y.b<y.a*this.b}
 val(){return Number(this.a)/Number(this.b)}
}
const q=(a,b)=>new Q(a,b),o=q(1),two=q(2),G=10n**18n;
const up=x=>q((G*x.a+x.b-1n)/x.b,G),dn=x=>q(G*x.a/x.b,G);
function eb(x){
 let y=x,p=0;
 while(o.lt(y)){y=y.div(two);p++}
 let l=o,u=o,L=o,U=o;
 for(let j=1;j<=24;j++){
  l=dn(l.mul(y).div(q(j)));u=up(u.mul(y).div(q(j)));
  L=L.add(l);U=U.add(u);
 }
 U=U.add(up(u.mul(y).div(q(25)).div(o.sub(y.div(q(26))))));
 while(p--){L=dn(L.sq());U=up(U.sq())}
 return [L,U];
}
const ex=x=>eb(x)[1],em=x=>up(o.div(eb(q(45).lt(x)?q(45):x)[0]));
const fact=n=>{let f=1n;for(let i=2n;i<=BigInt(n);i++)f*=i;return q(f)};
function ck(ok,label){if(!ok)throw Error(label)}
let H9=q(0);for(let j=1;j<=9;j++)H9=H9.add(q(1,j));
ck(q(50,3).lt(eb(H9)[0]),"harmonic lower bound");
const pu=q(22,7),pl=q(157,50);
ck(pu.div(q(188)).mul(ex(q(5,16)).sq()).lt(q(18,100).sq()),"vertical log bound");
ck(q(4,5).lt(q(82,100).mul(o.sub(q(18,100).sq().div(two)))),"vertical real fraction");
ck(q(98,100).lt(o.sub(pu.div(q(40)).sq().div(two)).sub(q(18,100).div(o.sub(q(18,100).sq().div(two))).mul(pu.div(q(40))))),"splice angle fraction");
const rows=[[128,44,32,200,18,85],[128,85,46,150,18,186],[128,186,62,75,18,337],[128,337,77,50,18,518],[128,518,89,35,18,699],[128,699,99,30,18,870],[128,870,106,25,18,991],[160,44,33,200,18,95],[160,95,49,125,18,206],[160,206,66,75,18,377],[160,377,82,45,18,598],[160,598,97,30,18,829],[160,829,106,25,18,990]];
const covered={128:44,160:44};
for(const [K,B,a2,at,L,N] of rows){
 const a=q(a2,2),alpha=q(at,1000),sk=q({96:9,128:11,160:12,192:13}[K]);
 ck(!q(K).lt(sk.sq())&&B<=covered[K]&&B>L&&N>covered[K],"overlap");
 const rr=o.add(a.sq().mul(q(K)).div(pl.sq())).div(q(K*K));
 const R=q(Math.ceil(Math.sqrt(rr.val())*1e6)+1,1000000);
 ck(rr.lt(R.sq()),"R");
 const b=q(4).mul(pl.sq()).div(a.sq().mul(q(K)).add(q(10))),m0=Math.floor((K-1)/2);
 ck(two.lt(b.mul(q(m0*129**2-8320))),"lattice integrand decreasing");
 const decay=(m,u)=>em(q(2*m).mul(u).div(two.add(u)));
 function lat(m,mode){
  const map=l=>mode===0?q(2*l+1):mode===1?q(1,l).add(q(1,l+1)):q(2,l+1);
  let z=q(0);
  for(let l=1;l<=64;l++)z=z.add(map(l).mul(decay(m,b.mul(q(l*(l+1))))));
  return up(z.add(decay(m-1,b.mul(q(4160))).mul(map(65)).div(b.mul(q((m-1)*131)))));
 }
 const f=lat(m0,0),j=lat((B-1)*K/2,0),g=lat(B*K/2,0),fL=lat(L*K/2,0);
 const p=up(R.mul(o.add(lat(m0,1)))),x=up(R.mul(two.add(lat(m0,2))));
 const ea=ex(alpha);
 ck(ea.lt(two),"tail contraction");
 const tilt=up(ea.add(ex(alpha.mul(two)).div(two.sub(ea))).div(two));
 const eps=up(ex(p).sub(o).mul(q(6)).div(fact(L)).add(em(alpha.mul(q(B-L))).mul(ex(tilt.mul(p)).sub(o))));
 const delta=q(6).div(fact(L)), amp=ex(tilt.mul(x)).sub(o);
 const W=up(amp.mul(o.add(delta).mul(em(alpha)).mul(j).add(two.add(delta).mul(em(alpha.mul(q(B-1)))).mul(f)).add(em(alpha.mul(q(B-L))).mul(fL))).add(g));
 const V=W.div(q(3));
 const mismatch=up(q(6).mul(R).mul(o.add(g.div(q(3)))).div(q(B).mul(fact(B-1))));
 const ref=q(4,3).div(a.div(sk).add(two)),c=ref.sub(eps);
 ck(q(0).lt(c)&&V.sq().add(W.add(two.mul(eps)).add(mismatch).sq()).lt(c.sq()),"ellipse "+K+" "+B);
 ck(V.lt(q(98,100).mul(ref).sub(eps)),"splice phase");
 const rad=a.sub(q(29,10).div(sk));
 ck(q(0).lt(rad)&&q(25*N,9).lt(rad.sq()),"splice location");
 covered[K]=N;
 text({K,B,N,a:a.val(),alpha:alpha.val(),L,V:V.val(),W:W.val(),eps:eps.val(),c:c.val()});
}
text(covered);

const el=y=>eb(y)[0],eu=y=>eb(y)[1];
const v=q(5631,5632),C=q(27,8),sk0=q(113,10);
ck(covered[128]>900&&covered[160]>900,"high overlap");
ck(q(62,100).sq().mul(q(255,44)).lt(q(3,2).sq()),"single critical length");
ck(q(129,100).lt(q(136,105))&&q(18).lt(q(128).mul(q(68,105).sub(q(1,2)))),"long cycle mean and slope");
const z=q(29,100),ch=q(128).mul(z.sq().div(two).sub(z.sq().mul(z).div(q(3))));
ck(q(3,2).mul(em(ch)).div(o.sub(em(q(18)))).add(q(2,10000)).lt(q(22,1000)),"profile error");
const rfrac=q(33,34).mul(q(45,100)),E=q(22,1000),alphaL=q(163,100),alphaR=q(108,100);
ck(eu(o).mul(q(45,100)).div(rfrac.sq().mul(sk0)).lt(q(57,100)),"profile derivative");
ck(o.add(q(57,100).add(two.mul(E)).div(o.sub(E))).lt(alphaL),"profile left");
ck(q(35,34).mul(o.add(E)).div(o.sub(E)).lt(alphaR),"profile right");
ck(o.lt(q(4).mul(q(43,100).sq()).mul(pl).mul(q(11,24)).mul(q(97,100)).mul(q(127,128))),"Fourier Gaussian");
ck(q(800).lt(el(q(40))),"Fourier remainder");
const eH=q(26,100), lH=q(43,100),eM=q(105,1000),lM=q(39,100),eL=q(1,1000);
ck(o.div(eH).lt(el(q(25,9).mul(q(1,2).sub(q(1,135))))),"high pure");
ck(o.div(eM).lt(el(v.div(two.mul(q(464,1000)).mul(q(477,1000))))),"medium pure");
ck(q(1000).lt(el(q(5631,220))),"low pure");
ck(C.div(lH).lt(el(v.div(two.mul(q(45,100).sq())))),"high left");
ck(q(81,16).div(lH).lt(el(v.mul(q(75)).mul(q(5,3).sub(q(50,31))))),"high right");
ck(alphaL.mul(eH).lt(lH)&&C.mul(q(12,11)).mul(eM).lt(lM),"local tail ratios");
const aa=q(132,1000), bb=q(136,1000);
ck(alphaL.mul(alphaR).div(aa.mul(o.sub(aa))).lt(el(q(25,9))),"high curvature");
ck(C.sq().mul(q(23,22)).div(bb.mul(o.sub(bb))).lt(el(v.div(q(464,1000).sq()))),"middle curvature");
ck(C.sq().mul(q(3,2)).div(bb.mul(o.sub(bb))).lt(el(q(5631,441))),"middle small curvature");
function cost(e,m,far){const z=o.sub(e.sq());let i=e.div(z),a=e.mul(o.add(e.sq())).div(z.sq());if(far){i=i.sub(e);a=a.sub(e)}return two.mul(C).mul(i.add(a.div(q(m))))}
ck(alphaL.add(alphaR).mul(eH).add(cost(eH,34,true)).lt(o),"high witness");
ck(cost(eM,10,false).lt(o)&&cost(eL,1,false).lt(o),"other witnesses");
const d=q(33,100),b=q(12,10000);
ck(q(27,4).mul(q(6,10).div(q(75)).add(q(45,100).div(sk0))).lt(d)&&q(27,4).div(q(5632)).lt(b),"drift");
ck(q(7000).lt(el(q(2995,10000).mul(q(128)))),"heavy drift");
for (const [a,l] of [[aa,lH],[bb,lM],[q(6,1000),q(6,1000)]]){
const z=o.sub(l.sq());
ck(two.mul(a).add(d).add(a.mul(l).mul(d).div(z)).add(a.mul(d.div(z).add(b.mul(o.add(l.sq())).div(z.sq())))).lt(o.sub(a)),"signed mean");
}
```
