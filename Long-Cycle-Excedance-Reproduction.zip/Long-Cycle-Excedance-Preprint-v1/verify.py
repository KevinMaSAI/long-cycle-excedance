from pathlib import Path
from subprocess import run
import argparse, os, sys

ROOT = Path(__file__).resolve().parent
EARLIER = ROOT / "Supplement" / "earlier"
ANALYSIS = EARLIER / "analysis"
REPLAY = ROOT / "replay"

def invoke(*args, cwd=ROOT):
    print("+", *args, flush=True)
    run([str(a) for a in args], cwd=cwd, check=True)

def py(file, *args, cwd=ANALYSIS):
    invoke(sys.executable, "-B", file, *args, cwd=cwd)

def main():
    if not __debug__ or os.getenv("PYTHONOPTIMIZE") not in (None, "", "0"):
        raise SystemExit("Verification requires assertion-enabled Python.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("suite", choices=("quick", "bands", "fixed"))
    suite = parser.parse_args().suite
    if suite == "quick":
        for f in sorted(REPLAY.glob("*.js")):
            invoke("node", f)
    elif suite == "bands":
        for f in sorted((REPLAY / "bands").glob("*.js")):
            invoke("node", f)
        for name in ("check_complex_primary_large_k.py", "check_uniform_k_log.py",
                     "check_uniform_upper_central_contour.py",
                     "check_uniform_upper_central_residues.py",
                     "check_uniform_cut_seven_halves.py", "check_uniform_edge_k64.py",
                     "check_sharp_fixed_k_tail.py"):
            py(name)
    else:
        py("check_interlacing_gamma.py", 63, cwd=EARLIER)
        for k in (4, 5):
            py("check_interlacing_general.py", 127, k, cwd=EARLIER)
        for k, last in ((6,191),(7,255),(8,319),(9,399),(10,323),(11,440),(12,528),(13,675)):
            py("check_fixed_k_dyadic_fast.py", k, last)
    print("PASS:", suite, flush=True)

if __name__ == "__main__":
    main()
