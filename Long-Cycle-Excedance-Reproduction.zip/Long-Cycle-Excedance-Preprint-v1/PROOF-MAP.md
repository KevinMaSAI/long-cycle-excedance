# Proof dependency map

Pair indices always refer to the first member n; the second member is n+1. The sign arguments use the exact restricted polynomials.

| Parameter block | Starting point | Replay |
|---|---|---|
| k=3 | `Supplement/earlier/PROOF.md`, `INTERLACING.md`, `INTERLACING_REPLAY.md` | `check_interlacing_gamma.py 63` in the earlier directory |
| k=4,5 | `Supplement/earlier/K4_INTERLACING.md` and `K5_INTERLACING.md` | `check_interlacing_general.py 127 4` and `127 5` there |
| k=6–9 | `Supplement/earlier/analysis/K6_INTERLACING.md` through `K9_INTERLACING.md` | Individual bound checks and the generic exact dyadic prefix driver below |
| k=10–13 | `Supplement/earlier/analysis/SHARP_FIXED_K_TAIL.md` and `FAST_DYADIC_REPLAY.md` | `check_sharp_fixed_k_tail.py` and exact prefixes below |
| k=14,15 | Main text §5, `Supplement/bands/long_cycles_k14_k15_all_n.md`, `long_cycles_k14_k15_counts_and_edges.md` | `replay/*.js` and uniform 112k-tail replays in `replay/bands/` |
| 16≤k<1024 | Main text §6.2 and Table 2; band notes `long_cycles_all_n_k{16,20,24,32,48,64,80,96,128,256}.md` | Corresponding names in `replay/bands/` and the subordinate derivations called out by each note |
| k≥1024 | `Supplement/earlier/analysis/COMPLEX_PRIMARY_LARGE_K.md`, `UNIFORM_K_LOG.md`, and references within them | `check_complex_primary_large_k.py`, `check_uniform_k_log.py` and supporting earlier interval checks |

For a single fixed prefix, run `python -B Supplement/earlier/analysis/check_fixed_k_dyadic_fast.py K LAST` with the following K and LAST. These values certify (K,LAST) inclusively as pairs; the last pair ends at LAST+1.

| K | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| LAST | 191 | 255 | 319 | 399 | 323 | 440 | 528 | 675 |

For the eight quick checks, `counts` bounds normalized coefficient masses, `onset` checks four adjacent pairs by integer remainders, and `sparse`, `middle`, and `upper` each have an exterior (edge) and interior (center) check. The `replay/bands/` names identify the proof notes whose JavaScript blocks they reproduce, with numerical suffixes in source order. Older notes in the supplement include intermediate bounds; prefer the final band notes and follow their dependency references.

A zero-exit run does not validate transcription from the analytic argument by itself. In particular, verify the direction of the oriented successor inequality and check both endpoints of each splice when independently auditing the work.
