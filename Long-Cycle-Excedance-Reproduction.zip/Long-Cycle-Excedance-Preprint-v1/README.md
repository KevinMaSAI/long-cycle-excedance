# Real zeros and consecutive interlacing of excedance polynomials with a minimum cycle length

Verification draft, 27 November 2026. The manuscript and supplement present a computer-assisted candidate proof covering all integers n ≥ k ≥ 3. No independent mathematical review or formal verification is claimed. The project is not a study of descents.

## Read
- `manuscript.pdf`: English AMS-style preprint.
- `manuscript.tex`: source (AMS-LaTeX and standard TeX Live packages, no external assets or BibTeX). Run `pdflatex -halt-on-error manuscript.tex` twice.
- `PROOF-MAP.md`: read in parallel with Sections 5 and 6 of the paper. The notes and certificates are part of the proof.
- `SUBMISSION.md`: draft metadata, not part of the proof. Confirm the credited name(s), rights and licence before any public deposit.

## Verify
Requires Node.js 24 or a compatible recent release with BigInt, and Python 3.12 or a compatible recent release. No third-party packages are needed for the entry points below. Do not run Python with `-O` or set `PYTHONOPTIMIZE`; that disables certificate assertions. From this directory:

```text
python -B verify.py quick
python -B verify.py bands
python -B verify.py fixed
```

- **quick** runs the eight certificate programs for the closing bands k=14,15.
- **bands** runs the stored JavaScript scripts for analytic bounds, as well as selected earlier Python analytic certificates. A successful execution is not a substitute for checking the proof of each bound in the corresponding note.
- **fixed** replays exact finite prefixes for k=3–13. The largest prefixes can take tens of minutes or longer depending on hardware. See the proof map for individual commands. Earlier k=12 and k=13 output is preserved under `Supplement/earlier/analysis/`.
- The verifier stops on a nonzero exit. Numeric prints in the JavaScript programs may be rounded for display; the decisive inequality comparisons are BigInt-based. The archive does not claim a formal proof kernel or any aggregate model-usage figure.

The paper was developed with substantive assistance from OpenAI ChatGPT. This draft is for checking and preparation, not an assertion of external endorsement or publication priority.
